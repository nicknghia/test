function focusFirstInput() {
  // assuming one form per page
  for(i=0; i < document.forms[0].length; i++) {

    // not a hidden element
    if (document.forms[0][i].type != "hidden") {

      // and it's not disabled and not readonly
      if (document.forms[0][i].disabled != true && document.forms[0][i].readOnly != true) {

        // and not any of the (save,save & return, cancel) buttons
        if(document.forms[0][i].className != "saveBtn" && document.forms[0][i].className != "cancelBtn" && document.forms[0][i].className != "saveRtnBtn") {

          // set the focus to it
          document.forms[0][i].focus();
          break;
        }
      }
    }
  }
  // don't scroll the page...its annoying
  window.scroll(0,0);
}

// assuming global var named capPanel exists
function capLock(e){
  kc = e.keyCode?e.keyCode:e.which;
  sk = e.shiftKey?e.shiftKey:((kc == 16)?true:false);

  if(((kc >= 65 && kc <= 90) && !sk)||((kc >= 97 && kc <= 122) && sk))
    capPanel.show();
  else
    capPanel.hide();
}

function getCapLockPanel() {
  var panel = new YAHOO.widget.Panel("caplock",
              {
			    width : "130px",
			    fixedcenter : false,
			    visible : false,
			    constraintoviewport : true,
			    draggable : false,
			    close : false,
			    modal : false,
                effect:{effect:YAHOO.widget.ContainerEffect.FADE, duration: 0.3}
		      });
   panel.setBody("Caps lock is on");
   return panel;
}

function hideNoScript() {
  document.getElementById('noScript').style.display="none";
}

function showLowScreenRes() {
  // make sure width matches the value for the .content element in nx.css
  if(screen.width<1150) {
    document.getElementById("lowResMsg").innerHTML = "This site is best viewed at a higher resolution than the current "+screen.width+"x"+screen.height;
    document.getElementById("lowRes").style.display="block";
  }
}

function cookieTest() {
  YAHOO.util.Cookie.set("test", "0");

  var value = YAHOO.util.Cookie.get("test");

  if(value == 0) {
    YAHOO.util.Cookie.remove("test");
    return true;
  } else {
    return false;
  }
}

function showCookieWarn() {
  var cookieEnabled = cookieTest();
  if(!cookieEnabled)
    document.getElementById("noCookie").style.display="block";
}

function initializeArray(arrayToInitialize,value) {
    for(i=0; i<arrayToInitialize.length; i++) {
      arrayToInitialize[i] = value;
    }
}

// Converts all text fields (except email and URLs) from lower case to upper case
function upperOnSubmit()
{
    if( document.forms.length > 0 ) 
    {
        var field = document.forms[0];
        for(i = 0; i < field.length; i++) 
        {
            if( (field.elements[i].type == "text")  && (field.elements[i].name!= "txtEmail")&& (field.elements[i].name!="txtUrl"))
                document.forms[0].elements[i].value = document.forms[0].elements[i].value.toUpperCase();
        }
    }
}


function confirmSaveAll(domainObject)
{
	return confirm("Are you sure you want to save the entire "+domainObject+" and return to "+domainObject+" home? ");
}
function toUpperCase()
{
    if( document.forms.length > 0 ) 
    {
        var field = document.forms[0];
        for(i = 0; i < field.length; i++) 
        {
            if( (field.elements[i].type == "text") )
            {
             txt=document.forms[0].elements[i].value.toUpperCase();
             txt=txt.replace(/'/g,"");                 
             document.forms[0].elements[i].value =txt;
            }
        }
    }
}

function deleteConfirmation()
{
    if(!confirm('Are you sure you want to delete this record?'))
    {
        return false;
    }
    else
        return true;
}
function deleteConfirm(recordName)
{   
    if (!confirm('Are you sure you want to delete this ' + recordName + '?'))
    {
        return false;   
    }
    else
        return true;
}

function onEnterPress(process,var_action,var_module)
{
    if(event.keyCode==13)
    {
             return searchUrl(process,var_action,var_module);
    }
}
function searchUrl(process,var_action,var_module)
{
    if(document.forms[0].search.value != 0)
    {
        txt=document.forms[0].search.value.toUpperCase();
        txt=txt.replace(/'/g,""); 
        document.forms[0].search.value=txt
        document.forms[0].process.value=process;
        document.forms[0].action=var_action;
        document.forms[0].submit();
        return true;
    }
    else
    {
        alert("Please enter  "+var_module +" to search");
        document.forms[0].search.focus();
        return false;
    }    
    
}

function onEnterPress1(process,var_action,var_module)
{
    if(event.keyCode==13)
    {
             return searchUrl1(process,var_action,var_module);
    }
}
function searchUrl1(process,var_action,var_module)
{            
    if(document.forms[0].search.value != 0)
    {
       txt=document.forms[0].search.value.toUpperCase();
         txt=txt.replace(/'/g,""); 
        document.forms[0].search.value=txt
        document.forms[0].hdnProcess.value=process;
        document.forms[0].action=var_action;
        document.forms[0].submit();
        return true;
    }
    else
    {
        alert("Please enter  "+var_module +" to search");
        document.forms[0].search.focus();
        return false;
    }    
    
}


function getNumberCode()
{
    if(event.keyCode!=13)
    {    
     if((event.keyCode < 47 || event.keyCode > 57) )
        return false;    
    }
    return true;
}


// create the prototype on the String object
//Function trim removes all leading and trailing whiespaces 
String.prototype.trim = function() {

 // skip leading and trailing whitespace
 // and return everything in between
  var x=this;
  x=x.replace(/^\s*(.*)/, "$1");
  x=x.replace(/(.*?)\s*$/, "$1");
  return x;
}

function disableButtons(form){
	
	var input= form.getElementsByTagName('input');
	for (var b = 0; b < input.length; b++) {
		if(input[b].type == 'image' || input[b].type == 'button' || input[b].type == 'submit'){
			input[b].disabled = true;
			if(input[b].style.filter != null && input[b].style.filter != '')
				input[b].filters.alpha.opacity=40;
		}
	}
	
	var anchor= form.getElementsByTagName('A');
	for (var b = 0; b < anchor.length; b++) {
		anchor[b].disabled=true;
	}
	
	var img= form.getElementsByTagName('img');
	for (var b = 0; b < img.length; b++) {
		if(img[b].style.filter != null && img[b].style.filter != ''){
				img[b].filters.alpha.opacity=50;
		}
	}
	document.body.style.cursor='wait';
}

  
     $(function () {
        $("#timeoutDialog").dialog({
            autoOpen: false,
            resizable: true,
            height: 150,
            width: 300,
            
            
            buttons: [{
                text: "OK",
                click: function() {
                    logouttime = 1200;         // reset timeout to 1200 seconds
                    $(this).dialog("close");
                }
            }],
                          
            
            modal: true,
            
		    open: function(event, ui) {
		        setTimeout(function(){
		            $('#timeoutDialog').dialog('close');                
		        }, 120000);   // auto close after 120 seconds
            },
            overlay: {
                 opacity: 0.8,
                 background: "black"
            }
        });
    });     

  
	function statusMessage()
		{
			logouttime --;
			if (logouttime < 120 )    // less than 120 seconds
			{
				window.status='Inactive user will be logged out after ' + logouttime + ' seconds';
				$("#timeoutDialog").dialog("open");
				$("#timeoutDialog").text("Click OK to reset timeout. " + logouttime + " seconds remaining.");
			}
			if(logouttime == 0)
			{
                            //clearTimeout();
			    return autoLogout();
			}
			else
			{
				setTimeout("statusMessage()", 1000);    // every 1 second
			}
		}


	function autoLogout()
	{
		window.location.href="/ctuLogonAction.action?myAction=LOGOUT";
	}


