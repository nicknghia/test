/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.requesttracker.dao;

import com.ctu.tsa.fas.hibernate.HibernateUtil;
import com.ctu.tsa.fas.requesttracker.data.Cturequest;
import com.ctu.tsa.fas.requesttracker.data.RequestReferenceData;
import com.ctu.tsa.fas.requesttracker.data.RequestTrackerData;
import com.ctu.tsa.fas.requesttracker.model.Request;
import com.freightdesk.fdcommons.ConnectionUtil;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.Iterator;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import org.hibernate.HibernateException;
import org.hibernate.Query;
import org.hibernate.QueryException;
import org.hibernate.ScrollableResults;
import org.hibernate.Session;
import org.hibernate.Transaction;

/**
 *
 * @author STCI
 */
public class RequestTrackerDAO {

    private static RequestTrackerDAO instance = null;

    public RequestTrackerDAO() {
        // System.out.println("**********************RequestTrackerDAO CONSTRUCTOR");

    }

    public static RequestTrackerDAO getInstance() {
        // System.out.println("**********************RequestTrackerDAO getInstance");
        if (instance == null) {
            instance = new RequestTrackerDAO();
        }
        return instance;
    }

    public Map<String, String> getSubjectRegionList() throws QueryException {
        //System.out.println("RequestTrackerDAO begin hql requestracketdao");

        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select SUBJECTREGIONID, REGIONNAME from FD.ctusubjectregion ORDER BY REGIONNAME";

        Session session = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString(), resultSet.get(1).toString());
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            System.out.println("RequestTrackerDAO HibernateException:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            session.close();
        }
        return map;

    }

    public Map<String, String> getRequestTypeList() throws QueryException {
//        System.out.println("RequestTrackerDAO begin hql getRequestTypeList");
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select REQUESTTYPE, REQUESTNAME from FD.CTUREQUESTTYPE ORDER BY REQUESTNAME";
        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString(), resultSet.get(1).toString());
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            session.close();
        }
        return map;
    }

    public Map<String, String> getAirportList() throws QueryException {
       //System.out.println("RequestTrackerDAO begin hql getRequestTypeList---------------------");
        LinkedHashMap<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select OrgId, PortCode, OrgName from FD.OrgHierarchy where OrgHierarchyTypeCode = 'AIRPT' ORDER BY PortCode";
        Session session = null;
        String airportCode = "???";
        String airportName = "UNDEFINED";
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    if (null != resultSet.get(1)) {
                        airportCode = resultSet.get(1).toString();
                    }
                    if (null != resultSet.get(2)) {
                        airportName = resultSet.get(2).toString();
                        if (airportCode.length() > 1 && !airportCode.equalsIgnoreCase(airportName.split("-")[0].trim())) {
                            airportName = airportCode + " - " + airportName;    // OrgCode-OrgName
                        }
                    }
                    //map.put(resultSet.get(0).toString(), airportName);  // order by OrgId
                    map.put(airportCode + "~~" + resultSet.get(0).toString(), airportName);  // order by OrgCode~~OrgId
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            session.close();
        }
        return map;
    }

    public List<String> getSubjectIndividualList() throws QueryException {

        List<String> list = new ArrayList<String>();

        String queryStr = "select SubjectIndividual from FD.CtuRequest";
        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    String subjIndField = resultSet.get(0).toString();
                    String[] subjInds = subjIndField.split(";");

                    for (int i = 0; i < subjInds.length; i++) {
                        if (!subjInds[i].trim().isEmpty()) {
//                            System.out.println(subjects[i]);
                            list.add(subjInds[i]);
                        }
                    }
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            System.out.println(" DAO exception:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            session.close();
        }
        return list;
    }

    
    public List<String> getRequestNumberList(String subjectIndividual) throws Exception {
        // System.out.println("DAO: getRequestNumbers for subjectIndividual:" + subjectIndividual);

        if (null == subjectIndividual || subjectIndividual.isEmpty()) {
            return null;
        }
        String subjectIndividual_ = null;

        String nameLF[] = subjectIndividual.split("[,|' ']");  // separated by comma or space
        if (nameLF.length == 2) {
            subjectIndividual = nameLF[0] + " " + nameLF[1];
            subjectIndividual_ = nameLF[1] + " " + nameLF[0];   // for fuzzy search: unordered first and last names
        }
                            
        String queryStr;
        Request request = null;
        String subjIndField;
        String[] subjInds;
        List<String> list = new ArrayList<String>();

        queryStr = "select SubjectIndividual, RequestNumber from FD.CtuRequest";

        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {

                    subjIndField = (null == resultSet.get(0)) ? "" : resultSet.get(0).toString();

                    if (!subjIndField.isEmpty()) {
                        subjInds = subjIndField.split(";");

                        for (int i = 0; i < subjInds.length; i++) {
                            // Fuzzy name search for unordered first and last name
                            if (subjectIndividual.equalsIgnoreCase(subjInds[i].trim()) ||
                                subjectIndividual_.equalsIgnoreCase(subjInds[i].trim())) {
                                
                                request.setRequestNumber((null == resultSet.get(1)) ? "" : resultSet.get(1).toString());
                                list.add(request.getRequestNumber());
                                break;
                            }
                            
                        }
                    }
                } while (resultSet.next());
            }

        } catch (Exception hqEx) {
            System.out.println("====exception in RT DAO:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            session.close();
        }
        return list;
    }

    public List<Request> getRequestList(String subjectIndividual) throws Exception {
        //System.out.println("DAO: getRequests for subjectIndividual:" + subjectIndividual);
        if (null == subjectIndividual || subjectIndividual.isEmpty()) {
            return null;
        }

        String subjectIndividualLF = null;
        String nameLF[] = subjectIndividual.split(",");
        if (nameLF.length == 2) {
            subjectIndividualLF = nameLF[1].trim() + " " + nameLF[0].trim();
        }

        List<Request> requestList = new ArrayList<Request>();
        String queryStr;
        Request request = null;
        String subjIndField = null;
        String name = null;
        String[] subjInds = null;

        String fieldNames = " REQUESTNUMBER, SUBJECTINDIVIDUAL ";

        queryStr = "select " + fieldNames + " from FD.CTUREQUEST order by LastUpdateTimeStamp DESC ";

        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {

                    subjIndField = (null == resultSet.get(1)) ? "" : resultSet.get(1).toString();

                    if (!subjIndField.isEmpty()) {
                        subjInds = subjIndField.split(";");
                        for (int i = 0; i < subjInds.length; i++) {
                            name = subjInds[i].trim();
                            if (!name.isEmpty()) {
                                if (name.equalsIgnoreCase(subjectIndividual)
                                        || name.equalsIgnoreCase(subjectIndividualLF)) {
                                    request = new Request();

                                    request.setRequestNumber((null == resultSet.get(0)) ? "" : resultSet.get(0).toString());
                                    requestList.add(request);
                                    break;
                                }
                            }
                        }
                    }
                } while (resultSet.next());
            }

        } catch (Exception hqEx) {
            System.out.println("====exception in RT DAO getRequestList(String subjectIndividual):" + hqEx.getMessage());
            throw hqEx;
        } finally {
            session.close();
        }
        return requestList;
    }

    public List<Request> getRequestsForSubject(String subjectField, String ajaxName) throws Exception {
        if (null == subjectField || subjectField.isEmpty()) {
            return null;
        }
//        System.out.println(ajaxName + " DAO: getRequestsForSubject:" + subjectField);
        
        // Fuzzy name search
        String ajaxName_ = "";
        String nameLF[] = ajaxName.split("[,|' ']+");  // separated by comma or spaces
        if (nameLF.length == 2) {
            ajaxName = nameLF[0] + " " + nameLF[1];
            ajaxName_ = nameLF[1] + " " + nameLF[0];   // for fuzzy search: unordered first and last names
        }
                            
        List<Request> requestList = new ArrayList<Request>();

        Request request = null;
        String subjectString = null;
        String[] subjects = null;
        String subject = "";

        String fieldNames = " REQUESTNUMBER, " + subjectField;

        String queryStr = "select " + fieldNames + " from FD.CTUREQUEST order by LastUpdateTimeStamp DESC ";

        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {

                    subjectString = (null == resultSet.get(1)) ? "" : resultSet.get(1).toString();

                    if (!subjectString.isEmpty()) {
                        subjects = subjectString.split(";");
                        for (int i = 0; i < subjects.length; i++) {
                            subject = subjects[i].trim();
                            if (!subject.isEmpty()) {
                                if (ajaxName.equalsIgnoreCase(subject) ||
                                    ajaxName_.equalsIgnoreCase(subject)) {
                                    
                                    request = new Request();
                                    request.setRequestNumber((null == resultSet.get(0)) ? "" : resultSet.get(0).toString());
                                    requestList.add(request);
                                    break;
                                }
                            }
                        }
                    }
                } while (resultSet.next());
            }

        } catch (Exception hqEx) {
            System.out.println("====exception in RT DAO getRequestsForSubject:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            session.close();
        }
        return requestList;
    }

    public void saveRequestHistory(Session session, Cturequest req) throws QueryException {
        //System.out.println("======saveRequestHistory:" + req.getRequestNumber());
        try {
            BigDecimal historyId = getSeqNextVal(session, "FD.CtuRequestHistoryId_Seq");

			String fieldNames = "(RequestId, RequestNumber, RequestStatus, LEADTARGETER, CoTargeters, SUBJECTINDIVIDUAL, SubjectCompany, SubjectRegionId, RequesterAgencyId, Requester, RequestorName, AirportId, DerogLevel, RECOMMENDATION, COMMENTS, StaInformation, LastUpdateUserName, LastUpdateTimeStamp)";

			String queryStr = "insert into FD.CtuRequestHistory " + fieldNames
                + " values (:historyId, :getRequestNumber, :getRequestStatus, :getLeadTargeter, :getCoTargeters, :getSubjectIndividual, :getSubjectCompany, :getSubjectReqionID, :getRequesterAgencyID, :getRequester, :getRequestorName, :getAirportId, :getDerogLevel, :getRecommendation, :getComments, :getStaInformation, :getLastUpdateUserName, :getLastUpdateTimestamp)";

            Query query = session.createSQLQuery(queryStr);
            query.setParameter("historyId", historyId);
            query.setParameter("getRequestNumber", req.getRequestNumber());
            query.setParameter("getRequestStatus", req.getRequestStatus());
            query.setParameter("getLeadTargeter", req.getLeadTargeter());
            query.setParameter("getCoTargeters", req.getCoTargeter());
            query.setParameter("getSubjectIndividual", req.getSubjectIndividual());
            query.setParameter("getSubjectCompany", req.getSubjectCompany());
            query.setParameter("getSubjectReqionID", req.getSubjectReqionID());
            query.setParameter("getRequesterAgencyID", req.getRequesterAgencyID());   // requestor number
            query.setParameter("getRequester", req.getRequester());   // requestor
            query.setParameter("getRequestorName", req.getRequestorName());
            query.setParameter("getAirportId", req.getAirportID());
            query.setParameter("getDerogLevel", req.getDerogLevel());
            query.setParameter("getRecommendation", req.getRecommendation());
            query.setParameter("getComments", req.getComments());
            query.setParameter("getStaInformation", req.getStaInformation());
            query.setParameter("getLastUpdateUserName", req.getLastUpdateUserName());
            query.setParameter("getLastUpdateTimestamp", req.getLastUpdateTimestamp());
            query.executeUpdate();
            session.flush();

        } catch (Exception hqEx) {
            System.out.println("====exception in RT DAO:" + hqEx.getMessage());
            throw hqEx;
        } 
    }

    public List<Request> getRequestHistory(String requestNumber) throws Exception {
        //System.out.println("======getRequestHistory for requestNumber:" + requestNumber);
        RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();

        if (null == requestNumber || requestNumber.isEmpty()) {
            return null;
        }
        List<Request> requestList = new ArrayList<Request>();

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS");
        Date date;

        String idString = "";

        String queryStr;
        Request request = null;

        String fieldNames = " REQUESTNUMBER, REQUESTSTATUS, REQUESTTYPE, REQUESTDATE, REQUESTER, DEROG, DEROGLEVEL, "
                + "AIRPORTID, SUBJECTREGIONID, LEADTARGETER, COTARGETERS, SUBJECTINDIVIDUAL, SUBJECTCOMPANY, RECOMMENDATION, "
                + "COMMENTS, REQUESTORNAME, REQUESTERAGENCYID, STAINFORMATION, LastUpdateUserName, LastUpdateTimeStamp ";

        queryStr = "select " + fieldNames + " from FD.CtuRequestHistory where REQUESTNUMBER = '" + requestNumber
                + "' order by LastUpdateTimeStamp DESC";

        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {

                    request = new Request();
                    request.setRequestNumber((null == resultSet.get(0)) ? "" : resultSet.get(0).toString());
                    request.setRequestStatus((null == resultSet.get(1)) ? "" : resultSet.get(1).toString());
                    request.setRequestType((null == resultSet.get(2)) ? "" : resultSet.get(2).toString());
                    request.setRequestDate((null == resultSet.get(3)) ? null : formatter.parse(resultSet.get(3).toString().substring(0, 10)));
                    request.setDerogFound((null == resultSet.get(5)) ? false : true);
                    idString = (null == resultSet.get(6)) ? "0" : resultSet.get(6).toString();  // derogLevel
                    request.setDerogLevel(translateDerogLevel(idString));
                    idString = (null == resultSet.get(7)) ? "0" : resultSet.get(7).toString();  // airport -- should get airport name from DB
                    request.setAirport(getAirportName(requestReferenceData.getAirportNamesLinkedMap(), idString));  // airportId in NEW list
                    idString = (null == resultSet.get(8)) ? "0" : resultSet.get(8).toString();  // subjectRegionId
                    request.setSubjectRegion(getName(requestReferenceData.getSubjectRegionLinkedMap(), idString));

                    idString = (null == resultSet.get(9)) ? "0" : resultSet.get(9).toString();  // leadtargeter
                    request.setLeadTargeterName(getName(requestReferenceData.getTargeterLinkedMap(), idString));

                    idString = (null == resultSet.get(10)) ? "" : resultSet.get(10).toString();  // cotargeters
                    request.setCoTargeterName(getNames(requestReferenceData.getTargeterLinkedMap(), idString));

                    request.setSubjectIndividual((null == resultSet.get(11)) ? "" : resultSet.get(11).toString());
                    request.setSubjectCompany((null == resultSet.get(12)) ? "" : resultSet.get(12).toString());
                    request.setRecommendation((null == resultSet.get(13)) ? "" : resultSet.get(13).toString());
                    request.setComments((null == resultSet.get(14)) ? "" : resultSet.get(14).toString());
                    request.setRequestorName((null == resultSet.get(15)) ? "" : resultSet.get(15).toString());
                    request.setRequestor((null == resultSet.get(16)) ? "0" : resultSet.get(16).toString());
                    request.setStaInformation((null == resultSet.get(17)) ? "" : resultSet.get(17).toString());
                    request.setLastUpdateUserName((null == resultSet.get(18)) ? "" : resultSet.get(18).toString());
                    date = (null == resultSet.get(19)) ? null : timestampFormat.parse(resultSet.get(19).toString());
                    request.setLastUpdateTimestamp(new Timestamp(date.getTime()));

                    requestList.add(request);

                } while (resultSet.next());
            }
        } catch (Exception hqEx) {
            System.out.println("====exception in RT getRequestHistory DAO:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            session.close();
        }
        return requestList;
    }

// This method is used for Duplicate Subject Individual dialog
    public Request getRequest(String requestNumber) throws Exception {
        System.out.println("====***==getRequest for requestNumber:" + requestNumber);
        if (null == requestNumber || requestNumber.isEmpty()) {
            return null;
        }
        
        
        RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();

        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date;

        String airportName = "";
        String coTargeters = "";
        String airportKey;
        String queryStr;
        Request request = null;

        String fieldNames = " R.REQUESTNUMBER, R.REQUESTSTATUS, R.REQUESTTYPE, R.REQUESTDATE, R.REQUESTER, R.DEROG, R.DEROGLEVEL, "
                + "R.AIRPORTID, R.SUBJECTREGIONID, R.LEADTARGETER, R.COTARGETERS, R.SUBJECTINDIVIDUAL, R.SUBJECTCOMPANY, R.RECOMMENDATION, "
                + "R.COMMENTS, R.REQUESTORNAME, R.REQUESTERAGENCYID, R.STAINFORMATION,  R.CreateUserName, R.CreateTimestamp, R.LastUpdateUsername, R.LastUpdateTimestamp ";

        queryStr = "select " + fieldNames + " from FD.CTUREQUEST R where R.REQUESTNUMBER = '" + requestNumber + "'";

        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                request = new Request();
                request.setRequestNumber((null == resultSet.get(0)) ? "" : resultSet.get(0).toString());
                request.setRequestStatus((null == resultSet.get(1)) ? "" : resultSet.get(1).toString());
                request.setRequestType((null == resultSet.get(2)) ? "" : resultSet.get(2).toString());
                request.setRequestDate((null == resultSet.get(3)) ? null : formatter.parse(resultSet.get(3).toString().substring(0, 10)));
                request.setDerogFound((null == resultSet.get(5)) ? false : true);
                request.setDerogLevel((null == resultSet.get(6)) ? "0" : resultSet.get(6).toString());
                request.setAirportKey((null == resultSet.get(7)) ? "0" : resultSet.get(7).toString());
                request.setSubjectRegionId((null == resultSet.get(8)) ? "0" : resultSet.get(8).toString());
                request.setLeadTargeterId((null == resultSet.get(9)) ? "0" : resultSet.get(9).toString());

                coTargeters = (null == resultSet.get(10)) ? "0" : resultSet.get(10).toString();
                request.setSubjectIndividual((null == resultSet.get(11)) ? "" : resultSet.get(11).toString());
                request.setSubjectCompany((null == resultSet.get(12)) ? "" : resultSet.get(12).toString());
                request.setRecommendation((null == resultSet.get(13)) ? "" : resultSet.get(13).toString());
                request.setComments((null == resultSet.get(14)) ? "" : resultSet.get(14).toString());
                request.setRequestorName((null == resultSet.get(15)) ? "" : resultSet.get(15).toString());
                request.setRequestorId((null == resultSet.get(16)) ? "0" : resultSet.get(16).toString());
                request.setStaInformation((null == resultSet.get(17)) ? "" : resultSet.get(17).toString());

                request.setCreateUserName((null == resultSet.get(18)) ? "" : resultSet.get(18).toString().split("@")[0]);
                date = (null == resultSet.get(19)) ? null : timestampFormat.parse(resultSet.get(19).toString().substring(0, 20));
                if (null != date) {
                    request.setCreateTimestamp(new Timestamp(date.getTime()));
                }
                request.setLastUpdateUserName((null == resultSet.get(20)) ? "" : resultSet.get(20).toString().split("@")[0]);
                date = (null == resultSet.get(21)) ? null : timestampFormat.parse(resultSet.get(21).toString().substring(0, 20));
                if (null != date) {
                    request.setLastUpdateTimestamp(new Timestamp(date.getTime()));
                }
                               
                    airportKey = request.getAirportKey();
                    airportName = "";
                    if (airportKey != null || !airportKey.isEmpty()) {
                        
                        for (Iterator it = requestReferenceData.getAirportNamesLinkedMap().entrySet().iterator(); it.hasNext();) {
                            Map.Entry entry = (Map.Entry) it.next();
                            String key = (String) entry.getKey();   // new Key = airportCode + airportId
                            if (key.split("~~")[1].equals(airportKey)) {
                                airportName = (String) entry.getValue();
                                airportKey = key;
                                break;
                            }
                        }
                        
                    }
                    request.setAirportKey(airportName);
//                    request.setAirport(airportKey);          ~~ delimeter problem  for Duplicate Subject/Edit pages    
                    request.setAirport(airportName);               

                // convert derog level
                String derogLevel = request.getDerogLevel();
                if (derogLevel.equals("2")) {
                    request.setDerogLevel("Medium");
                } else if (derogLevel.equals("3")) {
                    request.setDerogLevel("High");
                } else if (derogLevel.equals("1")) {
                    request.setDerogLevel("Low");
                } else {
                    request.setDerogLevel("");
                }

                request.setLeadTargeterName(getName(requestReferenceData.getTargeterLinkedMap(), request.getLeadTargeterId()));
                request.setSubjectRegion(getName(requestReferenceData.getSubjectRegionLinkedMap(), request.getSubjectRegionId()));

                String[] coTargeterAry;
                String cotargeterNames = "";
                coTargeterAry = coTargeters.split(",");
                for (int i = 0; i < coTargeterAry.length; i++) {
                    cotargeterNames += getName(requestReferenceData.getTargeterLinkedMap(), coTargeterAry[i].trim());
                    cotargeterNames += "; ";
                }
                cotargeterNames = cotargeterNames.trim();
                if (cotargeterNames.endsWith(";")) {
                    cotargeterNames = cotargeterNames.substring(0, cotargeterNames.length() - 1);
                }
                request.setCoTargeterName(cotargeterNames);

                //request.setRequestor( request.getRequestorId() + ":::" + getRequestorByRequestType(request.getRequestType(), request.getRequestorId()));  // for Edit:::Duplicate subject fields
                request.setRequestor(getRequestorByRequestType(request.getRequestType(), request.getRequestorId()));
            }
        } catch (Exception hqEx) {
            System.out.println("====exception in RT DAO:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            session.close();
        }
        return request;
    }

    private String getRequestorByRequestType(String requestType, String key) {

        RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();

        if (requestType.equals("CI")) {
            return getName(requestReferenceData.getCargoIncidentLinkedMap(), key);
        } else if (requestType.equals("OGA")) {
            return getName(requestReferenceData.getOgaReferralLinkedMap(), key);
        } else if (requestType.equals("JO")) {
            return getName(requestReferenceData.getJointOperationsLinkedMap(), key);
        } else {
            return getName(requestReferenceData.getCcsfApprovalLinkedMap(), key);
        }
    }

    public List<Request> getRequestList(String searchStatus, String searchData) throws Exception {
        
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date;

        String airportName = "";
        String airportKey;
        String queryStr;
        String searchString = null;
        RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();

        if (null != searchData) {
            searchString = searchData.toUpperCase();
        }

        String fieldNames = " R.REQUESTNUMBER, R.REQUESTSTATUS, R.REQUESTTYPE, R.REQUESTDATE, R.REQUESTER, R.DEROG, R.DEROGLEVEL, "
                + "R.AIRPORTID, R.SUBJECTREGIONID, R.LEADTARGETER, R.COTARGETERS, R.SUBJECTINDIVIDUAL, R.SUBJECTCOMPANY, R.RECOMMENDATION, "
                + "R.COMMENTS, R.REQUESTORNAME, R.REQUESTERAGENCYID, R.STAINFORMATION, R.CreateUserName, R.CreateTimestamp, R.LastUpdateUsername, R.LastUpdateTimestamp ";

        String joinTables = " inner join fd.cturequesttype TYPE on R.requesttype=TYPE.requesttype "
                + "left join fd.ctusubjectregion REG on R.subjectregionid=REG.subjectregionid "
                + "left join fd.orghierarchy AIR on R.airportid=AIR.orgid "
                + "left join FD.ctutargeter TAR on R.leadtargeter=TAR.targeterid "
                + "left join FD.ctutargeter TAR on R.cotargeters=TAR.targeterid ";  // check for multiple names

        String searchTextCompare = " upper(R.REQUESTNUMBER) like '%" + searchString + "%'"
                + " or upper(R.REQUESTSTATUS) like '%" + searchString + "%'"
                + " or upper(R.REQUESTER) like '%" + searchString + "%'"
                + " or upper(R.REQUESTORNAME) like '%" + searchString + "%'"
                + " or upper(R.SUBJECTINDIVIDUAL) like '%" + searchString + "%'"
                + " or upper(R.SUBJECTCOMPANY) like '%" + searchString + "%'"
                + " or upper(R.RECOMMENDATION) like '%" + searchString + "%'"
                + " or upper(R.COMMENTS) like '%" + searchString + "%'"
                + " or upper(R.CreateUserName) like '%" + searchString + "%' "
                + " or upper(R.LastUpdateUsername) like '%" + searchString + "%' "
                + " or upper(R.REQUESTDATE) like '%" + searchString + "%' ";

        String searchSelectCompare = " or upper(TYPE.REQUESTNAME) like '%" + searchString + "%'"
                + " or upper(AIR.ORGNAME) like '%" + searchString + "%'"
                + " or upper(REG.REGIONNAME) like '%" + searchString + "%'"
                + " or upper(tar.leadtargettername) like '%" + searchString + "%' ";

        queryStr = "select " + fieldNames + " from FD.CTUREQUEST R ";

        if ("AdvancedSearch".equals(searchStatus)) {
            if (null != searchData) {
                queryStr += searchData;
                queryStr += " ORDER BY R.LASTUPDATETIMESTAMP DESC ";
            }
        } else {
            if (null != searchData) {
                queryStr += joinTables;
            }

            if (null != searchStatus) {
                queryStr += " where R.REQUESTSTATUS='" + searchStatus + "'";
                if (null != searchData) {
                    queryStr += " and (" + searchTextCompare + searchSelectCompare + ")";
                }
                queryStr += " ORDER BY R.LASTUPDATETIMESTAMP ASC ";
            } else {
                if (null != searchData) {
                    queryStr += " where " + searchTextCompare + searchSelectCompare;
                }
                queryStr += " ORDER BY R.LASTUPDATETIMESTAMP DESC ";
            }
        }
//        System.out.println(searchString + "-- getRequestList query:" + queryStr);
        List<Request> requestList = new ArrayList<Request>();
        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    Request request = new Request();
                    request.setRequestNumber((null == resultSet.get(0)) ? "" : resultSet.get(0).toString());
                    request.setRequestStatus((null == resultSet.get(1)) ? "" : resultSet.get(1).toString());
                    request.setRequestType((null == resultSet.get(2)) ? "" : resultSet.get(2).toString());
                    request.setRequestDate((null == resultSet.get(3)) ? null : formatter.parse(resultSet.get(3).toString().substring(0, 10)));
                    request.setDerogFound((null == resultSet.get(5)) ? false : true);
                    request.setDerogLevel((null == resultSet.get(6)) ? "0" : resultSet.get(6).toString());
                    request.setAirportKey((null == resultSet.get(7)) ? "0" : resultSet.get(7).toString());
                    request.setSubjectRegionId((null == resultSet.get(8)) ? "0" : resultSet.get(8).toString());
                    //                   request.setSubjectRegion((null == resultSet.get(8)) ? "" : "Region " + resultSet.get(8).toString()); // testing
                    request.setLeadTargeterId((null == resultSet.get(9)) ? "0" : resultSet.get(9).toString());
                    request.setCoTargeter((null == resultSet.get(10)) ? "0" : resultSet.get(10).toString());
                    //System.out.println("====cotargeters:" + request.getCoTargeter());
                    request.setSubjectIndividual((null == resultSet.get(11)) ? "" : resultSet.get(11).toString());
                    request.setSubjectCompany((null == resultSet.get(12)) ? "" : resultSet.get(12).toString());
                    request.setRecommendation((null == resultSet.get(13)) ? "" : resultSet.get(13).toString());
                    request.setComments((null == resultSet.get(14)) ? "" : resultSet.get(14).toString());
                    request.setRequestorName((null == resultSet.get(15)) ? "" : resultSet.get(15).toString());
                    request.setStaInformation((null == resultSet.get(17)) ? "" : resultSet.get(17).toString());
                    request.setCreateUserName((null == resultSet.get(18)) ? "" : resultSet.get(18).toString());
                    date = (null == resultSet.get(19)) ? null : timestampFormat.parse(resultSet.get(19).toString().substring(0, 20));
                    if (null != date) {
                        request.setCreateTimestamp(new Timestamp(date.getTime()));
                    }
                    request.setLastUpdateUserName((null == resultSet.get(20)) ? "" : resultSet.get(20).toString());
                    date = (null == resultSet.get(21)) ? null : timestampFormat.parse(resultSet.get(21).toString().substring(0, 20));
                    if (null != date) {
                        request.setLastUpdateTimestamp(new Timestamp(date.getTime()));
                    }

                    airportKey = request.getAirportKey();
                    airportName = "";
                    if (airportKey != null || !airportKey.isEmpty()) {
                        
                        for (Iterator it = requestReferenceData.getAirportNamesLinkedMap().entrySet().iterator(); it.hasNext();) {
                            Map.Entry entry = (Map.Entry) it.next();
                            String key = (String) entry.getKey();   // new Key = airportCode + airportId
                            if (key.split("~~")[1].equals(airportKey)) {
                                airportName = (String) entry.getValue();
                                airportKey = key;
                                break;
                            }
                        }
                        
                    }
                    request.setAirportKey(airportName);
                    request.setAirport(airportKey);
                  

                    // convert derog level
                    String derogLevel = request.getDerogLevel();
                    if (derogLevel.equals("2")) {
                        request.setDerogLevel("Medium");
                    } else if (derogLevel.equals("3")) {
                        request.setDerogLevel("High");
                    } else if (derogLevel.equals("1")) {
                        request.setDerogLevel("Low");
                    } else {
                        request.setDerogLevel("");
                    }

                    request.setLeadTargeterName(getName(requestReferenceData.getTargeterLinkedMap(), request.getLeadTargeterId()));
                    request.setSubjectRegion(getName(requestReferenceData.getSubjectRegionLinkedMap(), request.getSubjectRegionId()));

                    String[] cotargeters;
                    String cotargeterNames = "";
                    cotargeters = request.getCoTargeter().split(",");
                    for (int i = 0; i < cotargeters.length; i++) {
//                      System.out.println(cotargeters[i]);
                        cotargeterNames += getName(requestReferenceData.getTargeterLinkedMap(), cotargeters[i].trim());
                        cotargeterNames += "\n";
                    }
//                      System.out.println(cotargeterNames);
                    request.setCoTargeterName(cotargeterNames);

                    requestList.add(request);
                } while (resultSet.next());
            }
            System.out.println("====request:" + requestList.size());

        } catch (Exception hqEx) {
            System.out.println("====exception in RT DAO:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            session.close();
        }
        return requestList;
    }

    public int getRequestCount() throws Exception {
        int count = 0;
        String queryStr = "SELECT COUNT(*) AS COUNT FROM FD.CTUREQUEST";
        System.out.println("-- getRequestList query:" + queryStr);
        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                if (null != resultSet.get(0)) {
                    count = (int) resultSet.get(0);
                }
            }
        } catch (Exception hqEx) {
            System.out.println("====exception in RT DAO:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            session.close();
        }
        return count;
    }

    public int getRequestCount(String searchStatus, String searchData) throws Exception {
        int count = 0;

        String queryStr;
        String searchString = null;

        if (null != searchData) {
            searchString = fixRestoreSearchText(searchData).toUpperCase();
        }

        String joinTables = " inner join fd.cturequesttype TYPE on R.requesttype=TYPE.requesttype "
                + "left join fd.ctusubjectregion REG on R.subjectregionid=REG.subjectregionid "
                + "left join fd.orghierarchy AIR on R.airportid=AIR.orgid "
                + "left join FD.ctutargeter TAR on R.leadtargeter=TAR.targeterid ";
        //        + "left join FD.ctutargeter TAR on R.cotargeters=TAR.targeterid ";  // sql error: not a number

        String searchTextCompare = " upper(R.REQUESTNUMBER) like '%" + searchString + "%'"
                + " or upper(R.REQUESTSTATUS) like '%" + searchString + "%'"
                + " or upper(R.REQUESTER) like '%" + searchString + "%'"
                + " or upper(R.REQUESTORNAME) like '%" + searchString + "%'"
                + " or upper(R.SUBJECTINDIVIDUAL) like '%" + searchString + "%'"
                + " or upper(R.SUBJECTCOMPANY) like '%" + searchString + "%'"
                + " or upper(R.RECOMMENDATION) like '%" + searchString + "%'"
                + " or upper(R.COMMENTS) like '%" + searchString + "%'"
                + " or upper(R.CreateUserName) like '%" + searchString + "%' "
                + " or upper(R.LastUpdateUsername) like '%" + searchString + "%' "
                + " or upper(R.REQUESTDATE) like '%" + searchString + "%' ";

        String searchSelectCompare = " or upper(TYPE.REQUESTNAME) like '%" + searchString + "%'"
                + " or upper(AIR.ORGNAME) like '%" + searchString + "%'"
                + " or upper(REG.REGIONNAME) like '%" + searchString + "%'"
                + " or upper(tar.leadtargettername) like '%" + searchString + "%' ";

        queryStr = "SELECT COUNT(*) AS COUNT FROM FD.CTUREQUEST R ";

        if ("AdvancedSearch".equals(searchStatus)) {
            if (null != searchData) {
                queryStr += searchData;
                //queryStr += " ORDER BY R.LASTUPDATETIMESTAMP DESC ";
            }
        } else {   // regular search
            if (null != searchData) {
                queryStr += joinTables;
            }

            if (null != searchStatus) {
                queryStr += " where R.REQUESTSTATUS='" + searchStatus + "'";
                if (null != searchData) {
                    queryStr += " and (" + searchTextCompare + searchSelectCompare + ")";
                }
                //queryStr += " ORDER BY R.LASTUPDATETIMESTAMP ASC ";
            } else {
                if (null != searchData) {
                    queryStr += " where " + searchTextCompare + searchSelectCompare;
                }
                //queryStr += " ORDER BY R.LASTUPDATETIMESTAMP DESC ";
            }
        }
        //System.out.println(searchString + "-- getRequestList query:" + queryStr);
        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                if (null != resultSet.get(0)) {
                    count = ((BigDecimal) resultSet.get(0)).intValueExact();
                }
            }
        } catch (Exception hqEx) {
            System.out.println("====exception in RT DAO:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            session.close();
        }
        return count;
    }
    
    private String translateDerogLevel(String DerogLevelIndex) {
        
        if (DerogLevelIndex.equals("1")) {
            return "Low";
        } else if (DerogLevelIndex.equals("2")) {
            return "Medium";
        } else if (DerogLevelIndex.equals("3")) {
            return "High";
        } else {
            return "None";
        }
    }
    // Replace single quote to two single quotes for SQL search. Use this for basic search in this class
    private String fixRestoreSearchText(String s) {
        
        int len = s.length();
        String s1 = "";
        for(int i=0; i<len; i++) {
           if (s.charAt(i) == '\'') {
               if (i+1 < len && s.charAt(i+1) == '\'') {  // ''
                   i++;
               }
               s1 += "''";
           }
           else {
               s1 += s.charAt(i) + "";
           }
        }
//        System.out.println("new s1: " + s1);
        return s1.replace("<escript>", "</script>");
    }
    
    public List<Request> getRequestList(String searchStatus, String searchData, int startPageIndex, int recordsPerPage) throws Exception {
        System.out.println("----getRequestList: searchStatus: " + searchStatus + " searchData:" + searchData + " startPageIndex:" + startPageIndex + ", recordsPerPage: " + recordsPerPage);
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        Date date;

        RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();

        String airportName = "";
        String airportKey;
        String queryStr;
        String searchString = null;
        startPageIndex--;    // index starts at 0
        //int range = startPageIndex + recordsPerPage;
        int startRowNum = startPageIndex * recordsPerPage;
        int endRowNum = startRowNum + recordsPerPage;

        if (null != searchData) {
//            searchString = searchData.replaceAll("'", "''");
            searchString = fixRestoreSearchText(searchData).toUpperCase();
        }

        String fieldNames = " R.REQUESTNUMBER, R.REQUESTSTATUS, R.REQUESTTYPE, R.REQUESTDATE, R.REQUESTER, R.DEROG, R.DEROGLEVEL, "
                + "R.AIRPORTID, R.SUBJECTREGIONID, R.LEADTARGETER, R.COTARGETERS, R.SUBJECTINDIVIDUAL, R.SUBJECTCOMPANY, R.RECOMMENDATION, "
                + "R.COMMENTS, R.REQUESTORNAME, R.REQUESTERAGENCYID, R.STAINFORMATION, R.CreateUserName, R.CreateTimestamp, R.LastUpdateUsername, R.LastUpdateTimestamp ";

        String joinTables = " inner join fd.cturequesttype TYPE on R.requesttype=TYPE.requesttype "
                + "left join fd.ctusubjectregion REG on R.subjectregionid=REG.subjectregionid "
                + "left join fd.orghierarchy AIR on R.airportid=AIR.orgid "
                + "left join FD.ctutargeter TAR on R.leadtargeter=TAR.targeterid ";
       //         + "left join FD.ctutargeter TAR on R.cotargeters=TAR.targeterid ";  // sql error: not a number

        String searchTextCompare = " upper(R.REQUESTNUMBER) like '%" + searchString + "%'"
                + " or upper(R.REQUESTSTATUS) like '%" + searchString + "%'"
                + " or upper(R.REQUESTER) like '%" + searchString + "%'"
                + " or upper(R.REQUESTORNAME) like '%" + searchString + "%'"
                + " or upper(R.SUBJECTINDIVIDUAL) like '%" + searchString + "%'"
                + " or upper(R.SUBJECTCOMPANY) like '%" + searchString + "%'"
                + " or upper(R.RECOMMENDATION) like '%" + searchString + "%'"
                + " or upper(R.COMMENTS) like '%" + searchString + "%'"
                + " or upper(R.CreateUserName) like '%" + searchString + "%' "
                + " or upper(R.LastUpdateUsername) like '%" + searchString + "%' "
                + " or upper(R.REQUESTDATE) like '%" + searchString + "%' ";

        String searchSelectCompare = " or upper(TYPE.REQUESTNAME) like '%" + searchString + "%'"
                + " or upper(AIR.ORGNAME) like '%" + searchString + "%'"
                + " or upper(REG.REGIONNAME) like '%" + searchString + "%'"
                + " or upper(tar.leadtargettername) like '%" + searchString + "%' ";

        if (recordsPerPage > 0) {
            queryStr = "select * from ( select  a.*, rownum rnum from (select " + fieldNames + " from FD.CTUREQUEST R ";
        } else {
            queryStr = "select " + fieldNames + " from FD.CTUREQUEST R ";
        }

        if ("AdvancedSearch".equals(searchStatus)) {
            if (null != searchData) {
                queryStr += searchData;
                queryStr += " ORDER BY R.LASTUPDATETIMESTAMP DESC ";
            }
        } else {
            if (null != searchData) {
                queryStr += joinTables;
            }

            if (null != searchStatus) {
                queryStr += " where R.REQUESTSTATUS='" + searchStatus + "'";
                if (null != searchData) {
                    queryStr += " and (" + searchTextCompare + searchSelectCompare + ")";
                }
                queryStr += " ORDER BY R.LASTUPDATETIMESTAMP ASC ";
            } else {
                if (null != searchData) {
                    queryStr += " where " + searchTextCompare + searchSelectCompare;
                }
                queryStr += " ORDER BY R.LASTUPDATETIMESTAMP DESC ";
            }
        }

        if (recordsPerPage > 0) {
            queryStr += ") a  where rownum <= " + endRowNum + ") where rnum > " + startRowNum;
        }

        //System.out.println("-- getRequestList query:" + queryStr);
        List<Request> requestList = new ArrayList<Request>();
        Session session = null;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    Request request = new Request();
                    request.setRequestNumber((null == resultSet.get(0)) ? "" : resultSet.get(0).toString());
                    request.setRequestStatus((null == resultSet.get(1)) ? "" : resultSet.get(1).toString());
                    request.setRequestType((null == resultSet.get(2)) ? "" : resultSet.get(2).toString());
                    request.setRequestDate((null == resultSet.get(3)) ? null : formatter.parse(resultSet.get(3).toString().substring(0, 10)));
                    request.setDerogFound((null == resultSet.get(5)) ? false : true);
                    request.setDerogLevel((null == resultSet.get(6)) ? "0" : resultSet.get(6).toString());
                    airportKey = (null == resultSet.get(7)) ? "0" : resultSet.get(7).toString();
                    request.setSubjectRegionId((null == resultSet.get(8)) ? "0" : resultSet.get(8).toString());
                    request.setLeadTargeterId((null == resultSet.get(9)) ? "0" : resultSet.get(9).toString());
                    request.setCoTargeter((null == resultSet.get(10)) ? "0" : resultSet.get(10).toString());
                    request.setSubjectIndividual((null == resultSet.get(11)) ? "" : resultSet.get(11).toString());
                    request.setSubjectCompany((null == resultSet.get(12)) ? "" : resultSet.get(12).toString());
                    request.setRecommendation((null == resultSet.get(13)) ? "" : resultSet.get(13).toString());
                    request.setComments((null == resultSet.get(14)) ? "" : resultSet.get(14).toString());
                    request.setRequestorName((null == resultSet.get(15)) ? "" : resultSet.get(15).toString());
                    request.setRequestor((null == resultSet.get(16)) ? "0" : resultSet.get(16).toString());
                    request.setStaInformation((null == resultSet.get(17)) ? "" : resultSet.get(17).toString());
                    request.setCreateUserName((null == resultSet.get(18)) ? "" : resultSet.get(18).toString());
                    date = (null == resultSet.get(19)) ? null : timestampFormat.parse(resultSet.get(19).toString().substring(0, 20));
                    if (null != date) {
                        request.setCreateTimestamp(new Timestamp(date.getTime()));
                    }
                    request.setLastUpdateUserName((null == resultSet.get(20)) ? "" : resultSet.get(20).toString());
                    date = (null == resultSet.get(21)) ? null : timestampFormat.parse(resultSet.get(21).toString().substring(0, 20));
                    if (null != date) {
                        request.setLastUpdateTimestamp(new Timestamp(date.getTime()));
                    }

                    airportName = "";
                    if (!airportKey.equals("0")) {
                        for (Iterator it = requestReferenceData.getAirportNamesLinkedMap().entrySet().iterator(); it.hasNext();) {
                            Map.Entry entry = (Map.Entry) it.next();
                            String key = (String) entry.getKey();   // new Key = airportCode + airportId
                            String value = (String) entry.getValue();
                            if (key.split("~~")[1].equalsIgnoreCase(airportKey)) {
                                airportName = value.split("-")[0];
                                airportKey = key;
//                                airportName = value;
                                break;
                            }
                        }
                    }
                    request.setAirport(airportName);
                    request.setAirportKey(airportKey);

                    // convert derog level
                    String derogLevel = request.getDerogLevel();
                    if (derogLevel.equals("2")) {
                        request.setDerogLevel("Medium");
                    } else if (derogLevel.equals("3")) {
                        request.setDerogLevel("High");
                    } else if (derogLevel.equals("1")) {
                        request.setDerogLevel("Low");
                    } else {
                        request.setDerogLevel("");
                    }

                    request.setLeadTargeterName(getName(requestReferenceData.getTargeterLinkedMap(), request.getLeadTargeterId()));
                    request.setSubjectRegion(getName(requestReferenceData.getSubjectRegionLinkedMap(), request.getSubjectRegionId()));

                    String[] cotargeters;
                    String cotargeterNames = "";
                    cotargeters = request.getCoTargeter().split(",");
                    for (int i = 0; i < cotargeters.length; i++) {
                        cotargeterNames += getName(requestReferenceData.getTargeterLinkedMap(), cotargeters[i].trim());
                        cotargeterNames += "\n";
                    }
                    request.setCoTargeterName(cotargeterNames);

                    requestList.add(request);
                } while (resultSet.next());
            }

        } catch (Exception hqEx) {
            System.out.println("====exception in RT DAO:" + hqEx.getMessage());
            throw hqEx;
        } finally {
            session.close();
        }
       return requestList;
    }

    private String getAirportName(Map<String, String> dataMap, String dataKey) {

        if (dataKey == null || dataKey.isEmpty()) {
            return "";
        } else {
            String key, id;
            for (Iterator it = dataMap.entrySet().iterator(); it.hasNext();) {
                Map.Entry entry = (Map.Entry) it.next();
                key = (String) entry.getKey();     // name~~id
                id = key.split("~~")[1];
                
                if (dataKey.equals(id)) {
                    return key.split("~~")[0];
                }
            }
            return "";
        }
    }

    private String getName(Map<String, String> dataMap, String dataKey) {

        if (dataKey == null || dataKey.isEmpty()) {
            return "";
        } else {
            for (Iterator it = dataMap.entrySet().iterator(); it.hasNext();) {
                Map.Entry entry = (Map.Entry) it.next();
                String key = (String) entry.getKey();
                String value = (String) entry.getValue();
                if (key.equalsIgnoreCase(dataKey)) {
                    return value;
                }
            }
            return "";
        }
    }

    private String getNames(Map<String, String> dataMap, String idString) {

        String[] nameAry;
        String nameString = "";
        nameAry = idString.split(",");
        for (int i = 0; i < nameAry.length; i++) {
            nameString += getName(dataMap, nameAry[i].trim());
            nameString += "; ";
        }
        if (nameString.trim().equals(";")) {
            return "";
        }
        return nameString;
    }

    public Map<String, String> getOgaReferralList() throws QueryException {

        Map<String, String> map = new LinkedHashMap<String, String>();
        String queryStr = "select OGAREFERRALID, REQUESTORAGENCY from FD.CTUOGAREFERRAL ORDER BY REQUESTORAGENCY";
        Session session = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString(), resultSet.get(1).toString());
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            session.close();
        }
        return map;

    }

    public Map<String, String> getJointOperationsList() throws QueryException {
        // System.out.println("RequestTrackerDAO begin hql requestracketdao");
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select JOINTOPERATIONID, REQUESTORAGENCY from FD.CTUJOINTOPERATIONS ORDER BY REQUESTORAGENCY";
        Session session = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
//                int i = 0;
                do {
//                    map.put(++i + "", resultSet.get(0).toString() + "~~" + resultSet.get(1).toString());  // sort by order
                    map.put(resultSet.get(0).toString() , resultSet.get(1).toString());  // sort by id
//                    map.put(resultSet.get(1).toString() , resultSet.get(1).toString());  // sort by name
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            session.close();
        }
        return map;

    }

    public Map<String, String> getFieldCallStaRequestList() throws QueryException {
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select REQUESTSTAID, STATYPE from FD.CTUFIELDCALLSTAREQUEST ORDER BY STATYPE";
        Session session = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString(), resultSet.get(1).toString());
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            System.out.println("getFieldCallStaRequestList exception");
            throw hqEx;
        } finally {
            session.close();
        }
        return map;

    }

    public Map<String, String> getStaInLieuOfList() throws QueryException {
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select StaInLieuOfId, StaInLieuOfType from FD.CtuStaInLieuOf ORDER BY StaInLieuOfId";
        Session session = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString(), resultSet.get(1).toString());
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            session.close();
        }
        return map;

    }

    public Map<String, String> getCargoIncidentList() throws QueryException {
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select CARGOINCIDENTID, REQUESTORAGENCY from FD.CTUCARGOINCIDENT ORDER BY REQUESTORAGENCY";
        Session session = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString(), resultSet.get(1).toString());
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            session.close();
        }
        return map;

    }

    public Map<String, String> getCCSFApprovalList() throws QueryException {
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select PSIID, PSINAMES from FD.CTUCCSFAPPROVAL ORDER BY PSINAMES";
        Session session = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString(), resultSet.get(1).toString());
                } while (resultSet.next());
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            session.close();
        }
        return map;

    }

    public String processEditRequest(String requestNumber, String thisUser) throws QueryException {

        String queryStr3 = "select Requester from FD.CtuRequest where RequestNumber = '" + requestNumber + "'";
//        String queryStr4 = "update Cturequest set LockedUser='" + thisUser + "' where RequestNumber= '" + requestNumber + "'";
        String queryStr4 = "update Cturequest set Requester='" + thisUser + "' where RequestNumber= '" + requestNumber + "'";
        Session session = null;
        String returnedUser = "";
        Transaction tx = null;
        Query query;
        ScrollableResults resultSet;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();

            query = session.createSQLQuery(queryStr3);
            resultSet = query.scroll();
            if (resultSet.first()) {
                returnedUser = (String) resultSet.get(0);
            }
            if (null == returnedUser) {
                query = session.createQuery(queryStr4);
                query.executeUpdate();
                tx.commit();
                returnedUser = "";
            } else if (thisUser.equalsIgnoreCase(returnedUser)) {
                returnedUser = "";
            } else {
                //System.out.println("DAO: returnedUser is " + returnedUser);
            }

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            session.close();
        }
        return returnedUser;
    }

    public void cancelEditRequest(String lockedUser) throws QueryException {

//        String queryStr = "update Cturequest set LockedUser = NULL where LockedUser = '" + lockedUser + "'";
        String queryStr = "update Cturequest set Requester = NULL where Requester = '" + lockedUser + "'";

        Session session = null;
        Transaction tx = null;
        Query query;

        try {
            session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            //System.out.println("DAO: Clear locked requests: " + queryStr );
            query = session.createQuery(queryStr);
            query.executeUpdate();
            tx.commit();

        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            session.close();
        }
    }

//    public void saveRequestTrackerForUpdateVersion(RequestTrackerData requestTrackerData) throws QueryException {
//        System.out.println("RequestTrackerDAO begin hql requestracketdao");
//        System.out.println("-RT DAO------------------RT data:" + requestTrackerData.toString());
//        Map<String, String> map = new LinkedHashMap<String, String>();
//        Transaction tx = null;
//        Cturequest cr = null;
//        boolean isUpdated = false;
//        Session session = null;
//        int requestId = 0;
//
//        try {
//            session = HibernateUtil.getSessionFactory().openSession();
//            tx = session.beginTransaction();
//            cr = new Cturequest();
//            // check to see if new or updated request
//            String requestNumber = requestTrackerData.getRequestNumber();
//            System.out.println("DAO  -------- JSP RequestNumber " + requestNumber);
//            if (null == requestNumber || requestNumber.isEmpty()) {
//                int seqnumber = (int) (getSeqNextVal(session).intValue());
//                cr.setRequestID(seqnumber);
//                String str = "CTU" + requestTrackerData.getRequestType() + "15-" + seqnumber;
//                cr.setRequestNumber(str);
//            } else {
//                isUpdated = true;
//                cr.setRequestNumber(requestNumber);
//                int requestNumberLength = requestNumber.length();
//                String requestIdStr = requestNumber.substring(requestNumberLength - 4, requestNumberLength);
//
//                System.out.println("DAO  -------- DB requestIdStr " + requestIdStr);
//                try {
//                    requestId = Integer.parseInt(requestIdStr);
//                } catch (Exception e) {
//                    System.out.println(e.getMessage());
//                }
//
//                cr.setRequestID(requestId);
//            }
//
//            // 
//            System.out.println("DAO  cr.setRequestNumber " + cr.getRequestNumber());
//
//            // Only update required data
//            if (!isUpdated) {
//                cr.setCargoIncidentID(requestTrackerData.getCargoIncident());
//                cr.setCtuCCSFApproval(requestTrackerData.getCcsfApproval());
//                cr.setPsiID(requestTrackerData.getPsiid());
//                cr.setStaRequestID(requestTrackerData.getStaRequestID());
//                cr.setOgaReferralID(requestTrackerData.getOgaReferral());
//                cr.setRequesterAgencyID(requestTrackerData.getRequesterAgencyID());
//
//                cr.setRequestType(requestTrackerData.getRequestType());
//                cr.setRequestDate(requestTrackerData.getRequestDate());
//                cr.setRequester(requestTrackerData.getRequestor());
//                cr.setRequestorName(requestTrackerData.getRequestorName());
//
//                String airportName = requestTrackerData.getAirportName();
//
//                int airportID = 0;
//
//                try {
//                    airportID = Integer.parseInt(airportName);
//                } catch (Exception e) {
//                    System.out.println(e.getMessage());
//                }
//
//                cr.setAirportID(airportID);
//                //System.out.println(" =============airportID: " + airportID);
//
//                cr.setSubjectIndividual(requestTrackerData.getSubjectIndividual());
//                cr.setSubjectCompany(requestTrackerData.getSubjectCompany());
//                cr.setStaRequestID(requestTrackerData.getStaRequestID());
//                try {
////                System.out.println(" requestTrackerData.getSubjectRegion()     " + requestTrackerData.getSubjectRegion());
//                    cr.setSubjectReqionID(Integer.parseInt(requestTrackerData.getSubjectRegion()));
//                } catch (Exception e) {
//                    System.out.println(e.getMessage());
//                    cr.setSubjectReqionID(0);    // NEED WORK
//                }
//            }
//
//            // common data for both new and update.
//            // Get targeter list
//            String leadTargeter = requestTrackerData.getLeadtargeter();
//            String requestStatus = null;
//            //System.out.println(" =============leadTargeter: " + leadTargeter);
//            if (leadTargeter == null || leadTargeter.isEmpty() || leadTargeter.contains("Please select")) {
//                leadTargeter = "0";
//                requestStatus = "Unassigned";
//            } else {
//                requestStatus = "Open";
//            }
//            cr.setLeadTargeter(leadTargeter);
//            System.out.println(" Inv Complete:)     " + requestTrackerData.isInvComplete());
//            if (requestTrackerData.isInvComplete()) {
//                requestStatus = "Closed";
//            }
//            cr.setRequestStatus(requestStatus);
//
//            String coTargeter = requestTrackerData.getCotargeter();
//            if (leadTargeter.equals("0") || coTargeter == null || leadTargeter.isEmpty() || coTargeter.contains("Please select")) {
//                coTargeter = "0";
//            }
//
//            System.out.println(" =============coTargeter: " + coTargeter);
//            cr.setCoTargeter(coTargeter);
//
////            System.out.println(" DEROG:)     " + requestTrackerData.isDerogFound());
//            String derogFound = requestTrackerData.isDerogFound() ? "Y" : null;
//            cr.setDerog(derogFound);
//
////            cr.setDerogLevel(null == requestTrackerData.getDerogLevel() ? "0" : requestTrackerData.getDerogLevel());
//            String derogLevelStr = requestTrackerData.getDerogLevel();
//            String derogLevel = null;
//
//            if (derogLevelStr == null) {
//                derogLevel = "0";
//            } else if (derogLevelStr.equalsIgnoreCase("Low")) {
//                derogLevel = "1";
//            } else if (derogLevelStr.equalsIgnoreCase("Medium")) {
//                derogLevel = "2";
//            } else if (derogLevelStr.equalsIgnoreCase("High")) {
//                derogLevel = "3";
//            }
//            cr.setDerogLevel(derogLevel);
//
//            //System.out.println(" getComments    " + requestTrackerData.getComments());
//            //System.out.println(" getRecommendation    " + requestTrackerData.getRecommendation());
//            cr.setComments(requestTrackerData.getComments());
//            cr.setRecommendation(requestTrackerData.getRecommendation());
//
//            if (isUpdated) {
//
//                String queryStr = null;
//                if (null == derogFound) {    // need refactor
//                    queryStr = "UPDATE Cturequest SET LEADTARGETER='" + leadTargeter
//                            + "', COTARGETERS='" + coTargeter
//                            + "', REQUESTSTATUS='" + requestStatus
//                            + "', DEROG=" + derogFound
//                            + ", DEROGLEVEL='" + derogLevel
//                            + "', RECOMMENDATION='" + requestTrackerData.getRecommendation()
//                            + "', COMMENTS='" + requestTrackerData.getComments()
//                            + "' WHERE REQUESTID = '" + requestId + "')";
//                } else {
//                    queryStr = "UPDATE Cturequest SET LEADTARGETER='" + leadTargeter
//                            + "', COTARGETERS='" + coTargeter
//                            + "', REQUESTSTATUS='" + requestStatus
//                            + "', DEROG='" + derogFound
//                            + "', DEROGLEVEL='" + derogLevel
//                            + "', RECOMMENDATION='" + requestTrackerData.getRecommendation()
//                            + "', COMMENTS='" + requestTrackerData.getComments()
//                            + "' WHERE REQUESTID = '" + requestId + "')";
//                }
//
//                System.out.println(" ------ Update Request data:" + queryStr);
//                Query query = session.createQuery(queryStr);
//                int result = query.executeUpdate();
//                System.out.println(" ------ Update Result:" + result);
////                session.update(cr);
//            } else {
//                System.out.println(" ------ Insert Request data:" + cr.toString());
//                session.save(cr);
//            }
//            tx.commit();
////        } catch (HibernateException hqEx) {
//        } catch (Exception hqEx) {
//            System.out.println(" ------Exception in Request data:" + hqEx.getMessage());
//            tx.rollback();
//            throw hqEx;
//        } finally {
//            session.close();
//        }
//
//    }
    public String saveRequestTracker(RequestTrackerData requestTrackerData) throws Exception {
        System.out.println("-RT DAO----saveRequestTracker----Form data:" + requestTrackerData.toString());
        Map<String, String> map = new LinkedHashMap<String, String>();
        Transaction tx = null;
        Cturequest cr = null;
        boolean isUpdated = false;
        Session session = null;
        int requestId = 0;
        String requestType = null;
        Date requestDate = requestTrackerData.getRequestDate();


        try {
            session = HibernateUtil.getSessionFactory().openSession();
            tx = session.beginTransaction();
            cr = new Cturequest();
            // check to see if new or updated request
            String requestNumber = requestTrackerData.getRequestNumber();
            //System.out.println("DAO  -------- RequestNumber from browser:" + requestNumber);
            if (null == requestNumber || requestNumber.isEmpty()) {

                // find last sequence number based on request type  ctu_request
                int seqnumber;
                try {
                   seqnumber = (int) getSeqNextVal(session, "FD.CtuRequestId_Seq").intValue();
                //   System.out.println("======saveRequest-CtuRequestId_Seq:" + seqnumber);
                }
                catch (HibernateException e) {
                   seqnumber = (int) getSeqNextVal(session, "ctu_request").intValue();
                   System.out.println("======saveRequest-OLD ctu_request:" + seqnumber);
                }
                
                cr.setRequestID(seqnumber);

                requestType = requestTrackerData.getRequestType();

                Calendar cal = Calendar.getInstance();
                cal.setTime(requestDate);

                int yy = requestDate.getMonth() < 9 ? requestDate.getYear() : requestDate.getYear() + 1;

                String newRequestNumber = "CTU" + requestType + (yy % 100);

                int requestTypeSeq = 0;
                String requestTypeSeqStr = getRequestTypeSequence(session, newRequestNumber);
                try {
                    requestTypeSeq = Integer.parseInt(requestTypeSeqStr);
                    requestTypeSeq++;
                    requestTypeSeqStr = String.format("%4s", Integer.toString(requestTypeSeq)).replace(' ', '0');
                } catch (Exception e) {
//                    System.out.println(e.getMessage() + " Set requestTypeSeq = 0001");
                    requestTypeSeqStr = "0001";
                }

                newRequestNumber = newRequestNumber + "-" + requestTypeSeqStr;

                cr.setRequestNumber(newRequestNumber);
//                System.out.println("DAO  -------- NEW RequestNumber " + newRequestNumber);
            } else {
                isUpdated = true;
                cr.setRequestNumber(requestNumber);
                requestId = (int) (getRequestId(session, requestNumber).intValue());

//                System.out.println("DAO  -------- DB requestId " + requestId);

                cr.setRequestID(requestId);
            }

//          Note: the following fields are not updated
//            cr.setCargoIncidentID(requestTrackerData.getCargoIncident());
//            cr.setCtuCCSFApproval(requestTrackerData.getCcsfApproval());
//            cr.setPsiID(requestTrackerData.getPsiid());
//            cr.setStaRequestID(requestTrackerData.getStaRequestID());
//            cr.setOgaReferralID(requestTrackerData.getOgaReferral());
            
            cr.setRequester(requestTrackerData.getRequestor());
            
            cr.setRequesterAgencyID(requestTrackerData.getRequesterAgencyID());

            cr.setRequestType(requestTrackerData.getRequestType());
            cr.setRequestDate(requestTrackerData.getRequestDate());

            cr.setRequestorName(requestTrackerData.getRequestorName());

            String airportCodeId = requestTrackerData.getAirportName();   

            int airportID = 0;

            try {
                airportID = Integer.parseInt(airportCodeId.split("~~")[1]);
                cr.setAirportID(airportID);
            } catch (Exception e) {
                System.out.println("RT DAO Exception airportCodeId:" + e.getMessage());
                cr.setAirportID(0);
            }

            cr.setSubjectIndividual(requestTrackerData.getSubjectIndividual());
            cr.setSubjectCompany(requestTrackerData.getSubjectCompany());
            try {
                cr.setSubjectReqionID(Integer.parseInt(requestTrackerData.getSubjectRegion()));
            } catch (Exception e) {
                System.out.println("RT DAO Exception setSubjectReqionID:" + e.getMessage());
                cr.setSubjectReqionID(0);    // NEED WORK
            }

            // common data for both new and update.
            // Get targeter list
            String leadTargeter = requestTrackerData.getLeadtargeter();
            String requestStatus = null;
            if (leadTargeter == null || leadTargeter.isEmpty() || leadTargeter.contains("Select")) {
                leadTargeter = "0";
                requestStatus = "Unassigned";
            } else {
                requestStatus = "Open";
            }
            cr.setLeadTargeter(leadTargeter);
            if (requestTrackerData.isInvComplete() && (!leadTargeter.equals("0"))) {
                requestStatus = "Closed";
            }
            cr.setRequestStatus(requestStatus);
            //           System.out.println(" Request Status is     " + requestStatus);

            String coTargeter = requestTrackerData.getCotargeter();
            if (leadTargeter.equals("0") || coTargeter == null || leadTargeter.isEmpty() || coTargeter.contains("Select")) {
                coTargeter = "0";
            }

//            System.out.println(" =============coTargeter: " + coTargeter);
            cr.setCoTargeter(coTargeter);

//            System.out.println(" DEROG:)     " + requestTrackerData.isDerogFound());
            String derogFound = requestTrackerData.isDerogFound() ? "Y" : null;
            cr.setDerog(derogFound);

            String derogLevelStr = requestTrackerData.getDerogLevel();
            String derogLevel = null;

            if (derogLevelStr == null) {
                derogLevel = "0";
            } else if (derogLevelStr.equalsIgnoreCase("Low")) {
                derogLevel = "1";
            } else if (derogLevelStr.equalsIgnoreCase("Medium")) {
                derogLevel = "2";
            } else if (derogLevelStr.equalsIgnoreCase("High")) {
                derogLevel = "3";
            }
            cr.setDerogLevel(derogLevel);
            cr.setStaInformation(requestTrackerData.getStaInformation());

            //System.out.println(" getComments    " + requestTrackerData.getComments());
            //System.out.println(" getRecommendation    " + requestTrackerData.getRecommendation());
            cr.setComments(requestTrackerData.getComments());
            cr.setRecommendation(requestTrackerData.getRecommendation());

            Date now = new Date();

            java.sql.Timestamp sqlTime = new java.sql.Timestamp(now.getTime());

            cr.setLastUpdateTimestamp(sqlTime);
            cr.setLastUpdateUserName(requestTrackerData.getUserId().split("@")[0]);

            // save the record for Request History (before save or update(cr))
            saveRequestHistory(session, cr);

            if (isUpdated) {
                // retain create user and time
                cr.setCreateTimeStamp(requestTrackerData.getCreateTimestamp());
                cr.setCreateUserName(requestTrackerData.getCreateUserName());
                System.out.println(" ------ Update Request data:" + cr.toString());
                session.update(cr);
            } else {
                cr.setCreateTimeStamp(sqlTime);
                cr.setCreateUserName(requestTrackerData.getUserId());
                System.out.println(" ------ Insert Request data:" + cr.toString());
                session.save(cr);
            }

            tx.commit();
        } catch (Exception hqEx) {
            System.out.println(" ------Exception in Request data:" + hqEx.getMessage());
            tx.rollback();
            session.close();
            throw hqEx;
        } 
        session.close();
        return cr.getRequestNumber();
    }


    private BigDecimal getSeqNextVal(Session session, String sequence) {
        BigDecimal value = null;
        try {
            Query query = session.createSQLQuery("select " + sequence + ".nextval from Dual");

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                value = (BigDecimal) resultSet.get(0);
 //               System.out.println(table + "-getSeqNextVal:" + value);
            }
            session.flush();

        } catch (HibernateException hqEx) {
            System.out.println("-HibernateException:" + sequence);
            throw hqEx;
        } 
        return value;

    }

    private BigDecimal getRequestId(Session session, String requestNumber) {
        BigDecimal value = null;
        try {
            Query query = session.createSQLQuery("select requestid from fd.cturequest where requestnumber = '" + requestNumber + "'");

            List<Object[]> result = new ArrayList<Object[]>();
            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                value = (BigDecimal) resultSet.get(0);
            }
            session.flush();

        } catch (HibernateException hqEx) {

            throw hqEx;
        } 
        return value;
    }

    private String getRequestTypeSequence(Session session, String preRequestNumber) {
        String value = "0000";
        try {
            Query query = session.createSQLQuery("select max(substr(RequestNumber, -4)) from fd.CtuRequest where RequestNumber like '" + preRequestNumber + "%'");

            List<Object[]> result = new ArrayList<Object[]>();
            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                value = (String) resultSet.get(0);
            }
            session.flush();
        } catch (HibernateException hqEx) {
            throw hqEx;
        } 
        return value;

    }

    public Map<String, String> getTargeterList() throws QueryException {
        // System.out.println("RequestTrackerDAO begin hql requestracketdao");
        Map<String, String> map = new LinkedHashMap<String, String>();

        String queryStr = "select TARGETERID, LEADTARGETTERNAME from FD.CTUTARGETER ORDER BY LEADTARGETTERNAME";
        Session session = null;
        try {
            session = HibernateUtil.getSessionFactory().openSession();
            Query query = session.createSQLQuery(queryStr);

            ScrollableResults resultSet = query.scroll();
            if (resultSet.first()) {
                do {
                    map.put(resultSet.get(0).toString(), resultSet.get(1).toString());
                } while (resultSet.next());
            }
        } catch (HibernateException hqEx) {
            throw hqEx;
        } finally {
            session.close();
        }
        return map;
  }
  
    /**
     * Gets a connection to the database.
     *
     * If the dataSource is null, it looks up the dataSource again, otherwise it
     * gets a connection from the dataSource.
     *
     * @return Connection
     */
    protected Connection getConnection()
            throws SQLException {
        return ConnectionUtil.getConnection();
    }
}
