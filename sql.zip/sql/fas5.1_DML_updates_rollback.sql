-------------------------------------------------
-- Copyright (c) Soft Tech Consulting, Inc.
-------------------------------------------------

-- Login as user FD before running this script DDL Rollback --

/*******************************************************************************/
/*                                   ROLLBACK DATA TABLES  	               */
/*******************************************************************************/
delete FD.SYSTEMROLEFUNCTION where SYSTEMFUNCTIONCODE ='NAVES';
delete FD.SYSTEMROLEFUNCTION where SYSTEMFUNCTIONCODE ='NAVDB';

delete FD.SYSTEMFUNCTION where SYSTEMFUNCTIONCODE ='NAVES';
delete FD.SYSTEMFUNCTION where SYSTEMFUNCTIONCODE ='NAVES';

--commit;