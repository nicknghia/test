-------------------------------------------------
-- Copyright (c) Soft Tech Consulting, Inc.
-------------------------------------------------

-- Login as user FD before running this script DDL Rollback --

/*******************************************************************************/
/*                                   ROLLBACK DATA TABLES  	               */
/*******************************************************************************/
delete FD.SYSTEMROLEFUNCTION where systemrolecode ='APAD';
delete FD.SYSTEMROLEFUNCTION where systemrolecode ='TAR';
delete FD.SYSTEMROLEFUNCTION where systemrolecode ='RDONL';

drop table FD.ASYNCPROCESSINGLOG;
drop table FD.COUNTRY;
drop table FD.FAS_APP_PROPERTIES;
drop table FD.ORGHIERARCHY;
drop table FD.ORGHIERARCHYTYPE;
drop table FD.ORGORGASSOC;
drop table FD.ORGREFERENCE;
drop table FD.ORGREFERENCETYPE;
drop table FD.ORGROLE;
drop table FD.REGIONTYPE;
drop table FD.REPORT;
drop table FD.REPORTPARAMETER;
drop table FD.SYSTEMFUNCTION;
drop table FD.SYSTEMROLE;
drop table FD.SYSTEMROLEFUNCTION;
drop table FD.SYSTEMUSER;
drop table FD.TIMEZONE;
drop table FD.TITLETYPE;
drop table FD.USERPASSWORDHIST;
drop table FD.USERSYSTEMROLE;
drop table FD.SYSTEMMESSAGE;

create table FD.ASYNCPROCESSINGLOG as select * from FD.ASYNCPROCESSINGLOG_BACKUP;
create table FD.COUNTRY as select * from FD.COUNTRY_BACKUP;
create table FD.FAS_APP_PROPERTIES as select * from FD.FAS_APP_PROPERTIES_BACKUP;
create table FD.ORGHIERARCHY as select * from FD.ORGHIERARCHY_BACKUP;
create table FD.ORGHIERARCHYTYPE as select * from FD.ORGHIERARCHYTYPE_BACKUP;
create table FD.ORGORGASSOC as select * from FD.ORGORGASSOC_BACKUP;
create table FD.ORGREFERENCE as select * from FD.ORGREFERENCE_BACKUP;
create table FD.ORGREFERENCETYPE as select * from FD.ORGREFERENCETYPE_BACKUP;
create table FD.ORGROLE as select * from FD.ORGROLE_BACKUP;
create table FD.REGIONTYPE as select * from FD.REGIONTYPE_BACKUP;
create table FD.REPORT as select * from FD.REPORT_BACKUP;
create table FD.REPORTPARAMETER as select * from FD.REPORTPARAMETER_BACKUP;
create table FD.SYSTEMFUNCTION as select * from FD.SYSTEMFUNCTION_BACKUP;
create table FD.SYSTEMROLE as select * from FD.SYSTEMROLE_BACKUP;
create table FD.SYSTEMROLEFUNCTION as select * from FD.SYSTEMROLEFUNCTION_BACKUP;
create table FD.SYSTEMUSER as select * from FD.SYSTEMUSER_BACKUP;
create table FD.TIMEZONE as select * from FD.TIMEZONE_BACKUP;
create table FD.TITLETYPE as select * from FD.TITLETYPE_BACKUP;
create table FD.USERPASSWORDHIST as select * from FD.USERPASSWORDHIST_BACKUP;
create table FD.USERSYSTEMROLE as select * from FD.USERSYSTEMROLE_BACKUP;
create table FD.SYSTEMMESSAGE as select * from FD.SYSTEMMESSAGE_BACKUP;


/*******************************************************************************/
/*      	DROP BACKUP TABLES			                                       */
/*******************************************************************************/


drop table FD.ASYNCPROCESSINGLOG_BACKUP;
drop table FD.COUNTRY_BACKUP;
drop table FD.FAS_APP_PROPERTIES_BACKUP;
drop table FD.ORGHIERARCHY_BACKUP;
drop table FD.ORGHIERARCHYTYPE_BACKUP;
drop table FD.ORGORGASSOC_BACKUP;
drop table FD.ORGREFERENCE_BACKUP;
drop table FD.ORGREFERENCETYPE_BACKUP;
drop table FD.ORGROLE_BACKUP;
drop table FD.REGIONTYPE_BACKUP;
drop table FD.REPORT_BACKUP;
drop table FD.REPORTPARAMETER_BACKUP;
drop table FD.SYSTEMFUNCTION_BACKUP;
drop table FD.SYSTEMROLE_BACKUP;
drop table FD.SYSTEMROLEFUNCTION_BACKUP;
drop table FD.SYSTEMUSER_BACKUP;
drop table FD.TIMEZONE_BACKUP;
drop table FD.TITLETYPE_BACKUP;
drop table FD.USERPASSWORDHIST_BACKUP;
drop table FD.USERSYSTEMROLE_BACKUP;
drop table FD.SYSTEMMESSAGE_BACKUP;
	
/*******************************************************************************/
/*      	DROP NEW TABLES AND SEQUENCES			  	                       */
/*******************************************************************************/

drop table FD.CTUCARGOINCIDENT cascade constraints;
drop table FD.CTUCCSFAPPROVAL cascade constraints;
drop table FD.CTUFIELDCALLSTAREQUEST cascade constraints;
drop table FD.CTUJOINTOPERATIONS cascade constraints;
drop table FD.CTUOGAREFERRAL cascade constraints;
drop table FD.CTUREQUEST cascade constraints;
drop sequence FD.CTUREQUESTID_SEQ;
drop table FD.CTUREQUESTHISTORY cascade constraints;
drop sequence FD.CTUREQUESTHISTORYID_SEQ;
drop table FD.CTUREQUESTTYPE cascade constraints;
drop table FD.CTUSTAINLIEUOF cascade constraints;
drop table FD.CTUSUBJECTREGION cascade constraints;
drop table FD.CTUTARGETER cascade constraints;


