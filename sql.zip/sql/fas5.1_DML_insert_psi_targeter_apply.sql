-------------------------------------------------
-- Copyright (c) Soft Tech Consulting, Inc.
-------------------------------------------------

-- Login as user FD before running this script DML Update --

/****************************************************************************************/
/* 					      ADD NEW ORG ROLES 					            			*/
/****************************************************************************************/
Insert into FD.ORGROLE (ORGROLECODE,ORGROLENAME,STATUS,CREATEUSERID,CREATETIMESTAMP,LASTUPDATEUSER,LASTUPDATETIMESTAMP,DOMAINNAME) 
      values ('PSI','PRINCIPLE SECURITY INSPECTOR','ACTIVE',USER,SYSDATE,null,SYSDATE,'PUBLIC');
Insert into FD.ORGROLE (ORGROLECODE,ORGROLENAME,STATUS,CREATEUSERID,CREATETIMESTAMP,LASTUPDATEUSER,LASTUPDATETIMESTAMP,DOMAINNAME) 
      values ('TAR','TARGETER','ACTIVE',USER,SYSDATE,null,SYSDATE,'PUBLIC');
 