-------------------------------------------------
-- Copyright (c) Soft Tech Consulting, Inc.
-------------------------------------------------

-- Login as user FD before running this script DDL Rollback --

/*******************************************************************************/
/*                                   ROLLBACK DATA TABLES  	               */
/*******************************************************************************/
drop table FD.CTUREQUEST;
drop table FD.CTUREQUESTHISTORY;
drop table FD.CTUREQUESTSTATUS;
drop table FD.CTUDEROGLEVEL;

create table FD.CTUREQUEST as select * from FD.CTUREQUEST_SI_STA;
create table FD.CTUREQUESTHISTORY as select * from FD.CTUREQUESTHISTORY_SI_STA;

drop table FD.CTUREQUEST_SI_STA;
drop table FD.CTUREQUESTHISTORY_SI_STA;	

revoke ALL ON FD.CTUREQUEST FROM FDAPP;
revoke ALL ON FD.CTUREQUESTHISTORY FROM FDAPP;


