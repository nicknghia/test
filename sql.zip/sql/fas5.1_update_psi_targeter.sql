-------------------------------------------------
-- Copyright (c) Soft Tech Consulting, Inc.
-------------------------------------------------

-- Login as user FD before running this script


--spool "\FAS5.0\New PSI-TAR\psi_targeter.txt"
--  Create new PSI and Targeters in the FAS application

set serveroutput on
set echo on


prompt '---------------------------MIGRATING PSIs / Targeters --------------------------------------------------------------------'
-- 2: Update RequestType in RequestHistory
update fd.ctuRequestHistory RH set RH.requestType = (select R.RequestType from FD.CtuRequest R where RH.requestNumber = R.requestNumber);

prompt '-----Old PSIs COUNTs------'
select count(*) as REQUEST_COUNT from fd.CTURequest where requesterAgencyId is not null and requesteragencyid > 0 and (requestType='SF' or requestType='IAC');
select count(*) as REQUEST_HISTORY_COUNT from fd.CTURequestHistory where requesterAgencyId is not null and requesteragencyid > 0 and (requestType='SF' or requestType='IAC');


--------------------------
declare
  type psiType is record (psiName fd.ctuCcsfApproval.psiNames%type, oldID fd.ctuCcsfApproval.psiId%type, newID FD.ORGHIERARCHY.orgId%type);  
  psiRecord psiType;
  
  cursor CV is
    select A.psiNames , A.psiId, B.OrgId into psiRecord from fd.ctuCcsfApproval A, FD.ORGHIERARCHY B 
    where b.orgrolecode='PSI'
    and upper(replace(a.psinames, ' ', '')) = upper(b.contactFirstname || b.contactLastname);

  rc number;
  rhc number;

begin
  open CV;
  fetch CV into psiRecord;
  
  while (CV%FOUND) loop
     dbms_output.put_line(psiRecord.psiName || ' : ' || psiRecord.oldID || ' -> ' || psiRecord.newID);
     select  count(*) into rc from fd.ctuRequest where requesterAgencyId=psiRecord.oldID and (requestType='SF' or requestType='IAC');

     update fd.cturequest set requesterAgencyId=psiRecord.newID where requesterAgencyId=psiRecord.oldID and (requestType='SF' or requestType='IAC'); 
     update fd.cturequestHistory set requesterAgencyId=psiRecord.newID where requesterAgencyId=psiRecord.oldID and (requestType='SF' or requestType='IAC'); 

     select  count(*) into rhc from fd.ctuRequest where requesterAgencyId=psiRecord.newID and (requestType='SF' or requestType='IAC');

     dbms_output.put_line( ' PSI Request Count: ' || rc || ' ?= ' || rhc);
     
     fetch CV into psiRecord;
     
  end loop;
  close CV;
end;
/
prompt '-----NEW PSIs COUNTs------'
select count(*) as REQUEST_COUNT from fd.CTURequest where requesterAgencyId is not null and requesteragencyid > 0 and (requestType='SF' or requestType='IAC');
select count(*) as REQUEST_HISTORY_COUNT from fd.CTURequestHistory where requesterAgencyId is not null and requesteragencyid > 0 and (requestType='SF' or requestType='IAC');

------------------------------------------------------------------------------------------------------------------------------------
prompt '-----Old leadTargeter------'
select count(*) as OLD_TAR_REQUEST_COUNT from fd.CTURequest where leadTargeter is not null and leadTargeter != '0'; 
select count(*) as OLD_TAR_REQUEST_HISTORY_COUNT from fd.CTURequestHistory where leadTargeter is not null and leadTargeter != '0'; 

declare
  type tarType is record (tarName fd.CTUTARGETER.LEADTARGETTERNAME%type, oldID fd.CTUTARGETER.TARGETERID%type, newID FD.ORGHIERARCHY.orgId%type);
  
  tarRecord tarType;
  
cursor CV is
  select A.LEADTARGETTERNAME, A.TARGETERID, B.OrgId into tarRecord  from fd.CTUTARGETER A, FD.ORGHIERARCHY B 
  where b.orgrolecode='TAR'
  and upper(replace(a.LEADTARGETTERNAME, ' ', '')) = upper(b.contactFirstname || b.contactLastname)

  order by a.targeterID desc;

  rc number;
  rhc number;

begin

  open CV;
  fetch CV into tarRecord;
  
  while (CV%FOUND) loop
     dbms_output.put_line(tarRecord.tarName || ' : ' || tarRecord.oldID || ' -> ' || tarRecord.newID);

     select  count(*) into rc from fd.ctuRequest where leadTargeter=tarRecord.oldID;

     update fd.cturequest set leadTargeter=tarRecord.newID where leadTargeter=tarRecord.oldId ;
     
     update fd.cturequestHistory set leadTargeter=tarRecord.newID where leadTargeter=tarRecord.oldId ;

     select  count(*) into rhc from fd.ctuRequest where leadTargeter=tarRecord.newID; 

     dbms_output.put_line( ' Request Count: ' || rc || ' ?= ' || rhc);
     
     fetch CV into tarRecord;
     
  end loop;
  close CV;
end;
/

prompt '-----New leadTargeters------'
select count(*) as NEW_TAR_REQUEST_COUNT from fd.CTURequest where leadTargeter is not null and leadTargeter != '0'; 
select count(*) as NEW_TAR_REQUEST_HISTORY_COUNT from fd.CTURequestHistory where leadTargeter is not null and leadTargeter != '0'; 
-----------------------------------------------------------------------------------------------

prompt '-----Old CoTargeters------'
select count(*) as REQUEST_COUNT from fd.CTURequest where coTargeters is not null and coTargeters != '0'; 
select count(*) as REQUEST_HISTORY_COUNT from fd.CTURequestHistory where coTargeters is not null and coTargeters != '0'; 

prompt '-----Old Invalid CoTargeters------'
select count(*) as INVALID_cotargeter_COUNT from fd.CTURequest where leadTargeter is null or leadTargeter = '0';
select requestNumber, coTargeters as OLD_COTARGETER from fd.CTURequest where leadTargeter is null or leadTargeter = '0';
select count(*) as INVALID_cotar_His_CNT from fd.CTURequestHistory where leadTargeter is null or leadTargeter = '0';


prompt '-----Converting CoTargeters------'

-- 4: Find all CoTargeters that need to be updated
declare
  type tarType is record (tarName fd.CTUTARGETER.LEADTARGETTERNAME%type, oldID fd.CTUTARGETER.TARGETERID%type, newID FD.ORGHIERARCHY.orgId%type);  
  tarRecord tarType;
  
    cursor CV is
      select A.LEADTARGETTERNAME, A.TARGETERID, B.OrgId into tarRecord  from fd.CTUTARGETER A, FD.ORGHIERARCHY B 
        where b.orgrolecode='TAR'
        and upper(replace(a.LEADTARGETTERNAME, ' ', '')) = upper(b.contactFirstname || b.contactLastname)
      order by a.targeterID;
    -----   -- requestId is unique here 
      type coTarType is record (reqId fd.CtuRequest.requestId%type, reqNum fd.CtuRequest.requestNumber%type, coTar fd.CtuRequest.cotargeters%type);  
      coTarRecord coTarType;
      
    cursor CT is   
      select requestId, requestNumber, coTargeters into coTarRecord  from fd.CTURequest where coTargeters is not null and coTargeters != '0'; 
   
    cursor CH is  
      select requestId, requestNumber, coTargeters into coTarRecord  from fd.CTURequestHistory where coTargeters is not null and coTargeters != '0'; 
    
    rc number;
    rhc number;
    
  	TYPE typTokenTab IS TABLE OF VARCHAR(100) INDEX BY BINARY_INTEGER;
  	tglTokenTab		typTokenTab;
    oldIDs typTokenTab;
    newIDs typTokenTab;
    i INTEGER;
    newIdStr varchar(1000);

  	FUNCTION creTokenList(pLine IN VARCHAR2, pDelimiter IN VARCHAR2) RETURN typTokenTab IS
   		sLine		VARCHAR2(2000);
      	nPos		INTEGER;
      	nPosOld		INTEGER;
          nIndex		INTEGER;
          nLength		INTEGER;
          nCnt		INTEGER;
          sToken		VARCHAR2(200);
          tTokenTab	typTokenTab;
      BEGIN
       	sLine := pLine;
    		IF (SUBSTR(sLine, LENGTH(sLine), 1) <> '|') THEN
    			sLine := sLine || '|';
    		END IF;
 
         	  nPos := 0;
            sToken := '';
           nLength := LENGTH(sLine);
           nCnt := 0;
 
           FOR nIndex IN 1..nLength LOOP
           	IF ((SUBSTR(sLine, nIndex, 1) = pDelimiter) OR (nIndex = nLength)) THEN
   	          	nPosOld := nPos;
               	nPos := nIndex;
   	          	nCnt := nCnt + 1;
   	            sToken := SUBSTR(sLine, nPosOld + 1, nPos - nPosOld - 1);
 
        				tTokenTab(nCnt) := sToken;
             END IF;
 
           END LOOP;
 
           RETURN tTokenTab;
       END creTokenList;
----------------------------
begin

  -- store oldId and newId in arrays
    open CV;
  fetch CV into tarRecord;
  i := 0;
  while (CV%FOUND) loop
     dbms_output.put_line(tarRecord.tarName || ' : ' || tarRecord.oldID || ' -> ' || tarRecord.newID);

     oldIDs(i) := tarRecord.oldID;
     newIDs(i) := tarRecord.newID;
     i := i+1;
     
     fetch CV into tarRecord;
     
  end loop;
  close CV;

  dbms_output.put_line('----- Updating CoTargeters for CtuRequest ID -----');

  open CT;
  fetch CT into coTarRecord;
  while (CT%FOUND) loop
     dbms_output.put_line(cotarRecord.reqNum || ' : ' || cotarRecord.coTar);
 
   	  tglTokenTab := creTokenList( coTarRecord.coTar, ',');
 
      newIdStr := '';
       FOR indx IN tglTokenTab.FIRST..tglTokenTab.LAST LOOP
          -- dbms_output.put_line(indx || ' oldId:' || tglTokenTab(indx));
           
           for j in oldIDs.first..oldIDs.last loop
             -- replace the old IDs
             if trim(tglTokenTab(indx)) = trim(oldIDs(j)) then
               if length(newIdStr) > 0 then
                  newIdStr := newIdStr || ',';
               end if;
               dbms_output.put_line('Found:' || tglTokenTab(indx) || ' -> ' || newIDs(j) || ' : ' || newIdStr);
               newIdStr := newidstr || newIDs(j);
               exit;

             -- retain the new IDs
             elsif trim(tglTokenTab(indx)) = trim(newIDs(j)) then
               if length(newIdStr) > 0 then
                  newIdStr := newIdStr || ',';
               end if;
               --dbms_output.put_line('Found:' || tglTokenTab(indx) || ' -> ' || newIDs(j) || ' : ' || newIdStr);
               newIdStr := newidstr || newIDs(j);
               exit;
             end if;
           end loop;  
           
       END LOOP;   -- next token
       -- replace the old CoTargeters with the new one
       if length(newIdStr) > 0 then
        ---update FD.CtuRequest set CoTargeters 
          dbms_output.put_line('update with ' || newIdStr);
          update FD.CtuRequest set CoTargeters = newIdStr  where requestNumber = cotarRecord.reqNum;  -- reqNum is unique
       
       end if;
       
     fetch CT into coTarRecord;
   end loop;
   close CT;
 --  	tglTokenTab.DELETE;
  -- for history
  dbms_output.put_line('----- Updating CoTargeters for CtuRequestHistory -----');
  
  open CH;
  fetch CH into coTarRecord;
  while (CH%FOUND) loop
     dbms_output.put_line(cotarRecord.reqId || ' : ' || cotarRecord.reqNum || ' : ' || cotarRecord.coTar);
 
   	  tglTokenTab := creTokenList( coTarRecord.coTar, ',');
 
      newIdStr := '';
       FOR indx IN tglTokenTab.FIRST..tglTokenTab.LAST LOOP
           --dbms_output.put_line(indx || ' oldId:' || tglTokenTab(indx));
           
           for j in oldIDs.first..oldIDs.last loop
             -- replace the old IDs
             if trim(tglTokenTab(indx)) = trim(oldIDs(j)) then
               if length(newIdStr) > 0 then
                  newIdStr := newIdStr || ',';
               end if;
               --dbms_output.put_line('Found:' || tglTokenTab(indx) || ' -> ' || newIDs(j) || ' : ' || newIdStr);
               newIdStr := newidstr || newIDs(j);
               exit;
             
             -- retain the new IDs
             elsif trim(tglTokenTab(indx)) = trim(newIDs(j)) then
               if length(newIdStr) > 0 then
                  newIdStr := newIdStr || ',';
               end if;
               --dbms_output.put_line('Found:' || tglTokenTab(indx) || ' -> ' || newIDs(j) || ' : ' || newIdStr);
               newIdStr := newidstr || newIDs(j);
               exit;
             end if;
           end loop;  
           
       END LOOP;   -- next token
       -- replace the old CoTargeters with the new one
       if length(newIdStr) > 0 then
        ---update FD.CtuRequest set CoTargeters 
          dbms_output.put_line('replace with ' || newIdStr);
          update FD.CtuRequestHistory set CoTargeters = newIdStr  where requestId = cotarRecord.reqId; -- not reqNum
       
       end if;
       
     fetch CH into coTarRecord;
   end loop;
   close CH;
end;
/
--rollback;
--   commit;

prompt '-----New CoTargeters------'
select count(*) as REQUEST_COUNT from fd.CTURequest where coTargeters is not null and coTargeters != '0'; 
select count(*) as REQUEST_HISTORY_COUNT from fd.CTURequestHistory where coTargeters is not null and coTargeters != '0'; 

prompt '-----Updated PSI/Targeters------'
select orgid, orgrolecode, orgname, contactfirstname, contactlastname from fd.orghierarchy where orgrolecode='PSI';
select orgid, orgrolecode, orgname, contactfirstname, contactlastname from fd.orghierarchy where orgrolecode='TAR';


--spool off

