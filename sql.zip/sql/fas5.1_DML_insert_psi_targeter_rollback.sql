-------------------------------------------------
-- Copyright (c) Soft Tech Consulting, Inc.
-------------------------------------------------

-- Login as user FD before running this script DML Rollback --

/****************************************************************************************/
/* 					      ROLLBACK - ADDING PSI and TAR ROLES  	            			*/
/****************************************************************************************/
Delete from FD.ORGROLE where ORGROLECODE = 'PSI';
Delete from FD.ORGROLE where ORGROLECODE = 'TAR';
 