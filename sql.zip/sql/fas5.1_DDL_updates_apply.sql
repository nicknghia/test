-------------------------------------------------
-- Copyright (c) Soft Tech Consulting, Inc.
-------------------------------------------------

-- Login as user FD before running this script DDL Updates --

/****************************************************************************************/
/*                                    BACKUP DATA TABLES  			       				*/
/****************************************************************************************/
create table FD.CTUREQUEST_SI_STA as select * from FD.CTUREQUEST;
create table FD.CTUREQUESTHISTORY_SI_STA as select * from FD.CTUREQUESTHISTORY;


/****************************************************************************************/
/*                                CREATE NEW TABLES			  			    			*/
/****************************************************************************************/

create table FD.CTUREQUESTSTATUS
  (
    REQUESTSTATUS  		VARCHAR2(10) NOT NULL,
    DESCRIPTION      		VARCHAR2(20),
    CREATEUSERID     		VARCHAR2(50),
    LASTUPDATEUSERID 		VARCHAR2(50),
    CREATETIMESTAMP 		DATE NOT NULL,
    LASTUPDATETIMESTAMP 	DATE
  );
alter table FD.CTUREQUESTSTATUS
   add constraint PK_CTUREQUESTSTATUS primary key (REQUESTSTATUS);
   
create table FD.CTUDEROGLEVEL
  (
    DEROGLEVEL  		VARCHAR2(1) NOT NULL,
    DESCRIPTION     VARCHAR2(20),
    CREATEUSERID     		VARCHAR2(50),
    LASTUPDATEUSERID 		VARCHAR2(50),
    CREATETIMESTAMP 		DATE NOT NULL,
    LASTUPDATETIMESTAMP 	DATE
  );
alter table FD.CTUDEROGLEVEL
   add constraint PK_CTUDEROGLEVEL primary key (DEROGLEVEL);

   
/****************************************************************************************/
/*        			GRANT ACCESS TO TABLES AND SEQUENCES    							*/
/****************************************************************************************/
GRANT ALL ON FD.CTUREQUESTSTATUS TO FDAPP;
GRANT ALL ON FD.CTUDEROGLEVEL TO FDAPP;


/****************************************************************************************/
/*                       UPDATE TABLE COLUMNS							    			*/
/****************************************************************************************/

alter table FD.CTUREQUEST modify SUBJECTINDIVIDUAL varchar2(4000);
alter table FD.CTUREQUESTHISTORY modify SUBJECTINDIVIDUAL varchar2(4000);

alter table FD.CTUREQUEST modify STAINFORMATION varchar2(4000);
alter table FD.CTUREQUESTHISTORY modify STAINFORMATION varchar2(4000);

alter table FD.CTUREQUEST modify SUBJECTCOMPANY varchar2(1000);
alter table FD.CTUREQUESTHISTORY modify SUBJECTCOMPANY varchar2(1000);

alter table FD.CTUREQUEST modify SUBJECTCOMPANY varchar2(1500);
alter table FD.CTUREQUESTHISTORY modify SUBJECTCOMPANY varchar2(1500);

alter table FD.CTUREQUEST modify COMMENTS varchar2(2500);
alter table FD.CTUREQUESTHISTORY modify COMMENTS varchar2(2500);

alter table FD.CTUREQUEST modify COTARGETERS varchar2(500);
alter table FD.CTUREQUESTHISTORY modify COTARGETERS varchar2(500);

alter table FD.CTUREQUEST modify REQUESTORNAME varchar2(100);
alter table FD.CTUREQUESTHISTORY modify REQUESTORNAME varchar2(100);

alter table FD.CTUREQUEST add INLIEUAIRPORT char(1);
alter table FD.CTUREQUESTHISTORY add INLIEUAIRPORT char(1);


