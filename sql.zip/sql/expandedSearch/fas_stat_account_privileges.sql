GRANT SELECT on ar.hz_parties TO "svc-stat-fasroapp";
GRANT SELECT on ar.hz_certifications TO "svc-stat-fasroapp";
GRANT SELECT on ar.hz_relationships TO "svc-stat-fasroapp";
GRANT SELECT on ar.hz_organization_profiles TO "svc-stat-fasroapp";
