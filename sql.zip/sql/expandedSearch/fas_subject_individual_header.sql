create or replace
PACKAGE FAS_SUBJECT_INDIVIDUAL AS 
	  
PROCEDURE SEL_RECORD_BY_STAID (
       p_sta_id       IN EGOV_IAC.STA_IAC_ASSOC_SEARCH.STA_ID%TYPE       
      ,p_ref_cursor    OUT SYS_REFCURSOR
      ,total_count   OUT NUMBER);
  
PROCEDURE SEL_RECORD_BY_LAST_NAME (     
       p_last_name     	IN  EGOV_IAC.STA_IAC_ASSOC_SEARCH.LAST_NAME%TYPE       
      ,p_ref_cursor    OUT SYS_REFCURSOR
      ,total_count     OUT NUMBER);
	  
PROCEDURE SEL_RECORD_BY_FIRST_LAST_NAME (     
       p_first_name     IN  EGOV_IAC.STA_IAC_ASSOC_SEARCH.FIRST_NAME%TYPE  
      ,p_last_name     	IN  EGOV_IAC.STA_IAC_ASSOC_SEARCH.LAST_NAME%TYPE 	   
      ,p_ref_cursor    OUT SYS_REFCURSOR
      ,total_count     OUT NUMBER);
	  
PROCEDURE SEL_REC_DET_BY_STA_LAST_FIRST (
       p_sta_id       IN EGOV_IAC.STA_IAC_ASSOC_SEARCH.STA_ID%TYPE
       ,p_last_name   IN EGOV_IAC.STA_IAC_ASSOC_SEARCH.LAST_NAME%TYPE
       ,p_first_name  IN EGOV_IAC.STA_IAC_ASSOC_SEARCH.FIRST_NAME%TYPE
      ,p_ref_cursor    OUT SYS_REFCURSOR);
     
PROCEDURE SEL_COMP_IN_PHY (
       p_sta_id       IN AR.HZ_CERTIFICATIONS.GRADE%TYPE   
      ,p_last_name    IN  EGOV_IAC.STA_IAC_ASSOC_SEARCH.LAST_NAME%TYPE  
      ,p_first_name   IN  EGOV_IAC.STA_IAC_ASSOC_SEARCH.FIRST_NAME%TYPE	   
      ,p_ref_cursor   OUT SYS_REFCURSOR ); 

PROCEDURE SEL_COMP_IN_PER (
       p_sta_id       IN AR.HZ_CERTIFICATIONS.GRADE%TYPE  
      ,p_last_name    IN  EGOV_IAC.STA_IAC_ASSOC_SEARCH.LAST_NAME%TYPE  
      ,p_first_name   IN  EGOV_IAC.STA_IAC_ASSOC_SEARCH.FIRST_NAME%TYPE		   
      ,p_ref_cursor    OUT SYS_REFCURSOR );  
       
PROCEDURE SEL_COMP_IN_CZN (
       p_sta_id       IN AR.HZ_CERTIFICATIONS.GRADE%TYPE  
      ,p_last_name    IN  EGOV_IAC.STA_IAC_ASSOC_SEARCH.LAST_NAME%TYPE  
      ,p_first_name   IN  EGOV_IAC.STA_IAC_ASSOC_SEARCH.FIRST_NAME%TYPE		   
      ,p_ref_cursor    OUT SYS_REFCURSOR );    
       
PROCEDURE SEL_COMP_IN_IAC (
       p_sta_id       IN AR.HZ_CERTIFICATIONS.GRADE%TYPE 
      ,p_last_name    IN  EGOV_IAC.STA_IAC_ASSOC_SEARCH.LAST_NAME%TYPE  
      ,p_first_name   IN  EGOV_IAC.STA_IAC_ASSOC_SEARCH.FIRST_NAME%TYPE       
      ,p_ref_cursor   OUT SYS_REFCURSOR );
       
PROCEDURE SEL_COMP_IN_AGENT (
       p_sta_id       IN AR.HZ_CERTIFICATIONS.GRADE%TYPE 
      ,p_last_name    IN  EGOV_IAC.STA_IAC_ASSOC_SEARCH.LAST_NAME%TYPE  
      ,p_first_name   IN  EGOV_IAC.STA_IAC_ASSOC_SEARCH.FIRST_NAME%TYPE  	   
      ,p_ref_cursor   OUT SYS_REFCURSOR );
       
PROCEDURE SEL_COMP_IN_AC (
       p_sta_id       IN AR.HZ_CERTIFICATIONS.GRADE%TYPE   
      ,p_last_name    IN  EGOV_IAC.STA_IAC_ASSOC_SEARCH.LAST_NAME%TYPE  
      ,p_first_name   IN  EGOV_IAC.STA_IAC_ASSOC_SEARCH.FIRST_NAME%TYPE	   
      ,p_ref_cursor   OUT SYS_REFCURSOR );              
      
END FAS_SUBJECT_INDIVIDUAL;