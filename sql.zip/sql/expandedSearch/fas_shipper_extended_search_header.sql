create or replace
PACKAGE FAS_SHIPPER_EXTENDED_SEARCH AS 

PROCEDURE SEL_REC_BY_ANY (
           p_party_id   IN HZ_ORIG_SYS_REFERENCES.orig_system_reference%TYPE   
          ,p_iac_number IN EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE    
          ,p_party_name IN HZ_PARTIES.PARTY_NAME%TYPE    
          ,p_org_name IN AR.HZ_ORGANIZATION_PROFILES.ORGANIZATION_NAME%TYPE    
          ,p_state IN HZ_PARTIES.STATE%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR );
		  
END FAS_SHIPPER_EXTENDED_SEARCH;