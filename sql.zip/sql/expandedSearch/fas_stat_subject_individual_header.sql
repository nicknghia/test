create or replace
PACKAGE FAS_STAT_SUBJECT_INDIVIDUAL AS 
	  
PROCEDURE SEL_PARTY_NAME_BY_AUTH_KEY (
       p_auth_key      IN AR.HZ_PARTIES.attribute22%TYPE       
      ,p_ref_cursor    OUT SYS_REFCURSOR);
	  
PROCEDURE SEL_STA_BY_AUTH_KEY (
       p_auth_key      IN AR.HZ_PARTIES.attribute22%TYPE      
      ,p_ref_cursor    OUT SYS_REFCURSOR);
	  
PROCEDURE SEL_STAT_STA_BY_PARTY_ID (
       p_party_id 	   IN  AR.HZ_PARTIES.PARTY_ID%TYPE      
      ,p_ref_cursor    OUT SYS_REFCURSOR);
       
END FAS_STAT_SUBJECT_INDIVIDUAL;