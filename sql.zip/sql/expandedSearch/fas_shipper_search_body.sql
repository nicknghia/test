create or replace
PACKAGE BODY FAS_SHIPPER_SEARCH AS

  PROCEDURE SEL_REC_BY_SHIPPER_NAME (
           p_party_name IN HZ_PARTIES.PARTY_NAME%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR 
          ,total_count  OUT NUMBER
	  ,count1  OUT NUMBER
	  ,count2  OUT NUMBER) AS

  BEGIN
    hz_common_pub.disable_cont_source_security;
	
	execute immediate 'TRUNCATE TABLE xxtsa.fas_shipper_temp';
	
	INSERT INTO xxtsa.fas_shipper_temp (ORIG_SYSTEM, ORIG_SYSTEM_NAME,IAC_PARTY_ID,SHIPPER_ID, PARTY_ID, 
ORG_SHIPPER , IND_SHIPPER, ATTRIBUTE18)
SELECT hosv.ORIG_SYSTEM, hosv.ORIG_SYSTEM_NAME,HOSV.ATTRIBUTE20 IAC_PARTY_ID,
hzosr.ORIG_SYSTEM_REFERENCE, hzosr.OWNER_TABLE_ID,
SIGN(COALESCE((select OP.party_iD from HZ_ORGANIZATION_PROFILES OP
where OP.PARTY_ID=HZOSR.OWNER_TABLE_ID AND OP.ACTUAL_CONTENT_SOURCE=HOSV.ORIG_SYSTEM AND ROWNUM <= 1),0)) org_shipper,
SIGN(COALESCE((select (PP.party_id) from HZ_PERSON_PROFILES PP
where PP.PARTY_ID=HZOSR.OWNER_TABLE_ID AND PP.ACTUAL_CONTENT_SOURCE=HOSV.ORIG_SYSTEM AND ROWNUM <= 1),0)) IND_shipper,
hosv.attribute18
--sign(pp.party_id), sign(op.party_id)
FROM hz_orig_systems_vl hosv
JOIN  HZ_ORIG_SYS_REFERENCES hzosr
ON hzosr.orig_system = hosv.orig_system 
join hz_parties p
on hzosr.OWNER_TABLE_ID=p.party_id 
AND hzosr.owner_table_name = 'HZ_PARTIES'
--and hzosr.owner_table_id=45957463
AND HZOSR.STATUS='A'
and hosv.attribute18 in ('IAC','AC')
and upper(p.party_name) like p_party_name
;

OPEN p_ref_cursor FOR
SELECT * FROM 
( 
SELECT 
COALESCE((SELECT APPROVAL_NBR FROM EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE IAC 
WHERE T.IAC_PARTY_ID=IAC.PARTY_ID AND ROWNUM <= 1),'') APPROVAL_NBR, 
(case when t.org_shipper = 1 then 'SHIPPER'
           else 'INDSHIPPER' END)  AS PARTY_TYPE,
t.SHIPPER_ID, p.party_name shipper_name, P.ATTRIBUTE15, P.ATTRIBUTE5,
t.ORIG_SYSTEM AS INTERNAL_APPROVAL_NBR, 
t.ORIG_SYSTEM_NAME AS IAC_NAME,
P.ADDRESS1, P.ADDRESS2, P.CITY, P.POSTAL_CODE,
P.STATE, P.LAST_UPDATE_DATE
from xxtsa.fas_shipper_temp t
join hz_parties p
on t.PARTY_ID=p.party_id
order by last_update_date desc)
WHERE rownum<5000
;
 
SELECT COALESCE ((SELECT SUM(ORG_SHIPPER)
    FROM xxtsa.fas_shipper_temp t), 
    0) into count1 from dual;

SELECT COALESCE ((SELECT SUM(IND_SHIPPER)
    FROM xxtsa.fas_shipper_temp t), 
    0) into count2 from dual; 

total_count := count1 + count2;

  END SEL_REC_BY_SHIPPER_NAME;
--------------------------------------------------------------------------------

PROCEDURE SEL_REC_BY_SHIPPER_NAME_IAC (
           p_party_name IN HZ_PARTIES.PARTY_NAME%TYPE  
          ,p_iac_number IN EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE		   
          ,p_ref_cursor OUT SYS_REFCURSOR 
          ,total_count  OUT NUMBER
	  ,count1  OUT NUMBER
	  ,count2  OUT NUMBER) AS

  BEGIN
    hz_common_pub.disable_cont_source_security;
	
	execute immediate 'TRUNCATE TABLE xxtsa.fas_shipper_temp';
	
	INSERT INTO xxtsa.fas_shipper_temp (ORIG_SYSTEM, ORIG_SYSTEM_NAME,IAC_PARTY_ID,SHIPPER_ID, PARTY_ID, 
ORG_SHIPPER , IND_SHIPPER, ATTRIBUTE18)
SELECT hosv.ORIG_SYSTEM, hosv.ORIG_SYSTEM_NAME,HOSV.ATTRIBUTE20 IAC_PARTY_ID,
hzosr.ORIG_SYSTEM_REFERENCE, hzosr.OWNER_TABLE_ID,
SIGN(COALESCE((select OP.party_iD from HZ_ORGANIZATION_PROFILES OP
where OP.PARTY_ID=HZOSR.OWNER_TABLE_ID AND OP.ACTUAL_CONTENT_SOURCE=HOSV.ORIG_SYSTEM AND ROWNUM <= 1),0)) org_shipper,
SIGN(COALESCE((select (PP.party_id) from HZ_PERSON_PROFILES PP
where PP.PARTY_ID=HZOSR.OWNER_TABLE_ID AND PP.ACTUAL_CONTENT_SOURCE=HOSV.ORIG_SYSTEM AND ROWNUM <= 1),0)) IND_shipper,
hosv.attribute18
--sign(pp.party_id), sign(op.party_id)
FROM hz_orig_systems_vl hosv
JOIN  HZ_ORIG_SYS_REFERENCES hzosr
ON hzosr.orig_system = hosv.orig_system 
join hz_parties p
on hzosr.OWNER_TABLE_ID=p.party_id 
AND hzosr.owner_table_name = 'HZ_PARTIES'
--and hzosr.owner_table_id=45957463
AND HZOSR.STATUS='A'
and hosv.attribute18 in ('IAC','AC')
and upper(p.party_name) like p_party_name
;

OPEN p_ref_cursor FOR
SELECT * FROM 
( 
SELECT 
COALESCE((SELECT APPROVAL_NBR FROM EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE IAC 
WHERE T.IAC_PARTY_ID=IAC.PARTY_ID AND ROWNUM <= 1),'') APPROVAL_NBR, 
(case when t.org_shipper = 1 then 'SHIPPER'
           else 'INDSHIPPER' END)  AS PARTY_TYPE,
t.SHIPPER_ID, p.party_name shipper_name, P.ATTRIBUTE15, P.ATTRIBUTE5,
t.ORIG_SYSTEM AS INTERNAL_APPROVAL_NBR, 
t.ORIG_SYSTEM_NAME AS IAC_NAME,
P.ADDRESS1, P.ADDRESS2, P.CITY, P.POSTAL_CODE,
P.STATE, P.LAST_UPDATE_DATE
from xxtsa.fas_shipper_temp t
join hz_parties p
on t.PARTY_ID=p.party_id
AND (t.ORIG_SYSTEM like p_iac_number OR
((SELECT APPROVAL_NBR FROM EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE IAC 
WHERE T.IAC_PARTY_ID=IAC.PARTY_ID AND ROWNUM <= 1) like p_iac_number)
)
order by last_update_date desc)
WHERE rownum<5000
;
 
SELECT COALESCE ((SELECT SUM(ORG_SHIPPER)
    FROM xxtsa.fas_shipper_temp t), 
    0) into count1 from dual;

SELECT COALESCE ((SELECT SUM(IND_SHIPPER)
    FROM xxtsa.fas_shipper_temp t), 
    0) into count2 from dual; 

total_count := count1 + count2;

  END SEL_REC_BY_SHIPPER_NAME_IAC;

--------------------------------------------------------------------------------

  PROCEDURE SEL_REC_BY_IAC_NUMBER (
           p_iac_number IN EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR 
          ,total_count  OUT NUMBER
	  ,count1  OUT NUMBER
	  ,count2  OUT NUMBER) AS

  BEGIN

    hz_common_pub.disable_cont_source_security;
	
	execute immediate 'TRUNCATE TABLE xxtsa.fas_shipper_temp';
	
	INSERT INTO xxtsa.fas_shipper_temp (ORIG_SYSTEM, ORIG_SYSTEM_NAME,IAC_PARTY_ID,SHIPPER_ID, PARTY_ID, 
ORG_SHIPPER , IND_SHIPPER, ATTRIBUTE18)
SELECT /*+ ORDERED */ hosv.ORIG_SYSTEM, hosv.ORIG_SYSTEM_NAME,HOSV.ATTRIBUTE20 IAC_PARTY_ID,
hzosr.ORIG_SYSTEM_REFERENCE, hzosr.OWNER_TABLE_ID,
SIGN(COALESCE((select OP.party_iD from HZ_ORGANIZATION_PROFILES OP
where OP.PARTY_ID=HZOSR.OWNER_TABLE_ID AND OP.ACTUAL_CONTENT_SOURCE=HOSV.ORIG_SYSTEM AND ROWNUM <= 1),0)) org_shipper,
SIGN(COALESCE((select (PP.party_id) from HZ_PERSON_PROFILES PP
where PP.PARTY_ID=HZOSR.OWNER_TABLE_ID AND PP.ACTUAL_CONTENT_SOURCE=HOSV.ORIG_SYSTEM AND ROWNUM <= 1),0)) IND_shipper,
hosv.attribute18
--sign(pp.party_id), sign(op.party_id)
FROM hz_orig_systems_vl hosv
JOIN EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE EICP 
ON hosv.ATTRIBUTE20 = EICP.PARTY_ID
JOIN  HZ_ORIG_SYS_REFERENCES hzosr
ON hzosr.orig_system = hosv.orig_system 
AND hzosr.owner_table_name = 'HZ_PARTIES'
--and hzosr.owner_table_id=45957463
AND HZOSR.STATUS='A'
and hosv.attribute18 in ('IAC','AC')
AND (hosv.ORIG_SYSTEM LIKE p_iac_number 
    OR EICP.APPROVAL_NBR LIKE p_iac_number);
--AND UPPER(hosv.ORIG_SYSTEM) LIKE p_iac_number;
  
    OPEN p_ref_cursor FOR
SELECT * FROM 
( SELECT 
COALESCE((SELECT APPROVAL_NBR FROM EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE IAC 
WHERE T.IAC_PARTY_ID=IAC.PARTY_ID AND ROWNUM <= 1),'') APPROVAL_NBR, 
(case when t.org_shipper = 1 then 'SHIPPER'
           else 'INDSHIPPER' END)  AS PARTY_TYPE,
t.SHIPPER_ID, p.party_name shipper_name, P.ATTRIBUTE15, P.ATTRIBUTE5,
COALESCE(t.ORIG_SYSTEM, (SELECT APPROVAL_NBR FROM EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE IAC 
    WHERE T.IAC_PARTY_ID=IAC.PARTY_ID AND ROWNUM <= 1),
    '') INTERNAL_APPROVAL_NBR, 
t.ORIG_SYSTEM_NAME AS IAC_NAME,
P.ADDRESS1, P.ADDRESS2, P.CITY, P.POSTAL_CODE,
P.STATE, P.LAST_UPDATE_DATE
from xxtsa.fas_shipper_temp t
join hz_parties p
on t.PARTY_ID=p.party_id  --p.party_id=45957463
order by last_update_date desc)
WHERE rownum<5000
;
 
SELECT COALESCE ((SELECT SUM(ORG_SHIPPER)
    FROM xxtsa.fas_shipper_temp t), 
    0) into count1 from dual;

SELECT COALESCE ((SELECT SUM(IND_SHIPPER)
    FROM xxtsa.fas_shipper_temp t), 
    0) into count2 from dual; 

total_count := count1 + count2;
  
  END SEL_REC_BY_IAC_NUMBER;
  
  PROCEDURE SEL_REC_BY_IAC_SHIPPER_ID (
           p_iac_number IN EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE  
          ,p_shipper_id   IN HZ_ORIG_SYS_REFERENCES.orig_system_reference%TYPE		   
          ,p_ref_cursor OUT SYS_REFCURSOR 
          ,total_count  OUT NUMBER
	  ,count1  OUT NUMBER
	  ,count2  OUT NUMBER) AS

  BEGIN

    hz_common_pub.disable_cont_source_security;
	
	execute immediate 'TRUNCATE TABLE xxtsa.fas_shipper_temp';
	
	INSERT INTO xxtsa.fas_shipper_temp (ORIG_SYSTEM, ORIG_SYSTEM_NAME,IAC_PARTY_ID,SHIPPER_ID, PARTY_ID, 
ORG_SHIPPER , IND_SHIPPER, ATTRIBUTE18)
SELECT /*+ ORDERED */ hosv.ORIG_SYSTEM, hosv.ORIG_SYSTEM_NAME,HOSV.ATTRIBUTE20 IAC_PARTY_ID,
hzosr.ORIG_SYSTEM_REFERENCE, hzosr.OWNER_TABLE_ID,
SIGN(COALESCE((select OP.party_iD from HZ_ORGANIZATION_PROFILES OP
where OP.PARTY_ID=HZOSR.OWNER_TABLE_ID AND OP.ACTUAL_CONTENT_SOURCE=HOSV.ORIG_SYSTEM AND ROWNUM <= 1),0)) org_shipper,
SIGN(COALESCE((select (PP.party_id) from HZ_PERSON_PROFILES PP
where PP.PARTY_ID=HZOSR.OWNER_TABLE_ID AND PP.ACTUAL_CONTENT_SOURCE=HOSV.ORIG_SYSTEM AND ROWNUM <= 1),0)) IND_shipper,
hosv.attribute18
--sign(pp.party_id), sign(op.party_id)
FROM hz_orig_systems_vl hosv
JOIN EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE EICP 
ON hosv.ATTRIBUTE20 = EICP.PARTY_ID
JOIN  HZ_ORIG_SYS_REFERENCES hzosr
ON hzosr.orig_system = hosv.orig_system 
AND hzosr.owner_table_name = 'HZ_PARTIES'
--and hzosr.owner_table_id=45957463
AND HZOSR.STATUS='A'
and hosv.attribute18 in ('IAC','AC')
AND (hosv.ORIG_SYSTEM LIKE p_iac_number 
    OR EICP.APPROVAL_NBR LIKE p_iac_number)
AND UPPER(hzosr.ORIG_SYSTEM_REFERENCE) LIKE p_shipper_id;
  
    OPEN p_ref_cursor FOR
	SELECT * FROM 
( SELECT 
COALESCE((SELECT APPROVAL_NBR FROM EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE IAC 
    WHERE T.IAC_PARTY_ID=IAC.PARTY_ID AND ROWNUM <= 1),
    (t.ORIG_SYSTEM),'') APPROVAL_NBR, 
(case when t.org_shipper = 1 then 'SHIPPER'
           else 'INDSHIPPER' END)  AS PARTY_TYPE,
t.SHIPPER_ID, p.party_name shipper_name, P.ATTRIBUTE15, P.ATTRIBUTE5,
COALESCE(t.ORIG_SYSTEM, (SELECT APPROVAL_NBR FROM EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE IAC 
    WHERE T.IAC_PARTY_ID=IAC.PARTY_ID AND ROWNUM <= 1),
    '') INTERNAL_APPROVAL_NBR, 
t.ORIG_SYSTEM_NAME AS IAC_NAME,
P.ADDRESS1, P.ADDRESS2, P.CITY, P.POSTAL_CODE,
P.STATE, P.LAST_UPDATE_DATE
from xxtsa.fas_shipper_temp t
join hz_parties p
on t.PARTY_ID=p.party_id  --p.party_id=45957463
order by last_update_date desc)
WHERE rownum<5000
;
    
SELECT COALESCE ((SELECT SUM(ORG_SHIPPER)
    FROM xxtsa.fas_shipper_temp t), 
    0) into count1 from dual;

SELECT COALESCE ((SELECT SUM(IND_SHIPPER)
    FROM xxtsa.fas_shipper_temp t), 
    0) into count2 from dual; 
	
total_count := count1 + count2;
  
  END SEL_REC_BY_IAC_SHIPPER_ID;

--------------------------------------------------------------------------------
  PROCEDURE SEL_REC_BY_STATE_CODE (
           p_state IN HZ_PARTIES.STATE%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
      hz_common_pub.disable_cont_source_security;
	
    OPEN p_ref_cursor FOR
    
    SELECT hzosr.orig_system_reference AS SHIPPER_ID,
      hzop.organization_name AS SHIPPER_NAME, 'SHIPPER' AS PARTY_TYPE,
      hzop.attribute15, hzop.attribute5,  
      hzop.actual_content_source AS APPROVAL_NBR,
      HOSV.ORIG_SYSTEM_NAME AS IAC_NAME,
      HZPARTY.ADDRESS1, HZPARTY.ADDRESS2, HZPARTY.CITY, HZPARTY.POSTAL_CODE,
      HZPARTY.STATE

    FROM ar.HZ_ORGANIZATION_PROFILES hzop,
      ar.HZ_ORIG_SYS_REFERENCES hzosr,
      hz_orig_systems_vl hosv,
      AR.HZ_PARTIES HZPARTY
  
    WHERE 
          hzop.organization_type = 'KSMS_Shipper'
      AND hzop.party_id = hzosr.owner_table_id
      AND hzosr.owner_table_name = 'HZ_PARTIES'
      AND hzosr.orig_system = hzop.actual_content_source   -- testing
      and HOSV.ORIG_SYSTEM = hzop.actual_content_source
      AND hzop.party_id = HZPARTY.party_id
      AND HZPARTY.STATE =  p_state
      AND hzosr.status = 'A'

      --AND ROWNUM <= 10000    -- testing

    ORDER BY hzop.attribute15, hzosr.CREATION_DATE DESC; 

  END SEL_REC_BY_STATE_CODE;
  ------------------------------------------------------------------------------
  
  PROCEDURE SEL_SHIPPER_DETAILS_BY_ID_IAC (
           p_shipper_id   IN HZ_ORIG_SYS_REFERENCES.orig_system_reference%TYPE    
          ,p_iac_number IN EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR ) as
          
  BEGIN
    hz_common_pub.disable_cont_source_security;
	
    OPEN p_ref_cursor FOR
	
	  SELECT 
	  hzosr.orig_system_reference AS SHIPPER_ID,  HZPARTY.party_id, 
      HZPARTY.PARTY_NAME AS SHIPPER_NAME, 'SHIPPER' AS PARTY_TYPE,
      --hzop.attribute15, '' AS attribute5, 
	  HZPARTY.attribute15, '' AS attribute5,
	  (case when HOSV.ATTRIBUTE18 = 'IAC' then IAC.APPROVAL_NBR
           else '' END)  AS APPROVAL_NBR,
      HOSV.ORIG_SYSTEM_NAME AS IAC_NAME,
      HZPARTY.ADDRESS1, HZPARTY.ADDRESS2, HZPARTY.CITY, HZPARTY.POSTAL_CODE,
      HZPARTY.STATE, HZPARTY.COUNTRY, HZPARTY.EMAIL_ADDRESS, 
	  1 AS OBJECT_VERSION_NUMBER,
      HZPARTY.PRIMARY_PHONE_AREA_CODE, 
      HZPARTY.PRIMARY_PHONE_NUMBER PRIMARY_PHONE_NUMBER,
      hzosr.CREATION_DATE

    FROM HZ_ORGANIZATION_PROFILES hzop

      join HZ_ORIG_SYS_REFERENCES hzosr
        on hzop.party_id = hzosr.owner_table_id
          AND hzosr.owner_table_name = 'HZ_PARTIES'
          AND hzosr.orig_system = hzop.actual_content_source

      join hz_orig_systems_vl hosv
        on HOSV.ORIG_SYSTEM = hzop.actual_content_source

      join AR.HZ_PARTIES HZPARTY
        on hzop.party_id = HZPARTY.party_id
		and HZPARTY.attribute_category = 'KSMS SHIPPER'

      --left join AR.HZ_LOCATIONS LOC
        --on LOC.actual_content_source = hzop.actual_content_source

      --join hz_party_sites hps 
        --on hzop.party_id = hps.party_id
        --and hzop.actual_content_source = hps.actual_content_source
		
      left join EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE IAC
        on HOSV.ATTRIBUTE20=IAC.PARTY_ID

      left join hz_contact_points hcp
        on hzop.party_id = hcp.owner_table_id
          and hzop.actual_content_source = hcp.actual_content_source
          and hcp.contact_point_type = 'PHONE'
          and hcp.status = 'A'       
    WHERE 
      hzop.organization_type = 'KSMS_Shipper'
      --and hps.location_id = LOC.location_id
      AND hzosr.status = 'A'
      AND hzosr.orig_system_reference = p_shipper_id
	  AND hzop.actual_content_source = p_iac_number
	  
	UNION
	
	select hzosr.orig_system_reference AS SHIPPER_ID, PROF.PARTY_ID,
      PROF.PERSON_NAME AS SHIPPER_NAME, 'INDSHIPPER' AS PARTY_TYPE,
	  PROF.ATTRIBUTE15, '' AS ATTRIBUTE5, 
	  (case when HOSV.ATTRIBUTE18 = 'IAC' then (
	  COALESCE(
      (select IACP.APPROVAL_NBR from EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE IACP,
      hz_orig_systems_vl hosv1 where  HOSV1.ATTRIBUTE20=IACP.PARTY_ID AND  
      HOSV1.ORIG_SYSTEM = p_iac_number), p_iac_number)
	  )
           else '' END)  AS APPROVAL_NBR,
	  HOSV.ORIG_SYSTEM_NAME AS IAC_NAME, 
	  HZPARTY.ADDRESS1, HZPARTY.ADDRESS2, HZPARTY.CITY, HZPARTY.POSTAL_CODE,
      HZPARTY.STATE, HZPARTY.COUNTRY, HZPARTY.EMAIL_ADDRESS, 1 AS OBJECT_VERSION_NUMBER,
      HZPARTY.PRIMARY_PHONE_AREA_CODE, HZPARTY.PRIMARY_PHONE_NUMBER,
	  hzosr.CREATION_DATE

    from AR.HZ_PERSON_PROFILES PROF, hz_orig_systems_vl hosv,
	     AR.HZ_PARTIES HZPARTY, HZ_ORIG_SYS_REFERENCES hzosr
		 
	WHERE 
	    hzosr.orig_system_reference = p_shipper_id AND	
		HZPARTY.party_id = hzosr.owner_table_id AND
		hosv.ORIG_SYSTEM = hzosr.ORIG_SYSTEM AND
	    HZPARTY.party_id = PROF.party_id 
		--HOSV.ATTRIBUTE20=IAC.PARTY_ID
		
		order by attribute15;
      --ORDER BY LOC.OBJECT_VERSION_NUMBER;
	  
  END SEL_SHIPPER_DETAILS_BY_ID_IAC;
          
------------------------------------------------------------------------------

PROCEDURE SEL_SHIPPER_AC_DET_BY_ID_IAC (
           p_shipper_id   IN HZ_ORIG_SYS_REFERENCES.orig_system_reference%TYPE    
          ,p_iac_number IN EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR ) as
          
  BEGIN
    hz_common_pub.disable_cont_source_security;
	
    OPEN p_ref_cursor FOR
	
	  SELECT hzosr.orig_system_reference AS SHIPPER_ID,  HZPARTY.party_id, 
      HZPARTY.PARTY_NAME AS SHIPPER_NAME, 'SHIPPER' AS PARTY_TYPE,
      --hzop.attribute15, '' AS attribute5,
	  HZPARTY.attribute15, '' AS attribute5,
	  (case when HOSV.ATTRIBUTE18 = 'IAC' then IAC.APPROVAL_NBR
           else '' END)  AS APPROVAL_NBR,
      HOSV.ORIG_SYSTEM_NAME AS IAC_NAME,
      HZPARTY.ADDRESS1, HZPARTY.ADDRESS2, HZPARTY.CITY, HZPARTY.POSTAL_CODE,
      HZPARTY.STATE, HZPARTY.COUNTRY, HZPARTY.EMAIL_ADDRESS, 
	  1 AS OBJECT_VERSION_NUMBER,
      HZPARTY.PRIMARY_PHONE_AREA_CODE, 
      HZPARTY.PRIMARY_PHONE_NUMBER PRIMARY_PHONE_NUMBER,
      hzosr.CREATION_DATE

    FROM HZ_ORGANIZATION_PROFILES hzop

      join HZ_ORIG_SYS_REFERENCES hzosr
        on hzop.party_id = hzosr.owner_table_id
          AND hzosr.owner_table_name = 'HZ_PARTIES'
          AND hzosr.orig_system = hzop.actual_content_source

      join hz_orig_systems_vl hosv
        on HOSV.ORIG_SYSTEM = hzop.actual_content_source

      join AR.HZ_PARTIES HZPARTY
        on hzop.party_id = HZPARTY.party_id
		and HZPARTY.attribute_category = 'KSMS SHIPPER'

      --left join AR.HZ_LOCATIONS LOC
      --  on LOC.actual_content_source = hzop.actual_content_source

      --join hz_party_sites hps 
      --  on hzop.party_id = hps.party_id
      --  and hzop.actual_content_source = hps.actual_content_source
		
      left join EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE IAC
        on HOSV.ATTRIBUTE20=IAC.PARTY_ID

      left join hz_contact_points hcp
        on hzop.party_id = hcp.owner_table_id
          and hzop.actual_content_source = hcp.actual_content_source
          and hcp.contact_point_type = 'PHONE'
          and hcp.status = 'A'              
    WHERE 
      hzop.organization_type = 'KSMS_Shipper'
      --and hps.location_id = LOC.location_id
      AND hzosr.status = 'A'
      AND hzosr.orig_system_reference = p_shipper_id
	  
	UNION
	
	select hzosr.orig_system_reference AS SHIPPER_ID, PROF.PARTY_ID,
      PROF.PERSON_NAME AS SHIPPER_NAME, 'INDSHIPPER' AS PARTY_TYPE,
	  PROF.ATTRIBUTE15, '' AS ATTRIBUTE5, 
	  (case when HOSV.ATTRIBUTE18 = 'IAC' then p_iac_number
           else '' END)  AS APPROVAL_NBR,
	  HOSV.ORIG_SYSTEM_NAME AS IAC_NAME,
	  HZPARTY.ADDRESS1, HZPARTY.ADDRESS2, HZPARTY.CITY, HZPARTY.POSTAL_CODE,
      HZPARTY.STATE, HZPARTY.COUNTRY, HZPARTY.EMAIL_ADDRESS, 1 AS OBJECT_VERSION_NUMBER,
      HZPARTY.PRIMARY_PHONE_AREA_CODE, HZPARTY.PRIMARY_PHONE_NUMBER,
	  hzosr.CREATION_DATE

    from AR.HZ_PERSON_PROFILES PROF, hz_orig_systems_vl hosv,
	     AR.HZ_PARTIES HZPARTY, HZ_ORIG_SYS_REFERENCES hzosr
		 
	WHERE 
	    hzosr.orig_system_reference = p_shipper_id AND	
		HZPARTY.party_id = hzosr.owner_table_id AND
		hosv.ORIG_SYSTEM = hzosr.ORIG_SYSTEM AND
	    HZPARTY.party_id = PROF.party_id 
		
		order by attribute15;
      --ORDER BY LOC.OBJECT_VERSION_NUMBER;

  END SEL_SHIPPER_AC_DET_BY_ID_IAC;

------------------------------------------------------------------------------

  PROCEDURE SEL_DISP_CODE_BY_PARTY_ID (
           p_party_id IN AR.HZ_ORGANIZATION_PROFILES.PARTY_ID%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
    hz_common_pub.disable_cont_source_security;
  
    OPEN p_ref_cursor FOR
	
    --SELECT O.ORGANIZATION_NAME, O.ORGANIZATION_PROFILE_ID, B.C_EXT_ATTR4, B.C_EXT_ATTR10
    SELECT O.ORGANIZATION_NAME, O.ORGANIZATION_PROFILE_ID, '' AS C_EXT_ATTR4, B.C_EXT_ATTR10	  
    
    from AR.HZ_ORGANIZATION_PROFILES O LEFT JOIN AR.HZ_ORG_PROFILES_EXT_B B
        ON O.ORGANIZATION_PROFILE_ID = B.ORGANIZATION_PROFILE_ID
    
    where (O.PARTY_ID) = (p_party_id)
               
    order by B.LAST_UPDATE_DATE  ;
  
  END SEL_DISP_CODE_BY_PARTY_ID;

---------------------------------------------------------------------------
  PROCEDURE SEL_DISP_CODE_BY_SHIPPER_ID (
           p_shipper_id   IN HZ_ORIG_SYS_REFERENCES.orig_system_reference%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
    hz_common_pub.disable_cont_source_security;
  
    OPEN p_ref_cursor FOR
	
	  --SELECT O.ORGANIZATION_NAME, O.ORGANIZATION_PROFILE_ID, B.C_EXT_ATTR4, B.C_EXT_ATTR10 
	  SELECT O.ORGANIZATION_NAME, O.ORGANIZATION_PROFILE_ID, '' AS C_EXT_ATTR4, B.C_EXT_ATTR10
    
      from AR.HZ_ORGANIZATION_PROFILES O LEFT JOIN AR.HZ_ORG_PROFILES_EXT_B B
        ON O.ORGANIZATION_PROFILE_ID = B.ORGANIZATION_PROFILE_ID,
         HZ_ORIG_SYS_REFERENCES hzosr
      
      where 
            O.party_id = hzosr.owner_table_id
        AND hzosr.orig_system_reference = p_shipper_id
        
     order by b.LAST_UPDATE_DATE  ;
      
  END SEL_DISP_CODE_BY_SHIPPER_ID;

------------------------------------------------------------------------------


  PROCEDURE SEL_NOTES_BY_PARTY_ID (
           p_party_id IN AR.HZ_ORGANIZATION_PROFILES.PARTY_ID%TYPE     
          ,p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
     hz_common_pub.disable_cont_source_security;
	  
     OPEN p_ref_cursor FOR
	  
	   SELECT T.NOTES, T.NOTES_DETAIL, T.LAST_UPDATE_DATE, T.LAST_UPDATED_BY, U.EMAIL_ADDRESS,
       B.ENTERED_DATE, B.ATTRIBUTE4, B.ATTRIBUTE2, B.ATTRIBUTE3, B.NOTE_TYPE, B.NOTE_STATUS,  
       B.ATTRIBUTE1, B.JTF_NOTE_ID
   
     from  JTF_NOTES_TL T 
          ,JTF_NOTES_B B 
		  ,FND_USER U
     where     
         B.JTF_NOTE_ID = T.JTF_NOTE_ID 
		 and U.USER_ID = T.LAST_UPDATED_BY
         and B.NOTE_TYPE in ('KSMS_TSA_NOTE','KSMS_GENERAL_NOTE')
         and B.SOURCE_OBJECT_ID = p_party_id
         order by T.LAST_UPDATE_DATE DESC;
		 
  END SEL_NOTES_BY_PARTY_ID;

-------------------------------------------------------------------------------

  PROCEDURE SEL_REC_BY_ORGANIZATION_NAME (
           p_org_name IN AR.HZ_ORGANIZATION_PROFILES.ORGANIZATION_NAME%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR 
          ,total_count  OUT NUMBER
	  ,count1  OUT NUMBER
	  ,count2  OUT NUMBER) AS

  BEGIN

    hz_common_pub.disable_cont_source_security;
	
	execute immediate 'TRUNCATE TABLE xxtsa.fas_shipper_temp';
	
	INSERT INTO xxtsa.fas_shipper_temp (ORIG_SYSTEM, ORIG_SYSTEM_NAME,IAC_PARTY_ID,SHIPPER_ID, PARTY_ID, 
ORG_SHIPPER , IND_SHIPPER, ATTRIBUTE18)
SELECT /*+ ORDERED */ hosv.ORIG_SYSTEM, hosv.ORIG_SYSTEM_NAME,HOSV.ATTRIBUTE20 IAC_PARTY_ID,
hzosr.ORIG_SYSTEM_REFERENCE, hzosr.OWNER_TABLE_ID,
SIGN(COALESCE((select OP.party_iD from HZ_ORGANIZATION_PROFILES OP
where OP.PARTY_ID=HZOSR.OWNER_TABLE_ID AND OP.ACTUAL_CONTENT_SOURCE=HOSV.ORIG_SYSTEM AND ROWNUM <= 1),0)) org_shipper,
SIGN(COALESCE((select (PP.party_id) from HZ_PERSON_PROFILES PP
where PP.PARTY_ID=HZOSR.OWNER_TABLE_ID AND PP.ACTUAL_CONTENT_SOURCE=HOSV.ORIG_SYSTEM AND ROWNUM <= 1),0)) IND_shipper,
hosv.attribute18
--sign(pp.party_id), sign(op.party_id)
FROM hz_orig_systems_vl hosv
JOIN  HZ_ORIG_SYS_REFERENCES hzosr
ON hzosr.orig_system = hosv.orig_system 
AND hzosr.owner_table_name = 'HZ_PARTIES'
--and hzosr.owner_table_id=45957463
AND HZOSR.STATUS='A'
and hosv.attribute18 in ('IAC','AC')
AND UPPER(HOSV.ORIG_SYSTEM_NAME) LIKE p_org_name;

-- commit;

   OPEN p_ref_cursor FOR  
SELECT * FROM 
( SELECT 
COALESCE((SELECT APPROVAL_NBR FROM EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE IAC 
WHERE T.IAC_PARTY_ID=IAC.PARTY_ID AND ROWNUM <= 1),'') APPROVAL_NBR, 
(case when t.org_shipper = 1 then 'SHIPPER'
           else 'INDSHIPPER' END)  AS PARTY_TYPE,
t.SHIPPER_ID, p.party_name shipper_name, P.ATTRIBUTE15, P.ATTRIBUTE5,
t.ORIG_SYSTEM AS INTERNAL_APPROVAL_NBR, 
t.ORIG_SYSTEM_NAME AS IAC_NAME,
P.ADDRESS1, P.ADDRESS2, P.CITY, P.POSTAL_CODE,
P.STATE, P.LAST_UPDATE_DATE
from xxtsa.fas_shipper_temp t
join hz_parties p
on t.PARTY_ID=p.party_id  --p.party_id=45957463
order by last_update_date desc)
WHERE rownum<5000
;
    
SELECT COALESCE ((SELECT SUM(ORG_SHIPPER)
    FROM xxtsa.fas_shipper_temp t), 
    0) into count1 from dual;

SELECT COALESCE ((SELECT SUM(IND_SHIPPER)
    FROM xxtsa.fas_shipper_temp t), 
    0) into count2 from dual;
	
total_count := count1 + count2;

  END SEL_REC_BY_ORGANIZATION_NAME;
  
  PROCEDURE SEL_REC_BY_ORG_NAME_SHIPPER_ID (
           p_org_name IN AR.HZ_ORGANIZATION_PROFILES.ORGANIZATION_NAME%TYPE 
          ,p_shipper_id   IN HZ_ORIG_SYS_REFERENCES.orig_system_reference%TYPE		   
          ,p_ref_cursor OUT SYS_REFCURSOR 
          ,total_count  OUT NUMBER
	  ,count1  OUT NUMBER
	  ,count2  OUT NUMBER) AS

  BEGIN

    hz_common_pub.disable_cont_source_security;
	
	execute immediate 'TRUNCATE TABLE xxtsa.fas_shipper_temp';
	
	INSERT INTO xxtsa.fas_shipper_temp (ORIG_SYSTEM, ORIG_SYSTEM_NAME,IAC_PARTY_ID,SHIPPER_ID, PARTY_ID, 
ORG_SHIPPER , IND_SHIPPER, ATTRIBUTE18)
SELECT /*+ ORDERED */ hosv.ORIG_SYSTEM, hosv.ORIG_SYSTEM_NAME,HOSV.ATTRIBUTE20 IAC_PARTY_ID,
hzosr.ORIG_SYSTEM_REFERENCE, hzosr.OWNER_TABLE_ID,
SIGN(COALESCE((select OP.party_iD from HZ_ORGANIZATION_PROFILES OP
where OP.PARTY_ID=HZOSR.OWNER_TABLE_ID AND OP.ACTUAL_CONTENT_SOURCE=HOSV.ORIG_SYSTEM AND ROWNUM <= 1),0)) org_shipper,
SIGN(COALESCE((select (PP.party_id) from HZ_PERSON_PROFILES PP
where PP.PARTY_ID=HZOSR.OWNER_TABLE_ID AND PP.ACTUAL_CONTENT_SOURCE=HOSV.ORIG_SYSTEM AND ROWNUM <= 1),0)) IND_shipper,
hosv.attribute18
--sign(pp.party_id), sign(op.party_id)
FROM hz_orig_systems_vl hosv
JOIN  HZ_ORIG_SYS_REFERENCES hzosr
ON hzosr.orig_system = hosv.orig_system 
AND hzosr.owner_table_name = 'HZ_PARTIES'
--and hzosr.owner_table_id=45957463
AND HZOSR.STATUS='A'
and hosv.attribute18 in ('IAC','AC')
AND UPPER(HOSV.ORIG_SYSTEM_NAME) LIKE p_org_name
AND upper(hzosr.orig_system_reference) like upper(p_shipper_id);

-- commit;

   OPEN p_ref_cursor FOR  
SELECT * FROM 
(SELECT
COALESCE((SELECT APPROVAL_NBR FROM EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE IAC 
WHERE T.IAC_PARTY_ID=IAC.PARTY_ID AND ROWNUM <= 1),'') APPROVAL_NBR, 
(case when t.org_shipper = 1 then 'SHIPPER'
           else 'INDSHIPPER' END)  AS PARTY_TYPE,
t.SHIPPER_ID, p.party_name shipper_name, P.ATTRIBUTE15, P.ATTRIBUTE5,
t.ORIG_SYSTEM AS INTERNAL_APPROVAL_NBR, 
t.ORIG_SYSTEM_NAME AS IAC_NAME,
P.ADDRESS1, P.ADDRESS2, P.CITY, P.POSTAL_CODE,
P.STATE, P.LAST_UPDATE_DATE
from xxtsa.fas_shipper_temp t
join hz_parties p
on t.PARTY_ID=p.party_id  --p.party_id=45957463
order by last_update_date desc)
WHERE rownum<5000
;

SELECT COALESCE ((SELECT SUM(ORG_SHIPPER)
    FROM xxtsa.fas_shipper_temp t), 
    0) into count1 from dual;

SELECT COALESCE ((SELECT SUM(IND_SHIPPER)
    FROM xxtsa.fas_shipper_temp t), 
    0) into count2 from dual;
	
total_count := count1 + count2;

  END SEL_REC_BY_ORG_NAME_SHIPPER_ID;

-------------------------------------------------------------------------------

END FAS_SHIPPER_SEARCH;

-- GRANT EXECUTE on FAS_SHIPPER_SEARCH TO SVC_KSMS_FASREADONLYAPP;
-- GRANT EXECUTE on FAS_SHIPPER_SEARCH TO "svc-ksms-fasroapp";
-- Grant all on xxtsa.fas_shipper_temp  to "svc-ksms-fasroapp"; 