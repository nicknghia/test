create or replace
PACKAGE BODY FAS_SUBJECT_COMPANY AS

---------------------------------------------------------------------------------------------
  
  PROCEDURE SEL_REC_BY_NAME_SUMMARY_PAGE (
            p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
    OPEN p_ref_cursor FOR 
  
    select P.PARTY_NAME AS NAME, F.APPROVAL_NBR AS ID, 'IAC' AS TYPE,
        EXT.IACMS_STATUS_CODE AS STATUS, P.STATE, P.Party_Id, 0 AS OBJECT_ID
        
      from AR.HZ_PARTIES P, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE F,  IACMS_IAC_PROFILE_EXTENSIONS EXT
      where P.PARTY_ID = F.PARTY_ID  
      AND P.PARTY_ID = EXT.PARTY_ID
      AND (EXT.IACMS_STATUS_CODE 
      IN ('ACTIVE','INACTIVE','NEEDSREVIEW','RENEWREQUEST','RENEWREQUIRE', 'APPREQUEST'))
      AND UPPER(P.PARTY_NAME) like p_name 
      
    union
      SELECT distinct P.PARTY_NAME as NAME, '' as ID, 'AC' as TYPE, F.ACTIVE_FLAG as STATUS, P.STATE, P.Party_Id, 0 as OBJECT_ID
  
      FROM AR.HZ_PARTIES P,   EGOV_SCHEMA.EGOV_CARRIER_PROFILE F
      WHERE 
        P.PARTY_ID = F.PARTY_ID    AND 
        UPPER(P.PARTY_NAME) like p_name
        AND F.ACTIVE_FLAG in ('Y', 'N')
  
    union
      SELECT P.PARTY_NAME as NAME, PROFILE.APPROVAL_NBR as ID, 'STA' as TYPE, F.ACTIVE_FLAG as STATUS, P.STATE, P.Party_Id, R.OBJECT_ID   
      
      FROM EGOV_SCHEMA.EGOV_INDIRECT_STATION F, AR.HZ_PARTIES P, 
      AR.HZ_RELATIONSHIPS R , AR.HZ_PARTIES P2, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE PROFILE
     
      WHERE F.party_id  = p.party_id AND R.RELATIONSHIP_TYPE = 'INDIRECT_CARRIER_STATION' 
      AND  R.DIRECTIONAL_FLAG = 'F' AND R.SUBJECT_ID = P.PARTY_ID 
  --    AND R.RELATIONSHIP_CODE = 'SEC_CONTACT' AND R.SUBJECT_ID = P.PARTY_ID     
      AND NVL(R.END_DATE, SYSDATE + 1) > sysdate 
      AND R.OBJECT_ID = P2.PARTY_ID 
      AND PROFILE.PARTY_ID = P2.PARTY_ID     
      AND UPPER(P.PARTY_NAME) like p_name
      AND F.ACTIVE_FLAG in ('Y', 'N')
  
    union
      SELECT 	
        PARTY.PARTY_NAME AS NAME, INDIRECT_AGENT_PROFILE.AGENT_ID as ID, 'AGENT' AS TYPE,
        INDIRECT_AGENT_PROFILE.ACTIVE_FLAG as STATUS, 
        PARTY.STATE, party.Party_Id, 0 as OBJECT_ID
      FROM  AR.HZ_PARTIES PARTY, EGOV_IAC.IACMS_INDIRECT_AGENT INDIRECT_AGENT_PROFILE     
      WHERE indirect_agent_profile.party_id  = party.party_id                           
        AND UPPER (PARTY.PARTY_NAME ) like p_name
        AND INDIRECT_AGENT_PROFILE.ACTIVE_FLAG IN ('Y', 'N')
        
     ORDER BY TYPE ASC, STATUS ASC    
     ;
	
  END SEL_REC_BY_NAME_SUMMARY_PAGE;
-----------------------begin nick
---------------------------------------------------------------------------------------------
  
  PROCEDURE SEL_REC_BY_NAME_SUMMARY_1 (
            p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
    OPEN p_ref_cursor FOR 
  
    select P.PARTY_NAME AS NAME, F.APPROVAL_NBR AS ID, 'IAC' AS TYPE,
        EXT.IACMS_STATUS_CODE AS STATUS, P.STATE, P.Party_Id, 0 AS OBJECT_ID
        
      from AR.HZ_PARTIES P, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE F,  IACMS_IAC_PROFILE_EXTENSIONS EXT
      where P.PARTY_ID = F.PARTY_ID  
      AND P.PARTY_ID = EXT.PARTY_ID
      AND (EXT.IACMS_STATUS_CODE 
      IN ('ACTIVE','INACTIVE','NEEDSREVIEW','RENEWREQUEST','RENEWREQUIRE', 'APPREQUEST'))
      AND UPPER(P.PARTY_NAME) like p_name 
      
     ORDER BY STATUS ASC;
	
  END SEL_REC_BY_NAME_SUMMARY_1;

---------------------------------------------------------------------------------------------
  
  PROCEDURE SEL_REC_BY_NAME_SUMMARY_2 (
            p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
    OPEN p_ref_cursor FOR 
  
      SELECT distinct P.PARTY_NAME as NAME, '' as ID, 'AC' as TYPE, F.ACTIVE_FLAG as STATUS, P.STATE, P.Party_Id, 0 as OBJECT_ID
  
      FROM AR.HZ_PARTIES P,   EGOV_SCHEMA.EGOV_CARRIER_PROFILE F
      WHERE 
        P.PARTY_ID = F.PARTY_ID    AND 
        UPPER(P.PARTY_NAME) like p_name
  
         --ORDER BY STATUS ASC;
         ORDER BY STATUS DESC;
	
  END SEL_REC_BY_NAME_SUMMARY_2;

---------------------------------------------------------------------------------------------
  
  PROCEDURE SEL_REC_BY_NAME_SUMMARY_3 (
            p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
    OPEN p_ref_cursor FOR 
  
      SELECT P.PARTY_NAME as NAME, PROFILE.APPROVAL_NBR as ID, 'STA' as TYPE, F.ACTIVE_FLAG as STATUS, P.STATE, P.Party_Id, R.OBJECT_ID   
      
      FROM EGOV_SCHEMA.EGOV_INDIRECT_STATION F, AR.HZ_PARTIES P, 
      AR.HZ_RELATIONSHIPS R , AR.HZ_PARTIES P2, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE PROFILE
     
      WHERE F.party_id  = p.party_id AND R.RELATIONSHIP_TYPE = 'INDIRECT_CARRIER_STATION' 
      AND  R.DIRECTIONAL_FLAG = 'F' AND R.SUBJECT_ID = P.PARTY_ID 
  --    AND R.RELATIONSHIP_CODE = 'SEC_CONTACT' AND R.SUBJECT_ID = P.PARTY_ID     
      AND NVL(R.END_DATE, SYSDATE + 1) > sysdate 
      AND R.OBJECT_ID = P2.PARTY_ID 
      AND PROFILE.PARTY_ID = P2.PARTY_ID     
      AND UPPER(P.PARTY_NAME) like p_name
      AND F.ACTIVE_FLAG in ('Y', 'N')
  
     ORDER BY STATUS ASC;
	
  END SEL_REC_BY_NAME_SUMMARY_3;

---------------------------------------------------------------------------------------------
  
  PROCEDURE SEL_REC_BY_NAME_SUMMARY_4 (
            p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
    OPEN p_ref_cursor FOR 
  
      SELECT 	
        PARTY.PARTY_NAME AS NAME, INDIRECT_AGENT_PROFILE.AGENT_ID as ID, 'AGENT' AS TYPE,
        INDIRECT_AGENT_PROFILE.ACTIVE_FLAG as STATUS, PARTY.STATE, party.Party_Id, 0 as OBJECT_ID
      FROM  AR.HZ_PARTIES PARTY, EGOV_IAC.IACMS_INDIRECT_AGENT INDIRECT_AGENT_PROFILE
      WHERE indirect_agent_profile.party_id  = party.party_id 
        AND UPPER (PARTY.PARTY_NAME ) like p_name
        
     --ORDER BY STATUS ASC;
     ORDER BY STATUS DESC;
	
  END SEL_REC_BY_NAME_SUMMARY_4;

---- end Nick ------------------------
---- Tracy edited  
PROCEDURE SEL_REC_BY_IAC_NAME_SUM_PAGE(
             	p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE, 
          P_begin_idx   in number,
        	P_end_idx   in number,
	p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
    OPEN p_ref_cursor FOR 
        Select * from (select a.*, rownum rnum from
(select P.PARTY_NAME AS NAME, F.APPROVAL_NBR AS ID, 'IAC' AS TYPE, EXT.IACMS_STATUS_CODE AS STATUS,
P.STATE, P.Party_Id, 0 AS OBJECT_ID
from AR.HZ_PARTIES P, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE F,  IACMS_IAC_PROFILE_EXTENSIONS EXT
      	where P.PARTY_ID = F.PARTY_ID  
      AND P.PARTY_ID = EXT.PARTY_ID
      AND (EXT.IACMS_STATUS_CODE 
      IN ('ACTIVE','INACTIVE','NEEDSREVIEW','RENEWREQUEST','RENEWREQUIRE', 'APPREQUEST'))
      AND UPPER(P.PARTY_NAME) like p_name
      ORDER BY TYPE ASC, STATUS ASC
) a
where rownum <=  p_end_idx
    ) where rnum > p_begin_idx;
  END  SEL_REC_BY_IAC_NAME_SUM_PAGE;

-------
PROCEDURE SEL_REC_BY_AC_NAME_SUM_PAGE(
             	p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE, 
				P_begin_idx   in number,
				P_end_idx   in number,
				p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
    OPEN p_ref_cursor FOR 
        select * from (select a.*, rownum rnum from
			(select distinct P.PARTY_NAME as NAME, '' as ID, 'AC' as TYPE, F.ACTIVE_FLAG as STATUS, P.STATE, P.Party_Id, 0 as OBJECT_ID
			 from AR.HZ_PARTIES P,   EGOV_SCHEMA.EGOV_CARRIER_PROFILE F
			 where  P.PARTY_ID = F.PARTY_ID
					AND UPPER(P.PARTY_NAME) like p_name
					--ORDER BY TYPE ASC, STATUS ASC) a
          ORDER BY TYPE ASC, STATUS DESC) a
		where rownum <=  p_end_idx
			) where rnum > p_begin_idx;
END  SEL_REC_BY_AC_NAME_SUM_PAGE;

------------------------

PROCEDURE SEL_REC_BY_STA_NAME_SUM_PAGE(
             	p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE, 
				P_begin_idx   in number,
				P_end_idx   in number,
				p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
    OPEN p_ref_cursor FOR 
        select * from (select a.*, rownum rnum from
		    (select P.PARTY_NAME as NAME, PROFILE.APPROVAL_NBR as ID, 'STA' as TYPE, F.ACTIVE_FLAG as STATUS, P.STATE, P.Party_Id, R.OBJECT_ID   
			from EGOV_SCHEMA.EGOV_INDIRECT_STATION F, AR.HZ_PARTIES P, AR.HZ_RELATIONSHIPS R , AR.HZ_PARTIES P2, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE PROFILE
			where F.party_id  = p.party_id AND R.RELATIONSHIP_TYPE = 'INDIRECT_CARRIER_STATION' 
					AND  R.DIRECTIONAL_FLAG = 'F' AND R.SUBJECT_ID = P.PARTY_ID 
			  --    AND R.RELATIONSHIP_CODE = 'SEC_CONTACT' AND R.SUBJECT_ID = P.PARTY_ID     
				  AND NVL(R.END_DATE, SYSDATE + 1) > sysdate 
				  AND R.OBJECT_ID = P2.PARTY_ID 
				  AND PROFILE.PARTY_ID = P2.PARTY_ID     
				  AND UPPER(P.PARTY_NAME) like p_name
				  AND F.ACTIVE_FLAG in ('Y', 'N')
				  ORDER BY TYPE ASC, STATUS ASC
				  )a
		where rownum <=  p_end_idx
    ) where rnum > p_begin_idx;
END  SEL_REC_BY_STA_NAME_SUM_PAGE;
			  
-------------------------

PROCEDURE SEL_REC_BY_AGT_NAME_SUM_PAGE(
             	p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE, 
				P_begin_idx   in number,
				P_end_idx   in number,
				p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
    OPEN p_ref_cursor FOR 
        select * from (select a.*, rownum rnum from
		(select PARTY.PARTY_NAME AS NAME, INDIRECT_AGENT_PROFILE.AGENT_ID as ID, 'AGENT' AS TYPE, 
    INDIRECT_AGENT_PROFILE.ACTIVE_FLAG as STATUS, 
    PARTY.STATE, party.Party_Id, 0 as OBJECT_ID
		 from  AR.HZ_PARTIES PARTY, EGOV_IAC.IACMS_INDIRECT_AGENT INDIRECT_AGENT_PROFILE
		 where indirect_agent_profile.party_id  = party.party_id 
				AND UPPER (PARTY.PARTY_NAME ) like p_name
				--ORDER BY TYPE ASC, STATUS ASC
        ORDER BY TYPE ASC, STATUS DESC
		) a
			where rownum <=  p_end_idx
		) where rnum > p_begin_idx;
END  SEL_REC_BY_AGT_NAME_SUM_PAGE;	
  
  
  
  ----------- Tracy ended edited
-- unused
  PROCEDURE SEL_REC_BY_SC_IAC_DET (
          p_name IN  AR.HZ_PARTIES.PARTY_NAME%TYPE          		   
         ,p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
     OPEN p_ref_cursor FOR
	  select P.PARTY_NAME, P.PARTY_ID, P.STATUS, P.ADDRESS1, P.ADDRESS2, P.CITY, P.POSTAL_CODE, 
    P.STATE, K.PHONE_NUMBER, K.FIRST_NAME, K.LAST_NAME, K.DESIGNATION, K.COORDINATOR_ID, 
    K.EMAIL_ADDRESS, K.USERNAME, K.TITLE,
    G.KNOWN_AS, G.KNOWN_AS2, G.KNOWN_AS3,
    EXT.EIN_NBR, EXT.APPROVED_SIC_CODE SIC_CODE,
    F.APPROVAL_NBR, F.ACTIVE_FLAG, F.LAST_RENEWAL_DT, F.APPROVING_AGT, F.APPROVAL_DT, F.NEXT_EXPIRATION_DT,
    F.COMMENTS,
    EXT.IACMS_STATUS_CODE IAC_STATUS
  from AR.HZ_PARTIES P, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE F, 
       IACMS_IAC_PROFILE_EXTENSIONS EXT, EGOV_IAC.IAC_PROPOSED_SC_VALUES K,
       AR.HZ_ORGANIZATION_PROFILES G
  where P.PARTY_ID = F.PARTY_ID  
    AND P.PARTY_ID = EXT.PARTY_ID
    AND P.PARTY_ID = K.IAC_PARTY_ID
    AND F.PARTY_ID = G.PARTY_ID
    AND F.PARTY_ID = EXT.PARTY_ID

    AND (EXT.IACMS_STATUS_CODE 
    IN ('ACTIVE','INACTIVE','NEEDSREVIEW','RENEWREQUEST','RENEWREQUIRE', 'APPREQUEST'))
    AND UPPER(P.PARTY_NAME) = p_name
    AND ROWNUM <= 1;
    --ORDER BY K.DESIGNATION DESC;
    
  END SEL_REC_BY_SC_IAC_DET;

  ---------------------------------------------------------------------------------------------
  
  PROCEDURE SEL_REC_BY_SC_AC_DET (
           p_id  IN  AR.HZ_PARTIES.PARTY_ID%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
    OPEN p_ref_cursor FOR  
      SELECT P.PARTY_NAME , P.PARTY_ID, P.ADDRESS1, P.ADDRESS2, P.CITY, P.POSTAL_CODE,  P.STATE
       ,'' as PHONE_NUMBER, P.PERSON_FIRST_NAME as FIRST_NAME, P.PERSON_LAST_NAME as LAST_NAME, P.ATTRIBUTE1 as DESIGNATION, '' as COORDINATOR_ID,   '' as EMAIL_ADDRESS  
      FROM AR.HZ_PARTIES P
      WHERE  
        P.PARTY_ID = p_id
        AND ROWNUM <= 1;

  END SEL_REC_BY_SC_AC_DET;

  ---------------------------------------------------------------------------------------------
   PROCEDURE SEL_REC_BY_SC_AGT_DET (
           p_id  IN  AR.HZ_PARTIES.PARTY_ID%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
    OPEN p_ref_cursor FOR    
    
    
    SELECT 	
      PARTY.PARTY_NAME, INDIRECT_AGENT_PROFILE.AGENT_ID, 'AGENT' AS TYPE,
      INDIRECT_AGENT_PROFILE.ACTIVE_FLAG as STATUS, 
      PARTY.ADDRESS1, PARTY.ADDRESS2, PARTY.CITY, PARTY.STATE, PARTY.POSTAL_CODE
 
    FROM  AR.HZ_PARTIES PARTY, EGOV_IAC.IACMS_INDIRECT_AGENT INDIRECT_AGENT_PROFILE
	    
    WHERE indirect_agent_profile.party_id  = party.party_id 
      AND PARTY.PARTY_ID = p_id

	  AND ROWNUM <= 1;
 
  END SEL_REC_BY_SC_AGT_DET;
  

  ---------------------------------------------------------------------------------------------

  PROCEDURE SEL_REC_BY_SC_AGT_CONTACTS (
           p_id  IN  AR.HZ_PARTIES.PARTY_ID%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
    OPEN p_ref_cursor FOR    
    
    
    SELECT P.PERSON_FIRST_NAME FIRST_NAME,P.PERSON_LAST_NAME LAST_NAME,
     P.ATTRIBUTE2 AS USERNAME, P.EMAIL_ADDRESS EMAIL,
    '('||P.PRIMARY_PHONE_AREA_CODE||') '|| P.PRIMARY_PHONE_NUMBER PHONE 
    FROM   AR.HZ_RELATIONSHIPS R, AR.HZ_PARTIES P 
    WHERE  R.RELATIONSHIP_CODE = 'AGENT_AUTH_REP_FOR' AND    R.STATUS = 'A' 
    AND    NVL(R.END_DATE, SYSDATE) >= SYSDATE AND    R.SUBJECT_ID = P.PARTY_ID 
    --AND ROWNUM <= 400 -- performance
    AND  R.OBJECT_ID = (
      SELECT PARTY_ID FROM AR.HZ_PARTIES
      WHERE P.PARTY_ID = p_id
    );
 
  END SEL_REC_BY_SC_AGT_CONTACTS;
  
  ---------------------------------------------------------------------------------------------

  PROCEDURE SEL_REC_FOR_SC_AGT_ASSOC_IAC (
           p_id  IN  AR.HZ_PARTIES.PARTY_ID%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
    OPEN p_ref_cursor FOR    
/*    for SMA only ?
    SELECT DISTINCT PARTY.PARTY_ID, PARTY.PARTY_NAME, PROFILE.APPROVAL_NBR IAC_NUMBER, 
       iac_party.PARTY_NAME AS IAC_NAME,
       iac_party.CITY AS CITY, iac_party.STATE AS STATE, EXT.IACMS_STATUS_CODE AS STATUS,
       PROFILE.NEXT_EXPIRATION_DT EXPIRED_DATE

        FROM  AR.HZ_PARTIES PARTY, AR.HZ_RELATIONSHIPS CARRIER_AFFILIATE , 
        AR.HZ_PARTIES iac_party, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE PROFILE , 
        EGOV_IAC.IACMS_IAC_PROFILE_EXTENSIONS EXT, EGOV_IAC.IACMS_INDIRECT_AGENT INDIRECT_AGENT_PROFILE 

        WHERE indirect_agent_profile.party_id  = party.party_id 
        AND CARRIER_AFFILIATE.RELATIONSHIP_CODE = 'INDIRECT_AGENT_FOR' 
        AND CARRIER_AFFILIATE.SUBJECT_ID = PARTY.PARTY_ID AND INDIRECT_AGENT_PROFILE.PARTY_ID = PARTY.PARTY_ID 
        AND CARRIER_AFFILIATE.OBJECT_ID = iac_party.PARTY_ID AND iac_party.PARTY_ID = EXT.PARTY_ID 
        AND PROFILE.PARTY_ID = iac_party.PARTY_ID  

        AND INDIRECT_AGENT_PROFILE.AGENT_ID =(
        SELECT INDIRECT_AGENT_PROFILE.AGENT_ID
           FROM AR.HZ_PARTIES PARTY, EGOV_IAC.IACMS_INDIRECT_AGENT INDIRECT_AGENT_PROFILE
           WHERE INDIRECT_AGENT_PROFILE.PARTY_ID = PARTY.PARTY_ID
      AND PARTY.PARTY_ID = p_id );
*/

  SELECT PARTY.PARTY_ID, iac_party.PARTY_NAME AS IAC_NAME, PROFILE.APPROVAL_NBR as IAC_NUMBER, iac_party.CITY, iac_party.STATE,
    EXT.IACMS_STATUS_CODE AS STATUS, PROFILE.NEXT_EXPIRATION_DT as EXPIRED_DATE

      FROM  AR.HZ_PARTIES PARTY, AR.HZ_RELATIONSHIPS CARRIER_AFFILIATE , AR.HZ_PARTIES iac_party, 
      EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE PROFILE , EGOV_IAC.IACMS_IAC_PROFILE_EXTENSIONS EXT, 
      EGOV_IAC.IACMS_INDIRECT_AGENT INDIRECT_AGENT_PROFILE 
      
      WHERE 
      CARRIER_AFFILIATE.RELATIONSHIP_CODE = 'INDIRECT_AGENT_FOR' 
      and indirect_agent_profile.party_id  = party.party_id
      AND CARRIER_AFFILIATE.SUBJECT_ID = PARTY.PARTY_ID 
      AND CARRIER_AFFILIATE.OBJECT_ID = iac_party.PARTY_ID 
      AND iac_party.PARTY_ID = EXT.PARTY_ID 
      AND PROFILE.PARTY_ID = iac_party.PARTY_ID  
      and party.party_id = p_id 
      --AND ROWNUM <= 200 -- performance
      ORDER BY  EXT.IACMS_STATUS_CODE;
  
 
  END SEL_REC_FOR_SC_AGT_ASSOC_IAC;
  
 
  ---------------------------------------------------------------------------------------------
  PROCEDURE SEL_REC_FOR_SC_AGT_STA (
           p_id  IN  AR.HZ_PARTIES.PARTY_ID%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR ) AS
  BEGIN
    OPEN p_ref_cursor FOR    

    SELECT DISTINCT SEARCH.STA_ID, SEARCH.FIRST_NAME, SEARCH.LAST_NAME, 
      CERT.CREATION_DATE, CERT.ISSUED_ON_DATE, CERT.EXPIRES_ON_DATE,
      HZPARTY.STATUS, SEARCH.AGENT_ACTIVE_FLAG RECORD_STATUS, SEARCH.APPLICATION_STATUS

    FROM (EGOV_IAC.STA_AGENT_ASSOC_SEARCH ) search,    
      AR.HZ_CERTIFICATIONS CERT,
	  AR.HZ_PARTIES HZPARTY
	where SEARCH.APPLICANT_PARTY_ID = CERT.party_id and search.AGENT_PARTY_ID = p_id and
	  HZPARTY.PARTY_ID = CERT.PARTY_ID 
      --AND ROWNUM <= 200 -- performance
    ORDER BY  HZPARTY.STATUS, CERT.CREATION_DATE DESC;
 
 
  END SEL_REC_FOR_SC_AGT_STA;
 
  ---------------------------------------------------------------------------------------------
  PROCEDURE SEL_REC_BY_STATION_DET (
           p_id  IN  AR.HZ_PARTIES.PARTY_ID%TYPE          		   
           , p_cursor_1 OUT SYS_REFCURSOR 
           , p_cursor_2 OUT SYS_REFCURSOR 
           , p_cursor_3 OUT SYS_REFCURSOR ) AS
  BEGIN
 
    -- profile
    OPEN p_cursor_1 FOR    
  
    SELECT P.PARTY_ID, P.PARTY_NAME, P.STATE, ICP.APPROVAL_NBR, F.ACTIVE_FLAG,
      P.ADDRESS1, P.ADDRESS2, P.CITY, P.POSTAL_CODE, P2.PARTY_NAME AS IAC_NAME,  ICP.APPROVAL_NBR as IAC_NUMBER,
      K.FIRST_NAME, K.LAST_NAME, K.EMAIL_ADDRESS, K.PHONE_NUMBER 
      , F.COMMENTS
    
    FROM EGOV_SCHEMA.EGOV_INDIRECT_STATION F, AR.HZ_PARTIES P, 
    AR.HZ_RELATIONSHIPS R , AR.HZ_PARTIES P2, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE ICP,
    EGOV_IAC.IAC_PROPOSED_SC_VALUES K
    ,EGOV_IAC.IACMS_IAC_PROFILE_EXTENSIONS X 
   
    WHERE F.party_id  = p.party_id AND R.RELATIONSHIP_TYPE = 'INDIRECT_CARRIER_STATION' 
      AND  R.DIRECTIONAL_FLAG = 'F' 
      AND R.SUBJECT_ID = P.PARTY_ID 
      AND R.OBJECT_ID = P2.PARTY_ID 
      AND P2.PARTY_ID = X.PARTY_ID 
      AND ICP.PARTY_ID = P2.PARTY_ID  
      AND P.PARTY_ID = K.IAC_PARTY_ID 
      AND P.PARTY_ID = p_id
    
      AND ROWNUM < 2;

      --airport
    OPEN p_cursor_2 FOR

    SELECT P.PARTY_NAME as AIRPORT_NAME, P.ATTRIBUTE1 as AIRPORT_ABBR
    FROM AR.HZ_PARTIES P
    WHERE P.PARTY_ID = (
    select  R.subject_id 
      from AR.HZ_RELATIONSHIPS R
      where R.object_id = p_id
        AND R.SUBJECT_TYPE = 'ORGANIZATION' 
        AND R.RELATIONSHIP_TYPE = 'INDIRECT_FACILITY_STATION'
        AND R.STATUS = 'A'
        AND ROWNUM < 2
     );      
   -- contacts 

    OPEN p_cursor_3 FOR
        SELECT OWNER_TABLE_ID, PHONE_AREA_CODE, PHONE_LINE_TYPE, CONTACT_POINT_TYPE, PHONE_NUMBER, 
        EMAIL_ADDRESS, PRIMARY_FLAG, PHONE_EXTENSION, RAW_PHONE_NUMBER, PHONE_COUNTRY_CODE, STATUS, 
        CONTACT_POINT_ID, URL, EMAIL_FORMAT, CONTACT_POINT_PURPOSE 
        FROM AR.HZ_CONTACT_POINTS WHERE OWNER_TABLE_ID = (
          SELECT OBJECT_ID 
            FROM AR.HZ_RELATIONSHIPS 
            WHERE (RELATIONSHIP_CODE = 'SEC_CONTACT') AND (SUBJECT_ID = p_id) AND ROWNUM < 2);
        
  
  END SEL_REC_BY_STATION_DET;
  
---------------------------------------------------------------------------------------------
  

PROCEDURE SEL_CONTACTS_BY_PARTY_ID (
           p_id  IN  AR.HZ_PARTIES.PARTY_ID%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR ) AS
BEGIN
    OPEN p_ref_cursor FOR    
/*    
  select
        p.PERSON_FIRST_NAME, p.PERSON_MIDDLE_NAME, p.PERSON_LAST_NAME ,
        C.OWNER_TABLE_ID, c.PHONE_AREA_CODE, c.PHONE_LINE_TYPE, c.CONTACT_POINT_TYPE, c.PHONE_NUMBER, 
        c.EMAIL_ADDRESS, c.PHONE_COUNTRY_CODE 
        FROM AR.HZ_CONTACT_POINTS C, AR.HZ_PARTIES p WHERE p.PARTY_ID = c.owner_table_id and c.OWNER_TABLE_ID = (select object_id from 
          (SELECT OBJECT_ID 
            FROM AR.HZ_RELATIONSHIPS 
            WHERE RELATIONSHIP_CODE = 'SEC_CONTACT' AND SUBJECT_ID = p_id and end_date > sysdate  ORDER BY LAST_UPDATE_DATE DESC  ) where rownum = 1);  
*/
    select
        p.PERSON_FIRST_NAME, p.PERSON_MIDDLE_NAME, p.PERSON_LAST_NAME , p.attribute2 as USER_NAME, 
        C.OWNER_TABLE_ID, c.PHONE_AREA_CODE, c.PHONE_LINE_TYPE, c.CONTACT_POINT_TYPE, c.PHONE_NUMBER, 
        c.EMAIL_ADDRESS, c.PHONE_COUNTRY_CODE 
        FROM AR.HZ_CONTACT_POINTS C, AR.HZ_PARTIES p WHERE p.PARTY_ID = c.owner_table_id         
        and c.OWNER_TABLE_ID in  
          (SELECT OBJECT_ID 
            FROM AR.HZ_RELATIONSHIPS 
            WHERE (RELATIONSHIP_CODE = 'HAS_AGENT_AUTH_REP'
                  OR RELATIONSHIP_CODE = 'SEC_CONTACT')                  
            AND SUBJECT_ID = p_id ) ;  
           
END SEL_CONTACTS_BY_PARTY_ID;


---------------------------------------------------------------------------------------------
  
PROCEDURE SEL_STAs_BY_PARTY_ID (
           p_id  IN  AR.HZ_PARTIES.PARTY_ID%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR ) AS
BEGIN
    OPEN p_ref_cursor FOR    
    

    SELECT SEARCH.STA_ID, SEARCH.FIRST_NAME, SEARCH.LAST_NAME,
      HZPARTY.STATUS, CERT.CREATION_DATE, CERT.ISSUED_ON_DATE,CERT.EXPIRES_ON_DATE, CERT.LAST_UPDATE_DATE,    
       SEARCH.APPLICATION_STATUS

       FROM ( EGOV_IAC.STA_CARRIER_ASSOC_SEARCH ) search, AR.HZ_CERTIFICATIONS CERT,
	   AR.HZ_PARTIES HZPARTY
       where search.SPONSOR_PARTY_ID = p_id and search.APPLICANT_PARTY_ID =  CERT.PARTY_ID and
	   HZPARTY.PARTY_ID = CERT.PARTY_ID 
       ORDER BY HZPARTY.STATUS ASC, CERT.CREATION_DATE DESC;
  
           
END SEL_STAs_BY_PARTY_ID;



END FAS_SUBJECT_COMPANY;

-- GRANT EXECUTE on FAS_SUBJECT_COMPANY TO SVC_IACMS_FASREADONLYAPP;
-- GRANT EXECUTE on FAS_SUBJECT_COMPANY TO "svc-iacms-fasroapp";