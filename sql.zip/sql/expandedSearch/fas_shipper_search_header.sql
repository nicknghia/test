create or replace
PACKAGE FAS_SHIPPER_SEARCH AS 
		  
PROCEDURE SEL_REC_BY_SHIPPER_NAME (
           p_party_name IN HZ_PARTIES.PARTY_NAME%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR 
	  ,total_count  OUT NUMBER
	  ,count1  OUT NUMBER
	  ,count2  OUT NUMBER);
	  
PROCEDURE SEL_REC_BY_SHIPPER_NAME_IAC (
           p_party_name IN HZ_PARTIES.PARTY_NAME%TYPE    
		  ,p_iac_number IN EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE
          ,p_ref_cursor OUT SYS_REFCURSOR 
	  ,total_count  OUT NUMBER
	  ,count1  OUT NUMBER
	  ,count2  OUT NUMBER);
		  
PROCEDURE SEL_REC_BY_IAC_NUMBER (
           p_iac_number IN EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR 
	  ,total_count  OUT NUMBER
	  ,count1  OUT NUMBER
	  ,count2  OUT NUMBER);
	  
PROCEDURE SEL_REC_BY_IAC_SHIPPER_ID (
           p_iac_number IN EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE  
		  ,p_shipper_id   IN HZ_ORIG_SYS_REFERENCES.orig_system_reference%TYPE		   
          ,p_ref_cursor OUT SYS_REFCURSOR 
	  ,total_count  OUT NUMBER
	  ,count1  OUT NUMBER
	  ,count2  OUT NUMBER);
		  
PROCEDURE SEL_REC_BY_STATE_CODE (
           p_state IN HZ_PARTIES.STATE%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR );
		  
PROCEDURE SEL_SHIPPER_DETAILS_BY_ID_IAC (
           p_shipper_id   IN HZ_ORIG_SYS_REFERENCES.orig_system_reference%TYPE    
          ,p_iac_number IN EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR );
		  
PROCEDURE SEL_SHIPPER_AC_DET_BY_ID_IAC (
           p_shipper_id   IN HZ_ORIG_SYS_REFERENCES.orig_system_reference%TYPE    
          ,p_iac_number IN EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR );
          
PROCEDURE SEL_DISP_CODE_BY_PARTY_ID (
           p_party_id IN AR.HZ_ORGANIZATION_PROFILES.PARTY_ID%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR );         
		  
PROCEDURE SEL_DISP_CODE_BY_SHIPPER_ID (
           p_shipper_id   IN HZ_ORIG_SYS_REFERENCES.orig_system_reference%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR );
		  
PROCEDURE SEL_NOTES_BY_PARTY_ID (
           p_party_id IN AR.HZ_ORGANIZATION_PROFILES.PARTY_ID%TYPE   
          ,p_ref_cursor OUT SYS_REFCURSOR );
		  
PROCEDURE SEL_REC_BY_ORGANIZATION_NAME (
           p_org_name IN AR.HZ_ORGANIZATION_PROFILES.ORGANIZATION_NAME%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR 
	  ,total_count  OUT NUMBER
	  ,count1  OUT NUMBER
	  ,count2  OUT NUMBER);
	  
PROCEDURE SEL_REC_BY_ORG_NAME_SHIPPER_ID (
           p_org_name IN AR.HZ_ORGANIZATION_PROFILES.ORGANIZATION_NAME%TYPE   
          ,p_shipper_id   IN HZ_ORIG_SYS_REFERENCES.orig_system_reference%TYPE		   
          ,p_ref_cursor OUT SYS_REFCURSOR 
	  ,total_count  OUT NUMBER
	  ,count1  OUT NUMBER
	  ,count2  OUT NUMBER);

END FAS_SHIPPER_SEARCH;