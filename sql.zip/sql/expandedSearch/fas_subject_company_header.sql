create or replace
PACKAGE FAS_SUBJECT_COMPANY AS 

PROCEDURE SEL_REC_BY_NAME_SUMMARY_PAGE (
           p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR );

PROCEDURE SEL_REC_BY_NAME_SUMMARY_1 (
           p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR );

PROCEDURE SEL_REC_BY_NAME_SUMMARY_2 (
           p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR );

PROCEDURE SEL_REC_BY_NAME_SUMMARY_3 (
           p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR );

PROCEDURE SEL_REC_BY_NAME_SUMMARY_4 (
           p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR );

PROCEDURE SEL_REC_BY_IAC_NAME_SUM_PAGE(
             	p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE, 
          P_begin_idx   in number,
        	P_end_idx   in number,
          p_ref_cursor OUT SYS_REFCURSOR );
          
PROCEDURE SEL_REC_BY_AC_NAME_SUM_PAGE(
             	p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE, 
				P_begin_idx   in number,
				P_end_idx   in number,
				p_ref_cursor OUT SYS_REFCURSOR );
        
PROCEDURE SEL_REC_BY_STA_NAME_SUM_PAGE(
             	p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE, 
				P_begin_idx   in number,
				P_end_idx   in number,
				p_ref_cursor OUT SYS_REFCURSOR );
        
PROCEDURE SEL_REC_BY_AGT_NAME_SUM_PAGE(
             	p_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE, 
				P_begin_idx   in number,
				P_end_idx   in number,
				p_ref_cursor OUT SYS_REFCURSOR );        

PROCEDURE SEL_REC_BY_SC_IAC_DET (
          p_name IN  AR.HZ_PARTIES.PARTY_NAME%TYPE          		   
         ,p_ref_cursor OUT SYS_REFCURSOR );  
         
PROCEDURE SEL_REC_BY_SC_AC_DET (
           p_id  IN  AR.HZ_PARTIES.PARTY_ID%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR );

PROCEDURE SEL_REC_BY_SC_AGT_DET (
           p_id  IN  AR.HZ_PARTIES.PARTY_ID%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR );
		   
PROCEDURE SEL_REC_BY_SC_AGT_CONTACTS (
           p_id  IN  AR.HZ_PARTIES.PARTY_ID%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR );
		   
PROCEDURE SEL_REC_FOR_SC_AGT_ASSOC_IAC (
           p_id  IN  AR.HZ_PARTIES.PARTY_ID%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR );
		   
PROCEDURE SEL_REC_FOR_SC_AGT_STA (
           p_id  IN  AR.HZ_PARTIES.PARTY_ID%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR );
		   
PROCEDURE SEL_REC_BY_STATION_DET (
           p_id  IN  AR.HZ_PARTIES.PARTY_ID%TYPE          		   
           , p_cursor_1 OUT SYS_REFCURSOR 
           , p_cursor_2 OUT SYS_REFCURSOR 
           , p_cursor_3 OUT SYS_REFCURSOR );
           
PROCEDURE SEL_CONTACTS_BY_PARTY_ID (
           p_id  IN  AR.HZ_PARTIES.PARTY_ID%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR );

PROCEDURE SEL_STAs_BY_PARTY_ID (
           p_id  IN  AR.HZ_PARTIES.PARTY_ID%TYPE          		   
           ,p_ref_cursor OUT SYS_REFCURSOR );

END FAS_SUBJECT_COMPANY;