create or replace
PACKAGE BODY FAS_SHIPPER_EXTENDED_SEARCH AS

/*
			eStatement.setString(1, shipperId);
			eStatement.setString(2, iacNumber);
			eStatement.setString(3, shipperName);
			eStatement.setString(4, iacAcCompany);
			eStatement.setString(5, stateCode);
	        eStatement.registerOutParameter(6, OracleTypes.CURSOR);
*/
PROCEDURE SEL_REC_BY_ANY (
           p_party_id   IN HZ_ORIG_SYS_REFERENCES.orig_system_reference%TYPE   
          ,p_iac_number IN EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE    
          ,p_party_name IN HZ_PARTIES.PARTY_NAME%TYPE    
          ,p_org_name IN AR.HZ_ORGANIZATION_PROFILES.ORGANIZATION_NAME%TYPE    
          ,p_state IN HZ_PARTIES.STATE%TYPE    
          ,p_ref_cursor OUT SYS_REFCURSOR ) as
		  
  BEGIN
    hz_common_pub.disable_cont_source_security;
	
    OPEN p_ref_cursor FOR
    
    SELECT hzosr.orig_system_reference AS SHIPPER_ID,
        hzop.organization_name AS SHIPPER_NAME, 'SHIPPER' AS PARTY_TYPE,
        hzop.attribute15, hzop.attribute5,  
        hzop.actual_content_source AS APPROVAL_NBR,
        HOSV.ORIG_SYSTEM_NAME AS IAC_NAME,
        HZPARTY.ADDRESS1, HZPARTY.ADDRESS2, HZPARTY.CITY, HZPARTY.POSTAL_CODE,
        HZPARTY.STATE

    FROM HZ_ORGANIZATION_PROFILES hzop,
        HZ_ORIG_SYS_REFERENCES hzosr,
        hz_orig_systems_vl hosv,
        AR.HZ_PARTIES HZPARTY
    
    WHERE 
        hzop.organization_type = 'KSMS_Shipper'
        AND hzop.party_id = hzosr.owner_table_id
        AND hzosr.owner_table_name = 'HZ_PARTIES'
        AND hzosr.orig_system = hzop.actual_content_source
        and HOSV.ORIG_SYSTEM = hzop.actual_content_source
        AND hzop.party_id = HZPARTY.party_id
        AND hzosr.status = 'A'
        AND hzosr.orig_system_reference like  p_party_id 
        AND hzop.actual_content_source like p_iac_number
        AND UPPER (hzop.organization_name) like p_party_name
        and upper(HOSV.ORIG_SYSTEM_NAME) like p_org_name
        AND HZPARTY.STATE like  p_state

     ORDER BY hzop.attribute15; 

  END SEL_REC_BY_ANY;



END FAS_SHIPPER_EXTENDED_SEARCH;

-- GRANT EXECUTE on FAS_SHIPPER_EXTENDED_SEARCH TO SVC_KSMS_FASREADONLYAPP;