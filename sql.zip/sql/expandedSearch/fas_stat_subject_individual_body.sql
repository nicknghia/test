create or replace
PACKAGE BODY FAS_STAT_SUBJECT_INDIVIDUAL AS

PROCEDURE SEL_PARTY_NAME_BY_AUTH_KEY (
       p_auth_key      IN AR.HZ_PARTIES.attribute22%TYPE       
      ,p_ref_cursor    OUT SYS_REFCURSOR) AS
  BEGIN
    OPEN p_ref_cursor FOR 
	
	SELECT party.PARTY_NAME, party.attribute22  STAAUTHORIZATIONKEY,
           party.PARTY_ID	
      FROM AR.HZ_PARTIES party
      WHERE
        UPPER (party.attribute22) = upper(p_auth_key);
	  
END SEL_PARTY_NAME_BY_AUTH_KEY;

PROCEDURE SEL_STA_BY_AUTH_KEY (
       p_auth_key      IN AR.HZ_PARTIES.attribute22%TYPE        
      ,p_ref_cursor    OUT SYS_REFCURSOR) AS
  BEGIN
    OPEN p_ref_cursor FOR 
	
	select DISTINCT STA.PARTY_ID, party.PARTY_NAME, party.attribute22 STAT_AUTHORIZATION_KEY,
      STA.PERSON_FIRST_NAME FIRST_NAME, STA.PERSON_LAST_NAME LAST_NAME,
      --fac.BUSINESS_NAME, fac.STAT_AUTHORIZATION_KEY, fac.FACILITY_PARTY_ID, 
      --fac.PRIMARY_PARTY_ID,
      rel.SUBJECT_ID, rel.OBJECT_ID, rel.ATTRIBUTE2, 'STAT' SPONSOR_TYPE, 
      CERT.STATUS, CERT.CREATION_DATE, CERT.ISSUED_ON_DATE,
      CERT.EXPIRES_ON_DATE, CERT.LAST_UPDATE_DATE, CERT.CURRENT_STATUS STA_STATUS,
      CERT.GRADE STA_ID, '' AS AGENT_NAME
    from --xxtsa_facility_coord_12623 fac,
      ar.hz_relationships rel,
      ar.hz_parties party,
      ar.hz_parties STA,
      AR.HZ_CERTIFICATIONS CERT
    where rel.OBJECT_ID = party.party_id AND
          cert.party_id = STA.party_id AND
      --UPPER (fac.stat_authorization_key) = UPPER(p_auth_key)
	  rel.subject_id = cert.party_id AND
	  UPPER (party.attribute22) = (p_auth_key)
	  order by CERT.STATUS ASC, CERT.CREATION_DATE DESC;
	  
END SEL_STA_BY_AUTH_KEY;

PROCEDURE SEL_STAT_STA_BY_PARTY_ID (
       p_party_id 	   IN  AR.HZ_PARTIES.PARTY_ID%TYPE        
      ,p_ref_cursor    OUT SYS_REFCURSOR) AS
  BEGIN
    OPEN p_ref_cursor FOR 
	
	select DISTINCT STA.PARTY_ID, party.PARTY_NAME, party.attribute22 STAT_AUTHORIZATION_KEY,
      STA.PERSON_FIRST_NAME FIRST_NAME, STA.PERSON_LAST_NAME LAST_NAME,
      rel.SUBJECT_ID, rel.OBJECT_ID, rel.ATTRIBUTE2, 'STAT' SPONSOR_TYPE, 
      STA.STATUS, CERT.CREATION_DATE, CERT.ISSUED_ON_DATE,
      CERT.EXPIRES_ON_DATE, CERT.LAST_UPDATE_DATE, CERT.CURRENT_STATUS STA_STATUS,
      CERT.GRADE STA_ID, '' AS AGENT_NAME
    from 
      ar.hz_relationships rel,
      ar.hz_parties party,
      ar.hz_parties STA,
      AR.HZ_CERTIFICATIONS CERT
    where rel.OBJECT_ID = party.party_id AND
          cert.party_id = STA.party_id AND
      --UPPER (fac.stat_authorization_key) = UPPER(p_auth_key)
	  rel.subject_id = cert.party_id AND
	  party.party_id = p_party_id
	  order by STA.STATUS ASC, CERT.CREATION_DATE DESC;
	  
END SEL_STAT_STA_BY_PARTY_ID;

END FAS_STAT_SUBJECT_INDIVIDUAL;

-- GRANT EXECUTE on FAS_STAT_SUBJECT_INDIVIDUAL TO SVC_STAT_FASREADONLYAPP;
-- GRANT EXECUTE on FAS_STAT_SUBJECT_INDIVIDUAL TO "svc-stat-fasroapp";
