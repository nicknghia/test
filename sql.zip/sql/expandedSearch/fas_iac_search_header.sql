create or replace
PACKAGE FAS_IAC_SEARCH AS

PROCEDURE SEL_REC_BY_IAC_NUM (
        p_iac_num  	  IN  EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE        
       ,p_ref_cursor  OUT SYS_REFCURSOR
	   ,total_count   OUT NUMBER);
	   
PROCEDURE SEL_REC_BY_IAC_NUM_1 (
        p_iac_num  	  IN  EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE        
       ,p_ref_cursor  OUT SYS_REFCURSOR
	   ,total_count   OUT NUMBER);
       
PROCEDURE SEL_REC_BY_IAC_NAME (
        p_party_name    IN  AR.HZ_PARTIES.PARTY_NAME%TYPE
       ,p_ref_cursor    OUT SYS_REFCURSOR
	   ,total_count     OUT NUMBER);
       
PROCEDURE SEL_IAC_DETAILS_BY_IAC_NAME (
        p_iac_num  	    IN  EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE 
       ,p_iac_name     	IN  AR.HZ_PARTIES.PARTY_NAME%TYPE
       ,p_ref_cursor    OUT SYS_REFCURSOR );
	   
PROCEDURE SEL_IAC_DETAILS_BY_IAC_NAME_1 (
        p_iac_name     	IN  AR.HZ_PARTIES.PARTY_NAME%TYPE
       ,p_ref_cursor    OUT SYS_REFCURSOR );
	   	   
PROCEDURE SEL_PRINCIPLE_CORD_BY_PARTY_ID (
        p_party_id 	  IN  AR.HZ_PARTIES.PARTY_ID%TYPE        
       ,p_ref_cursor  OUT SYS_REFCURSOR );
	   
PROCEDURE SEL_STATION_BY_IAC_NUM (
        p_iac_num  	  IN  EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE  
       ,p_ref_cursor    OUT SYS_REFCURSOR );	
	   
PROCEDURE SEL_AGENT_BY_IAC_NUM (
        p_iac_num  	  IN  EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE  
       ,p_ref_cursor    OUT SYS_REFCURSOR );
	   
PROCEDURE SEL_STA_BY_PARTY_ID (
        p_party_id 	  IN  AR.HZ_PARTIES.PARTY_ID%TYPE 	
       ,p_ref_cursor  OUT SYS_REFCURSOR );
	   
PROCEDURE SEL_STA_BY_IAC_NUM (
        p_iac_num  IN  	EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE        
       ,p_ref_cursor  OUT SYS_REFCURSOR );
	   
PROCEDURE SEL_STATION_REC_BY_PARTY_ID (
        p_party_id 	  IN  AR.HZ_PARTIES.PARTY_ID%TYPE  
	   ,p_object_id   IN  AR.HZ_PARTIES.PARTY_ID%TYPE		
       ,p_ref_cursor  OUT SYS_REFCURSOR );
	   
PROCEDURE SEL_AIRPORT_BY_PARTY_ID (
        p_party_id 	  IN  AR.HZ_PARTIES.PARTY_ID%TYPE		
       ,p_ref_cursor  OUT SYS_REFCURSOR );
	   
PROCEDURE SEL_ST_CONTACTS_BY_PARTY_ID (
        p_party_id 	  IN  AR.HZ_PARTIES.PARTY_ID%TYPE 	
       ,p_ref_cursor  OUT SYS_REFCURSOR );
	   
PROCEDURE SEL_CONTACTS_NAMES_BY_PARTY_ID (
        p_party_id 	  IN  AR.HZ_PARTIES.PARTY_ID%TYPE 	
       ,p_ref_cursor  OUT SYS_REFCURSOR );
	   
PROCEDURE SEL_IAC_NAME_BY_IAC_NUM (
        p_iac_num  	  IN  EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE        
       ,p_ref_cursor  OUT SYS_REFCURSOR);	   
END FAS_IAC_SEARCH;
