create or replace
PACKAGE FAS_IAC_SEARCH_TEST AS 

PROCEDURE SEL_REC (
        P_begin_idx   in number,
        P_end_idx   in number,
        p_ref_cursor  OUT SYS_REFCURSOR
	   );
     
PROCEDURE SEL_COUNT (
	   total_count   OUT NUMBER );

PROCEDURE SEL_REC_BY_IAC_NUM (
        p_iac_num  	  IN  EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE,
        P_begin_idx   in number,
        P_end_idx     in number,
        p_ref_cursor  OUT SYS_REFCURSOR
	   );
     
PROCEDURE SEL_COUNT_BY_IAC_NUM (
        p_iac_num  	  IN  EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE   ,
	    total_count   OUT NUMBER 
	    );
	   
PROCEDURE SEL_REC_BY_IAC_NAME (
        p_party_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE,
        P_begin_idx   in number,
        P_end_idx     in number,
        p_ref_cursor  OUT SYS_REFCURSOR
       );

PROCEDURE SEL_REC_BY_IAC_NAME_REG (
        p_party_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE,
        P_begin_idx   in number,
        P_end_idx     in number,
        p_ref_cursor  OUT SYS_REFCURSOR
       );

PROCEDURE SEL_COUNT_BY_IAC_NAME (
        p_party_name   IN  AR.HZ_PARTIES.PARTY_NAME%TYPE,
        total_count    OUT NUMBER);
        
PROCEDURE SEL_COUNT_BY_IAC_NAME_REG (
        p_party_name   IN  AR.HZ_PARTIES.PARTY_NAME%TYPE,
        total_count    OUT NUMBER);
        
PROCEDURE SEL_SORT_REC (
        P_begin_idx   in number,
        P_end_idx     in number,
        P_attribute   in VARCHAR2,
        P_order       in VARCHAR2,
        p_ref_cursor  OUT SYS_REFCURSOR
	   );
        
PROCEDURE SEL_SORT_REC_BY_IAC_NUM (
        p_iac_num  	  IN  EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE,
        P_begin_idx   in number,
        P_end_idx     in number,
        P_attribute   in VARCHAR2,
        P_order       in VARCHAR2,
        p_ref_cursor  OUT SYS_REFCURSOR
	   );
     
PROCEDURE SEL_SORT_REC_BY_IAC_NAME (
        p_party_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE,
        P_begin_idx   in number,
        P_end_idx     in number,
        P_attribute   in VARCHAR2,
        P_order       in VARCHAR2,
        p_ref_cursor  OUT SYS_REFCURSOR
       );

PROCEDURE SEL_SORT_REC_BY_IAC_NAME_REG (
        p_party_name  IN  AR.HZ_PARTIES.PARTY_NAME%TYPE,
        P_begin_idx   in number,
        P_end_idx     in number,
        P_attribute   in VARCHAR2,
        P_order       in VARCHAR2,
        p_ref_cursor  OUT SYS_REFCURSOR
       );


END FAS_IAC_SEARCH_TEST;