create or replace
PACKAGE BODY FAS_IAC_SEARCH_TEST AS

  PROCEDURE SEL_REC (
        P_begin_idx   in number,
        P_end_idx   in number,
        p_ref_cursor  OUT SYS_REFCURSOR
	   ) AS
  BEGIN
   OPEN p_ref_cursor FOR
  
  select * from ( select  a.*, rownum rnum from 
     (select P.PARTY_NAME, P.PARTY_ID, P.STATUS, F.APPROVAL_NBR, EXT.IACMS_STATUS_CODE IAC_STATUS
      from AR.HZ_PARTIES P, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE F, 
        IACMS_IAC_PROFILE_EXTENSIONS EXT
      where P.PARTY_ID = F.PARTY_ID  
        AND P.PARTY_ID = EXT.PARTY_ID
        AND (EXT.IACMS_STATUS_CODE 
          IN ('ACTIVE','INACTIVE','NEEDSREVIEW','RENEWREQUEST','RENEWREQUIRE', 'APPREQUEST'))
        ORDER BY EXT.IACMS_STATUS_CODE ASC
    ) a  
    where rownum <=  p_end_idx
    ) where rnum > p_begin_idx; 
	    
  END SEL_REC;  

 	   
--------------------------------	   

  PROCEDURE SEL_COUNT (
	   total_count   OUT NUMBER ) AS
  BEGIN
   select count(*) into total_count
  from AR.HZ_PARTIES P, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE F, 
    IACMS_IAC_PROFILE_EXTENSIONS EXT
  where P.PARTY_ID = F.PARTY_ID  
    AND P.PARTY_ID = EXT.PARTY_ID
	AND (EXT.IACMS_STATUS_CODE 
    IN ('ACTIVE','INACTIVE','NEEDSREVIEW','RENEWREQUEST','RENEWREQUIRE', 'APPREQUEST'));
    
  END SEL_COUNT;
  
 ----------------------------

  PROCEDURE SEL_REC_BY_IAC_NUM (
        p_iac_num  	  IN  EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE,
        P_begin_idx   in number,
        P_end_idx   in number,
        p_ref_cursor  OUT SYS_REFCURSOR
	   ) AS
  BEGIN
   OPEN p_ref_cursor FOR
  
  select * from ( select  a.*, rownum rnum from 
  
     (select P.PARTY_NAME, P.PARTY_ID, P.STATUS, F.APPROVAL_NBR, EXT.IACMS_STATUS_CODE IAC_STATUS
  
      from AR.HZ_PARTIES P, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE F, 
        IACMS_IAC_PROFILE_EXTENSIONS EXT
      where P.PARTY_ID = F.PARTY_ID  
        AND P.PARTY_ID = EXT.PARTY_ID
        AND (EXT.IACMS_STATUS_CODE 
          IN ('ACTIVE','INACTIVE','NEEDSREVIEW','RENEWREQUEST','RENEWREQUIRE', 'APPREQUEST'))
        AND UPPER(F.APPROVAL_NBR) LIKE p_iac_num 
        and rownum <=  p_end_idx
        ORDER BY EXT.IACMS_STATUS_CODE ASC
    ) a  
   -- where rownum <=  p_end_idx
    ) where rnum > p_begin_idx; 
	    
  END SEL_REC_BY_IAC_NUM;  

 ----------------------------

  PROCEDURE SEL_COUNT_BY_IAC_NUM (
     p_iac_num  	  IN  EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE   ,
	   total_count   OUT NUMBER ) AS
  BEGIN
   select count(*) into total_count
  from AR.HZ_PARTIES P, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE F, 
    IACMS_IAC_PROFILE_EXTENSIONS EXT
  where P.PARTY_ID = F.PARTY_ID  
    AND P.PARTY_ID = EXT.PARTY_ID
	AND (EXT.IACMS_STATUS_CODE 
    IN ('ACTIVE','INACTIVE','NEEDSREVIEW','RENEWREQUEST','RENEWREQUIRE', 'APPREQUEST'))
    AND UPPER(F.APPROVAL_NBR) LIKE p_iac_num ;	
    
  END SEL_COUNT_BY_IAC_NUM;
  
  
  ----------------------------

  PROCEDURE SEL_COUNT_BY_IAC_NAME_REG (
        p_party_name     IN  AR.HZ_PARTIES.PARTY_NAME%TYPE,
        total_count    OUT NUMBER) AS
  BEGIN
  -- parameter sniffing
    declare name1 AR.HZ_PARTIES.PARTY_NAME%TYPE;
    begin
    name1 := upper(p_party_name);    
    
    select count (*) into total_count
          from AR.HZ_PARTIES P, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE F, 
            IACMS_IAC_PROFILE_EXTENSIONS EXT
        where P.PARTY_ID = F.PARTY_ID  
          AND P.PARTY_ID = EXT.PARTY_ID
        AND (EXT.IACMS_STATUS_CODE 
          IN ('ACTIVE','INACTIVE','NEEDSREVIEW','RENEWREQUEST','RENEWREQUIRE', 'APPREQUEST'))
          --AND UPPER(P.PARTY_NAME) like UPPER(p_party_name)
          AND UPPER(P.PARTY_NAME) like name1;
      
      end;
  END SEL_COUNT_BY_IAC_NAME_REG;

----------------------------

  PROCEDURE SEL_COUNT_BY_IAC_NAME (
        p_party_name     IN  AR.HZ_PARTIES.PARTY_NAME%TYPE,
        total_count    OUT NUMBER) AS
  BEGIN
    
    select count (*) into total_count
          from AR.HZ_PARTIES P, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE F, 
            IACMS_IAC_PROFILE_EXTENSIONS EXT
        where P.PARTY_ID = F.PARTY_ID  
          AND P.PARTY_ID = EXT.PARTY_ID
        AND (EXT.IACMS_STATUS_CODE 
          IN ('ACTIVE','INACTIVE','NEEDSREVIEW','RENEWREQUEST','RENEWREQUIRE', 'APPREQUEST'))
          AND UPPER(P.PARTY_NAME) like p_party_name
      ;
      
  END SEL_COUNT_BY_IAC_NAME;

----------------------------

  PROCEDURE SEL_REC_BY_IAC_NAME_REG (
          p_party_name     IN  AR.HZ_PARTIES.PARTY_NAME%TYPE,
          P_begin_idx   in number,
          P_end_idx   in number,
          p_ref_cursor   OUT SYS_REFCURSOR) as
       
  BEGIN
    -- parameter sniffing
    declare 
      name1 AR.HZ_PARTIES.PARTY_NAME%TYPE;
      beginIdx number;
      endIdx number;
      
    begin
      name1 := upper(p_party_name);    
      beginIdx := p_begin_idx;
      endIdx := p_end_idx;
  
      OPEN p_ref_cursor FOR
  
      select * from ( select a.*, rownum rnum from       
         (select P.PARTY_NAME, P.PARTY_ID, P.STATUS, F.APPROVAL_NBR, EXT.IACMS_STATUS_CODE IAC_STATUS
            from AR.HZ_PARTIES P, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE F, 
              IACMS_IAC_PROFILE_EXTENSIONS EXT
          where P.PARTY_ID = F.PARTY_ID  
            AND P.PARTY_ID = EXT.PARTY_ID
            AND (EXT.IACMS_STATUS_CODE 
              IN ('ACTIVE','INACTIVE','NEEDSREVIEW','RENEWREQUEST','RENEWREQUIRE', 'APPREQUEST'))
            AND UPPER(P.PARTY_NAME) like name1
            and rownum <=  endIdx        -- since name is not indexed
            ORDER BY EXT.IACMS_STATUS_CODE ASC  
          ) a  
          --where rownum <=  p_end_idx
       ) where rnum > beginIdx;
     end;
  END SEL_REC_BY_IAC_NAME_REG;
    
    
  ------------------------

  PROCEDURE SEL_REC_BY_IAC_NAME (
          p_party_name     IN  AR.HZ_PARTIES.PARTY_NAME%TYPE,
          P_begin_idx   in number,
          P_end_idx   in number,
          p_ref_cursor   OUT SYS_REFCURSOR) as
       
  BEGIN

    OPEN p_ref_cursor FOR
  
      select * from ( select a.*, rownum rnum from 
      (
      select P.PARTY_NAME, P.PARTY_ID, P.STATUS, F.APPROVAL_NBR, EXT.IACMS_STATUS_CODE IAC_STATUS
        from AR.HZ_PARTIES P, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE F, 
          IACMS_IAC_PROFILE_EXTENSIONS EXT
      where P.PARTY_ID = F.PARTY_ID  
        AND P.PARTY_ID = EXT.PARTY_ID
        AND (EXT.IACMS_STATUS_CODE 
          IN ('ACTIVE','INACTIVE','NEEDSREVIEW','RENEWREQUEST','RENEWREQUIRE', 'APPREQUEST'))
        AND UPPER(P.PARTY_NAME) like p_party_name
       and rownum <=  p_end_idx        -- since name is not indexed
        ORDER BY EXT.IACMS_STATUS_CODE ASC  
      ) a  
      --where rownum <=  p_end_idx
      ) where rnum > p_begin_idx;

   
    END SEL_REC_BY_IAC_NAME;
    
   
  ------------------------


 PROCEDURE SEL_SORT_REC (
        P_begin_idx   in number,
        P_end_idx   in number,
        P_attribute   in VARCHAR2,
        p_order   in VARCHAR2,
        p_ref_cursor  OUT SYS_REFCURSOR
	   ) AS
 
  BEGIN
   OPEN p_ref_cursor FOR
   select * from ( select  a.*, rownum rnum from 
     (select P.PARTY_NAME, P.PARTY_ID, P.STATUS, F.APPROVAL_NBR, EXT.IACMS_STATUS_CODE IAC_STATUS
      from AR.HZ_PARTIES P, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE F, 
        IACMS_IAC_PROFILE_EXTENSIONS EXT
      where P.PARTY_ID = F.PARTY_ID  
        AND P.PARTY_ID = EXT.PARTY_ID
        AND (EXT.IACMS_STATUS_CODE 
          IN ('ACTIVE','INACTIVE','NEEDSREVIEW','RENEWREQUEST','RENEWREQUIRE', 'APPREQUEST'))
       order by
        case when P_attribute = 'iacStatus' and p_order = 'up' then EXT.IACMS_STATUS_CODE end asc,
        case when P_attribute = 'iacStatus' and  p_order = 'down' then EXT.IACMS_STATUS_CODE end desc,
        case when P_attribute = 'iacName' and p_order = 'up' then P.PARTY_NAME end asc,
        case when P_attribute = 'iacName' and  p_order = 'down' then P.PARTY_NAME end desc,
        case when P_attribute = 'iacId' and p_order = 'up' then F.APPROVAL_NBR end asc,
        case when P_attribute = 'iacId' and  p_order = 'down' then F.APPROVAL_NBR end desc
    ) a  
    where rownum <=  p_end_idx
    ) where rnum > p_begin_idx; 
	    
  END SEL_SORT_REC;  
--------------------------------

  PROCEDURE SEL_SORT_REC_BY_IAC_NUM (
        p_iac_num  	  IN  EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE.APPROVAL_NBR%TYPE,
        P_begin_idx   in number,
        P_end_idx     in number,
        P_attribute   in VARCHAR2,
        P_order       in VARCHAR2,
        p_ref_cursor  OUT SYS_REFCURSOR
	   ) AS
 
  BEGIN
   OPEN p_ref_cursor FOR
   select * from ( select  a.*, rownum rnum from 
     (select P.PARTY_NAME, P.PARTY_ID, P.STATUS, F.APPROVAL_NBR, EXT.IACMS_STATUS_CODE IAC_STATUS
      from AR.HZ_PARTIES P, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE F, 
        IACMS_IAC_PROFILE_EXTENSIONS EXT
      where P.PARTY_ID = F.PARTY_ID  
        AND P.PARTY_ID = EXT.PARTY_ID
        AND (EXT.IACMS_STATUS_CODE 
          IN ('ACTIVE','INACTIVE','NEEDSREVIEW','RENEWREQUEST','RENEWREQUIRE', 'APPREQUEST'))
        AND UPPER(F.APPROVAL_NBR) LIKE  p_iac_num 
       order by
        case when P_attribute = 'iacStatus' and p_order = 'up' then EXT.IACMS_STATUS_CODE end asc,
        case when P_attribute = 'iacStatus' and  p_order = 'down' then EXT.IACMS_STATUS_CODE end desc,
        case when P_attribute = 'iacName' and p_order = 'up' then P.PARTY_NAME end asc,
        case when P_attribute = 'iacName' and  p_order = 'down' then P.PARTY_NAME end desc,
        case when P_attribute = 'iacId' and p_order = 'up' then F.APPROVAL_NBR end asc,
        case when P_attribute = 'iacId' and  p_order = 'down' then F.APPROVAL_NBR end desc
    ) a  
    where rownum <=  p_end_idx
    ) where rnum > p_begin_idx; 
	    
  END SEL_SORT_REC_BY_IAC_NUM;  
--------------------------------
PROCEDURE SEL_SORT_REC_BY_IAC_NAME_REG (
        p_party_name     IN  AR.HZ_PARTIES.PARTY_NAME%TYPE,
        P_begin_idx   in number,
        P_end_idx     in number,
        P_attribute   in VARCHAR2,
        P_order       in VARCHAR2,
        p_ref_cursor  OUT SYS_REFCURSOR
	   ) AS
 
  BEGIN

    -- parameter sniffing
    declare 
      name1 AR.HZ_PARTIES.PARTY_NAME%TYPE;
      beginIdx number;
      endIdx number;
      attribute1  VARCHAR2(20);
      order1      VARCHAR2(10);
      
    begin
      name1 := upper(p_party_name);    
      beginIdx := p_begin_idx;
      endIdx := p_end_idx;
      attribute1 := p_attribute;
      order1 := p_order;

   OPEN p_ref_cursor FOR
   select * from ( select  a.*, rownum rnum from 
     (select P.PARTY_NAME, P.PARTY_ID, P.STATUS, F.APPROVAL_NBR, EXT.IACMS_STATUS_CODE IAC_STATUS
      from AR.HZ_PARTIES P, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE F, 
        IACMS_IAC_PROFILE_EXTENSIONS EXT
      where P.PARTY_ID = F.PARTY_ID  
        AND P.PARTY_ID = EXT.PARTY_ID
        AND (EXT.IACMS_STATUS_CODE 
          IN ('ACTIVE','INACTIVE','NEEDSREVIEW','RENEWREQUEST','RENEWREQUIRE', 'APPREQUEST'))
        AND UPPER(P.PARTY_NAME) like name1
       order by
        case when attribute1 = 'iacStatus' and order1 = 'up' then EXT.IACMS_STATUS_CODE end asc,
        case when attribute1 = 'iacStatus' and  order1 = 'down' then EXT.IACMS_STATUS_CODE end desc,
        case when attribute1 = 'iacName' and order1 = 'up' then P.PARTY_NAME end asc,
        case when attribute1 = 'iacName' and  order1 = 'down' then P.PARTY_NAME end desc,
        case when attribute1 = 'iacId' and order1 = 'up' then F.APPROVAL_NBR end asc,
        case when attribute1 = 'iacId' and  order1 = 'down' then F.APPROVAL_NBR end desc
    ) a  
    where rownum <=  endIdx
    ) where rnum > beginIdx; 
     end;	    
  END SEL_SORT_REC_BY_IAC_NAME_REG;  

--------------------------------------------------------     
PROCEDURE SEL_SORT_REC_BY_IAC_NAME (
        p_party_name     IN  AR.HZ_PARTIES.PARTY_NAME%TYPE,
        P_begin_idx   in number,
        P_end_idx     in number,
        P_attribute   in VARCHAR2,
        P_order       in VARCHAR2,
        p_ref_cursor  OUT SYS_REFCURSOR
	   ) AS
 
  BEGIN
   OPEN p_ref_cursor FOR
   select * from ( select  a.*, rownum rnum from 
     (select P.PARTY_NAME, P.PARTY_ID, P.STATUS, F.APPROVAL_NBR, EXT.IACMS_STATUS_CODE IAC_STATUS
      from AR.HZ_PARTIES P, EGOV_SCHEMA.EGOV_INDIRECT_CARRIER_PROFILE F, 
        IACMS_IAC_PROFILE_EXTENSIONS EXT
      where P.PARTY_ID = F.PARTY_ID  
        AND P.PARTY_ID = EXT.PARTY_ID
        AND (EXT.IACMS_STATUS_CODE 
          IN ('ACTIVE','INACTIVE','NEEDSREVIEW','RENEWREQUEST','RENEWREQUIRE', 'APPREQUEST'))
        AND UPPER(P.PARTY_NAME) like p_party_name
       order by
        case when P_attribute = 'iacStatus' and p_order = 'up' then EXT.IACMS_STATUS_CODE end asc,
        case when P_attribute = 'iacStatus' and  p_order = 'down' then EXT.IACMS_STATUS_CODE end desc,
        case when P_attribute = 'iacName' and p_order = 'up' then P.PARTY_NAME end asc,
        case when P_attribute = 'iacName' and  p_order = 'down' then P.PARTY_NAME end desc,
        case when P_attribute = 'iacId' and p_order = 'up' then F.APPROVAL_NBR end asc,
        case when P_attribute = 'iacId' and  p_order = 'down' then F.APPROVAL_NBR end desc
    ) a  
    where rownum <=  p_end_idx
    ) where rnum > p_begin_idx; 
	    
  END SEL_SORT_REC_BY_IAC_NAME;  
	   
END FAS_IAC_SEARCH_TEST;