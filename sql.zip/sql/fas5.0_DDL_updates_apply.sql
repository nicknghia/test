-------------------------------------------------
-- Copyright (c) Soft Tech Consulting, Inc.
-------------------------------------------------

-- Login as user FD before running this script DDL Updates --

/****************************************************************************************/
/*                                    BACKUP DATA TABLES  			       				*/
/****************************************************************************************/
create table FD.ASYNCPROCESSINGLOG_BACKUP as select * from FD.ASYNCPROCESSINGLOG;
create table FD.COUNTRY_BACKUP as select * from FD.COUNTRY;
create table FD.FAS_APP_PROPERTIES_BACKUP as select * from FD.FAS_APP_PROPERTIES;
create table FD.ORGHIERARCHY_BACKUP as select * from FD.ORGHIERARCHY;
create table FD.ORGHIERARCHYTYPE_BACKUP as select * from FD.ORGHIERARCHYTYPE;
create table FD.ORGORGASSOC_BACKUP as select * from FD.ORGORGASSOC;
create table FD.ORGREFERENCE_BACKUP as select * from FD.ORGREFERENCE;
create table FD.ORGREFERENCETYPE_BACKUP as select * from FD.ORGREFERENCETYPE;
create table FD.ORGROLE_BACKUP as select * from FD.ORGROLE;
create table FD.REGIONTYPE_BACKUP as select * from FD.REGIONTYPE;
create table FD.REPORT_BACKUP as select * from FD.REPORT;
create table FD.REPORTPARAMETER_BACKUP as select * from FD.REPORTPARAMETER;
create table FD.SYSTEMFUNCTION_BACKUP as select * from FD.SYSTEMFUNCTION;
create table FD.SYSTEMROLE_BACKUP as select * from FD.SYSTEMROLE;
create table FD.SYSTEMROLEFUNCTION_BACKUP as select * from FD.SYSTEMROLEFUNCTION;
create table FD.SYSTEMUSER_BACKUP as select * from FD.SYSTEMUSER;
create table FD.TIMEZONE_BACKUP as select * from FD.TIMEZONE;
create table FD.TITLETYPE_BACKUP as select * from FD.TITLETYPE;
create table FD.USERPASSWORDHIST_BACKUP as select * from FD.USERPASSWORDHIST;
create table FD.USERSYSTEMROLE_BACKUP as select * from FD.USERSYSTEMROLE;
create table FD.SYSTEMMESSAGE_BACKUP as select * from FD.SYSTEMMESSAGE;


/****************************************************************************************/
/*                       CHANGE FIELD NAME LENGTH TO VARCHAR2(50)     			*/
/****************************************************************************************/
alter table FD.ASYNCPROCESSINGLOG modify CREATEUSERID varchar2(50);
alter table FD.ASYNCPROCESSINGLOG modify LASTUPDATEUSERID varchar2(50);

alter table FD.COUNTRY modify CREATEUSERID varchar2(50);
alter table FD.COUNTRY modify LASTUPDATEUSERID varchar2(50);

alter table FD.FAS_APP_PROPERTIES modify CREATEUSERID varchar2(50);
alter table FD.FAS_APP_PROPERTIES modify LASTUPDATEUSERID varchar2(50);

alter table FD.ORGHIERARCHY modify CREATEUSERID varchar2(50);
alter table FD.ORGHIERARCHY modify LASTUPDATEUSERID varchar2(50);

alter table FD.ORGHIERARCHYTYPE modify CREATEUSERID varchar2(50);
alter table FD.ORGHIERARCHYTYPE modify LASTUPDATEUSERID varchar2(50);

alter table FD.ORGORGASSOC modify CREATEUSERID varchar2(50);
alter table FD.ORGORGASSOC modify LASTUPDATEUSERID varchar2(50);

alter table FD.ORGREFERENCE modify CREATEUSERID varchar2(50);
alter table FD.ORGREFERENCE modify LASTUPDATEUSERID varchar2(50);

alter table FD.ORGREFERENCETYPE modify CREATEUSERID varchar2(50);
alter table FD.ORGREFERENCETYPE modify LASTUPDATEUSERID varchar2(50);

alter table FD.ORGROLE modify CREATEUSERID varchar2(50);
alter table FD.ORGROLE modify LASTUPDATEUSER varchar2(50);

alter table FD.REGIONTYPE modify CREATEUSERID varchar2(50);
alter table FD.REGIONTYPE modify LASTUPDATEUSERID varchar2(50);

alter table FD.REPORT modify CREATEUSERID varchar2(50);
alter table FD.REPORT modify LASTUPDATEUSERID varchar2(50);

alter table FD.REPORTPARAMETER modify CREATEUSERID varchar2(50);
alter table FD.REPORTPARAMETER modify LASTUPDATEUSERID varchar2(50);

alter table FD.SYSTEMFUNCTION modify CREATEUSERID varchar2(50);
alter table FD.SYSTEMFUNCTION modify LASTUPDATEUSERID varchar2(50);

alter table FD.SYSTEMROLE modify CREATEUSERID varchar2(50);
alter table FD.SYSTEMROLE modify LASTUPDATEUSERID varchar2(50);

alter table FD.SYSTEMROLEFUNCTION modify CREATEUSERID varchar2(50);
alter table FD.SYSTEMROLEFUNCTION modify LASTUPDATEUSERID varchar2(50);

alter table FD.SYSTEMUSER modify CREATEUSERID varchar2(50);
alter table FD.SYSTEMUSER modify LASTUPDATEUSERID varchar2(50);
alter table FD.SYSTEMUSER modify USERID varchar2(50);

alter table FD.TIMEZONE modify CREATEUSERID varchar2(50);
alter table FD.TIMEZONE modify LASTUPDATEUSER varchar2(50);

alter table FD.TITLETYPE modify CREATEUSERID varchar2(50);
alter table FD.TITLETYPE modify LASTUPDATEUSERID varchar2(50);

alter table FD.USERPASSWORDHIST modify CREATEUSERID varchar2(50);
alter table FD.USERPASSWORDHIST modify LASTUPDATEUSERID varchar2(50); 	

alter table FD.USERSYSTEMROLE modify CREATEUSERID varchar2(50);
alter table FD.USERSYSTEMROLE modify LASTUPDATEUSERID varchar2(50);

alter table FD.SYSTEMMESSAGE modify CREATEUSERID varchar2(50);
alter table FD.SYSTEMMESSAGE modify LASTUPDATEUSERID varchar2(50);


/****************************************************************************************/
/*      			CREATE NEW TABLES FOR REQUEST TRACKER								*/
/****************************************************************************************/
create table FD.CTUCARGOINCIDENT
  (
    CARGOINCIDENTID  		INTEGER NOT NULL,
    REQUESTORAGENCY  		VARCHAR2(10) NOT NULL,
    DESCRIPTION      		VARCHAR2(20),
    CREATEUSERID     		VARCHAR2(50),
    LASTUPDATEUSERID 		VARCHAR2(50),
    CREATETIMESTAMP 		DATE NOT NULL,
    LASTUPDATETIMESTAMP 	DATE
  );
alter table FD.CTUCARGOINCIDENT
   add constraint PK_CTUCARGOINCIDENT primary key (CARGOINCIDENTID);

   
create table FD.CTUCCSFAPPROVAL
  (
    PSIID            		INTEGER NOT NULL,
    PSINAMES         		VARCHAR2(25) NOT NULL,
    DESCRIPTION      		VARCHAR2(20),
	ACTIVE					VARCHAR2(1) DEFAULT 'Y' NOT NULL,
    CREATEUSERID     		VARCHAR2(50),
    LASTUPDATEUSERID 		VARCHAR2(50),
    CREATETIMESTAMP 		DATE NOT NULL,
    LASTUPDATETIMESTAMP 	DATE
  );
alter table FD.CTUCCSFAPPROVAL
   add constraint PK_CTUCCSFAPPROVAL primary key (PSIID);


create table FD.CTUFIELDCALLSTAREQUEST
  (
    REQUESTSTAID			INTEGER NOT NULL,
    STATYPE          		VARCHAR2(50) NOT NULL,
    DESCRIPTION      		VARCHAR2(20),
    CREATEUSERID     		VARCHAR2(50),
    LASTUPDATEUSERID 		VARCHAR2(50),
    CREATETIMESTAMP 		DATE NOT NULL,
    LASTUPDATETIMESTAMP 	DATE
  );
alter table FD.CTUFIELDCALLSTAREQUEST
   add constraint PK_CTUFIELDCALLSTAREQUEST primary key (REQUESTSTAID);


create table FD.CTUJOINTOPERATIONS
  (
    JOINTOPERATIONID 		INTEGER NOT NULL,
    REQUESTORAGENCY  		VARCHAR2(10) NOT NULL,
    DESCRIPTION      		VARCHAR2(20),
    CREATEUSERID     		VARCHAR2(50),
    LASTUPDATEUSERID 		VARCHAR2(50),
    CREATETIMESTAMP 		DATE NOT NULL,
    LASTUPDATETIMESTAMP 	DATE
  );
alter table FD.CTUJOINTOPERATIONS
   add constraint PK_CTUJOINTOPERATIONS primary key (JOINTOPERATIONID);


create table FD.CTUOGAREFERRAL
  (
    OGAREFERRALID    		INTEGER NOT NULL,
    REQUESTORAGENCY  		VARCHAR2(10) NOT NULL,
    DESCRIPTION      		VARCHAR2(20),
    CREATEUSERID     		VARCHAR2(50),
    LASTUPDATEUSERID 		VARCHAR2(50),
    CREATETIMESTAMP 		DATE NOT NULL,
    LASTUPDATETIMESTAMP 	DATE
  );
alter table FD.CTUOGAREFERRAL
   add constraint PK_CTUOGAREFERRAL primary key (OGAREFERRALID);

create table FD.CTUREQUEST
  (
    REQUESTID         		INTEGER NOT NULL,
    REQUESTNUMBER     		VARCHAR2(100),
    REQUESTSTATUS     		VARCHAR2(10),
    REQUESTTYPE       		VARCHAR2(100),
    CARGOINCIDENTID  		INTEGER,
    CTUCCSFAPPROVAL   		INTEGER,
    PSIID             		INTEGER,
    STAREQUESTID      		INTEGER,
    OGAREFERRALID     		INTEGER,
    REQUESTERAGENCYID 		INTEGER,
    REQUESTDATE 			DATE,
    REQUESTER         		VARCHAR2(100),
    AIRPORTID         		INTEGER,
    SUBJECTINDIVIDUAL 		VARCHAR2(500),
    SUBJECTCOMPANY    		VARCHAR2(500),
    SUBJECTREGIONID   		INTEGER,
    RESULTS           		VARCHAR2(1000),
    RECOMMENDATION    		VARCHAR2(1000),
    COMMENTS          		VARCHAR2(2000),
    DEROG             		VARCHAR2(1),
    DEROGLEVEL        		VARCHAR2(1),
    CREATEUSERNAME    		VARCHAR2(50),
    CREATETIMESTAMP 		TIMESTAMP(6),
    LASTUPDATEUSERNAME		VARCHAR2(50),
    LASTUPDATETIMESTAMP 	TIMESTAMP(6),
    LEADTARGETER   			VARCHAR2(200),
    COTARGETERS    			VARCHAR2(200),
    REQUESTORNAME  			VARCHAR2(50),
    STAINFORMATION 			VARCHAR2(500),
    lockeduser 			varchar2(100)
  );

create sequence FD.CTUREQUESTID_SEQ INCREMENT BY 1 START WITH 1;
alter table FD.CTUREQUEST
   add constraint PK_CTUREQUEST primary key (REQUESTID);


create table FD.CTUREQUESTHISTORY
  (
    REQUESTID         		INTEGER NOT NULL,
    REQUESTNUMBER     		VARCHAR2(100),
    REQUESTSTATUS     		VARCHAR2(10),
    REQUESTTYPE       		VARCHAR2(100),
    CARGOINCIDENTID   		INTEGER,
    CTUCCSFAPPROVAL   		INTEGER,
    PSIID             		INTEGER,
    STAREQUESTID      		INTEGER,
    OGAREFERRALID     		INTEGER,
    REQUESTERAGENCYID 		INTEGER,
    REQUESTDATE				DATE,
    REQUESTER         		VARCHAR2(100),
    AIRPORTID         		INTEGER,
    SUBJECTINDIVIDUAL 		VARCHAR2(500),
    SUBJECTCOMPANY    		VARCHAR2(500),
    SUBJECTREGIONID   		INTEGER,
    RESULTS           		VARCHAR2(1000),
    RECOMMENDATION    		VARCHAR2(1000),
    COMMENTS          		VARCHAR2(2000),
    DEROG             		VARCHAR2(1),
    DEROGLEVEL        		VARCHAR2(1),
    CREATEUSERNAME    		VARCHAR2(50),
    CREATETIMESTAMP 		TIMESTAMP (6),
    LASTUPDATEUSERNAME 		VARCHAR2(50),
    LASTUPDATETIMESTAMP 	TIMESTAMP (6),
    LEADTARGETER   			VARCHAR2(200),
    COTARGETERS    			VARCHAR2(200),
    REQUESTORNAME  			VARCHAR2(50),
    STAINFORMATION 			VARCHAR2(500)
  );
create sequence FD.CTUREQUESTHISTORYID_SEQ INCREMENT BY 1 START WITH 1;
alter table FD.CTUREQUESTHISTORY
   add constraint PK_CTUREQUESTHISTORY primary key (REQUESTID);

   
create table FD.CTUREQUESTTYPE
  (
    REQUESTTYPE      		VARCHAR2(10) NOT NULL,
    REQUESTNAME      		VARCHAR2(50) NOT NULL,
    DESCRIPTION      		VARCHAR2(20),
    CREATEUSERID     		VARCHAR2(50),
    LASTUPDATEUSERID 		VARCHAR2(50),
    CREATETIMESTAMP 		DATE NOT NULL,
    LASTUPDATETIMESTAMP 	DATE
 );
alter table FD.CTUREQUESTTYPE
   add constraint PK_CTUREQUESTTYPE primary key (REQUESTTYPE); 
 
 
create table FD.CTUSTAINLIEUOF 
 (
	STAINLIEUOFID        	INTEGER NOT NULL,
	STAINLIEUOFTYPE      	VARCHAR2(20),
	DESCRIPTION          	VARCHAR2(20),
	CREATEUSERID         	VARCHAR2(50),
	CREATETIMESTAMP      	TIMESTAMP(6),
	LASTUPDATEUSERID     	VARCHAR2(50),
	LASTUPDATETIMESTAMP  	TIMESTAMP(6)
);
alter table FD.CTUSTAINLIEUOF
   add constraint PK_CTUSTAINLIEUOF primary key (STAINLIEUOFID); 


create table FD.CTUSUBJECTREGION
  (
    SUBJECTREGIONID  		INTEGER NOT NULL,
    REGIONNAME       		VARCHAR2(10) NOT NULL,
    DESCRIPTION      		VARCHAR2(20),
	ACTIVE					VARCHAR2(1) DEFAULT 'Y',
    CREATEUSERID     		VARCHAR2(50),
    LASTUPDATEUSERID 		VARCHAR2(50),
    CREATETIMESTAMP 		DATE NOT NULL,
    LASTUPDATETIMESTAMP 	DATE
  );
alter table FD.CTUSUBJECTREGION
   add constraint PK_CTUSUBJECTREGION primary key (SUBJECTREGIONID); 
  
  
create table FD.CTUTARGETER
  (
    TARGETERID        		INTEGER NOT NULL,
    LEADTARGETTERNAME 		VARCHAR2(25) NOT NULL,
    DESCRIPTION       		VARCHAR2(20),
	ACTIVE					VARCHAR2(1) DEFAULT 'Y' NOT NULL,
    CREATEUSERID      		VARCHAR2(50),
    LASTUPDATEUSERID  		VARCHAR2(50),
    CREATETIMESTAMP 		DATE NOT NULL,
    LASTUPDATETIMESTAMP		DATE
  );
alter table FD.CTUTARGETER
   add constraint PK_CTUTARGETER primary key (TARGETERID); 


/****************************************************************************************/
/*        			GRANT ACCESS TO TABLES AND SEQUENCES    							*/
/****************************************************************************************/
GRANT ALL ON FD.CTUCARGOINCIDENT TO FDAPP;
GRANT ALL ON FD.CTUCCSFAPPROVAL TO FDAPP;
GRANT ALL ON FD.CTUFIELDCALLSTAREQUEST TO FDAPP;
GRANT ALL ON FD.CTUJOINTOPERATIONS TO FDAPP;
GRANT ALL ON FD.CTUOGAREFERRAL TO FDAPP;
GRANT ALL ON FD.CTUREQUEST TO FDAPP;
GRANT ALL ON FD.CTUREQUESTID_SEQ TO FDAPP;
GRANT ALL ON FD.CTUREQUESTHISTORY TO FDAPP;
GRANT ALL ON FD.CTUREQUESTHISTORYID_SEQ TO FDAPP;
GRANT ALL ON FD.CTUREQUESTTYPE TO FDAPP;
GRANT ALL ON FD.CTUSTAINLIEUOF TO FDAPP;
GRANT ALL ON FD.CTUSUBJECTREGION TO FDAPP;
GRANT ALL ON FD.CTUTARGETER TO FDAPP;
