import java.io.FileInputStream;
import java.io.InputStream;
import java.util.Properties;

import javax.xml.namespace.QName;

import org.apache.axis.client.Call;
import org.apache.axis.client.Service;

import java.io.IOException;

public class WSClient {
	private static final String PROPERTIES_FILE = "WSclient.properties";

	public static void main(String[] args) {
		InputStream is = null;
		String endpoint = null;
		String ret = null;
		Properties props = new Properties();

		try {
			// Open the input stream to read in the properties file
			is = WSClient.class.getResourceAsStream("/" + PROPERTIES_FILE);
			props.load(is);

			// Set variables from property file
			String hostname = props.getProperty("HOSTNAME");
			String protocal = props.getProperty("PROTOCAL");
			String port = props.getProperty("PORT");
			String servicePath = props.getProperty("SERVICEPATH");
			String method = props.getProperty("METHOD");
			long shipmentId = Long.parseLong(props.getProperty("SHIPID"));
			String domainName = props.getProperty("DOMAINNAME");
			String wsUser = props.getProperty("WSUSER");
			String msgType = props.getProperty("MSGTYPE");
			String file = props.getProperty("FILE");
			String user = props.getProperty("USER");
			String pass = props.getProperty("PASS");
			String truststore = props.getProperty("TRUSTSTORE");
			String truststoreType = props.getProperty("TRUSTSTORETYPE");
			String trustPass = props.getProperty("TRUSTPASS");

			if (notNull(port)) {
				endpoint = protocal + "://" + hostname + ":" + port + servicePath;
			} else {
				endpoint = protocal + "://" + hostname + servicePath;
			}

			if (notNull(truststore)) {
				System.out.println("*** Set truststore to " + truststore);
				System.setProperty("javax.net.ssl.trustStore", truststore);
			}
			if (notNull(trustPass)) {
				System.out.println("*** Set trustpass");
				System.setProperty("javax.net.ssl.trustStorePassword", trustPass);
			}
			if (notNull(truststoreType)) {
				System.out.println("*** Set truststoreType to " + truststoreType);
				System.setProperty("javax.net.ssl.trustStoreType", truststoreType);
			}

			Service service = new Service();
			Call call = (Call) service.createCall();

			if (notNull(user) && notNull(pass)) {
				System.out.println("*** Set http basic user/pass");
				call.setUsername(user);
				call.setPassword(pass);
			}
			call.setTargetEndpointAddress(new java.net.URL(endpoint));

			if (notNull(method)) {
				System.out.println("*** Set method to " + method);
				call.setOperationName(new QName(method));
			}

			System.out.println("*** Calling service at " + endpoint);
			if (method.equalsIgnoreCase("send")) {
				ret =  (String) call.invoke(new Object[] { msgType, wsUser, convertFileToString(file) });
			}
			else if (method.equalsIgnoreCase("retrieve")) {
				ret = (String) call.invoke(new Object[] { shipmentId, domainName });
			}
			else {
				ret = (String) call.invoke(new Object[] {});
			}
			System.out.println("\n*** Service response\n" + ret);

		} catch (Exception e) {
			System.out.println(e.toString());
		} finally {
			try {
				// close the inputStream
				if (is != null) {
					is.close();
				}
			} catch (IOException ex) {
				System.out.println(ex.toString());
			}
		}
	}

	private static boolean notNull(String input) {
		if (input != null && input.trim().length() > 0) {
			return true;
		} else {
			return false;
		}
	}
	
	private static String convertFileToString(String fileName) {
		try {
			FileInputStream file = new FileInputStream(fileName);
			byte[] b = new byte[file.available()];
			file.read(b);
			file.close();
			String result = new String(b);
			return result;
		} catch (Exception e) {
			System.out.println("Error while converting file to string:" + e);
		}
		return null;
	}
}
