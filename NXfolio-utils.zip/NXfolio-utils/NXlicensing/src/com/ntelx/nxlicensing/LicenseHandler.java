/** 
 * Copyright (c) 2009 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of FreightDesk Technologies, LLC 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * @author Michael Echevarria
 *
 */
package com.ntelx.nxlicensing;

import java.io.BufferedWriter;
import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.security.InvalidKeyException;
import java.sql.Timestamp;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.Properties;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.Base64;
import com.freightdesk.fdcommons.FDSuiteProperties;
import com.freightdesk.fdcommons.FormatDate;
import com.freightdesk.fdcommons.licensing.InvalidLicenseException;
import com.freightdesk.fdcommons.licensing.LicenseKey;
import com.freightdesk.fdcommons.licensing.LicenseValidator;

public class LicenseHandler {
	private static Logger logger = Logger.getLogger(LicenseHandler.class);
	private static String outputFile = "SuiteLicense.properties";
	public static String newline = System.getProperty("line.separator");
	private static String properties = "License.txt";

	static LicenseValidator licenseValidator = new LicenseValidator();
	static LicenseGenerator licenseGenerator = new LicenseGenerator();

	/**
	 * @param args
	 * @throws IOException
	 * @throws FileNotFoundException
	 * @throws InvalidLicenseException
	 * @throws ClassNotFoundException
	 * @throws IllegalBlockSizeException
	 * @throws BadPaddingException
	 * @throws InvalidKeyException
	 */
	public static void main(String[] args) throws FileNotFoundException, IOException, GeneralSecurityException, ClassNotFoundException, InvalidLicenseException {
		processLicense();
	}

	/**
	 * @param fileName
	 * @throws IOException
	 * @throws FileNotFoundException
	 * @throws InvalidLicenseException
	 * @throws ClassNotFoundException
	 * @throws InvalidKeyException
	 * @throws BadPaddingException
	 * @throws IllegalBlockSizeException
	 */
	public static void processLicense() throws IOException, FileNotFoundException, GeneralSecurityException, ClassNotFoundException {
		logger.info("begin");
		Properties props = new Properties();
		props.load(new FileInputStream(properties));
		// Map that contains the product name and license. Example:
		// FDfolio,Tw8GXRKWJA/ll9CViJXiiw\=\=
		Hashtable<String, String> productLicenseMap = new Hashtable<String, String>();

		// Get the properties from License.txt
		byte keyMajorVersion = Byte.parseByte(props.getProperty("key.version.major"));
		byte keyMinorVersion = Byte.parseByte(props.getProperty("key.version.minor"));
		String licType = props.getProperty("product.license.type");
		Timestamp expiryDate = FormatDate.parse(props.getProperty("license.expire.date"), "dd-MMM-yyyy");
		productLicenseMap = setProductNames(productLicenseMap, props.getProperty("license.products"));

		// utility variables
		Enumeration<String> enumOfKeys = productLicenseMap.keys();
		FileWriter fstream = new FileWriter(outputFile);
		BufferedWriter out = new BufferedWriter(fstream);
		System.setProperty("FD_RUNTIME_HOME", ".");
		FDSuiteProperties.load(new FileInputStream(properties), 187568912);
		
		// write the license header
		out.write("# expire " + props.getProperty("license.expire.date") + newline);
		
		// Create a license for each product in the product list
		logger.info("Generating license keys.");
		while (enumOfKeys.hasMoreElements()) {
			String productName = enumOfKeys.nextElement();
			
			String licenseStr = licenseGenerator.generateLicense(keyMajorVersion, keyMinorVersion, licType, productName, expiryDate);
			logger.debug("licenseStr :" + licenseStr);
			logger.debug("licenseStr.length() :" + licenseStr.length());
			logger.debug("props.getProperty(\"license.key\") :" + props.getProperty("license.key"));
			logger.debug("licenseStr.equals(props.getProperty(\"license.key\")) :" + licenseStr.equals(props.getProperty("license.key")));

			LicenseKey licKey = licenseValidator.createLicenseKey(licenseStr);
			logger.debug("licenseValidator.createLicenseKey(licenseStr) :" + licKey);

			try {
				logger.debug("licenseValidator.validateLicense(licenseStr) :" + licenseValidator.validateLicense(licKey, productName));
				productLicenseMap.put(productName, licenseStr);
			} catch (InvalidLicenseException e) {
				logger.error(e.getMessage());
				e.printStackTrace();
			}

			// Write product=license to properties file.
			out.write(productName + "=" + productLicenseMap.get(productName) + newline);

		}
		out.close();
		logger.info("Finished writing to " + outputFile);
	}

	public static void write() throws IOException {
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		DataOutputStream dos = new DataOutputStream(bos);
		dos.writeByte(156);
		dos.writeByte(156);
		dos.writeByte(156);
		dos.writeByte(156);
		dos.writeUTF("99999999");

		logger.info(Base64.encodeBytes(bos.toByteArray()));
		logger.info(bos.toByteArray().length);

	}

	private static Hashtable<String, String> setProductNames(Hashtable<String, String> productLicenseMap, String rawList) {
		rawList = rawList.trim();
		String[] tokens = rawList.split(",");
		logger.info(tokens.length + " products to generate licenses for in " + properties);
		for (int i = 0; i < tokens.length; i++) {
			productLicenseMap.put(tokens[i], "");
		}
		return productLicenseMap;
	}

}
