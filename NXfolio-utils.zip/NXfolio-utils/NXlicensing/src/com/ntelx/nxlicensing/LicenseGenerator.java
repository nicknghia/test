/** 
* Copyright (c) 2000-2002 FreightDesk Technologies, LLC 
*  All rights reserved. 
* 
* This software is the confidential and proprietary information of FreightDesk Technologies, LLC 
* ("Confidential Information").  You shall not disclose such Confidential Information 
* and shall use it only in accordance with the terms of the license agreement you entered 
* into with FreightDesk Technologies, LLC. 
* 
* 
*  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDLicensing/src/com/freightdesk/fdlicensing/LicenseGenerator.java,v 1.1 2007/04/12 16:49:04 dkumar Exp $ 
* 
*  Modification History:
*  $Log: LicenseGenerator.java,v $
*  Revision 1.1  2007/04/12 16:49:04  dkumar
*  base version
*
*/
package com.ntelx.nxlicensing;

import java.io.ByteArrayOutputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.security.GeneralSecurityException;
import java.sql.Timestamp;

import com.freightdesk.fdcommons.Base64;
import com.freightdesk.fdcommons.FormatDate;
import com.freightdesk.fdcommons.SymmetricCipher;
import com.freightdesk.fdcommons.licensing.LicenseKey;
import com.freightdesk.fdcommons.licensing.LicenseConstants;

/**
 * @author Deepak Kumar
 *
 */
public class LicenseGenerator
{

    /**
     * Generates the final License Ticket/data from the individual license related data
     * @param keyVersionMajor
     * @param keyVersionMinor
     * @param licenseType
     * @param product
     * @param expirationDate
     * @return encrypted License String
     * @throws IOException 
     * @throws GeneralSecurityException 
     */
    public String generateLicense(byte keyVersionMajor, byte keyVersionMinor, String licenseType, String product, Timestamp expirationDate) throws GeneralSecurityException, IOException
    {
        validateLicenseData(keyVersionMajor,keyVersionMinor,licenseType,product,expirationDate);
        byte licenseTypeCode = LicenseConstants.LicenseType.getLicenseTypeCode(licenseType);
        byte productCode = LicenseConstants.ProductCode.getConfigCode(product);
        LicenseKey licKey = new LicenseKey(keyVersionMajor,keyVersionMinor,licenseTypeCode,productCode,expirationDate);
        return generateTicket(licKey);
    }

    /**
     * Generates the final License data to be shiiped with product from LicenseKey object
     * @param key LicenseKey Object
     * @return encrypted License String
     * @throws GeneralSecurityException
     * @throws IOException 
     */
    private String generateTicket(LicenseKey key) throws GeneralSecurityException, IOException
    {
        ByteArrayOutputStream byteOutStream = new ByteArrayOutputStream();
        DataOutputStream out = new DataOutputStream(byteOutStream);
        key.writeToStream(out);
        out.flush();
        byte[] data = byteOutStream.toByteArray();
        byte[] encryptedBytes =  SymmetricCipher.getInstance().encrypt(data);
        String encodedStr = Base64.encodeBytes(encryptedBytes);
        return encodedStr;
    }


    /**
     * Validates license input information
     * @param keyVersionMajor
     * @param keyVersionMinor
     * @param licenseType
     * @param product
     * @param expirationDate
     * @return
     */
    private boolean validateLicenseData(byte keyVersionMajor, byte keyVersionMinor, String licenseType, String product, Timestamp expirationDate)
    {
        boolean valid = true;
        StringBuffer errors = new StringBuffer();
        
        if(!((keyVersionMajor >= LicenseConstants.KEY_MAJOR_MIN.byteValue()) && (keyVersionMajor < LicenseConstants.KEY_MAJOR_MAX.byteValue())))
        {
            valid=false;
            errors.append("Invalid key major version :"+keyVersionMajor+" \n");
        }
        
        if(!((keyVersionMinor >= LicenseConstants.KEY_MINOR_MIN.byteValue()) && (keyVersionMinor < LicenseConstants.KEY_MINOR_MAX.byteValue())))
        {
            valid=false;
            errors.append("Invalid key minor version :"+keyVersionMinor+" \n");
        }
        
        if(product == null|| LicenseConstants.ProductCode.getConfigCode(product)< 0)
        {
            valid=false;
            errors.append("Invalid product Name :"+product+" \n");
        }

        if(licenseType == null|| LicenseConstants.LicenseType.getLicenseTypeCode(licenseType)< 0)
        {
            valid=false;
            errors.append("Invalid license type:"+licenseType+" \n");
        }
        if(expirationDate==null ||expirationDate.before(new Timestamp(System.currentTimeMillis())))
        {
            valid=false;
            errors.append("Invalid expirationDate:"+FormatDate.doFormatDate(expirationDate,LicenseConstants.DATE_FORMAT)+" \n");
        }

        if(valid==true)
        {
            return valid ;
        }
        else
        {
            throw new RuntimeException(errors.toString());
        }
    }

}
