/** 
* Copyright (c) 2000-2002 FreightDesk Technologies, LLC 
*  All rights reserved. 
* 
* This software is the confidential and proprietary information of FreightDesk Technologies, LLC 
* ("Confidential Information").  You shall not disclose such Confidential Information 
* and shall use it only in accordance with the terms of the license agreement you entered 
* into with FreightDesk Technologies, LLC. 
* 
* 
*  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDLicensing/src/com/freightdesk/fdlicensing/GenerateSymmetricKeyWithKS.java,v 1.1 2007/04/19 10:37:23 dkumar Exp $ 
* 
*  Modification History:
*  $Log: GenerateSymmetricKeyWithKS.java,v $
*  Revision 1.1  2007/04/19 10:37:23  dkumar
*  SymmetricKeyGeneration
*
*  Revision 1.2  2007/04/16 14:42:49  dkumar
*  using Bouncycastle crypto provider
*
*  Revision 1.1  2007/04/12 16:49:04  dkumar
*  base version
*
*/
package com.ntelx.nxlicensing;

import javax.crypto.*;

import java.security.*;
import java.io.*;

public class GenerateSymmetricKeyWithKS 
{
    private static String STORE_NAME = "C:/FDfolio/FD-runtime/fdt_store.ks";
    private static char[] STORE_PASSWD = "variaware".toCharArray();
    private static char[] KEY_PASSWD = "fdt_secret".toCharArray();
    private static String KEY_ALIAS = "fdt_symm_key";

    public static void main(String[] argv) throws Exception {

    // Generate a DES Key
    KeyGenerator kg = KeyGenerator.getInstance("DES");
    //initialize the key size
    SecretKey desKey = kg.generateKey();

    // load an empty KeyStore with type 'JCEKS'
    // and save the generated key into it.
    KeyStore ks = KeyStore.getInstance("JCEKS");   
//    FileInputStream fis = new FileInputStream(STORE_NAME);
    ks.load(null, STORE_PASSWD);
    ks.setKeyEntry(KEY_ALIAS, desKey, KEY_PASSWD, null);

    // Store the KeyStore object into a file 'tempTest.ks'.
    FileOutputStream fos = new FileOutputStream(STORE_NAME);
    ks.store(new BufferedOutputStream(fos), STORE_PASSWD);

    // Load the keystore file and verify the DES key can
    // be successfully retrieved.
    Key retrievedKey = ks.getKey(KEY_ALIAS, KEY_PASSWD);
    if (retrievedKey instanceof SecretKey) {
        SecretKey key2 = (SecretKey) retrievedKey;
        System.out.println("Success "+retrievedKey);
//        if (desKey.equals(key2)) {
//        System.out.println("Success - DES Keys are the same!");
//        } else {
//        System.out.println("Failed - DES Keys are NOT the same!");
//        }
    } else {
        System.out.println("Failed - Keys retrieved is of WRONG type!");
    }
    }
}
