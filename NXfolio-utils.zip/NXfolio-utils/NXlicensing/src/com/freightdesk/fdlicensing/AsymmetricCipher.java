/** 
* Copyright (c) 2000-2002 FreightDesk Technologies, LLC 
*  All rights reserved. 
* 
* This software is the confidential and proprietary information of FreightDesk Technologies, LLC 
* ("Confidential Information").  You shall not disclose such Confidential Information 
* and shall use it only in accordance with the terms of the license agreement you entered 
* into with FreightDesk Technologies, LLC. 
* 
* 
*  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDLicensing/src/com/freightdesk/fdlicensing/AsymmetricCipher.java,v 1.1 2007/04/12 16:49:04 dkumar Exp $ 
* 
*  Modification History:
*  $Log: AsymmetricCipher.java,v $
*  Revision 1.1  2007/04/12 16:49:04  dkumar
*  base version
*
*/
package com.freightdesk.fdlicensing;

import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.security.GeneralSecurityException;
import java.security.Key;
import java.security.KeyStore;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.security.cert.Certificate;

import javax.crypto.Cipher;

/**
 * @author Deepak Kumar
 *
 */
public class AsymmetricCipher
{
    private static String algorithm = "RSA/NONE/NoPadding";
    private static PublicKey publickey = null;
    private static PrivateKey privateKey = null;
    private static Signature sig = null;

    
    private static String CLIENT_STORE_NAME = "C:/keystore/fdt_client_store";
    private static char[] CLIENT_STORE_PASSWD = "fdtclient".toCharArray();
    private static String PUBLIC_CERT_ALIAS = "licKey";

    private static String SIGNER_STORE_NAME = "C:/keystore/fdt_store";
    private static char[] SIGNER_STORE_PASSWD = "variaware".toCharArray();
    private static char[] PRIVATE_KEY_PASSWD = "fdtlickey".toCharArray();
    private static String PRIVATE_KEY_ALIAS = "licKey";
    
    private static Cipher cipher = null;

    static
    {
        try {
  //          sig = Signature.getInstance(algorithm); 
            cipher = Cipher.getInstance(algorithm,"BC");
       } catch (Exception e) {
           System.err.println("Exception in AsymetricCipher :"+e.getMessage());
       }
    }


    public static class ClientCipher
    {
        static
        {
            try {
                setUpCleint();
           } catch (Exception e) {
               System.err.println("Exception in ClientCipher :"+e.getMessage());
           }
        }

        public static boolean verify(byte[] digest, byte[] content) throws GeneralSecurityException
        {
            sig.initVerify(publickey);
            sig.update (content);
            if (sig.verify(digest)) {
              System.out.println ("Valid");
              return true;
            } else {
              System.out.println ("Invalid");
              return false;
            }
        }
        
        public static String decryptByPublicKey(byte[] encryptionBytes) throws GeneralSecurityException
        {
            cipher.init(Cipher.DECRYPT_MODE, publickey);
            byte[] recoveredBytes = 
            cipher.doFinal(encryptionBytes);
            String recovered =  new String(recoveredBytes);
            return recovered;
        }

        private static void setUpCleint() throws Exception
        {
            KeyStore clientKS = KeyStore.getInstance("JCEKS");   
            FileInputStream fis = new FileInputStream(CLIENT_STORE_NAME);
            clientKS.load(new BufferedInputStream(fis), CLIENT_STORE_PASSWD);
            Certificate cert = clientKS.getCertificate(PUBLIC_CERT_ALIAS);
            publickey = cert.getPublicKey();
        }


    }
    
    public static class SenderCipher
    {
        static
        {
            try {
                setUpSender();
            } catch (Exception e) {
               System.err.println("Exception in SenderCipher :"+e.getMessage());
            }
        }

        public static byte[] sign(byte[] content) throws GeneralSecurityException
        {
            sig.initSign(privateKey);
            sig.update (content);
            byte digest[] = sig.sign();
            return digest;
        }
        
        public static byte[] encryptByPrivateKey(String input) throws GeneralSecurityException 
        {
            cipher.init(Cipher.ENCRYPT_MODE, privateKey);
            byte[] inputBytes = input.getBytes();
            return cipher.doFinal(inputBytes);
        }

        private static void setUpSender() 
        {
            Key retrievedKey=null;
            try {
            KeyStore senderKS;
        
            senderKS = KeyStore.getInstance("JCEKS");
            FileInputStream fis = new FileInputStream(SIGNER_STORE_NAME);
            senderKS.load(new BufferedInputStream(fis), SIGNER_STORE_PASSWD);
            System.out.println(senderKS.toString());
            System.out.println(senderKS.isKeyEntry(PRIVATE_KEY_ALIAS));
            retrievedKey = senderKS.getKey(PRIVATE_KEY_ALIAS, PRIVATE_KEY_PASSWD);
            if (retrievedKey instanceof PrivateKey) {
                privateKey = (PrivateKey) retrievedKey;
            } else {
                System.out.println("Failed - Keys retrieved is of WRONG type!"+retrievedKey);
            }
            } catch (Exception e) {
                System.out.println("Failed - Keys retrieved is of WRONG type "+retrievedKey);
                e.printStackTrace();
            }   
      }

    }
}
