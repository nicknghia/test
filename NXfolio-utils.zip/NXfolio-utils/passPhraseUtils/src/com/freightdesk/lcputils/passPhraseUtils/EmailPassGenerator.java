
package com.freightdesk.lcputils.passPhraseUtils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;

import org.apache.commons.codec.binary.Base64;

import sun.misc.BASE64Encoder;

	/**
	 * Generates a passPhrase for email based on a password
	 * Used from Command Line
	 *
	 */

public class EmailPassGenerator
{
	public static String pass = null;
	public static String encPass = null;


	public static void main (String args[])
	{

		if (args.length < 1)
		{
			 System.out.println( "USAGE IS: Java EmailPassGenerator password" );
			 System.exit(0);
		}
		
		try {
		  /** Target password */
		  pass = args[0];
		
		  encPass = new String(Base64.encodeBase64(pass.getBytes()));
	    
		} catch (Exception ex) {
			System.out.println("Failed to encode.");
			ex.printStackTrace();
		}
		
		System.out.println( "Passphrase for password " + pass + " is " + encPass );
	}
}
