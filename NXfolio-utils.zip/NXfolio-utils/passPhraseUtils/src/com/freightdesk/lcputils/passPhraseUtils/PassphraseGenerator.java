/**
 *
 * Copyright (c) 2000-2002 FreightDesk Technologies, LLC
 *  All rights reserved.
 *
 * This software is the confidential and proprietary information of FreightDesk Technologies, LLC
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with FreightDesk Technologies, LLC.
 *
 *
 *  This utility will generate to stdout a passphrase for the given password 
 *  $Id: PassphraseGenerator.java,v 1.1 2004/04/07 14:30:25 bdealey Exp $ 
 *
 *  Modification History:
 *  $Log: PassphraseGenerator.java,v $
 *  Revision 1.1  2004/04/07 14:30:25  bdealey
 *  Moved from lcp-client
 *
 *
 *
 *
 */

/**
 * To Run
 * java PassphraseGenerator password
 *
 */

package com.freightdesk.lcputils.passPhraseUtils;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import sun.misc.BASE64Encoder;

	/**
	 * Generates a passPhrase based on a password
	 * Used from Command Line
	 *
	 */

public class PassphraseGenerator
{
	public static  String password =null;

	/** The type of hashing alogorithm to be used eg. MD5, SHA */
	final static  String hashingAlgo = "SHA-1";

	public static void main (String args[])
	{

		if (args.length < 1)
		{
			 System.out.println( "USAGE IS: Java PassphraseGenerator password" );
			 System.exit(0);
		}

		/** Target password */
		password = args[0];

		byte[] buf = new byte[password.length()];
		buf = password.getBytes();
		MessageDigest algo = null;
		try
		{
			algo = MessageDigest.getInstance(hashingAlgo);
		} catch (NoSuchAlgorithmException nsa) {
			System.out.println ("No Such Algorithm : " + nsa);
			nsa.printStackTrace();
			return;
		}
		algo.reset();
		algo.update(buf);
		byte[] digestedPwdBytes = algo.digest();
		String passwordHash = new String(new BASE64Encoder().encode(digestedPwdBytes));
		System.out.println( "Passphrase for password " + password + " is " + passwordHash );
	}
}
