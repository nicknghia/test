/**
 *
 * Copyright (c) 2000-2002 FreightDesk Technologies, LLC
 *  All rights reserved.
 *
 * This software is the confidential and proprietary information of FreightDesk Technologies, LLC
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with FreightDesk Technologies, LLC.
 *
 *
 *  Modification History:
 *  $Log: SetPassword.java,v $
 *  Revision 1.1.2.1  2010/04/23 22:27:26  mechevarria
 *  updated
 *
 *  Revision 1.1  2004/04/07 14:30:25  bdealey
 *  Moved from lcp-client
 *
 *  Revision 1.1  2004/03/09 09:28:53  ngupta
 *  For multiple or single user
 *
 * 
 *
 */
package com.freightdesk.lcputils.passPhraseUtils;

import java.sql.*;
import java.security.MessageDigest; 
import java.security.NoSuchAlgorithmException;
import sun.misc.BASE64Encoder;

/**                                                                                                                                
  * Updates the passwords in the DB with their hashes.                                                                              
  *                                                                                                                                 
  * @author nitin.gupta                                                                                                          
  */

public class SetPassword
{
    //	   using java.sql.{Statement, DriverManager, Connection, ResultSet,SQLEx.}                                                         
    /** Target database driver */
    public static String DBDriver = "oracle.jdbc.driver.OracleDriver";
    /** Target database userid */
    public static String dbUser = "scott";
    /** Target database password */
    public static String dbPass = "tiger";
    public static String dbUrl = "192.168.20.10:1521:LCPDB";
    public static String userName = null;
    public static String passPhrase = null;
    public static String domainName = null;
	final static String hashingAlgo = "SHA-1";
    public static void main(String args[])
    {
        try
        {
            if (args.length < 5)
            {
                System.out.println("USAGE IS: Java SetPassword DB_URL DB_USER DB_PW Username Passpharse");
                System.exit(0);
            }
            /* Database URL */
            dbUrl = args[0];
            /* UserName  */
            dbUser = args[1];
            /* password  */
            dbPass = args[2];
            try
            {
                // separates the userName and domainName from userId
                int index = args[3].indexOf('.');
                userName = args[3].substring(index + 1, args[3].length());
                domainName = args[3].substring(0, index);
                passPhrase = args[4];
            }
            catch (Exception e)
            {
                System.out.println("Please enter Username properly. It should be username.domain");
                System.exit(0);
            }
            // load the Oracle driver by referencing it
            String conString = "jdbc:oracle:thin:@" + dbUrl;
            System.out.println("conString - " + conString + "/n" + "dbUrl - " + dbUrl + " " + "dbUser - " + dbUser + " " + "dbPass - " + dbPass + " " + "userName - " + userName + " " + "domainName - " + domainName + " " + "passPhrase - " + passPhrase);
            System.out.println("Loading driver classes ....");
            Class.forName(DBDriver);
            System.out.println("Driver Loaded.");
            System.out.println("Geting Connection ....");
            Connection con = DriverManager.getConnection(conString, dbUser, dbPass);
            System.out.println("Connection Found");
            PreparedStatement pStmt = null;
			String passwordHash = "";
			
			if ( passPhrase != null && !passPhrase.equals(""))
			{                      
				byte[] buf = new byte[passPhrase.length()];
				buf = passPhrase.getBytes();
				MessageDigest algo = null;
				try {
					algo = MessageDigest.getInstance(hashingAlgo);
				} catch (NoSuchAlgorithmException nsa) {
					System.out.println ("No Such Algorithm : " + nsa); 
					nsa.printStackTrace();
					return;
				}
				algo.reset();
				algo.update(buf);
				byte[] digestedPwdBytes = algo.digest(); 
				passwordHash = new String(new BASE64Encoder().encode(digestedPwdBytes)); 
			}
			else
			{ 
				System.out.println("Please enter UserPassword properly.");
                System.exit(0);
			}

            Statement stmt1 = con.createStatement();
            // Create an update statement here                                                                             
            String updateSql = "UPDATE SYSTEMUSER SET PASSPHRASEHASH = '" + passwordHash + "' WHERE USERID = '" + userName + "' and DOMAINNAME = '" + domainName + "'";
            // Run the update statement     
            System.out.println("updateSql: " + updateSql);
            int rowUpdated = stmt1.executeUpdate(updateSql);
            if(rowUpdated == 0){
            	System.out.println("User/Domain not found -"  + args[3]);
            }
            else{
				System.out.println("Password set for - " + args[3]);
            }
        }
        catch (SQLException sqle)
        {
            System.out.println("sqle: " + sqle);
            sqle.printStackTrace();
        }
        catch (ClassNotFoundException cnfe)
        {
            System.out.println("Failed to load JDBC/ODBC driver.");
        }
        catch (Exception e)
        {
            e.printStackTrace();
        }
    }
}
