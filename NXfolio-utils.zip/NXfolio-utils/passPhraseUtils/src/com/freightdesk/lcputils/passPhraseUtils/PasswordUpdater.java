/**
 *
 * Copyright (c) 2000-2002 FreightDesk Technologies, LLC
 *  All rights reserved.
 *
 * This software is the confidential and proprietary information of FreightDesk Technologies, LLC
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with FreightDesk Technologies, LLC.
 *
 *
 *  Modification History:
 *  $Log: PasswordUpdater.java,v $
 *  Revision 1.1.2.1  2010/04/23 22:27:26  mechevarria
 *  updated
 *
 *  Revision 1.1  2004/04/07 14:30:25  bdealey
 *  Moved from lcp-client
 *
 *  Revision 1.1  2004/03/09 09:28:53  ngupta
 *  For multiple or single user
 *
 * 
 *  
 *
 */

/**
 * To Run
 * java PasswordUpdater MachineIP PortNo SID UserName PWD                                                                                                                             
 * 
 */
package com.freightdesk.lcputils.passPhraseUtils;

import java.security.MessageDigest; 
import java.security.NoSuchAlgorithmException;
import java.sql.*;
import sun.misc.BASE64Encoder;
//import org.apache.xerces.utils.Base64;

	/**                                                                                                                                
	 * Updates the passwords in the DB with their hashes.                                                                              
	 * Used from Command Line                                                                                                                                 
	 *                                                                                                          
	 */                                                                                                                                
            
public class PasswordUpdater {
	/** Target database driver */                                                                                                  
			public static  String DBDriver = "oracle.jdbc.driver.OracleDriver";                                                       
			/** Target database IP */                                                                                                      
			public static  String IP = null;;                                                                               
			/** Target database port */                                                                                                    
			public static String port = null;                                                                                      
			/** Target database SID */                                                                                                     
			public static  String SID = null;                                                                                      
			/** Target database userid */                                                                                                  
			public static  String user = null;                                                                                     
			/** Target database password */                                                                                                
			public static  String pass =null;    
			
			/** The type of hashing alogorithm to be used eg. MD5, SHA */
			final static  String hashingAlgo = "SHA-1";
					
                                                                                                                                   
		                                                                                                                           
			public static void main (String args[])                                                                                        
			{                                                                                                                              
				Connection con = null;
				ResultSet rs = null;
				Statement stmt = null, stmt2 = null;
				
				try {                            
					if (args.length < 5)
					{                                                                                 
					 System.out.println("USAGE IS: Java PasswordUpdater IPAddress Port SID Userid CurrentPassword");
					 System.exit(0);
					}
					/** Database server IP */
					IP = args[0];                                                                               
					/** Target database port */                                                                                                    
					port = args[1];                                                                                      
					/** Target database SID */                                                                                                     
					SID = args[2];                                                                                      
					/** Target database userid */                                                                                                  
					user = args[3];                                                                                     
					/** Target database password */                                                                                                
					pass = args[4];                                                                                     
        		 
						// load the Oracle driver by referencing it                                                                            
					System.out.println("Loading driver classes ....");
					Class.forName(DBDriver);
					System.out.println ("Ok classes loaded");                                                                              
				 
					try{
						
						con =  DriverManager.getConnection("jdbc:oracle:thin:@" + IP + ":" + port + ":" + SID,user,pass);
						System.out.println ("Connection established");                                                                              

					}catch(Exception e){
						System.out.println ("Could not establish connection : " + e); 
						e.printStackTrace();
						return;	
					}
					
					stmt = con.createStatement();                                                                                
					rs = stmt.executeQuery("SELECT SYSTEMUSERID, USERID, PASSWORD, PASSPHRASEHASH FROM SYSTEMUSER");                
					while (rs.next()) 
					{                                                                                                    
						String systemuserid = rs.getString(1);                                                                             
						String userid = rs.getString(2);                                                                                   
						String password = rs.getString(3);                                                                                 
						String passphraseh = rs.getString(4);                                                                              
                    	if ( password != null && !password.equals(""))
						{                      
						
							byte[] buf = new byte[password.length()];
							buf = password.getBytes();
							MessageDigest algo = null;
							try {
								algo = MessageDigest.getInstance(hashingAlgo);
							} catch (NoSuchAlgorithmException nsa) {
								System.out.println ("No Such Algorithm : " + nsa); 
								nsa.printStackTrace();
								return;
							}
							algo.reset();
							algo.update(buf);
							byte[] digestedPwdBytes = algo.digest(); 
							String passwordHash = new String(new BASE64Encoder().encode(digestedPwdBytes)); 
							stmt2 = con.createStatement();                                                      
							// Create an update statement here                                                                             
							String updateSql = "UPDATE SYSTEMUSER SET PASSPHRASEHASH = '" + passwordHash + "' WHERE SYSTEMUSERID = " + systemuserid;
							System.out.println("Password updated for USERID = " + userid );
							// Run the update statement                                                                                    
							stmt2.executeUpdate (updateSql);                                                                            
						}                                                                                                               
					} 
				}catch (ClassNotFoundException cnfe) {                                                                                    
					System.out.println("Failed to load JDBC/ODBC driver.");                                                                
				}  
				catch (SQLException sqle) {                                                                                              
					System.out.println ("SQL Exception: " + sqle);                                                                                  
					sqle.printStackTrace();                                                                                                
				}catch (Exception e) { 
					System.out.println("Exception : " + e);
					e.printStackTrace();                                                                                                   
				} finally{
					try{
						if(rs!=null)
						    rs.close();
						if(stmt!=null)
							stmt.close();
						if(stmt2!=null)
							stmt2.close();
						if(con!=null && !con.isClosed())
							con.close();
					}catch(SQLException esql){
					  System.out.println("Error closing database resources.");
					}
				}
			}
}
