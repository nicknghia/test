set pagesize 999
set linesize 255
set feedback off
ttitle left '***** INSTANCE PARTY ACCT RELATIONSHIP CODES *****' bold
column Party_type format A25
column Meaning format A30 wrap
column Description format A30 wrap
column Enabled_flag format A12
column End_date format A14

SELECT NAME,
DESCRIPTION,
PARTY_USE_FLAG,
ACCOUNT_USE_FLAG,
CONTACT_USE_FLAG,
START_DATE_ACTIVE,
END_DATE_ACTIVE
FROM CSI_IPA_RELATION_TYPES;