set linesize 255
set feedback off
ttitle left '***** WORKFLOW ATTRIBUTES  *****' bold
column WORKFLOW_NAME format A30 HEADING 'Workflow Name';
column ATTRIBUTE_NAME format A30 HEADING 'Attribute Name';
column ATTR_DESC format A30 HEADING 'Attr Desc';

select B.DISPLAY_NAME WORKFLOW_NAME,A.NAME ATTRIBUTE_NAME,A.DESCRIPTION ATTR_DESC
from WF_ITEM_ATTRIBUTES_TL A, WF_ITEM_TYPES_TL B 
where A.item_type IN ('SERVEREQ','JTFBRMSR','JTFBRMPR','JTFTASK')
AND A.ITEM_TYPE = B.NAME
ORDER BY 1,2,3;
