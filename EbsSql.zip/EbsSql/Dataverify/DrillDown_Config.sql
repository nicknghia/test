set linesize 255
set feedback off
ttitle left '***** Drilldown Configuration *****' bold
column BRM_OBJECT_CODE format A30 wrap
column RULE_NAME format A30 wrap
column RULE_DESCRIPTION format A30 wrap

select a.BLOCK_NAME_CODE, b.COLUMN_NAME, c.LABEL
from CSC_PROF_BLOCKS_B a, CSC_PROF_TABLE_COLUMNS_B b, CSC_PROF_TABLE_COLUMNS_tl c
where a.BLOCK_ID = b.BLOCK_ID
and  b.TABLE_COLUMN_ID = c.TABLE_COLUMN_ID
and a.BLOCK_NAME_CODE like '%Inquiries%'
order by 1;
