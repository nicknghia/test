PROMPT **************************************
PROMPT *******  CONNECT as APPS     *********
PROMPT **************************************
PROMPT Please Enter User Name
undefine USER_NAME
define USER_NAME = &1
PROMPT Please Enter Password
undefine PASSWORD
define PASSWORD = &2
PROMPT Please Enter Connect String
undefine SCHEMA_NAME
define SCHEMA_NAME = &3
CONNECT &USER_NAME/&PASSWORD@&SCHEMA_NAME
set feedback off
set scan on
set define on
PROMPT Please Enter Spool File Name
undefine SPOOLFILENAME
define SPOOLFILENAME = &4
spool &SPOOLFILENAME
set termout off
set heading on

@@PATCH_LEVEL.sql
@@CS_INDEXES.SQL
@@AdminUsers.sql
@@Global_Address_format.sql
@@Custom_Security_grants.sql
@@SRTYPE_PARTY_ROLES.SQL
@@FND_CUSTOM_APP.sql
@@FND_MENUS.sql
@@FND_RESPONSIBILITIES.sql
@@FND_RESP_MENUS.sql
@@invalid_summary.sql
@@invalid_list.sql
@@Matter_level_profile_values.sql
@@Alerts_info.sql
@@ar_communication_type.sql
@@ar_contact_type.sql
@@ar_contact_usage.sql
@@ar_contactrole_type.sql
@@ar_partysite_use_code.sql
@@ar_party_type.sql
@@ar_phoneline_type.sql
@@ar_relationship_type.sql
@@ar_relationship_type_group.sql
@@AR_PARTY_REL_TYPE.sql
@@MATTER_INQUIRY_STATUSES.sql
REM@@CS_PROB_CODE_MEANING.sql
@@CS_PROBLEM_CODES.sql
REM@@MATTER_INQUIRY_URGENCIES.sql
@@MATTER_INQUIRY_SEVERITIES.sql
@@MATTER_INQUIRY_TYPES.sql
rem@@vpd_incident_types.sql
@@fnd_jtf_note_status.sql
@@NOTE_TYPES.sql
@@NOTE_TO_SOURCE_MAPPING.sql
@@SR_NOTE_MAPS.SQL
@@fnd_jtf_resource_types.sql
@@fnd_jtf_role_type.sql
@@jtf_task_status.sql
@@JTF_TASK_TYPE.sql
@@jtf_task_priorities.sql
@@TASK_MAPPINGS.SQL
@@CS_LOOKUPS.sql
@@CS_PROFILE_VALUES.sql
@@CSC_PROFILE_VALUES.sql
@@FND_PROFILE_VALUES.sql
@@fnd_messages.sql
@@EGOV_VIEWS.sql
@@USERMGMT_ROLES.sql
@@TSA_PACKAGES.sql
@@VPD_GROUPS.sql
@@WF_ATTRIBUTES.sql
rem@@WF_CUSTOM_LEVEL.sql
@@SYSADMIN_EMAIL.SQL
@@ATTCH_functions.sql
@@JTF_ROLES.sql
@@JTF_GROUPS.sql
@@JTF_GROUP_USAGE.SQL
@@JTF_GROUP_MEMBERS.sql
@@BRM_INQUIRY_RULES.sql
rem@@brm_task_rules.sql
@@MATTER_ROLE_TYPES.sql
@@Resp_Srtype_mapping.sql
@@LINKS_PC.sql
@@IMS_PC.sql
@@DISP_CODES.sql
@@EA_ATTR_GROUPS.sql
@@ExtAttr_DBColumn.sql
@@SRTYPE_ATTRGRP_MAP.sql
@@EA_EXT_TABLE_VIEW.sql
REM@@EA_OBJECT_EXT_TABLES.sql
@@EA_COLUMNS.sql
@@ValueSetsAttached.sql
@@VALUE_SET_INFO.SQL
@@SRTYPE_PAGE_MAP.sql
@@FlexFieldSegments.sql


spool off
set termout on
set feedback on
