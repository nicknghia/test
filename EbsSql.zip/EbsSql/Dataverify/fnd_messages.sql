set pagesize 999
set linesize 255
set feedback off
ttitle left '***** CUSTOM MESSAGES  *****'
column MESSAGE_NAME  format A25 HEADING 'Message Name';
column MESSAGE_TEXT format A30 wrap HEADING 'Prompt';
  
SELECT MESSAGE_NAME
      ,MESSAGE_TEXT
FROM FND_NEW_MESSAGES
WHERE (MESSAGE_NAME LIKE 'CSZ%' OR MESSAGE_NAME LIKE 'TSA%')
ORDER BY 1,2;
