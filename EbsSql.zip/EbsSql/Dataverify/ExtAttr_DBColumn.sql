set pagesize 999
set linesize 255
set feedback off
ttitle left '***** EXT Attr Display name to DB Column Mapping *****' bold
column ATTR_DISPLAY_NAME format A30 HEADING 'Attr Display Name';
column DATABASE_COLUMN format A30 HEADING 'Database Column';


SELECT DISTINCT a.ATTR_DISPLAY_NAME
	  ,a.DATABASE_COLUMN
FROM EGO_ATTRS_V A
    ,EGO_OBJ_ATTR_GRP_ASSOCS_V B
where a.ATTR_GROUP_NAME = b.ATTR_GROUP_NAME
order by 1,2;
