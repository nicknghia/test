set pagesize 999
set linesize 255
set feedback off
ttitle left '***** PROBLEM CODE MAPPING *****' bold
column Incident_type format A30
column Problem_code  format A30
column End_date format A14

select csit.name Incident_type 
,cspm.problem_code Problem_code
,end_date_active End_date
from cs_sr_prob_code_mapping cspm
,cs_incident_types_tl csit
where cspm.incident_type_id = csit.incident_type_id
order by incident_type, problem_code;
