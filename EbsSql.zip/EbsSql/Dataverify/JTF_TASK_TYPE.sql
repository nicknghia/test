set pagesize 999
set linesize 255
set feedback off
ttitle left '***** JTF TASK TYPES *****' bold
column NAME format A25 HEADING 'Name';
column Description format A40 HEADING 'Description';
column SEEDED_FLAG format A5 HEADING 'Seeded Flag';

SELECT TL.name ,TL.description
,B.SEEDED_FLAG
FROM jtf_task_types_B B, jtf_task_types_tl TL
WHERE B.TASK_TYPE_ID = TL.TASK_TYPE_ID
AND NVL(B.END_DATE_ACTIVE,SYSDATE+1) >= SYSDATE
ORDER BY 1,2,3;