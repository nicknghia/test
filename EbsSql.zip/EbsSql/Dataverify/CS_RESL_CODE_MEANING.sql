set pagesize 999
set linesize 255
set feedback off
ttitle left '***** RESOLUTION CODE MEANING *****' 

select LOOKUP_CODE,MEANING,START_DATE_ACTIVE,ENABLED_FLAG
from cs_lookups where lookup_type ='REQUEST_RESOLUTION_CODE'
ORDER BY 1;
