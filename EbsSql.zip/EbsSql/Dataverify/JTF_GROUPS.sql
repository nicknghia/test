set pagesize 999
set linesize 255
set feedback off
ttitle left '***** Resource Groups  *****' bold
column GROUP_NAME format A30 HEADING 'Group Name';
column group_DESC format A60 HEADING 'Group Desc';
column ATTRIBUTE2 format A30 HEADING 'Application';

select b.GROUP_NAME,b.group_DESC,A.ATTRIBUTE2
from jtf_rs_groups_b a, jtf_rs_groups_tl b
where a.GROUP_ID = b.GROUP_ID
 AND NVL(A.END_DATE_ACTIVE,SYSDATE+1) >= SYSDATE
ORDER BY 1,2,3;
