set pagesize 999
set linesize 255
set feedback off
ttitle left '***** MATTER/INQUIRY STATUSES *****' bold
col STATUS format A30 HEADING 'Status';
col Description format A30 HEADING 'Description';

select TL.name STATUS
,TL.description
from cs_incident_STATUSES_B B, cs_incident_STATUSES_tl TL
WHERE B.INCIDENT_STATUS_ID = TL.INCIDENT_STATUS_ID
  and nvl(b.end_date_active,sysdate+1) >= sysdate
order by 1,2;
