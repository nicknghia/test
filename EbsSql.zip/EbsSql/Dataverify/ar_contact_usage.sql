set pagesize 999
set linesize 255
set feedback off
ttitle left '***** CONTACT USAGES *****' bold
col Contact_usage format A20 HEADING 'Contact Usage';
col Meaning format A30 HEADING 'Meaning';
col Description format A30 HEADING 'Description';
col Enabled_flag format A8 HEADING 'Enabled';

select lookup_code Contact_usage
,Meaning
,Description
,Enabled_flag
from ar_lookups
WHERE lookup_type = 'CONTACT_USAGE'
 and nvl(end_date_active,sysdate+1) >= sysdate
ORDER BY 1,2,3,4;


