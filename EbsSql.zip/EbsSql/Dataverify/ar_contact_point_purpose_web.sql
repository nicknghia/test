set pagesize 999
set linesize 255
set feedback off
ttitle left '***** CONTACT POINT PURPOSE WEB *****' bold
column Contact_point_purpose A25 HEADING 'Contact Point Purpose';
column Meaning format A30 HEADING 'Meaning';
column Description format A30 HEADING 'Description';
column Enabled_flag format A12 HEADING 'Enabled Flag';

select lookup_code Contact_point_purpose_web
,Meaning
,Description
,Enabled_flag
from ar_lookups
where lookup_type = 'CONTACT_POINT_PURPOSE_WEB'
  and nvl(end_date_active,sysdate+1) >= sysdate
ORDER BY 1,2,3,4;

