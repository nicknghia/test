set pagesize 999
set linesize 255
set feedback off
ttitle left '***** Matter Role Types *****' bold
column LOOKUP_CODE format A30 HEADING 'Lookup Code';
column MEANING  format A30 HEADING 'Meaning';
column ENABLED_FLAG  format A8 HEADING 'Enabled';

SELECT LOOKUP_CODE,MEANING,ENABLED_FLAG
FROM FND_LOOKUPS WHERE LOOKUP_TYPE = 'MATTER_ROLE_TYPE'
and nvl(end_date_active,sysdate+1) >= sysdate
ORDER BY 1,2,3;
