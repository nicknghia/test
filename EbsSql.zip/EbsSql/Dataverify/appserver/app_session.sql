set linesize 255
set feedback off
ttitle left '***** APPLICATION SESSIONS  *****' 
column LOGIN_TYPE format A15 wrap
column LOGIN_ID format A15 wrap
column AUDSID format A15 wrap
column START_TIME format A11 wrap
column END_TIME format A11 wrap
column RESOURCE_CONSUMER_GROUP format A30 wrap
column LOGIN_RESP_ID format A30 wrap


SELECT LOGIN_TYPE
,      LOGIN_ID
,      AUDSID
,      START_TIME
,      END_TIME
,      RESOURCE_CONSUMER_GROUP
,      LOGIN_RESP_ID
FROM APPLSYS.FND_APPL_SESSIONS
ORDER BY 1;



