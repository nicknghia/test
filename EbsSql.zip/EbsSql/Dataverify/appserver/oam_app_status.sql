set linesize 255
set feedback off
ttitle left '***** OAM APP STATUS   *****' 
column METRIC_SHORT_NAME format A25 wrap
column APPLICATION_ID format A9 wrap
column CONCURRENT_QUEUE_NAME format A30 wrap
column NAME format A25 wrap
column TYPE format A9 wrap
column STATUS_CODE format A30 wrap
column NODE_NAME format A25 wrap


SELECT METRIC_SHORT_NAME
,      APPLICATION_ID
,      CONCURRENT_QUEUE_NAME
,      NAME
,      TYPE
,      STATUS_CODE
,      NODE_NAME
FROM APPLSYS.FND_OAM_APP_SYS_STATUS
order by 1;



