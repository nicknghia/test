set linesize 255
set feedback off
ttitle left '***** OID/Portal SERVERS   *****' 
column NAME format A25 wrap
column SERVER_GUID format A9 wrap
column NODE_ID format A30 wrap
column INTERNAL format A25 wrap
column APPL_TOP_GUID format A9 wrap
column SERVER_TYPE format A30 wrap
column PRI_ORACLE_HOME format A9 wrap
column AUX_ORACLE_HOME format A30 wrap

SELECT NAME
,SERVER_GUID
,NODE_ID
,INTERNAL
,APPL_TOP_GUID
,SERVER_TYPE
,PRI_ORACLE_HOME
,AUX_ORACLE_HOME
FROM APPLSYS.FND_APP_SERVERS
ORDER BY 1;

