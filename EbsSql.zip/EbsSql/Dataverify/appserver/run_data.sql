PROMPT **************************************
PROMPT *******  CONNECT as APPS     *********
PROMPT **************************************
PROMPT Please Enter User Name
undefine USER_NAME
define USER_NAME = &1
PROMPT Please Enter Password
undefine PASSWORD
define PASSWORD = &2
PROMPT Please Enter Connect String
undefine SCHEMA_NAME
define SCHEMA_NAME = &3
CONNECT &USER_NAME/&PASSWORD@&SCHEMA_NAME
set feedback off
set scan on
set define on
PROMPT Please Enter Spool File Name
undefine SPOOLFILENAME
define SPOOLFILENAME = &4
spool &SPOOLFILENAME
set termout off

@@application_servers.sql
@@other_servers.sql
@@app_tops.sql
@@application_nodes.sql
@@oam_app_status.sql
@@app_session.sql
@@applied_patches.sql


spool off
set termout on
set feedback on
