set linesize 255
set feedback off
ttitle left '***** APPL TOPS   *****' 
column APPL_TOP_GUID format A15 wrap
column NAME format A5 wrap
column NODE_ID format A30 wrap
column PATH format A15 wrap
column FILE_SYSTEM_GUID format A5 wrap
column SHARED format A5 wrap


SELECT APPL_TOP_GUID
,NAME
,NODE_ID
,PATH
,FILE_SYSTEM_GUID
,SHARED
FROM APPLSYS.FND_APPL_TOPS
order by 1;




