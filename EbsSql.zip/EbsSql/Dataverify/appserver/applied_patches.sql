set linesize 255
set feedback off
ttitle left '***** APPLIED PATCHES *****' 
column PATCH_NAME format A15 wrap
column PATCH_TYPE format A15 wrap
column MAINT_PACK_LEVEL format A15 wrap
column DATE_APPLIED format A30 wrap
column IMPORTED_FLAG format A11 wrap
column IMPORTED_FROM_DB format A30 wrap
column IMPORTED_ID format A30 wrap
column MERGE_DATE format A30 wrap
column DATA_MODEL_DONE_FLAG format A30 wrap



SELECT PATCH_NAME
,      PATCH_TYPE
,      MAINT_PACK_LEVEL
,      CREATION_DATE DATE_APPLIED
,      IMPORTED_FLAG
,      IMPORTED_FROM_DB
,      IMPORTED_ID
,      MERGE_DATE
,      DATA_MODEL_DONE_FLAG
FROM APPLSYS.AD_APPLIED_PATCHES
ORDER BY 1;



