set linesize 255
set feedback off
ttitle left '***** APPLICATION SERVERS   *****' 
column NODE_NAME format A15 wrap
column PLATFORM_CODE format A5 wrap
column DESCRIPTION format A30 wrap
column BASEPATH format A15 wrap
column STATUS format A5 wrap
column PING_RESPONSE format A5 wrap
column LAST_MONITORED_TIME format A15 wrap
column NODE_MODE format A5 wrap
column SERVER_ADDRESS format A30 wrap
column HOST format A15 wrap
column WEBHOST format A15 wrap
column VIRTUAL_IP format A10 wrap


SELECT NODE_NAME
,PLATFORM_CODE
,DESCRIPTION
,BASEPATH
,STATUS
,PING_RESPONSE
,LAST_MONITORED_TIME
,NODE_MODE
,SERVER_ADDRESS
,HOST
,DOMAIN
,WEBHOST
,VIRTUAL_IP
FROM APPLSYS.FND_NODES;



