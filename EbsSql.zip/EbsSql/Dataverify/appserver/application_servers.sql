set linesize 255
set feedback off
ttitle left '***** APPLICATION SERVERS   *****' 
column SERVER_ID format A15 wrap
column SERVER_ADDRESS format A45 wrap
column DESCRIPTION format A30 wrap

SELECT SERVER_ID
,      SERVER_ADDRESS
,      DESCRIPTION
FROM APPLSYS.FND_APPLICATION_SERVERS
order by 1;

