set pagesize 999
set linesize 255
set feedback off
ttitle left '***** RELATIONSHIP TYPES *****' bold
col Relationship_type format A25 HEADING 'Relationship Type';
col Meaning format A30 HEADING 'Meaning';
col Description format A30 HEADING 'Description';
col Enabled_flag format A8 HEADING 'Enabled';

select lookup_code Relationship_type
,Meaning
,Description
,Enabled_flag
from ar_lookups
WHERE lookup_type = 'RELATIONSHIP_TYPE'
  and nvl(end_date_active,sysdate+1) >= sysdate
ORDER BY 1,2,3,4;
