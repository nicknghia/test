set pagesize 999
set linesize 255
set feedback off
ttitle left '***** FND PROFILE VALUES  *****' bold
column PROFILE_NAME format A30 HEADING 'Profile Name';
column USER_NAME format A30 HEADING 'User Name';
column USER_VALUE format A30 HEADING 'User Value';
column LEVEL format A30 HEADING 'Level';

SELECT distinct FPO.PROFILE_OPTION_NAME PROFILE_NAME, 
FPOT.USER_PROFILE_OPTION_NAME USER_NAME,
FPOV.PROFILE_OPTION_VALUE USER_VALUE,
decode(fpov.level_id,10001,
		'SITE',10002,
		'APPLICATION',10003,
		'RESPONSIBILITY',
		10004,'USER')"LEVEL"
FROM FND_PROFILE_OPTIONS FPO, FND_PROFILE_OPTIONS_TL FPOT, FND_PROFILE_OPTION_VALUES FPOV
WHERE FPO.application_id in (select application_id from fnd_application
	  				 	 where application_short_name = 'FND')
AND FPO.END_DATE_ACTIVE IS NULL 
AND FPO.PROFILE_OPTION_NAME = FPOT.PROFILE_OPTION_NAME
AND FPO.PROFILE_OPTION_ID = FPOV.PROFILE_OPTION_ID
ORDER BY 1,2,3,4;
