set pagesize 999
set linesize 255
set feedback off
ttitle left '***** APPLICATION PATCH LEVEL *****' bold
column ApplicationName format A25
column Status format A30 wrap
column PatchLevel format A30 wrap


SELECT SUBSTR(v.application_name,1,25) ApplicationName
,DECODE(SUBSTR(i.status,1,2),'I','Installed','L','Custom','N','Not Installed','S','SharedProduct') Status
, SUBSTR(i.patch_level,1,15)  PatchLevel
     FROM fnd_application_vl v, fnd_product_installations i
       WHERE v.application_id (+)= i.application_id
       AND i.status != 'N'
      ORDER BY 1,2,3;