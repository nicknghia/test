set pagesize 999
set linesize 255
set feedback off
ttitle left '***** SR TYPE and PAGE MAPPING *****' bold
column SR_TYPE format A30 HEADING 'SR Type';
column INTERNAL_NAME format A30 HEADING 'Internal Name';
column DISPLAY_NAME format A30 HEADING 'Display Name';


SELECT CIT.NAME SR_TYPE
      ,B.INTERNAL_NAME
      ,TL.DISPLAY_NAME
FROM EGO_PAGES_B B, EGO_PAGES_TL TL, CS_INCIDENT_TYPES_TL CIT 
WHERE B.PAGE_ID = TL.PAGE_ID 
AND TO_CHAR(CIT.INCIDENT_TYPE_ID) = B.CLASSIFICATION_CODE
ORDER BY 1,2,3;
