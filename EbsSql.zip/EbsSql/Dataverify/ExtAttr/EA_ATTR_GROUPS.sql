set pagesize 999
set linesize 255
set feedback off
ttitle left '***** Extensible Attribute groups *****' bold
column descriptive_flexfield_name format A27 wrap
column descriptive_flex_context_code format A32 wrap
column MULTI_ROW format A9
column AGV_NAME format A32

select descriptive_flexfield_name
      ,descriptive_flex_context_code
      ,decode(multi_row,'Y','YES','NO') MULTI_ROW
      ,agv_name
from ego_fnd_dsc_flx_ctx_ext 
where application_id in (222,170)
order by 1,2,3,4;
