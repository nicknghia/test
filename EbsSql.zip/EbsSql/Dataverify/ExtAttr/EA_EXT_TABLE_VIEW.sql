set pagesize 999
set linesize 255
set feedback off
ttitle left '***** Extensible Attribute table and view *****' bold
column descriptive_flexfield_name format A30 wrap
column application_tl_table_name format A30 wrap
column application_vl_name format A30

select descriptive_flexfield_name 
	  ,application_tl_table_name 
	  ,application_vl_name 
from ego_fnd_desc_flexs_ext ext
where application_id in (222,170)
order by 1,2,3;
