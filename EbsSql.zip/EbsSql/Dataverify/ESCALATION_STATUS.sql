set pagesize 999
set linesize 255
set feedback off
set heading off
ttitle left '***** JTF TASK ESC STATUS *****' 

SELECT  ' STATUS'|| '	' || 
'DESCRIPTION'|| '	' ||
'FROM_DATE'|| '	' ||
'TO_DATE'|| '	' ||
'USAGE' || '	' ||
'START_BY'|| '	' ||
'DUE_DATE'|| '	' ||
'CLOSED_FLAG'|| '	' ||
'SEEDED_FLAG'|| '	' ||
'ASSIGNED_FLAG'|| '	' ||
'WORKING_FLAG'|| '	' ||
'APPROVED_FLAG'|| '	' ||
'COMPLETED_FLAG'|| '	' ||
'CANCELLED_FLAG'|| '	' ||
'REJECTED_FLAG'|| '	' ||
'ACCEPTED_FLAG'|| '	' ||
'ON_HOLD_FLAG'|| '	' ||
'SCHEDULABLE_FLAG'|| '	' ||
'DELETE_ALLOWED'|| '	' ||
'TASK_STATUS'|| '	' ||
'ASSIGN_STATUS'
FROM DUAL
UNION
SELECT  TL.NAME|| '	' ||
TL.DESCRIPTION|| '	' ||
B.START_DATE_ACTIVE|| '	' ||
B.END_DATE_ACTIVE|| '	' ||
B.USAGE|| '	' ||
B.START_DATE_TYPE|| '	' ||
B.END_DATE_TYPE|| '	' ||
B.CLOSED_FLAG|| '	' ||
B.SEEDED_FLAG|| '	' ||
B.ASSIGNED_FLAG|| '	' ||
B.WORKING_FLAG|| '	' ||
B.APPROVED_FLAG|| '	' ||
B.COMPLETED_FLAG|| '	' ||
B.CANCELLED_FLAG|| '	' ||
B.REJECTED_FLAG|| '	' ||
B.ACCEPTED_FLAG|| '	' ||
B.ON_HOLD_FLAG|| '	' ||
B.SCHEDULABLE_FLAG|| '	' ||
B.DELETE_ALLOWED_FLAG|| '	' ||
B.TASK_STATUS_FLAG|| '	' ||
B.ASSIGNMENT_STATUS_FLAG
FROM jtf_task_statuses_B B, jtf_task_statuses_tl TL
WHERE B.TASK_STATUS_ID = TL.TASK_STATUS_ID
AND usage = 'ESCALATION';