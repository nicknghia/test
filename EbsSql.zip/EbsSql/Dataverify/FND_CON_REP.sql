set pagesize 999
set linesize 255
set feedback off
ttitle left '***** Concurrent Programs  *****' bold
column EXECUTABLE_NAME format A30 wrap
column DESCRIPTION format A60 wrap
column CREATION_DATE format A30 wrap


select a.EXECUTABLE_NAME,b.DESCRIPTION,a.CREATION_DATE from fnd_executables a, fnd_executables_tl b
where a.application_id in (514,170)
and a.EXECUTABLE_ID = b.EXECUTABLE_ID
and to_char(a.creation_date,'YYYY') > '2002'
ORDER BY 1;