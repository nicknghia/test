set pagesize 999
set linesize 255
set feedback off
ttitle left '***** BRM TASK RULES  *****' bold
column workflow_item_type format A30 wrap
column workflow_process_name format A60 wrap
column end_date_active format A30 wrap
column last_brm_check_date  format A30 wrap


SELECT DISTINCT workflow_item_type 
      ,workflow_process_name 
      ,end_date_active
      ,last_brm_check_date 
FROM jtf_brm_processes 
where workflow_process_name like 'XXTSA_ESC_TASK%'
ORDER BY 1,2,3,4;