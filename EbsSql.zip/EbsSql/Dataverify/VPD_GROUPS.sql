set pagesize 999
set linesize 255
set feedback off
ttitle left '***** VPD EDIT/READ ACCESS *****' bold
column MATTER_TYPE format A30 HEADING 'Matter Type';
column GROUP_NAME format A30 HEADING 'Group Name';
column WRITE format A5 HEADING 'Write';
column READ format A5 HEADING 'Read';

select CDG.INCIDENT_TYPE_NAME MATTER_TYPE
,CDG.GROUP_NAME GROUP_NAME
,CDG.EDIT_ACCESS WRITE
,CDG.VIEW_ACCESS READ
from tsasys.INCIDENT_TYPE_GROUP_ACCESS cdg
order by 1,2,3,4;
