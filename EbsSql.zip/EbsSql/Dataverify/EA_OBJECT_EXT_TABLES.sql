set pagesize 999
set linesize 255
set feedback off
ttitle left '***** Extensible Attribute TABLES *****' bold
column application format A30
column ext_table_name format A30

select decode(application_id,170,'Service',222,'TCA') application
,ext_table_name
from ego_object_ext_tables_b
where application_id in (222,170)
order by 1,2;