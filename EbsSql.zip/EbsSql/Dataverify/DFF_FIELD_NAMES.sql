set pagesize 999
set linesize 255
set feedback off
ttitle left '***** DFF COLUMNS  *****' bold
column DESCRIPTIVE_FLEX_CONTEXT_CODE A30 wrap
column app_col_name format A30 wrap
column end_usr_col_name format A30 wrap
column Required format A5 wrap

select distinct fdfc.DESCRIPTIVE_FLEX_CONTEXT_CODE,
                fdfc.application_column_name app_col_name,
                fdfc.end_user_column_name end_usr_col_name,
                fdfc.required_flag Required
from FND_DESCR_FLEX_COLUMN_USAGES fdfc
where fdfc.application_id in (select application_id from fnd_application
	  				 	 where application_short_name = 'CS')
AND descriptive_flexfield_name = 'EGOV_CS_INCIDENT_EXTNS'
order by 1;