set pagesize 999
set linesize 255
set feedback off
ttitle left '***** Resource ROles  *****' bold
column ROLE_CODE format A30 HEADING 'Role Code';
column ROLE_NAME format A30 HEADING 'Role Name';
column ROLE_DESC format A30 HEADING 'Role Desc';

select a.ROLE_CODE,b.ROLE_NAME,b.ROLE_DESC
from jtf_rs_roles_b a, jtf_rs_roles_tl b
where a.ROLE_id = b.ROLE_ID
and a.SEEDED_FLAG = 'N'
ORDER BY 1,2,3;
