set pagesize 999
set linesize 255
set feedback off
ttitle left '***** RELATIONSHIP TYPE GROUPS *****' bold
col Relationship_type_group format A25 HEADING 'Relationship Type Group';
col Meaning format A30 HEADING 'Meaning';
col Description format A30 HEADING 'Description';
col Enabled_flag format A8 HEADING 'Enabled';

select lookup_code Relationship_type_group
,Meaning
,Description
,Enabled_flag
from ar_lookups
WHERE lookup_type = 'RELATIONSHIP_TYPE_GROUP'
 and nvl(end_date_active,sysdate+1) >= sysdate
ORDER BY 1,2,3,4;
