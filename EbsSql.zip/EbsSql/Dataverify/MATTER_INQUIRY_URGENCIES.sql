set pagesize 999
set linesize 255
set feedback off
ttitle left '***** URGENCY TYPES *****' bold
column Urgency format A30
column Description format A30 wrap
column IMPORTANCE_LEVEL format A30
column START_DATE_ACTIVE format A30 wrap
column END_DATE_ACTIVE format A30

select TL.name Urgency
,TL.description
,B.IMPORTANCE_LEVEL
,B.START_DATE_ACTIVE
,B.END_DATE_ACTIVE
from cs_incident_urgencies_B B, cs_incident_urgencies_tl TL
WHERE B.INCIDENT_URGENCY_ID = TL.INCIDENT_URGENCY_ID
order by 1,2,3,4,5;
