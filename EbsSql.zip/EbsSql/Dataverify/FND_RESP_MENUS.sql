set pagesize 999
set linesize 255
set feedback off
ttitle left '***** Menus Attached to Responsibility  *****' bold
col responsibility_name format A30 heading 'Resp Name';
col menu_name format A30 heading  'Menu Name';
col type format A30 heading 'Type';


select rtl.responsibility_name,fm.menu_name,FM.TYPE 
from fnd_responsibility_tl rtl, fnd_responsibility fr,fnd_menus fm
where rtl.RESPONSIBILITY_ID = fr.RESPONSIBILITY_ID
and fr.MENU_ID = fm.MENU_ID
AND FR.APPLICATION_ID IN (170,514)
ORDER BY 1,2,3;
