set pagesize 999
set linesize 255
set feedback off
ttitle left '***** SEVERITY TYPES *****' bold
col Severity format A30 HEADING 'Severity';
col Description format A30 HEADING 'Description';

select tl.name Severity
,tl.Description
from cs_incident_severities b, cs_incident_severities_tl tl
where b.INCIDENT_SEVERITY_ID = tl.INCIDENT_SEVERITY_ID
  and nvl(b.end_date_active,sysdate+1) >= sysdate
order by 1,2;
