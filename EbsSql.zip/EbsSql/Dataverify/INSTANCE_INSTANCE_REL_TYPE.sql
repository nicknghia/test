set pagesize 999
set linesize 255
set feedback off
ttitle left '***** INSTANCE-INSTANCE RELATION TYPE CODES *****' bold
column Party_type format A25
column Meaning format A30 wrap
column Description format A30 wrap
column Enabled_flag format A12
column End_date format A14

SELECT RELATIONSHIP_TYPE_CODE,
NAME,
DESCRIPTION,
RELATIONSHIP_DIRECTION,
TRANSACTION_ONLY_FLAG,
ACTIVE_START_DATE,
ACTIVE_END_DATE
FROM CSI_II_RELATION_TYPES;
