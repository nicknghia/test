set pagesize 999
set linesize 255
set feedback off
ttitle left '***** JTF NOTE TYPES *****' bold
col Jtf_note_type format A25 HEADING 'JTF Note Type';
col Meaning format A30 HEADING 'Meaning';
col Description format A30 HEADING 'Description';
col Enabled_flag format A12 HEADING 'Enabled';

select lookup_code jtf_note_type
,Meaning
,Description
,Enabled_flag
from fnd_lookups
WHERE lookup_type = 'JTF_NOTE_TYPE'
 and nvl(end_date_active,sysdate+1) >= sysdate
ORDER BY 1,2,3,4;
