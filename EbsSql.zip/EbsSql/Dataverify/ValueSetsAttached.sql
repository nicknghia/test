set pagesize 999
set linesize 255
set feedback off
ttitle left '***** Value Sets Attached *****' bold


column SR_TYPE format A30 heading 'SR TYPE';
column ATTR_DISPLAY_NAME format A30 heading 'Attr Display Name';
column VALUE_SET_NAME format A30 heading 'Value Set name';
column ID_COLUMN_NAME format A25 heading 'ID Column name';
column VALUE_COLUMN_NAME format A25 heading 'Value Columns Name';


SELECT DISTINCT C.NAME SR_TYPE
	  ,ATTR_DISPLAY_NAME
	  ,VALUE_SET_NAME
	  ,D.ID_COLUMN_NAME
	  ,D.VALUE_COLUMN_NAME
FROM EGO_ATTRS_V A
    ,EGO_OBJ_ATTR_GRP_ASSOCS_V B
    ,CS_INCIDENT_TYPES_TL C
	,FND_FLEX_VALIDATION_TABLES  D
    ,FND_FLEX_VALUE_SETS E
WHERE A.ATTR_GROUP_NAME = B.ATTR_GROUP_NAME
AND B.CLASSIFICATION_CODE = TO_CHAR(C.INCIDENT_TYPE_ID)
AND A.VALUE_SET_ID = E.FLEX_VALUE_SET_ID
AND E.FLEX_VALUE_SET_ID = D.FLEX_VALUE_SET_ID
AND A.ENABLED_FLAG = 'Y'
ORDER BY 1,2,3,4,5;

