set pagesize 999
set linesize 255
set feedback off
ttitle left '***** MATTER/INQUIRY TYPES *****' bold
col NAME format A25 HEADING 'Name';
col Description format A30 HEADING 'Description';
col WORKFLOW format A25 HEADING 'Workflow';


select A.name
,A.description
,B.WORKFLOW
from cs_incident_types_tl A,CS_INCIDENT_TYPES_B B
WHERE A.INCIDENT_TYPE_ID = B.INCIDENT_TYPE_ID
  and nvl(b.end_date_active,sysdate+1) >= sysdate
order by 1,2,3;
