set pagesize 999
set linesize 255
set feedback off

ttitle left '***** SECURITY FUNCTIONS *****' bold
col INSTANCE_SET_NAME format a30  heading INSTANCE_SET_NAME;
col NAME format a30 heading name;
col predicate format a29 heading 'Predicate';
col end_date format a9 heading 'Grant|End Dt';


select DISTINCT B1.INSTANCE_SET_NAME,G.NAME,b1.PREDICATE,G.END_DATE from 
fnd_objects b, fnd_objects_tl tl, 
FND_OBJECT_INSTANCE_SETS B1, FND_OBJECT_INSTANCE_SETS_TL T1, FND_GRANTS G
where b.OBJECT_ID = tl.OBJECT_ID
AND B.OBJECT_ID = B1.OBJECT_ID
AND B1.INSTANCE_SET_ID = T1.INSTANCE_SET_ID
AND G.INSTANCE_SET_ID = T1.INSTANCE_SET_ID
and b.OBJ_NAME = 'JTF_TASK_RESOURCE'
ORDER BY 1,2,3,4;
