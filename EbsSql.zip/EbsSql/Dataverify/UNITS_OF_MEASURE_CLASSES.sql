set pagesize 999
set linesize 255
set feedback off
set heading off
ttitle left '***** UNIT OF MEASURE CLASSES *****'
SELECT ' NAME'|| '	'||
'DESCRIPTION'|| '	'||
'BASE_UNIT'|| '	'||
'UOM'|| '	'||
'INACTIVE_ON'
FROM DUAL
UNION
SELECT UCT.UOM_CLASS_TL|| '	'||
UCT.DESCRIPTION|| '	'||
UMT.UNIT_OF_MEASURE|| '	'||
UMT.UOM_CODE|| '	'||
UMT.DISABLE_DATE
FROM MTL_UOM_CLASSES_TL UCT,
MTL_UNITS_OF_MEASURE_TL UMT
WHERE UCT.UOM_CLASS = UMT.UOM_CLASS
AND UMT.BASE_UOM_FLAG = 'Y';