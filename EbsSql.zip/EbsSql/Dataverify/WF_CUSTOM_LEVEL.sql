set linesize 255
set feedback off
ttitle left '***** Workflow Custom Level  *****' bold
column name format A30 wrap
column PROTECT_LEVEL format A30 wrap
column CUSTOM_LEVEL format A30 wrap
column description format A30 wrap

select a.NAME,a.PROTECT_LEVEL,a.CUSTOM_LEVEL,b.description
from wf_item_TYPES a, wf_item_types_tl b
WHERE a.NAME IN  ('SERVEREQ','JTFBRMSR','JTFBRMPR','JTFTASK')
and a.name = b.name
ORDER BY 1,2,3,4;
