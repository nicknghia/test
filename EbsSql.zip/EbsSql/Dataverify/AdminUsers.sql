set pagesize 999
set linesize 255
set feedback off
ttitle left '***** ADMIN User INFO *****' bold
column USER_NAME format A30 HEADING 'USER Name';
column SOURCE_NAME format A30 HEADING 'sOURCE NAME';
column EMAIL_ADDRESS format A30 HEADING 'EMAIL';
column GROUP_NAME format A30 HEADING 'GROUP';

select a.USER_NAME, b.SOURCE_NAME, c.EMAIL_ADDRESS, e.GROUP_NAME 
from fnd_user A, jtf_rs_resource_extns b, per_all_people_f c, jtf_rs_group_members d, jtf_rs_groups_tl e
where a.user_name in ('TSATOP_ADMIN','TIBCO_TCC')
and a.USER_ID = b.USER_ID
and b.SOURCE_ID = c.PERSON_ID
and b.RESOURCE_ID = d.RESOURCE_ID
and d.GROUP_ID = e.GROUP_ID
ORDER BY 1,2,3,4;