set pagesize 999
set linesize 255
set feedback off
ttitle left '***** Registered Custom Applications  *****' bold
column APPLICATION_SHORT_NAME format A30 heading 'App Short Name';
column APPLICATION_NAME format A30 heading 'App Name';
column BASEPATH  format A45 heading 'Basepath';


select a.APPLICATION_SHORT_NAME,b.APPLICATION_NAME,a.BASEPATH 
from fnd_application a, fnd_application_tl b
where a.application_short_name like '%TSA%'
and a.APPLICATION_ID = b.APPLICATION_ID
ORDER BY 1,2,3;