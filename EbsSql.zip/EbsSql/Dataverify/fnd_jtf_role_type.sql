set pagesize 999
set linesize 255
set feedback off
ttitle left '***** JTF ROLE TYPES *****' bold
column Jtf_role_type format A25 HEADING 'JTF Role Type';
column Meaning format A30 HEADING 'Meaning';
column Description format A30 HEADING 'Description';
column Enabled_flag format A12 HEADING 'Enabled';



select lookup_code jtf_role_type
,Meaning
,Description
,Enabled_flag
from fnd_lookups
WHERE lookup_type = 'JTF_RS_ROLE_TYPE'
 and nvl(end_date_active,sysdate+1) >= sysdate
ORDER BY 1,2,3,4;
