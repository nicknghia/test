set pagesize 999
set linesize 255
set feedback off
ttitle left '***** Profile Values at Matter Responsibility  *****' bold
col PROFILE_NAME format A30 heading 'Profile Name';
col USER_NAME format A30 heading 'User Profile Name';
col USER_VALUE format A30 heading 'Value';

SELECT FPO.PROFILE_OPTION_NAME PROFILE_NAME, 
FPOT.USER_PROFILE_OPTION_NAME USER_NAME,
FPOV.PROFILE_OPTION_VALUE USER_VALUE
FROM FND_PROFILE_OPTIONS FPO, FND_PROFILE_OPTIONS_TL FPOT, FND_PROFILE_OPTION_VALUES FPOV
WHERE FPO.END_DATE_ACTIVE IS NULL 
AND FPO.PROFILE_OPTION_NAME = FPOT.PROFILE_OPTION_NAME
AND FPO.PROFILE_OPTION_ID = FPOV.PROFILE_OPTION_ID
and fpov.LEVEL_ID = 10003
and fpov.LEVEL_VALUE in (select responsibility_id from fnd_responsibility_tl
                         where  upper(responsibility_name) = 'MATTERS')
ORDER BY 1,2,3;
