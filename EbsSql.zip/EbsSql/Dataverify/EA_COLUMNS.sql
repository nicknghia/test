set pagesize 999
set linesize 255
set feedback off
ttitle left '***** SR TYPE AND EA COLUMN MAPPING *****' bold

column SR_TYPE format A15 heading 'SR TYPE';
column ATTR_DISPLAY_NAME format A20 heading 'Attr Display Name';
column DATABASE_COLUMN format A15 heading 'Database Column';
column SEARCH_MEANING  format A12 heading 'Search Allowed';
column REQUIRED_MEANING format A12 heading 'Required';
column ENABLED_MEANING format A12 heading 'Enabled';
column DEFAULT_VALUE format A12 heading 'Default value';

SELECT DISTINCT C.NAME 
	  ,ATTR_DISPLAY_NAME
	  ,DATABASE_COLUMN
        ,A.SEARCH_MEANING 
        ,a.REQUIRED_MEANING
	  ,a.ENABLED_MEANING
	  ,substr(a.DEFAULT_VALUE,1,30) DEFAULT_VALUE
FROM EGO_ATTRS_V A
    ,EGO_OBJ_ATTR_GRP_ASSOCS_V B
    ,CS_INCIDENT_TYPES_TL C
	,FND_FLEX_VALIDATION_TABLES  D
    ,FND_FLEX_VALUE_SETS E
WHERE A.ATTR_GROUP_NAME = B.ATTR_GROUP_NAME
AND B.CLASSIFICATION_CODE = TO_CHAR(C.INCIDENT_TYPE_ID)
AND A.VALUE_SET_ID = E.FLEX_VALUE_SET_ID
AND E.FLEX_VALUE_SET_ID = D.FLEX_VALUE_SET_ID
AND A.ENABLED_FLAG = 'Y'
ORDER BY 1,2,3,4,5,6,7;
