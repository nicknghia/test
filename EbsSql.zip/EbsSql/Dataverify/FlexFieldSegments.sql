set pagesize 999
set linesize 255
set feedback off
ttitle left '*****Flexfield Segments for Receivables *****' bold
column APPLICATION_TABLE_NAME format A25 heading 'Table Name';
column FREEZE_FLEX_DEFINITION_FLAG format A6 heading 'Frozen';
column TITLE  format A30 heading 'Title';
column CONCATENATED_SEGS_VIEW_NAME format A30 heading 'View Name';


select a.APPLICATION_TABLE_NAME
	  ,a.FREEZE_FLEX_DEFINITION_FLAG
	  ,a.TITLE
	  ,a.CONCATENATED_SEGS_VIEW_NAME
from FND_DESCRIPTIVE_FLEXS_VL a where application_id in (514,170,222)
and a.APPLICATION_TABLE_NAME like  'HZ%'
ORDER BY 1,2,3,4;