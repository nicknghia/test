set pagesize 999
set linesize 255
set feedback off
ttitle left '***** LIST OF INVALID OBJECTS *****' bold
column Object_name format A30 heading 'Object Name';
column Object_type format A25 heading 'Object Type';

select object_name
,object_type
from all_objects
where status = 'INVALID'
order by object_type, object_name;
