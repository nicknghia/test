set pagesize 999
set linesize 255
set feedback off
ttitle left '***** PARTY SITE USE CODES *****' bold
col Party_site_use_code format A25 HEADING 'Party Site Use Code';
col Meaning format A30 HEADING 'Meaning';
col Description format A30 HEADING 'Description';
col Enabled_flag format A8 HEADING 'Enabled';

select lookup_code Party_site_use_code
,Meaning
,Description
,Enabled_flag
from ar_lookups
WHERE lookup_type = 'PARTY_SITE_USE_CODE'
  and nvl(end_date_active,sysdate+1) >= sysdate
ORDER BY 1,2,3,4;
