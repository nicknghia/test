set pagesize 999
set linesize 255
set feedback off
ttitle left '*****  Custom Folders  *****' bold
column NAME format A30 wrap
column OBJECT format A60 wrap
column ITEM_NAME  format A30 wrap
column ITEM_PROMPT  format A30 wrap

SELECT F.NAME,F.OBJECT,FC.ITEM_NAME,FC.ITEM_PROMPT 
FROM FND_FOLDERS F, FND_FOLDER_COLUMNS FC
WHERE F.FOLDER_ID = FC.FOLDER_ID
ORDER BY 1;