set pagesize 999
set linesize 255
set feedback off
set heading off
ttitle left '***** UNITS OF MEASURE  *****' 
SELECT ' UNIT_OF_MEASURE'|| '	' || 
'UOM'|| '	' || 
'DESCRIPTION'|| '	' || 
'BASE_UNIT_FLAG'|| '	' || 
'UOM_CLASS CLASS'|| '	' || 
'INACTIVE_ON'
FROM DUAL
UNION
SELECT UNIT_OF_MEASURE|| '	' ||
UOM_CODE|| '	' ||
DESCRIPTION|| '	' ||
BASE_UOM_FLAG|| '	' ||
UOM_CLASS|| '	' ||
DISABLE_DATE
FROM MTL_UNITS_OF_MEASURE_TL;