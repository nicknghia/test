set pagesize 999
set linesize 255
set feedback off
ttitle left '***** TSA CUSTOM PACKAGES *****' bold
column PACKAGE_NAME format A30 HEADING 'Package Name';
column STATUS format A30 HEADING 'Status';
column OWNER format A30 HEADING 'Owner';

SELECT OBJECT_NAME PACKAGE_NAME
,STATUS 
,OWNER 
FROM ALL_OBJECTS 
WHERE (OBJECT_NAME LIKE 'TSA%' OR  OBJECT_NAME LIKE 'XXTSA%')
AND OBJECT_TYPE IN ('PACKAGE','PACKAGE BODY','FUNCTION','PROCEDURE')
ORDER BY 1,2,3;