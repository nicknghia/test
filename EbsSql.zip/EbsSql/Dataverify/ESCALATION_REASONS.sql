set pagesize 999
set linesize 255
set feedback off
set heading off
ttitle left '***** JTF TASK ESC REASONS *****' 

Select ' esc_reason' || '	' ||
'MEANING' || '	' ||
'DESCRIPTION' || '	' ||
'LEAF_NODE' || '	' ||
'ENABLED_FLAG' || '	' ||
'START_DATE_ACTIVE' || '	' ||
'END_DATE_ACTIVE'
FROM DUAL
UNION
select LOOKUP_CODE || '	' ||
RTRIM(MEANING) || '	' ||
RTRIM(DESCRIPTION) || '	' ||
LEAF_NODE || '	' ||
ENABLED_FLAG || '	' ||
START_DATE_ACTIVE || '	' ||
END_DATE_ACTIVE
from fnd_lookups
where lookup_type = 'JTF_TASK_REASON_CODES'
ORDER BY 1;
