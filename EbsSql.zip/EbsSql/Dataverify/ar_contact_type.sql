set pagesize 999
set linesize 255
set feedback off
ttitle left '***** CONTACT TYPES *****' bold
column Contact_type format A20 HEADING 'Contact Type';
column Meaning format A30 HEADING 'Meaning';
column Description format A30 HEADING 'Description';
column Enabled_flag format A12 HEADING 'Enabled Flag';

select lookup_code Contact_type
,Meaning
,Description
,Enabled_flag
from ar_lookups
WHERE lookup_type = 'CONTACT_TYPE'
 and nvl(end_date_active,sysdate+1) >= sysdate
ORDER BY 1,2,3,4;
