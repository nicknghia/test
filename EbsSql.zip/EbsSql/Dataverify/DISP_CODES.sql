set pagesize 999
set linesize 255
set feedback off
ttitle left '***** Dispostion Codes *****' bold
column lookup_code format A25
column Meaning format A40 wrap
column Description format A40 wrap
column enabled_flag format A1

select lookup_code,meaning,description,enabled_flag
from fnd_lookup_values 
where lookup_type = 'REQUEST_RESOLUTION_CODE'
and NVL(end_date_active,sysdate+1) > sysdate
order by 1,2,3,4;
