set pagesize 999
set linesize 255
set feedback off
ttitle left '***** JTF TASK PRIORITIES *****' bold
column Task_priority format A25 HEADING 'Task Priority';
column Description format A40 HEADING 'Description';

SELECT TL.name task_priority
,TL.description
FROM jtf_task_priorities_B B, jtf_task_priorities_tl TL
WHERE B.TASK_PRIORITY_ID = TL.TASK_PRIORITY_ID
 AND NVL(B.END_DATE_ACTIVE,SYSDATE+1) >= SYSDATE
order by 1,2;
