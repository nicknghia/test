set pagesize 999
set linesize 255
set feedback off
ttitle left '***** DrillDown Window Fields *****' bold
column column_name format A30
column label  format A30
column drilldown_column_flag  format A3
column column_sequence  format A3
column block_name_code A30

select b.column_name,tl.label,b.drilldown_column_flag,b.column_sequence
from CSC_PROF_TABLE_COLUMNS_B b, CSC_PROF_TABLE_COLUMNS_tl tl,csc_prof_blocks_b cb
where b.TABLE_COLUMN_ID = tl.TABLE_COLUMN_ID
and cb.BLOCK_ID = b.BLOCK_ID
--and cb.BLOCK_NAME_CODE in ('OPEN')
and b.TABLE_NAME like 'CS%'
ORDER BY 1;