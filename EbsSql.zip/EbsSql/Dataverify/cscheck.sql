REM $Header: cscheck.sql 115.0 2004/02/18 20:29:06 tbharti ship $
REM +=======================================================================+
REM |    Copyright (c) 2004 Oracle Corporation, Redwood Shores, CA, USA     |
REM |                         All rights reserved.                          |
REM +=======================================================================+
REM | FILENAME                                                              |
REM |     cscheck.sql                                                       |
REM |                                                                       |
REM | DESCRIPTION                                                           |
REM |     This SQL script is used to gather diagnostic information          | 
REM |     related to files and settings used in Service Products.           |
REM |                                                                       |
REM | INPUT/OUTPUT                                                          |
REM |     Inputs : Apps User Name                                           |
REM |                                                                       |
REM |     Output : cscheck.txt                                              |
REM |                                                                       |
REM | NOTE                                                                  |
REM |     This SQL script is run from SQL*Plus.                             |
REM |                                                                       |
REM | HISTORY                                                               |
REM |     22-NOV-2004              TBHARTI               CREATED            |
REM |     14-JUL-2005              TBHARTI               UPDATED            |
REM |     Incorporated changes suggested for CS iBug Initiative.            |
REM |                                                                       |
REM +=======================================================================+

clear buffer;

set verify off
set heading on
set feed off
set linesize 120
set pagesize 5000
set underline '='
set serveroutput on size 1000000

variable apps_uid    number;
variable appl_id1    number;
variable appl_id2    number;
variable appl_id3    number;
variable appl_id4    number;
variable appl_id5    number;

prompt ************************************************************
prompt Important:
prompt 
prompt 1. Run this script from SQL*Plus.
prompt 2. Log into SQL*Plus as a User having access to APPS Schema.
prompt 3. Output  of the script (cscheck.txt) is  created in User's 
prompt    current working directory.
prompt ************************************************************

prompt
accept 6 char prompt 'Please enter User Name of the Apps User reporting the problem : '
prompt (Use SYSADMIN)

PROMPT Please Enter Spool File Name
undefine SPOOLFILENAME
define SPOOLFILENAME = &4
spool &SPOOLFILENAME

select 

prompt ************************************************************
prompt **************** Service Diagnostics Report ****************
prompt ************************************************************

declare
  db_name varchar2(10);
begin
  begin
    select 
      user_id
    into
      :apps_uid
    from fnd_user
    where user_name like upper('&6');
    exception 
      when others then
        dbms_output.put_line(fnd_global.local_chr(10)||'ERROR: Invalid User Name, the output is Incomplete.');
        dbms_output.put_line('Please run the script again, by entering a correct User Name.');
        return;
  end;

  select
    170 -- Service
  , 511 -- Customer Care
  , -1
  , -1
  , -1
  into
    :appl_id1
  , :appl_id2
  , :appl_id3
  , :appl_id4
  , :appl_id5
  from dual;

  select name into db_name from v$database;

  dbms_output.put_line(fnd_global.local_chr(10)||'Run on Database '||db_name||
                                                 ' at '||to_char(sysdate, 'DD-MON-YYYY HH:MI:SS')||
                                                 ' for Apps User '||upper('&6'));
end;
/

col grp_name format a25 heading 'Product Group Name' ;
col grp_type format a20 heading 'Group Type' ;
col multi_org format a10 heading 'Multi Org?' ;
col multi_lingual format a10 heading 'Multi|Lingual?' ;
col multi_currency format a10 heading 'Multi|Currency?' ;
col app_name format a50 heading 'Application Name' ;
col app_s_name format a8 heading 'Short|Name' ;
col inst_status format a10 heading 'Installed?' ;
col product_version format a12 heading 'Product|Version' ;
col patchset format a14 heading 'Patchset Level' ;
col app_id format 9990 heading 'Appl Id' ;

prompt
prompt APPLICATION INSTALLATION DETAILS
prompt ================================

select 
  product_group_name grp_name
, product_group_type grp_type
, multi_org_flag multi_org
, multi_lingual_flag multi_lingual
, multi_currency_flag multi_currency
from fnd_product_groups;

select 
  fav.application_name app_name
, fav.application_short_name app_s_name
, decode(fpi.status, 'I', 'Yes', 
                     'S', 'Shared', 
                     'N', 'No', fpi.status) inst_status
, fpi.product_version
, nvl(fpi.patch_level, 'Not Available') patchset
, fav.application_id app_id
from fnd_application_vl fav, fnd_product_installations fpi
where fav.application_id = fpi.application_id
order by 3 desc;

prompt
prompt PATCHES APPLIED
prompt ===============

declare
  l_count     number:= 0;

  cursor patched_appl
  is 
  select
    fav.application_short_name
  , substr(fav.application_name, 1, 60) application_name
  from  fnd_application_vl fav
  where fav.application_id in (:appl_id1, :appl_id2, :appl_id3, :appl_id4, :appl_id5)
  order by fav.application_name;

  cursor applied_patches(c_appl_short_name varchar2)
  is
  select
    distinct
    aap.patch_name
  , substr(aap.patch_type, 1, 8) patch_type
  , aap.applied_patch_id
  , aap.creation_date
  from  ad_applied_patches aap,
        ad_patch_run_bugs ab
  where ab.application_short_name = c_appl_short_name
  and   ab.orig_bug_number        = aap.patch_name
  order by aap.creation_date desc;

  cursor patch_details(c_patch_id number)
  is
  select
    substr(apd.driver_file_name, 1, 15) d_file
  , substr(apd.platform, 1, 10) platform
  , substr(apd.platform_version, 1, 10) p_version
  , to_char(apr.start_date, 'DD-MON-RR HH:MI:SS') start_date
  , to_char(apr.end_date, 'DD-MON-RR HH:MI:SS') end_date
  , apr.success_flag success
  , substr(apr.failure_comments, 1, 25) fc
  from  ad_patch_drivers apd, 
        ad_patch_runs apr
  where apd.applied_patch_id = c_patch_id
  and   apd.patch_driver_id  = apr.patch_driver_id
  order by apr.start_date asc;

begin
  for patched_appl_rec in patched_appl loop

    l_count := 0;

    for applied_patches_rec in applied_patches(patched_appl_rec.application_short_name) loop

      if l_count = 0 then
        dbms_output.put_line(fnd_global.local_chr(10)||'================================================================================');
        dbms_output.put_line('Patches Applied for '||patched_appl_rec.application_name);
        dbms_output.put_line('================================================================================');
        dbms_output.put_line(fnd_global.local_chr(10)||'Patch # Type     Driver File     Platform   Version    Start Date         End Date           S Failure Reason          ');
        dbms_output.put_line('======= ======== =============== ========== ========== ================== ================== = =========================');
      end if;
 
      for patch_details_rec in patch_details(applied_patches_rec.applied_patch_id) loop

        dbms_output.put_line(rpad(applied_patches_rec.patch_name, 7)||' '||rpad(applied_patches_rec.patch_type, 8)||' '||
                             rpad(patch_details_rec.d_file, 15)||' '||rpad(patch_details_rec.platform, 10)||' '||
                             rpad(patch_details_rec.p_version, 10)||' '||rpad(patch_details_rec.start_date, 18)||' '||
                             rpad(patch_details_rec.end_date, 18)||' '||rpad(patch_details_rec.success, 1)||' '||
                             rpad(patch_details_rec.fc, 25));

      end loop;

      if l_count >= 10 then
        exit;
      else
        l_count := l_count + 1;
      end if;
    end loop;
  end loop;
end;
/

col db format a10 heading 'DB Name';
col created format a20 heading 'Creation Date';

prompt
prompt DATABASE NAME AND CREATION DATE
prompt ===============================

select 
  name db
, to_char(created, 'DD-MON-YYYY HH:MI:SS') created 
from v$database;

col ver format a64 heading 'Oracle RDBMS/Tools Version(s)';

prompt
prompt ORACLE VERSIONS
prompt ===============

select 
  banner ver 
from v$version;

col parameter format a30 heading 'Parameter Name';
col param_value format a49 heading 'Currently Set Value';

prompt
prompt DATABASE PARAMETER SETTINGS
prompt ===========================

select 
  name parameter
, value param_value 
from v$parameter
where name in (
'shared_pool_size',
'shared_pool_reserved_size',
'large_pool_size',
'pre_page_sga',
'use_indirect_data_buffers',
'nls_language',
'nls_date_format',
'nls_time_format',
'nls_numeric_characters',
'db_block_buffers',
'db_block_checksum',
'db_block_size',
'db_block_lru_latches',
'db_writer_processes',
'db_block_max_dirty_target',
'buffer_pool_keep',
'buffer_pool_recycle',
'optimizer_features_enable',
'sort_area_size',
'sort_area_retained_size',
'sort_multiblock_read_count',
'open_cursors',
'sql_trace',
'_optimizer_undo_changes',
'optimizer_mode',
'_optimizer_mode_force',
'_sort_elimination_cost_ratio',
'blank_trimming',
'always_anti_join',
'_complex_view_merging',
'_push_join_predicate',
'_push_join_union_view',
'_fast_full_scan_enabled',
'always_semi_join',
'_ordered_nested_loop',
'optimizer_max_permutations',
'optimizer_index_cost_adj',
'optimizer_index_caching',
'query_rewrite_enabled',
'query_rewrite_integrity',
'_or_expand_nvl_predicate',
'_like_with_bind_as_equality',
'_table_scan_cost_plus_one',
'_new_initial_join_orders',
'utl_file_dir',
'optimizer_percent_parallel',
'cursor_sharing',
'hash_join_enabled',
'hash_area_size',
'hash_multiblock_io_count')
order by name ;

prompt
prompt ROW COUNTS FROM RELEVANT TABLES
prompt ===============================

col hz_parties_count format 99999999999990 heading 'HZ Parties Count';

select count(*) hz_parties_count from HZ_PARTIES;

col okc_hdr_count format 99999999999990 heading 'OKC Headers Count';

select count(*) okc_hdr_count from OKC_K_HEADERS_B;

col csi_count format 99999999999990 heading 'CSI Item Instances Count';

select count(*) csi_count from CSI_ITEM_INSTANCES;

col cs_inc_count format 99999999999990 heading 'CS Incidents All Count';

select count(*) cs_inc_count from CS_INCIDENTS_ALL_B;

col sr_agent_security format a30 heading 'Service Security';
col ss_srtype_restrict format a15 heading 'iSupport Resp|Type Mapping';

prompt
prompt SERVICE SYSTEM OPTIONS
prompt ======================

select
  sr_agent_security
, ss_srtype_restrict 
from cs_system_options;

col program_tag format a25 heading 'Grant Program Tag';
col grantee_type format a7 heading 'Grantee|Type';
col start_date format a9 heading 'Grant|Start Dt';
col end_date format a9 heading 'Grant|End Dt';
col instance_set_name format a15 heading 'Instance Set';
col predicate format a29 heading 'Predicate';
col menu_name format a20 heading 'Menu(Permission Set)';

prompt
prompt SERVICE SEEDED GRANTS
prompt =====================

select 
  g.program_tag
, g.grantee_type
, ois.instance_set_name
, ois.predicate
, g.start_date
, g.end_date
, m.menu_name
From fnd_object_instance_sets ois, fnd_grants g, fnd_menus m
where ois.instance_set_id = g.instance_set_id
and   ois.instance_set_name like 'CS%' 
and   g.program_tag like 'CS_SRSEC%'
and   g.menu_id = m.menu_id;

col policy_name format a30 heading 'Policy Name';
col enable format a6 heading 'Enable';
col static_policy format a6 heading 'Static|Policy';
col object_name format a30 heading 'Object Name';
col object_owner format a10 heading 'Owner';

prompt
prompt SERVICE VPD POLICY
prompt ==================

select
  policy_name
, enable
, static_policy
, object_name
, object_owner 
from dba_policies
where policy_name like 'CS_%';

col sr_type_map format 9999999990 heading 'Resp SR Type Mapping Count';

select 
  count(*) sr_type_map
from cs_sr_type_mapping;

prompt
prompt PROFILE OPTION VALUES
prompt =====================

declare
  l_user_id   varchar2(255);
  l_user_name varchar2(255);
  l_resp_id   varchar2(255);
  l_resp_name varchar2(255);
  l_appl_id   number := -1;
  l_pov       varchar2(60);
  l_lvl       varchar2(10);
  
  cursor profile_options
  is
  select
    fpo.application_id
  , fpo.profile_option_id poi
  , fpo.profile_option_name pon
  , substr(fpo.user_profile_option_name, 1, 60) upon
  from  fnd_profile_options_vl fpo
  where fpo.application_id in (:appl_id1, :appl_id2, :appl_id3, :appl_id4, :appl_id5)
  and   fpo.start_date_active <= sysdate
  and  (nvl(fpo.end_date_active,sysdate) >= sysdate)
  order by fpo.application_id, fpo.user_profile_option_name;

  cursor appl_name(c_appl_id  number)
  is
  select 
    substr(application_name, 1, 60) application_name
  from fnd_application_vl
  where application_id = c_appl_id;

begin

  for rec1 in profile_options loop
    -- if application has changed then change the header.
    if rec1.application_id <> l_appl_id then
      for rec2 in appl_name(rec1.application_id) loop
        dbms_output.put_line(fnd_global.local_chr(10)||'================================================================================');
        dbms_output.put_line('Profile Option Values for '||rec2.application_name);
        dbms_output.put_line('================================================================================');
        dbms_output.put_line(fnd_global.local_chr(10)||
                             'User Profile Option Name                                     Default Value                                     ');
        dbms_output.put_line('============================================================ ==================================================');
      end loop;
      l_appl_id := rec1.application_id;
    end if;

    l_pov := fnd_profile.value_specific(name => rec1.pon, user_id => :apps_uid);

    dbms_output.put_line(rpad(rec1.upon, 60)||' '||rpad(l_pov, 50));

  end loop;
  
end;
/

col owner format a5 heading 'Owner';
col table_owner format a5 heading 'Table|Owner';
col table_name format a30 heading 'Table Name';
col trigger_name format a30 heading 'Trigger Name';
col trigger_type format a16 heading 'Trigger Type';
col triggering_event format a26 heading 'Triggering Event';
col status format a8 heading 'Status';

prompt
prompt DATABASE TRIGGERS
prompt =================

select
  atrg.table_owner
, atrg.table_name
, atrg.trigger_name
, atrg.trigger_type
, atrg.triggering_event
, atrg.status
from  all_triggers atrg, fnd_application fa
where fa.application_id in (:appl_id1, :appl_id2, :appl_id3, :appl_id4, :appl_id5)
and   atrg.table_owner  = fa.application_short_name
order by atrg.table_owner, atrg.table_name, atrg.trigger_type;

col index_name format a30 heading 'Index Name';
col index_type format a25 heading 'Index Type';
col last_analyzed format a11 heading 'Analyzed On';
                                         
prompt
prompt TABLE INDEXES
prompt =============

select
  iu.name table_owner
, io.name table_name
, o.name index_name
, decode(bitand(i.property, 16), 0, '', 'FUNCTION-BASED ') ||
        decode(i.type#, 1, 'NORMAL'||
              decode(bitand(i.property, 4), 0, '', 4, '/REV'),
                      2, 'BITMAP', 3, 'CLUSTER', 4, 'IOT - TOP',
                      5, 'IOT - NESTED', 6, 'SECONDARY', 7, 'ANSI', 8, 'LOB',
                      9, 'DOMAIN') index_type
, to_char(i.analyzetime, 'DD-MON-RR') last_analyzed
, decode(bitand(i.property, 2), 2, 'N/A',
        decode(bitand(i.flags, 1), 1, 'UNUSABLE',
              decode(bitand(i.flags, 8), 8, 'INRPOGRS', 'VALID'))) status
from sys.user$ iu, sys.obj$ io, sys.user$ u, sys.ind$ i, sys.obj$ o, fnd_application fa
where u.user# = o.owner#
  and o.obj# = i.obj#
  and i.bo# = io.obj#
  and io.owner# = iu.user#
  and io.type# = 2 -- tables
  and i.type# in (1, 2, 3, 4, 6, 7, 9)
  and fa.application_id in (:appl_id1, :appl_id2, :appl_id3, :appl_id4, :appl_id5)
  and iu.name = fa.application_short_name 
  order by iu.name, io.name, o.name;

declare
  type PkgCurType IS REF CURSOR;
  type ErrCurType IS REF CURSOR;
  l_pkg_cursor    PkgCurType;
  l_err_cursor    ErrCurType;
  l_query	  varchar2(10000);
  l_where         varchar2(5000);
  l_not_where     varchar2(5000);
  l_name          varchar2(30);
  l_pkg_name      varchar2(30);
  l_type          varchar2(15);
  l_pkg_type      varchar2(4);
  l_file_name     varchar2(25);
  l_version       varchar2(20);
  l_file_name_ver varchar2(500);
  l_status        varchar2(7);
  l_error         varchar2(100);
  l_sequence      number;
  l_prefix        varchar2(50);

  cursor obj_prefix
  is
  select fa.application_short_name||'\_%' prefix
  from   fnd_application fa
  where  fa.application_id in (:appl_id1, :appl_id2, :appl_id3, :appl_id4, :appl_id5)
  union
  select distinct substr(ft.table_name, 1, instr(ft.table_name, '_')-1)||'\_%' prefix
  from   fnd_tables ft
  where  ft.application_id in (:appl_id1, :appl_id2, :appl_id3, :appl_id4, :appl_id5);

  cursor pkg_errors(c_pkg_name varchar2, c_pkg_type varchar2)
  is
  select substr(ltrim(rtrim(text)), 1, 100) error
  from   all_errors
  where  name = c_pkg_name
  and    type = c_pkg_type
  order by sequence;

begin

  l_query := 'select 
                o.name
              , s.source
              , decode(o.type#, 9, ''SPEC'', 11, ''BODY'') type
              , decode(o.type#, 9, ''PACKAGE'', 11, ''PACKAGE BODY'') pkg_type
              , decode(o.status, 0, ''N/A'', 1, ''VALID'', ''INVALID'') status
              from  sys.source$ s, sys.obj$ o, sys.user$ u
              where u.name   = ''APPS''
              and   o.owner# = u.user#
              and   s.obj#   = o.obj#
              and   o.type#  in (9, 11)
              and   s.line between 2 and 3
              and   s.source like ''%Header: %''';

  open obj_prefix;
  loop
    fetch obj_prefix into l_prefix;
    exit when obj_prefix%notfound;

    if l_prefix <> '%' then
      if l_where is null then
        l_where := 'and ( o.name like '''||l_prefix||''' ESCAPE ''\''';
      else
        l_where := l_where||' or  o.name like '''||l_prefix||''' ESCAPE ''\''';
      end if;
    end if;
  end loop;
  close obj_prefix;

  if l_where is not null then
    l_where := l_where||')';
    l_query := l_query||l_where;
  else
    return;
  end if;

  l_query := l_query||' order by 1, 3 desc, 5 desc';

  dbms_output.put_line(fnd_global.local_chr(10)||'PACKAGE VERSIONS');
  dbms_output.put_line('================'||fnd_global.local_chr(10));

  dbms_output.put_line('Name                           File Name                 Version              Type Status ');
  dbms_output.put_line('============================== ========================= ==================== ==== =======');

  open l_pkg_cursor for l_query;
  loop
    fetch l_pkg_cursor into l_name, l_file_name_ver, l_pkg_type, l_type, l_status;
    exit when l_pkg_cursor%notfound;

    l_file_name :=  substr(ltrim(rtrim(substr(substr(l_file_name_ver, instr(l_file_name_ver,'Header: ')),
                                    instr(substr(l_file_name_ver, instr(l_file_name_ver,'Header: ')), ' ', 1, 1),
                                    instr(substr(l_file_name_ver, instr(l_file_name_ver,'Header: ')), ' ', 1, 2) -
                                    instr(substr(l_file_name_ver, instr(l_file_name_ver,'Header: ')), ' ', 1, 1) ))), 1, 25);

    l_version := ltrim(rtrim(substr(substr(l_file_name_ver, instr(l_file_name_ver,'Header: ')),
                                    instr(substr(l_file_name_ver, instr(l_file_name_ver,'Header: ')), ' ', 1, 2),
                                    instr(substr(l_file_name_ver, instr(l_file_name_ver,'Header: ')), ' ', 1, 3) -
                                    instr(substr(l_file_name_ver, instr(l_file_name_ver,'Header: ')), ' ', 1, 2) ))); 

    dbms_output.put_line(rpad(l_name, 30)||' '||rpad(l_file_name, 25)||' '||rpad(l_version, 20)||' '||rpad(l_pkg_type, 4)||' '||rpad(l_status, 7));

    if l_status <> 'VALID' then
      l_pkg_name := null;
      for pkg_errors_rec in pkg_errors(l_name, l_type) loop
        if l_pkg_name is null then
          dbms_output.put_line(fnd_global.local_chr(10)||'Errors for '||l_type||' '||l_name||fnd_global.local_chr(10));
          l_pkg_name := l_name;
        end if;
        dbms_output.put_line(pkg_errors_rec.error);
      end loop;
      if l_pkg_name is null then
        dbms_output.put_line(fnd_global.local_chr(10)||'Errors for '||l_type||' '||l_name||': None'||fnd_global.local_chr(10));
      else
        dbms_output.put_line(fnd_global.local_chr(10));
      end if;
          
    end if;
        
  end loop;

  l_query := 'select
                o.name
              , decode(o.type#, 4, ''VIEW'', 7, ''PROCEDURE'', 8, ''FUNCTION'', 
                               12, ''TRIGGER'', 13, ''TYPE'', 14, ''TYPE BODY'',
                               28, ''JAVA SOURCE'', 29, ''JAVA CLASS'', 43, ''DIMENSIONS'', ''UNDEFINED'')
             , nvl(substr(ltrim(rtrim(e.text)), 1, 75), ''No Errors'')
             , e.sequence#
             from  sys.obj$ o, sys.error$ e, sys.user$ u
             where u.name   = ''APPS''
             and   o.owner# = u.user#
             and   o.obj#   = e.obj#(+)
             and   o.status not in (0, 1)
             and   o.type# in (4, 7, 8, 12, 13, 14, 28, 29, 43)';

  if l_where is not null then
    l_query := l_query||l_where;
  end if;

  l_query := l_query||' order by 1, 4';

  dbms_output.put_line(fnd_global.local_chr(10)||'INVALID OBJECTS/ERRORS');
  dbms_output.put_line('======================'||fnd_global.local_chr(10));

  dbms_output.put_line('Name                           Type        Error                                                                  ');
  dbms_output.put_line('============================== =========== =======================================================================');
  open l_err_cursor for l_query;
  loop
    fetch l_err_cursor into l_name, l_type, l_error, l_sequence;
    exit when l_err_cursor%notfound;
    dbms_output.put_line(rpad(l_name, 30)||' '||rpad(l_type, 11)||' '||l_error);
  end loop;

  l_query := 'select
                r.name
              , decode(r.type#, 4, ''VIEW'', 7, ''PROCEDURE'', 8, ''FUNCTION'', 
                                9, ''PACKAGE'', 11, ''PACKAGE BODY'',
                               12, ''TRIGGER'', 13, ''TYPE'', 14, ''TYPE BODY'',
                               28, ''JAVA SOURCE'', 29, ''JAVA CLASS'', 43, ''DIMENSIONS'', ''UNDEFINED'')
             , nvl(substr(ltrim(rtrim(e.text)), 1, 75), ''No Errors'')
             , e.sequence#
             from  sys.obj$ o, sys.error$ e, sys.user$ u, sys.dependency$ d, sys.obj$ r
             where u.name   = ''APPS''
             and   o.owner# = u.user#
             and   o.type# in (4, 7, 8, 9, 11, 12, 13, 14, 28, 29, 43)
             and   o.obj#   = d.d_obj#
             and   r.obj#   = d.p_obj#
             and   r.status not in (0, 1)
             and   r.obj#   = e.obj#(+)';

  if l_where is not null then
    l_not_where := replace(l_where, 'like', 'not like');
    l_not_where := replace(l_not_where, 'o.name', 'r.name');
    l_not_where := replace(l_not_where, ' or ', ' and ');
    l_query := l_query||l_where;
    l_query := l_query||l_not_where;
  end if;

  l_query := l_query||' order by 1, 4';

  dbms_output.put_line(fnd_global.local_chr(10)||'INVALID REFERENCED OBJECTS/ERRORS FROM OTHER PRODUCTS');
  dbms_output.put_line('====================================================='||fnd_global.local_chr(10));

  dbms_output.put_line('Name                           Type        Error                                                                  ');
  dbms_output.put_line('============================== =========== =======================================================================');
  open l_err_cursor for l_query;
  loop
    fetch l_err_cursor into l_name, l_type, l_error, l_sequence;
    exit when l_err_cursor%notfound;
    dbms_output.put_line(rpad(l_name, 30)||' '||rpad(l_type, 11)||' '||l_error);
  end loop;

end;
/

/* All File Versions */
declare

  type ext_tbl is table of varchar2(30) index by binary_integer;  

  l_extension   ext_tbl;
  l_count       binary_integer := 1;

  cursor appl
  is
  select
    application_short_name
  from fnd_application
  where application_id in (:appl_id1, :appl_id2, :appl_id3, :appl_id4, :appl_id5);

  cursor ver (c_appl_short_name varchar2, c_extension varchar2) 
  is
  select
    af.subdir||'/'||af.filename file_name
  , afv.version_segment1 release
  , afv.version_segment2 version
  , max(to_number(substr(afv.version, decode(instr(afv.version, '.', 1, 2), 
                                             0, null, 
                                             instr(afv.version, '.', 1, 2) + 1)
                                    , instr(afv.version, '.', 1, 3) - instr(afv.version, '.', 1, 2)))) branch
  , max(to_number(substr(afv.version, decode(instr(afv.version, '.', 1, 3), 
                                             0, null, 
                                             instr(afv.version, '.', 1, 3) + 1)))) branch_version 
  from ad_files af, ad_file_versions afv
  where af.app_short_name = c_appl_short_name
  and   af.subdir         not like 'admin%'
  and   af.subdir         not like 'help%'
  and   af.subdir         not like '%driver%'
  and   af.subdir         not like '%readme%'
  and   substr(af.subdir, instr(af.subdir, '/', -1)+1) not in (select language_code
                                                               from   fnd_languages
                                                               where  installed_flag <> 'B')
  and   af.filename       like '%'||c_extension
  and   af.file_id        = afv.file_id
  and   afv.version_segment1||afv.version_segment2 = (select max(afv1.version_segment1)||max(afv1.version_segment2)
                                                      from   ad_files af1, ad_file_versions afv1
                                                      where  af1.app_short_name = af.app_short_name
                                                      and    af1.subdir         = af.subdir
                                                      and    af1.filename       = af.filename
                                                      and    af1.file_id        = afv1.file_id)
  group by af.subdir||'/'||af.filename, afv.version_segment1, afv.version_segment2;

begin
  /* 
  ** Assign File Types for all files for which versions need to be queried.
  */
  l_extension(1) := 'class';
  l_extension(2) := 'dep';
  l_extension(3) := 'dtd';
  l_extension(4) := 'fmb';
  l_extension(5) := 'ildt';
  l_extension(6) := 'jlt';
  l_extension(7) := 'js';
  l_extension(8) := 'lct';
  l_extension(9) := 'ldt';
  l_extension(10):= 'odf';
  l_extension(11):= 'pll';
  l_extension(12):= 'properties';
  l_extension(13):= 'rdf';
  l_extension(14):= 'scr';
  l_extension(15):= 'slt';
  l_extension(16):= 'sql';
  l_extension(17):= 'wft';
  l_extension(18):= 'wfx';
  l_extension(19):= 'xdf';
  l_extension(20):= 'xml';

  -- Print File Versions

  for appl_rec in appl loop

    l_count := l_extension.first;

    while l_count is not null loop

      dbms_output.put_line(fnd_global.local_chr(10)||appl_rec.application_short_name||' '||upper(l_extension(l_count))||' FILE VERSIONS');
      dbms_output.put_line(lpad(' ', length(appl_rec.application_short_name||' '||upper(l_extension(l_count))||' FILE VERSIONS')+1, '='));

      for ver_rec in ver(appl_rec.application_short_name, l_extension(l_count)) loop
      
        dbms_output.put_line(rpad(substr(ver_rec.file_name, 1, 94), 94)||' '||
                                         rpad(substr(rtrim(ver_rec.release||'.'||
                                                           ver_rec.version||'.'||
                                                           ver_rec.branch||'.'||
                                                           ver_rec.branch_version, '.'), 1, 25), 25));
      end loop; 
      l_count := l_extension.next(l_count);
    end loop;
  end loop;

end;
/

set head off
select '** End Report at '||to_char(sysdate, 'DD-MON-YYYY HH:MI:SS')||' **' from dual;

spool off

