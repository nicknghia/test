set pagesize 999
set linesize 255
set feedback off
set heading off
ttitle left '***** UNIT OF MEASURE CONVERSIONS *****' 
SELECT ' UNIT_OF_MEASURE'|| '	' || 
'CLASS'|| '	' || 
'CONVERSION_RATE'|| '	' || 
'BASE_UNIT'|| '	' || 
'INACTIVE_ON'
FROM DUAL
UNION
SELECT UC.UNIT_OF_MEASURE|| '	' || 
UC.UOM_CLASS|| '	' || 
UC.CONVERSION_RATE|| '	' || 
UMT.UNIT_OF_MEASURE|| '	' || 
UMT.DISABLE_DATE
FROM MTL_UOM_CONVERSIONS UC,
MTL_UNITS_OF_MEASURE_TL UMT
WHERE UMT.BASE_UOM_FLAG = 'Y'
AND UC.UOM_CLASS = UMT.UOM_CLASS;