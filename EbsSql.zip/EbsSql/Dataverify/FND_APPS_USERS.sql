set pagesize 999
set linesize 255
set feedback off
ttitle left '***** APPLICATION USERS  *****' bold
column user_name format A30 wrap
column effective_start_date format A11 wrap
column effective_end_date format A11 wrap
column responsibility_name format A30 wrap
column from_date format A11 wrap
column to_date format A11 wrap


SELECT FU.USER_NAME,
FU.START_DATE EFFECTIVE_START_DATE,
FU.END_DATE EFFECTIVE_END_DATE,
FRT.RESPONSIBILITY_NAME,
FUR.START_DATE FROM_DATE,
FUR.END_DATE TO_DATE
FROM FND_USER FU,
FND_USER_RESP_GROUPS FUR,
FND_RESPONSIBILITY_TL FRT,
PER_ALL_PEOPLE_F PPF
WHERE FU.USER_ID = FUR.USER_ID
AND FUR.RESPONSIBILITY_ID = FRT.RESPONSIBILITY_ID
AND FU.EMPLOYEE_ID = PPF.PERSON_ID
AND FU.END_DATE IS NULL
ORDER BY 1,2,3,4,5,6;