set pagesize 999
set linesize 255
set feedback off
ttitle left '***** PARTY REALTIONSHIP TYPES *****' bold
col Party_relations_type format A25 HEADING 'Party Relations Type';
col Meaning format A30 HEADING 'Meaning';
col Description format A30 HEADING 'Description';
col Enabled_flag format A12 HEADING 'Enabled';

select lookup_code Party_relations_type
,Meaning
,Description
,Enabled_flag
from ar_lookups
WHERE lookup_type = 'PARTY_RELATIONS_TYPE'
  and nvl(end_date_active,sysdate+1) >= sysdate
ORDER BY 1,2,3,4;

