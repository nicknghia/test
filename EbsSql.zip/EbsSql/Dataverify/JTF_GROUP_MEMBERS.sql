set pagesize 999
set linesize 255
set feedback off
ttitle left '***** User Group Membership  *****' bold
column USER_NAME format A25 HEADING 'User Name';
column GROUP_NAME format A25 HEADING 'Group Name';
column PRIMARY_GROUP format A30 HEADING 'Primary Group';



select DISTINCT d.USER_NAME, b.GROUP_NAME MEMBER_OF, XXTSA_SERVICE_UTIL_PKG.GET_PRIMARY_GROUP(PPF.PARTY_ID) PRIMARY_GROUP
from jtf_rs_group_members a, jtf_rs_groups_tl b, jtf_rs_resource_extns c,fnd_user d,PER_ALL_PEOPLE_F PPF
where a.GROUP_ID = b.GROUP_ID
and a.RESOURCE_ID = c.RESOURCE_ID
and c.USER_ID = d.USER_ID
AND PPF.PERSON_ID = C.SOURCE_ID
and a.DELETE_FLAG = 'N'
order by 1,2,3;
