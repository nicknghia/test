set pagesize 999
set linesize 255
set feedback off
ttitle left '***** JTF TASK STATUS *****' bold
column Task_status format A25 HEADING 'Task Status';
column Description format A40 HEADING 'Description';


SELECT TL.name task_status
,TL.description
FROM jtf_task_statuses_B B, jtf_task_statuses_tl TL
WHERE B.TASK_STATUS_ID = TL.TASK_STATUS_ID
 and nvl(B.END_DATE_ACTIVE,sysdate+1) >= sysdate
ORDER BY 1,2;
