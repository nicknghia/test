set pagesize 999
set linesize 255
set feedback off
ttitle left '***** INVENTORY ITEMS *****' bold
column Party_type format A25
column Meaning format A30 wrap
column Description format A30 wrap
column Enabled_flag format A12
column End_date format A14

SELECT *
FROM MTL_SYSTEM_ITEMS_B;
