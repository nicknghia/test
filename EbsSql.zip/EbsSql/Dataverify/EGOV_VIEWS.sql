set pagesize 999
set linesize 255
set feedback off
ttitle left '***** EGOV VIEWS *****' bold
column VIEW_NAME format A30 HEADING 'View Name';
column STATUS format A30 HEADING 'Status';
column OWNER format A30 HEADING 'Owner';

SELECT OBJECT_NAME VIEW_NAME
,STATUS 
,OWNER 
FROM ALL_OBJECTS 
WHERE OBJECT_NAME LIKE 'EGOV%' 
AND OBJECT_TYPE = 'VIEW'
ORDER BY 1,2,3;
