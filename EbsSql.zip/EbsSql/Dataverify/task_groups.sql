set linesize 255
set feedback off
ttitle left '***** Task Groups  *****' bold
column name format A60 wrap
column task_group format A10 wrap

select b.NAME , a.ATTRIBUTE2 task_group
from jtf_task_types_b a, jtf_task_types_tl b
where a.TASK_TYPE_ID = b.TASK_TYPE_ID
ORDER BY 1,2;

