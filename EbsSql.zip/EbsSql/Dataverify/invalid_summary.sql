set pagesize 999
set linesize 255
set feedback off
ttitle left '***** SUMMARY OF INVALID OBJECTS *****' bold
column Object_type format A25 heading 'Object Type'
column Total format 9999 heading 'Total'

select object_type
,count(object_type) Total
from all_objects
where status = 'INVALID'
group by object_type
order by object_type;
