set pagesize 999
set linesize 255
set feedback off
ttitle left '***** PARTY REALTIONSHIP TYPES *****' bold
col ALERT_NAME format A25 HEADING 'Alert Name';
col DESCRIPTION format A30 HEADING 'Description';
col NAME format A30 HEADING 'Action';
col Enabled_flag format A12 HEADING 'Enabled';


SELECT DISTINCT A.ALERT_NAME, A.DESCRIPTION, B.NAME, A.ENABLED_FLAG FROM ALR_ALERTS A, ALR_ACTIONS B 
WHERE A.ALERT_NAME LIKE 'TSA%'
AND A.ALERT_ID = B.ALERT_ID
order by 1,2,3,4;