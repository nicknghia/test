set linesize 255
set feedback off
ttitle left '***** Email SERVERS  *****' 
column SERVER_NAME format A9 wrap
column DNS_NAME format A30 wrap
column IP_ADDRESS format A25 wrap
column PORT format A30 wrap
column SERVER_TYPE_ID format A25 wrap
column RT_AVAILABILITY format A30 wrap

SELECT SERVER_NAME
,      DNS_NAME
,      IP_ADDRESS
,      PORT
,      SERVER_TYPE_ID
,      RT_AVAILABILITY
FROM IEM.IEM_EMAIL_SERVERS
order by 1,2,3,4;


