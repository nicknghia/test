set linesize 255
set feedback off
ttitle left '***** Email sCORES  *****' 
column CLASSIFICATION_ID format A9 wrap
column SCORE format A30 wrap
column EMAIL_ACCOUNT_ID format A25 wrap
column CLASSIFICATION_STRING format A30 wrap

SELECT CLASSIFICATION_ID
,      SCORE
,      EMAIL_ACCOUNT_ID
,      CLASSIFICATION_STRING
FROM IEM.IEM_EMAIL_CLASSIFICATIONS
order by 1,2,3,4;


