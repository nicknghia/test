set linesize 255
set feedback off
ttitle left '***** Email classifications  *****' 
column DB_LINK format A9 wrap
column DB_USERNAME format A30 wrap
column DB_SERVER_ID format A25 wrap
column IS_ADMIN format A30 wrap
column CONNECTION_DESC format A25 wrap

SELECT DB_LINK
,      DB_USERNAME
,      DB_SERVER_ID
,      IS_ADMIN
,      CONNECTION_DESC
FROM IEM.IEM_DB_CONNECTIONS
order by 1,2,3,4,5;


