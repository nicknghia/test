set linesize 255
set feedback off
ttitle left '***** Email ACCOUNTS  *****' 
column ACCOUNT_NAME format A9 wrap
column EMAIL_USER format A30 wrap
column DOMAIN format A25 wrap
column ACCOUNT_PROFILE format A30 wrap
column DB_SERVER_ID format A25 wrap
column REPLY_TO_ADDRESS format A30 wrap
column FROM_NAME format A25 wrap

SELECT ACCOUNT_NAME
,      EMAIL_USER
,      DOMAIN
,      ACCOUNT_PROFILE
,      DB_SERVER_ID
,      REPLY_TO_ADDRESS
,      FROM_NAME
FROM IEM.IEM_EMAIL_ACCOUNTS
order by 1,2,3,4,5,6,7;




