PROMPT **************************************
PROMPT *******  CONNECT as APPS     *********
PROMPT **************************************
PROMPT Please Enter User Name
undefine USER_NAME
define USER_NAME = &1
PROMPT Please Enter Password
undefine PASSWORD
define PASSWORD = &2
PROMPT Please Enter Connect String
undefine SCHEMA_NAME
define SCHEMA_NAME = &3
CONNECT &USER_NAME/&PASSWORD@&SCHEMA_NAME
set feedback off
set scan on
set define on
PROMPT Please Enter Spool File Name
undefine SPOOLFILENAME
define SPOOLFILENAME = &4
spool &SPOOLFILENAME
set termout off

@@EMC_DB_SERVERS.sql
@@EMC_CLASSIFICATIONS.sql
@@EMC_CONNECTIONS.sql
@@EMC_ACCOUNTS.sql
@@EMC_EMAIL_SCORES.sql
@@EMC_EMAIL_SERVERS.sql
@@EMC_EMAIL_SERVER_TYPES.sql
@@EMC_EMAIL_SERVER_GROUPS.sql


spool off
set termout on
set feedback on
