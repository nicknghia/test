set linesize 255
set feedback off
ttitle left '***** Email center DB SERVERS   *****' 
column DB_NAME format A9 wrap
column HOSTNAME format A30 wrap
column PORT format A25 wrap
column PROTOCOL format A9 wrap
column SID format A30 wrap
column SERVICE_NAME format A9 wrap
column DB_DESCRIPTION format A30 wrap
column RT_AVAILABILITY format A9 wrap
column EMAIL_NODE format A30 wrap
column ADMIN_USER format A30 wrap

SELECT DB_NAME
,      HOSTNAME
,      PORT
,      PROTOCOL
,      SID
,      SERVICE_NAME
,      DB_DESCRIPTION
,      RT_AVAILABILITY
,      EMAIL_NODE
,      ADMIN_USER
FROM IEM.IEM_DB_SERVERS
order by 1,2,3,4,5,6,7;

