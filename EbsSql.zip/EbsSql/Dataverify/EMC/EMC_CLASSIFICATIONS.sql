set linesize 255
set feedback off
ttitle left '***** Email classifications  *****' 
column CLASSIFICATION_ID format A9 wrap
column EMAIL_ACCOUNT_ID format A30 wrap
column CLASSIFICATION format A25 wrap

SELECT CLASSIFICATION_ID
,      EMAIL_ACCOUNT_ID
,      CLASSIFICATION
FROM IEM.IEM_CLASSIFICATIONS
order by 1,2,3;


