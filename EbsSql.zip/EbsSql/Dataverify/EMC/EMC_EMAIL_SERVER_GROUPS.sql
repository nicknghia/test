set linesize 255
set feedback off
ttitle left '***** Email SERVER GROUPS*****' 
column GROUP_NAME format A30 wrap
column GROUP_DESCRIPTION format A30 wrap


SELECT GROUP_NAME
,      GROUP_DESCRIPTION
FROM IEM.IEM_SERVER_GROUPS
order by 1,2;


