set linesize 255
set feedback off
ttitle left '***** Email SERVERS TYPES *****' 
column EMAIL_SERVER_TYPE format A9 wrap
column IS_SECURE format A30 wrap
column TYPE_DESCRIPTION format A25 wrap


SELECT EMAIL_SERVER_TYPE
,      IS_SECURE
,      TYPE_DESCRIPTION
FROM IEM.IEM_EMAIL_SERVER_TYPES
order by 1,2,3;


