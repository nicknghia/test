set pagesize 999
set linesize 255
set feedback off
ttitle left '***** JTF NOTE STATUSES *****' bold
col Jtf_note_status format A25 HEADING 'JTF Note Status';
col Meaning format A30 HEADING 'Meaning';
col Description format A30 HEADING 'Description';
col Enabled_flag format A12 HEADING 'Enabled';

select lookup_code jtf_note_status
,Meaning
,Description
,Enabled_flag
from fnd_lookups
WHERE lookup_type = 'JTF_NOTE_STATUS'
 and nvl(end_date_active,sysdate+1) >= sysdate
ORDER BY 1,2,3,4;

