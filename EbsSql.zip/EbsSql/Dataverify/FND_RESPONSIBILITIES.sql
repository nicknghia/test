set pagesize 999
set linesize 255
set feedback off
ttitle left '***** CUSTOM Responsibilities  *****' 
col responsibility_name format A30 heading 'Name';
col Description format A30 heading 'Description';
col responsibility_key format A25 heading 'Resp Key';

select DISTINCT rtl.responsibility_name
,rtl.description 
,r.responsibility_key
from fnd_responsibility_tl rtl, fnd_responsibility r, fnd_application_tl fat
where rtl.RESPONSIBILITY_ID = r.RESPONSIBILITY_ID
AND fat.APPLICATION_ID in (170,514)
and rtl.application_id = fat.application_id
ORDER BY 1,2,3;
