set pagesize 999
set linesize 255
set feedback off
ttitle left '***** VPD CIMS INCIDENT TYPES *****' bold
column incident_type format A30 wrap
column description format A30 wrap


select cst.cs_incident_type_name incident_type ,citl.description
from tsasys.cims_sr_types cst
,cs_incident_types_tl citl
where upper(citl.name) = upper(cst.cs_incident_type_name)
order by 1,2;
