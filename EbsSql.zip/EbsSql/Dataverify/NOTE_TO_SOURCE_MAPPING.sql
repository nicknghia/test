set pagesize 999
set linesize 255
set feedback off
ttitle left '***** JTF NOTE TYPE MAPPING *****' bold
column Source_object_code format A25 HEADING 'Source Object Code';
column Note_type format A30 HEADING 'Note Type';

select source_object_code source_object_code
,note_type
from jtf_notes_source_type_map
WHERE SOURCE_OBJECT_CODE = 'SR'
 and nvl(end_date,sysdate+1) >= sysdate
ORDER BY 1,2;

