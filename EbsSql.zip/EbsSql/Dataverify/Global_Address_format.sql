set pagesize 999
set linesize 255
set feedback off
ttitle left '***** Global Address Format *****' bold
col territory_short_name format A25 HEADING 'Country';
col address_style  format A30 HEADING 'Address Style';


select territory_short_name
      ,address_style 
from FND_TERRITORIES_VL
order by 1,2;