set pagesize 999
set linesize 255
set feedback off
ttitle left '***** IMS PROBLEM CODES *****' bold
column RESPONSIBILITY_NAME format A25 HEADING 'Responsibility Name';
column name format A30 HEADING 'Name';
column problem_code format A20 HEADING 'Problem Code';
column Meaning format A30 HEADING 'Meaning';

SELECT distinct FRT.RESPONSIBILITY_NAME,CIT.NAME,PCM.PROBLEM_CODE,CLK.meaning
FROM CS_SR_TYPE_MAPPING CTM
,FND_RESPONSIBILITY_TL FRT
,CS_SR_PROB_CODE_MAPPING_DETAIL PCM
,CS_LOOKUPS CLK
,CS_INCIDENT_TYPES_TL CIT 
WHERE CTM.RESPONSIBILITY_ID = FRT.RESPONSIBILITY_ID
AND CTM.INCIDENT_TYPE_ID = PCM.INCIDENT_TYPE_ID
AND CIT.INCIDENT_TYPE_ID = PCM.INCIDENT_TYPE_ID
AND FRT.RESPONSIBILITY_ID = CTM.RESPONSIBILITY_ID
AND FRT.RESPONSIBILITY_NAME IN ('OT','CAO','CAO - Building Services','CAO - OSHE','CAO - Property Management',
'CAO - Real Estate Services','CRC Manager Responsibility','HR Payroll','Ombudsman','SMA/TSA Leadership',
'TCC Agent Responsibility','Expunge Ombudsman','Expunge OT','IIPO Viewing','Expunge Inquiries Responsibility')
AND CLK.LOOKUP_CODE = PCM.PROBLEM_CODE
AND NVL(CTM.END_DATE,SYSDATE+1) > SYSDATE 
and NVL(PCM.END_DATE_ACTIVE,SYSDATE+1) > SYSDATE
order by 1,2,3,4;
