set pagesize 999
set linesize 255
set feedback off
ttitle left '***** USERMGMT ROLES *****' 
column ROLE_NAME format A30 HEADING 'Role Name';
column ROLE_TYPE format A15 HEADING 'Role Type';
column APP_ID format A10 HEADING 'APP ID';
column CONFLICT_FLAG format A10 HEADING 'Conflict Flag';



select ROLE_NAME,ROLE_TYPE,APP_ID,CONFLICT_FLAG
from EGOV_USERMGMT_ROLES
order by 1,2,3,4;
