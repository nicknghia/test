set pagesize 999
set linesize 255
set feedback off
ttitle left '***** BRM RULES  *****' bold
col workflow_item_type format A30 HEADING 'Workflow Item Type';
col workflow_process_name format A60 HEADING 'Workflow Process Name';
col last_brm_check_date  format A30 HEADING 'Last BRM Check Date';


SELECT DISTINCT workflow_item_type 
      ,workflow_process_name 
      ,last_brm_check_date 
FROM jtf_brm_processes 
where workflow_process_name like 'XXTSA%'
  AND NVL(END_DATE_ACTIVE,SYSDATE+1) >= SYSDATE
ORDER BY 1,2,3;
