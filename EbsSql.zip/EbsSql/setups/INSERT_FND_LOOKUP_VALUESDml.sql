REM   *************************************************************************************************
REM   Name:   INSERT_FND_LOOKUP_VALUESDml.sql
REM   Purpose: Script to create synonyms
REM            
REM   Constraints:  Run as apps/apps
REM
REM
REM    MODIFICATION HISTORY
REM
REM    Date          Person         cr num        Comments
REM    -----------   -----------    -------      ---------------------------------
REM    29-OCT-2005   ZAN/S yang      NONE        Initial Creation of the table script
REM    08-NOV-2005   Harender Marpu  None	 Adding Gating Criteria for the script  
REM    ************************************************************************************************/

REM WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

spool INSERT_FND_LOOKUP_VALUESDml.sql.log
set serveroutput on size 1000000
set define off

PROMPT ************************************************************************************
PROMPT Seed APPLSYS.FND_LOOKUP_VALUES
PROMPT ************************************************************************************
PROMPT

INSERT INTO APPLSYS.FND_LOOKUP_VALUES (
LOOKUP_TYPE,
LANGUAGE,
LOOKUP_CODE, 
MEANING, 
DESCRIPTION,
ENABLED_FLAG,
START_DATE_ACTIVE,
CREATED_BY,
CREATION_DATE,
LAST_UPDATED_BY,
LAST_UPDATE_DATE,
LAST_UPDATE_LOGIN,
SOURCE_LANG,
SECURITY_GROUP_ID,
VIEW_APPLICATION_ID,
ATTRIBUTE1)
VALUES (
'EGO_EF_DATA_LEVEL',
'US', 
'CS_INCIDENTS_LEVEL', 
'Incident Data Level', 
'Incident Data Level',
'Y',
SYSDATE,
2,
SYSDATE,
2,
SYSDATE,
0,
'US',
0,
0,
'CS_SERVICE_REQUEST'
);


PROMPT
PROMPT ******************************************************************************************
PROMPT 
PROMPT Please ignore any unique constraint violation errors.
PROMPT 
PROMPT Please Issue a Commit command and 
PROMPT then issue a EXIT command to continue to next step
PROMPT ******************************************************************************************
PROMPT

