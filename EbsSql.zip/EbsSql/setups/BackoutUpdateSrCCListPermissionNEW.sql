REM ***********************************************************************************
REM Name:    BackoutUpdateSrCCListPermissionNEW.sql
REM Desc:    Backs out values in the fnd_lookup_values table 
REM             
REM             
REM             Must manually commit to save changes.
REM    
REM Constraints: Run as apps on R115{env}1 database.  
REM              This script is rerunable
REM 
REM              
REM History:
REM
REM    Date        Programmer            ClearQuestNum   Description of Change
REM =========== ======================  =============   ===============================
REM 14-Feb-2008  RPotdar                Top000011120    Initial Creation
REM **********************************************************************************


WHENEVER OSERROR EXIT FAILURE ROLLBACK
WHENEVER SQLERROR EXIT FAILURE ROLLBACK

set serveroutput on size 1000000

-- setup spool file for logging SQL output, using timestamp and database name
column timecol new_value timestamp noprint
select to_char(sysdate, 'DD_MON_YY_HH24MISS') timecol from dual;

column dbparm new_value dbname noprint
select sys_context('USERENV','DB_NAME') dbparm from dual;


column hostentry new_value hostname noprint
select sys_context('USERENV','SERVER_HOST') hostentry from dual;


spool BackoutUpdateSrCCListPermissionNEW_&&hostname._&&dbname._&&timestamp..log

set echo on


PROMPT
PROMPT ***********************************************************
PROMPT set Dbms Application Info
PROMPT ***********************************************************
PROMPT

exec dbms_application_info.set_module('BackoutUpdateSrCCListPermissionNEW', 'startup');

PROMPT
PROMPT ***********************************************************
PROMPT verify that script is running as correct Oracle user
PROMPT ***********************************************************
PROMPT

DECLARE

  userName  varchar2(100);
  wronglogin exception;

BEGIN
  select user
  into userName
  FROM DUAL;

  if userName != 'APPS'
  then
    raise wronglogin;
  else
    dbms_output.put_line('Successful User Check');
  end if;

EXCEPTION

  when wronglogin
  then
    dbms_output.put_line('***FAILED user check');
    raise;
END;
/

PROMPT
PROMPT ***********************************************************
PROMPT track time for execution of the script
PROMPT ***********************************************************
PROMPT

set time on
set timing on


PROMPT
PROMPT *******************************************************************
PROMPT Expected number of updates to the fnd_lookup_values table.
PROMPT *******************************************************************
PROMPT

select count(*) "Expected Count"
from fnd_lookup_values
where lookup_type = 'CS_SR_CREATION_CHANNEL'
and trunc(start_date_active) <= trunc(sysdate)
and trunc(NVL(end_date_active, sysdate)) >= trunc(sysdate)
--and LOOKUP_CODE NOT IN ('EMAIL', 'INP','PHONE')
and LOOKUP_CODE IN ('CALLD', 'CALLF','CALLT');              


PROMPT
PROMPT *********************************************************************
PROMPT Update rows in the fnd_lookup_values table
PROMPT *********************************************************************
PROMPT

UPDATE fnd_lookup_values set attribute15=' '
where lookup_type = 'CS_SR_CREATION_CHANNEL'
and trunc(start_date_active) <= trunc(sysdate)
and trunc(NVL(end_date_active, sysdate)) >= trunc(sysdate)
--and LOOKUP_CODE NOT IN ('EMAIL', 'INP','PHONE')
and LOOKUP_CODE IN ('CALLD', 'CALLF','CALLT');

            
PROMPT 
PROMPT *******************************************************
PROMPT If the Expected count and number of updates match, 
PROMPT enter a COMMIT, otherwise, ROLLBACK.
PROMPT NOTE:  YOU MUST COMMIT TO SAVE THE CHANGES!!!!
PROMPT *******************************************************
PROMPT

spool off
