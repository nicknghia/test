REM   Constraints:  Run as apps/apps
REM
REM
REM    MODIFICATION HISTORY
REM
REM    Date          Person         cr num        Comments
REM    -----------   -----------    -------      ---------------------------------
REM    21-MAY-2007   S yang      NONE        Initial Creation of the script
REM    
REM    ************************************************************************************************/

REM WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

spool UpdateRepTempPermissions.log
set serveroutput on size 1000000
set define off

PROMPT ************************************************************************************
PROMPT updating XDO_TEMPLATES_B TABLE TO SET FUNCTION
PROMPT ************************************************************************************
PROMPT



UPDATE XDO_TEMPLATES_B 
set attribute15='TSA_MATTER_VIEW_REPORT'
   ,attribute13 = 'PDF'
WHERE application_short_name = 'CS'
and (end_date > sysdate OR end_date is null)
and template_code = 'TSAMDRPT';

UPDATE XDO_TEMPLATES_B set attribute15='TSA_MATTER_VIEW_REPORT', 
attribute13 = 'RTF',
attribute14=(select incident_type_id from CS_INCIDENT_TYPES_VL WHERE name='Employment Litigation') 
WHERE application_short_name = 'CS'
and (end_date > sysdate OR end_date is null)
and template_code = 'TSAMSPB' OR template_code = 'TSAEEOC';

UPDATE XDO_TEMPLATES_B set attribute15='TSA_MATTER_VIEW_REPORT',
attribute13 = 'RTF',
attribute14=(select incident_type_id from CS_INCIDENT_TYPES_VL WHERE name='Civil Enforcement Cases') 
WHERE application_short_name = 'CS'
and (end_date > sysdate OR end_date is null)
and template_code in ('TSANOV1', 'TSANOV2', 'TSAFNOV1', 'TSAFNOV2', 'TSANOVOPTION');


UPDATE XDO_TEMPLATES_B set attribute15='TSA_IMS_VIEW_REPORT'
,attribute13 = 'PDF'
WHERE application_short_name = 'CS'
and (end_date > sysdate OR end_date is null)
and template_code = 'TSAINQDRPT';



spool off
set define on
PROMPT
PROMPT ******************************************************************************************
PROMPT If the Script runs without any errors, commit the changes
PROMPT ******************************************************************************************
PROMPT
