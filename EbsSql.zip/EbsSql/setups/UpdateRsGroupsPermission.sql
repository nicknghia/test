REM   *************************************************************************************************
REM   Name:    UpdateRsGroupsPermission.sql
REM   Purpose: Script to update JTF_RS_GROUPS_B table to set the function for group striping
REM            
REM            
REM   Constraints:  Run as apps/apps
REM
REM
REM    MODIFICATION HISTORY
REM
REM    Date          Person         cr num        Comments
REM    -----------   -----------    -------      ---------------------------------
REM    21-MAY-2007   S yang      NONE        Initial Creation of the script
REM    20-JUL-2005   Harender Marpu  None	 Adding Gating Criteria for the script  
REM    ************************************************************************************************/

REM WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

spool UpdateRsGroupsPermission.log
set serveroutput on size 1000000
set define off

PROMPT ************************************************************************************
PROMPT updating JTF_RS_GROUPS_B TABLE TO SET FUNCTION
PROMPT ************************************************************************************
PROMPT
UPDATE JTF_RS_GROUPS_B set attribute15='TSA_LINKS_VIEW_RS_GROUP'
where attribute2='LINKS';

UPDATE JTF_RS_GROUPS_B set attribute15='TSA_IMS_VIEW_RS_GROUP'
where attribute2='IMS';


UPDATE JTF_RS_GROUPS_B set attribute15='TSA_BITS_VIEW_RS_GROUP'
where attribute2='BITS';


spool off
set define on
PROMPT
PROMPT ******************************************************************************************
PROMPT If the Script runs without any errors, commit the changes
PROMPT ******************************************************************************************
PROMPT