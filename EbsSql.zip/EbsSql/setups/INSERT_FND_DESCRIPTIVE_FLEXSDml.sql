
--Seed APPLSYS.FND_DESCRIPTIVE_FLEXS

REM   *************************************************************************************************
REM   Name:   INSERT_FND_DESCRIPTIVE_FLEXSDml.sql
REM   Purpose: SEED THE APPLSYS.FND_DESCRIPTIVE_FLEXS  table
REM            
REM   Constraints:  Run as apps/apps
REM
REM
REM    MODIFICATION HISTORY
REM
REM    Date          Person         cr num        Comments
REM    -----------   -----------    -------      ---------------------------------
REM    29-OCT-2005   ZAN/S yang      NONE        Initial Creation of the table script
REM    08-NOV-2005   Harender Marpu  None	 Adding Gating Criteria for the script  
REM    ************************************************************************************************/

REM WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

spool INSERT_FND_LOOKUP_VALUESDml.sql.log
set serveroutput on size 1000000
set define off

INSERT INTO APPLSYS.FND_DESCRIPTIVE_FLEXS (
	APPLICATION_ID, 
	APPLICATION_TABLE_NAME,
	DESCRIPTIVE_FLEXFIELD_NAME,
	TABLE_APPLICATION_ID,
	LAST_UPDATE_DATE,
	LAST_UPDATED_BY,
	CREATION_DATE,
	CREATED_BY,
	LAST_UPDATE_LOGIN,
	CONTEXT_REQUIRED_FLAG,
	CONTEXT_COLUMN_NAME,
	CONTEXT_USER_OVERRIDE_FLAG,
	CONCATENATED_SEGMENT_DELIMITER,
	FREEZE_FLEX_DEFINITION_FLAG,
	PROTECTED_FLAG
	)
	VALUES (
		170, 
		'CS_INCIDENTS_ALL_EXT_B',
		'CS_INCIDENTS_GROUP',
		170,
		SYSDATE,
		2,
		SYSDATE,
		2,
		0,
		'N',
		'ATTR_GROUP_ID',
		'Y',
		'.',
		'N',
		'N'	
	);


PROMPT
PROMPT ******************************************************************************************
PROMPT 
PROMPT Please ignore any unique constraint violation errors.
PROMPT 
PROMPT Please Issue a Commit command and 
PROMPT then issue a EXIT command to continue to next step
PROMPT ******************************************************************************************
PROMPT

