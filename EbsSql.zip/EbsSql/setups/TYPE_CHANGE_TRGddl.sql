REM   *************************************************************************************************
REM   Name:    TYPE_CHANGE_TRGddl.sql
REM   Purpose: Script to create the trigger monitoring the incident_type_id change.
REM            
REM   Constraints:  Run as apps/apps
REM
REM
REM    MODIFICATION HISTORY
REM
REM    Date          Person         cr num        Comments
REM    -----------   -----------    -------      ---------------------------------
REM    29-NOV-2005   ZAN/S yang      NONE        Initial Creation of the table script 
REM    ************************************************************************************************/

REM WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

spool TYPE_CHANGE_TRGddl.log
set serveroutput on size 1000000

PROMPT ************************************************************************************
PROMPT Create the trigger 
PROMPT ************************************************************************************
PROMPT

CREATE OR REPLACE TRIGGER TYPE_CHANGE_TRG
 AFTER UPDATE OF INCIDENT_TYPE_ID ON CS.CS_INCIDENTS_ALL_B
 FOR EACH ROW
	
DECLARE
  CURSOR map_cur
	IS
	SELECT m.FROM_ATTR_GROUP_ID, m.TO_ATTR_GROUP_ID
	FROM cs.EXT_ATTR_GROUP_MAPPING m, cs.CS_INCIDENTS_ALL_EXT_B ext
	WHERE m.FROM_INCIDENT_TYPE_ID = :OLD.INCIDENT_TYPE_ID and m.TO_INCIDENT_TYPE_ID = :NEW.INCIDENT_TYPE_ID
		  AND ext.INCIDENT_ID = :NEW.INCIDENT_ID AND ext.ATTR_GROUP_ID=m.FROM_ATTR_GROUP_ID;

  map_rec	map_cur%ROWTYPE;

BEGIN
	IF NOT map_cur%ISOPEN
	THEN
		OPEN map_cur;
	END IF;

	FETCH map_cur INTO map_rec;

	WHILE map_cur%FOUND
	LOOP
		UPDATE cs.CS_INCIDENTS_ALL_EXT_B
			SET ATTR_GROUP_ID = map_rec.TO_ATTR_GROUP_ID, LAST_UPDATE_DATE = SYSDATE
		WHERE INCIDENT_ID = :NEW.INCIDENT_ID AND ATTR_GROUP_ID = map_rec.FROM_ATTR_GROUP_ID;

		FETCH map_cur INTO map_rec;

	END LOOP;
	CLOSE map_cur;

END;
/

spool off;


PROMPT
PROMPT ******************************************************************************************
PROMPT 
PROMPT Please Issue EXIT command to continue to next step
PROMPT ******************************************************************************************
PROMPT

