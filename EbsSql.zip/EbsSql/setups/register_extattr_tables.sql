REM   *************************************************************************************************
REM   Name:    register_extattr_table.sql
REM   Purpose: Script to Register the CS_INCIDENTS_ALL_EXT_B, CS_INCIDENTS_ALL_EXT_TL 
REM            tables with Oracle applications Under CS schema
REM            
REM   Constraints:  Run as apps/apps
REM
REM
REM    MODIFICATION HISTORY
REM
REM    Date          Person         cr num        Comments
REM    -----------   -----------    -------      ---------------------------------
REM    29-OCT-2005   Harender Marpu    NONE      Initial Creation.
REM    31-OCT-2005   Harender Marpu    None	 Adding CS_INCIDENTS_ALL_EXT_TL table.  
REM    ************************************************************************************************/

REM WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

spool register_extattr_table.log
set serveroutput on size 1000000
set define off

PROMPT ************************************************************************************
PROMPT Registering CS_INCIDENTS_ALL_EXT_B/TL tables with APPS
PROMPT ************************************************************************************
PROMPT

BEGIN
 AD_DD.REGISTER_TABLE('CS','CS_INCIDENTS_ALL_EXT_B','T');
 AD_DD.REGISTER_TABLE('CS','CS_INCIDENTS_ALL_EXT_TL','T');
END;
/

spool off
set define on

PROMPT
PROMPT ******************************************************************************************
PROMPT 
PROMPT Please ignore any unique constraint violation errors.
PROMPT 
PROMPT Please Issue a Commit command and 
PROMPT then issue a EXIT command to continue to next step
PROMPT ******************************************************************************************
PROMPT

