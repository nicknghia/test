REM   *************************************************************************************************
REM   Name:    REG_TL_TABLES_TO_EGO_OBJECT_EXT_TABLES_B.sql
REM   Purpose: Script to Register EA table With EGO Objects
REM           
REM            
REM   Constraints:  Run as apps/apps
REM
REM
REM    MODIFICATION HISTORY
REM
REM    Date          Person         cr num        Comments
REM    -----------   -----------    -------      ---------------------------------
REM    27-APR-2007   ZAN/S yang      NONE        Initial Creation of the table script
REM    ************************************************************************************************/

REM WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

spool REG_TL_TABLES_TO_EGO_OBJECT_EXT_TABLES_B.log
set serveroutput on size 1000000
set define off

PROMPT ************************************************************************************
PROMPT creating CS_INCIDENTS_ALL_EXT_vL view in APPS Schema
PROMPT ************************************************************************************
PROMPT

INSERT INTO EGO.EGO_OBJECT_EXT_TABLES_B (
	OBJECT_ID,
	APPLICATION_ID, 
	EXT_TABLE_NAME,
	CREATED_BY,
	CREATION_DATE,
	LAST_UPDATED_BY,
	LAST_UPDATE_DATE	
	)
	VALUES (
		113, 
		170, 
		'CS_INCIDENTS_ALL_EXT_TL',
		0,
		SYSDATE,
		0,
		SYSDATE
	);

PROMPT ************************************************************************************
PROMPT This Script Requires Commit! Please Commit
PROMPT ************************************************************************************
PROMPT