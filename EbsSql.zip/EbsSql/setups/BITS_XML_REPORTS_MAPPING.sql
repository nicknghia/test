/* Formatted on 2007/12/04 11:25 (Formatter Plus v4.8.7) */
UPDATE xdo_templates_b
   SET attribute15 = 'BITS_PRE_CAR_WS_VIEW_RP' , attribute13 = 'PDF'
 WHERE application_short_name = 'CS' AND (end_date > SYSDATE OR end_date IS NULL) AND template_code = 'BITSPCARWS';

 UPDATE xdo_templates_b
   SET attribute15 = 'BITS_PRE_LOI_WS_VIEW_RP',
       attribute13 = 'RTF'
 WHERE application_short_name = 'CS' AND (end_date > SYSDATE OR end_date IS NULL) AND template_code = 'BITSPLOIWS';
 
 UPDATE xdo_templates_b
   SET attribute15 = 'BITS_SUIT_CAR_WS_VIEW_RP',
       attribute13 = 'PDF'
 WHERE application_short_name = 'CS' AND (end_date > SYSDATE OR end_date IS NULL) AND template_code = 'BITSSCARWS';
 
 UPDATE xdo_templates_b
   SET attribute15 = 'BITS_SUIT_LOI_WS_VIEW_RP',
       attribute13 = 'RTF'
 WHERE application_short_name = 'CS' AND (end_date > SYSDATE OR end_date IS NULL) AND template_code = 'BITSLOIWS';
 
 UPDATE xdo_templates_b
   SET attribute15 = 'BITS_IR_WS_VIEW_RP',
       attribute13 = 'PDF'
 WHERE application_short_name = 'CS' AND (end_date > SYSDATE OR end_date IS NULL) AND template_code = 'BITSIRWS';
 
 UPDATE xdo_templates_b
   SET attribute15 = 'BITS_BADGE_VIEW_RP',
       attribute13 = 'PDF'
 WHERE application_short_name = 'CS' AND (end_date > SYSDATE OR end_date IS NULL) AND template_code = 'BITSBDGTMP';
 
 UPDATE xdo_templates_b
   SET attribute15 = 'BITS_CREDENTIALS_VIEW_RP',
       attribute13 = 'PDF'
 WHERE application_short_name = 'CS' AND (end_date > SYSDATE OR end_date IS NULL) AND template_code = 'BITSCREDTMP';
 
 UPDATE xdo_templates_b
   SET attribute15 = 'BITS_CASE_DETAIL_VIEW_RP',
       attribute13 = 'PDF'
 WHERE application_short_name = 'CS' AND (end_date > SYSDATE OR end_date IS NULL) AND template_code = 'BITSDETRP';