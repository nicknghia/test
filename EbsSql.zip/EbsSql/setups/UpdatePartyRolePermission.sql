REM   Name:    UpdatePartyRolePermission.sql
REM   Purpose: Script to update CS_PARTY_ROLES_B table to set the function for PARTY ROLE striping
REM            
REM            
REM   Constraints:  Run as apps/apps
REM
REM
REM    MODIFICATION HISTORY
REM
REM    Date          Person         cr num        Comments
REM    -----------   -----------    -------      ---------------------------------
REM    21-MAY-2007   S yang      NONE        Initial Creation of the script
REM    20-JUL-2005   Harender Marpu  None	 Adding Gating Criteria for the script  
REM    ************************************************************************************************/

REM WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

spool UpdatePartyRolePermission.log
set serveroutput on size 1000000
set define off

PROMPT ************************************************************************************
PROMPT updating CS_PARTY_ROLES_B TABLE TO SET FUNCTION
PROMPT ************************************************************************************
PROMPT

UPDATE CS_PARTY_ROLES_B set attribute15='TSA_BITS_VIEW_PARTY_ROLE'
where Party_Role_Code like 'BITS_%';

UPDATE CS_PARTY_ROLES_B set attribute15='TSA_LINKS_VIEW_PARTY_ROLE'
where CREATION_DATE < to_date('12/31/2006', 'MM/DD/YYYY');

spool off
set define on
PROMPT
PROMPT ******************************************************************************************
PROMPT If the Script runs without any errors, commit the changes
PROMPT ******************************************************************************************
PROMPT