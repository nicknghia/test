REM   *************************************************************************************************
REM   Name:    EXT_ATTR_GROUP_MAPPINGdml.sql
REM   Purpose: Script to insert into extended attribute group mappings.
REM            
REM   Constraints:  Run as apps/apps
REM
REM
REM    MODIFICATION HISTORY
REM
REM    Date          Person         cr num        Comments
REM    -----------   -----------    -------      ---------------------------------
REM    29-NOV-2005   ZAN/S yang      NONE        Initial Creation of the table script 
REM    ************************************************************************************************/

REM WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

spool EXT_ATTR_GROUP_MAPPINGdml.log
set serveroutput on size 1000000
set define off

PROMPT ************************************************************************************
PROMPT INSERTING INTO EXT_ATTR_GROUP_MAPPING table in schema CS.
PROMPT ************************************************************************************
PROMPT

DELETE FROM CS.EXT_ATTR_GROUP_MAPPING;

INSERT INTO CS.EXT_ATTR_GROUP_MAPPING(
  FROM_ATTR_GROUP_ID,
  TO_ATTR_GROUP_ID,
  FROM_INCIDENT_TYPE_ID,
  TO_INCIDENT_TYPE_ID,
  CREATED_BY
 ) VALUES (	(select attr_group_id from EGO_ATTR_GROUPS_V where attr_group_name = 'TCCSEC_GRP'), 	
	(select attr_group_id from EGO_ATTR_GROUPS_V where attr_group_name = 'CRC_INQ_GRP'),	41,	1, 0);


INSERT INTO CS.EXT_ATTR_GROUP_MAPPING(
  FROM_ATTR_GROUP_ID,
  TO_ATTR_GROUP_ID,
  FROM_INCIDENT_TYPE_ID,
  TO_INCIDENT_TYPE_ID,
  CREATED_BY
 ) VALUES (	(select attr_group_id from EGO_ATTR_GROUPS_V where attr_group_name = 'TCC_SEC_INQ_DET'), 	
	(select attr_group_id from EGO_ATTR_GROUPS_V where attr_group_name = 'CRC_INQUIRY_DETAIL'),41,	1, 0);


INSERT INTO CS.EXT_ATTR_GROUP_MAPPING(
  FROM_ATTR_GROUP_ID,
  TO_ATTR_GROUP_ID,
  FROM_INCIDENT_TYPE_ID,
  TO_INCIDENT_TYPE_ID,
  CREATED_BY
 ) VALUES (	(select attr_group_id from EGO_ATTR_GROUPS_V where attr_group_name = 'CRC_INQ_GRP'), 	
	(select attr_group_id from EGO_ATTR_GROUPS_V where attr_group_name = 'TCCSEC_GRP'),	1,	41, 0);


INSERT INTO CS.EXT_ATTR_GROUP_MAPPING(
  FROM_ATTR_GROUP_ID,
  TO_ATTR_GROUP_ID,
  FROM_INCIDENT_TYPE_ID,
  TO_INCIDENT_TYPE_ID,
  CREATED_BY
 ) VALUES (	(select attr_group_id from EGO_ATTR_GROUPS_V where attr_group_name = 'CRC_INQUIRY_DETAIL'), 	
	(select attr_group_id from EGO_ATTR_GROUPS_V where attr_group_name = 'TCC_SEC_INQ_DET'), 1,41, 0);

 
 spool off;
 set define on
 
 PROMPT
 PROMPT ******************************************************************************************
 PROMPT 
 PROMPT Please ignore any unique constraint violation errors.
 PROMPT 
 PROMPT Please Issue a Commit command and 
 PROMPT then issue a EXIT command to continue to next step
 PROMPT ******************************************************************************************
 PROMPT

 
 select * from CS.EXT_ATTR_GROUP_MAPPING
	
	




