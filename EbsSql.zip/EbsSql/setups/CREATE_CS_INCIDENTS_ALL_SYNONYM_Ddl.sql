REM   *************************************************************************************************
REM   Name:   create_cs_inicdents_all_synonym_Ddl.SQL
REM   Purpose: Script to create synonyms
REM            
REM   Constraints:  Run as apps/apps
REM
REM
REM    MODIFICATION HISTORY
REM
REM    Date          Person         cr num        Comments
REM    -----------   -----------    -------      ---------------------------------
REM    29-OCT-2005   ZAN/S yang      NONE        Initial Creation of the table script
REM    08-NOV-2005   Harender Marpu  None	 Adding Gating Criteria for the script  
REM    ************************************************************************************************/

REM WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

spool create_cs_inicdents_all_synonym_Ddl.log
set serveroutput on size 1000000
set define off

PROMPT ************************************************************************************
PROMPT create synonyms for Extensible attributes
PROMPT ************************************************************************************
PROMPT

create public synonym CS_INCIDENT_ALL_EXT_S for CS.CS_INCIDENT_ALL_EXT_S;
create public synonym CS_INCIDENTS_ALL_EXT_B for cs.CS_INCIDENTS_ALL_EXT_B;
create public synonym CS_INCIDENTS_ALL_EXT_TL for cs.CS_INCIDENTS_ALL_EXT_TL;

spool off
set define on

PROMPT
PROMPT ******************************************************************************************
PROMPT Please issue exit command and then continue to next step
PROMPT ******************************************************************************************
PROMPT

