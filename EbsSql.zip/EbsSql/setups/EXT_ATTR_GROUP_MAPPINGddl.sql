REM   *************************************************************************************************
REM   Name:    EXT_ATTR_GROUP_MAPPINGddl.sql
REM   Purpose: Script to insert into extended attribute group mappings.
REM            
REM   Constraints:  Run as apps/apps
REM
REM
REM    MODIFICATION HISTORY
REM
REM    Date          Person         cr num        Comments
REM    -----------   -----------    -------      ---------------------------------
REM    29-NOV-2005   ZAN/S yang      NONE        Initial Creation of the table script 
REM    ************************************************************************************************/

REM WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

spool EXT_ATTR_GROUP_MAPPINGddl.log
set serveroutput on size 1000000

PROMPT ************************************************************************************
PROMPT Creating EXT_ATTR_GROUP_MAPPING table and its indexes in schema CS.
PROMPT ************************************************************************************
PROMPT

CREATE TABLE EXT_ATTR_GROUP_MAPPING
(
  FROM_ATTR_GROUP_ID     NUMBER(15)             NOT NULL,
  TO_ATTR_GROUP_ID       NUMBER(15)             NOT NULL,
  FROM_INCIDENT_TYPE_ID  NUMBER(15)             NOT NULL,
  TO_INCIDENT_TYPE_ID    NUMBER(15)             NOT NULL,
  CREATED_BY             NUMBER(15)             NOT NULL,
  CREATION_DATE          DATE,
  LAST_UPDATED_BY        NUMBER(15),
  LAST_UPDATE_DATE       DATE,
  LAST_UPDATE_LOGIN      NUMBER(15)
)
TABLESPACE CSD
PCTUSED    60
PCTFREE    10
INITRANS   10
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             32K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        4
            FREELIST GROUPS  4
            BUFFER_POOL      DEFAULT
           )
LOGGING 
NOCACHE
NOPARALLEL;


CREATE INDEX EXT_ATTR_GROUP_MAPPING_N1 ON EXT_ATTR_GROUP_MAPPING
(FROM_INCIDENT_TYPE_ID)
LOGGING
TABLESPACE CSX
PCTFREE    10
INITRANS   11
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        4
            FREELIST GROUPS  4
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


CREATE UNIQUE INDEX EXT_ATTR_GROUP_MAPPING_U1 ON EXT_ATTR_GROUP_MAPPING
(FROM_ATTR_GROUP_ID, TO_ATTR_GROUP_ID)
LOGGING
TABLESPACE CSX
PCTFREE    10
INITRANS   11
MAXTRANS   255
STORAGE    (
            INITIAL          16K
            NEXT             16K
            MINEXTENTS       1
            MAXEXTENTS       2147483645
            PCTINCREASE      0
            FREELISTS        4
            FREELIST GROUPS  4
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;


GRANT ALTER, DELETE, INDEX, INSERT, REFERENCES, SELECT, UPDATE, ON COMMIT REFRESH, QUERY REWRITE, DEBUG, FLASHBACK ON  EXT_ATTR_GROUP_MAPPING TO APPS WITH GRANT OPTION;

spool off;

PROMPT
PROMPT ******************************************************************************************
PROMPT 
PROMPT Please Issue a EXIT command to continue to next step
PROMPT ******************************************************************************************
PROMPT



