REM   *************************************************************************************************
REM   Name:   INSERT_FND_DESCRIPTIVE_FLEXS_TLDml.sql
REM   Purpose: SEED APPLSYS.FND_DESCRIPTIVE_FLEXS_TL
REM            
REM   Constraints:  Run as apps/apps
REM
REM
REM    MODIFICATION HISTORY
REM
REM    Date          Person         cr num        Comments
REM    -----------   -----------    -------      ---------------------------------
REM    29-OCT-2005   ZAN/S yang      NONE        Initial Creation of the table script
REM    08-NOV-2005   Harender Marpu  None	 Adding Gating Criteria for the script  
REM    ************************************************************************************************/

REM WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

spool INSERT_FND_LOOKUP_VALUESDml.sql.log
set serveroutput on size 1000000
set define off

PROMPT ************************************************************************************
PROMPT APPLSYS.FND_DESCRIPTIVE_FLEXS_TL
PROMPT ************************************************************************************
PROMPT

INSERT INTO APPLSYS.FND_DESCRIPTIVE_FLEXS_TL (
APPLICATION_ID, 
DESCRIPTIVE_FLEXFIELD_NAME,
LANGUAGE,
TITLE,
LAST_UPDATE_DATE,
LAST_UPDATED_BY,
CREATION_DATE,
CREATED_BY,
LAST_UPDATE_LOGIN,
FORM_CONTEXT_PROMPT,
SOURCE_LANG,
DESCRIPTION)
VALUES (
170, 
'CS_INCIDENTS_GROUP',
'US',
'CS Incident Extension',
SYSDATE,
2,
SYSDATE,
2,
0,
'Context Value',
'US',
'CS Extensible Attribute Group');

PROMPT
PROMPT ******************************************************************************************
PROMPT 
PROMPT Please ignore any unique constraint violation errors.
PROMPT 
PROMPT Please Issue a Commit command and 
PROMPT then issue a EXIT command to continue to next step
PROMPT ******************************************************************************************
PROMPT

