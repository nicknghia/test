set head off
set feedback off
set serveroutput on;
set pages 0
set linesize 120;

declare

v_owner varchar2(30);
v_index_name varchar2(30);
v_table_name varchar2(100);
v_constraint_name varchar2(100);
sql_stmt    VARCHAR2(2000);

v_pre_cnt NUMBER;
v_pst_cnt NUMBER;
v_user_id NUMBER;
v_user_name varchar2(100);

l_fileid    utl_file.file_type;
ws_file_name  varchar2(50) := 'AppsUser_purge_'||to_char(sysdate,'YYYYMMDD')||'.log';


CURSOR c_constraint IS 
select owner,TABLE_NAME,CONSTRAINT_NAME from all_constraints  
where table_name 
in ('FND_USER','FND_USER_RESP_GROUPS','FND_USER_PREFERENCES','FND_LOGINS','FND_UNSUCCESSFUL_LOGINS','FND_LOG_TRANSACTION_CONTEXT');

CURSOR C2 IS
SELECT OWNER,TABLE_NAME,INDEX_NAME FROM ALL_INDEXES 
WHERE TABLE_NAME IN ('FND_USER','FND_USER_RESP_GROUPS','FND_USER_PREFERENCES','FND_LOGINS','FND_UNSUCCESSFUL_LOGINS'
                    ,'FND_LOG_TRANSACTION_CONTEXT');


cursor c_user is
SELECT USER_ID,USER_NAME
FROM FND_USER 
WHERE (employee_id is not null or customer_id is not null or supplier_id is not null);
 --and user_id = 1074;  Please comment this line after testing. For testing hardcode a value from your system.




begin

l_fileid:=utl_file.fopen('/usr/tmp',ws_file_name,'a');
utl_file.put_line(l_fileid,'***********************************************');
utl_file.put_line(l_fileid, 'Staring Apps User Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');


utl_file.put_line(l_fileid,'Starting - Disabling Constraints at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
OPEN c_constraint;
loop
  FETCH c_constraint INTO v_owner,v_table_name,v_constraint_name;
  EXIT WHEN c_constraint%NOTFOUND;
  sql_stmt := 'ALTER TABLE ' ||v_owner||'.'||v_table_name||' DISABLE CONSTRAINT '||v_constraint_name;
  EXECUTE IMMEDIATE sql_stmt;
  sql_stmt := NULL;
END LOOP;
close c_constraint;
utl_file.put_line(l_fileid,'Done - Disabling Constraints at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));


utl_file.put_line(l_fileid,'Starting  Apps User Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));

SELECT COUNT(*)
INTO v_pre_cnt
FROM FND_USER 
WHERE (employee_id is not null or customer_id is not null or supplier_id is not null);

utl_file.put_line(l_fileid,'Record Count Before the Purge is: '||v_pre_cnt);

OPEN c_user;
loop
  FETCH c_user INTO v_user_id,v_user_name;
  EXIT WHEN c_user%NOTFOUND;
  
  sql_stmt := 'DELETE FROM APPLSYS.FND_USER WHERE USER_ID = ' ||v_user_id;
  EXECUTE IMMEDIATE sql_stmt;
  sql_stmt := NULL;

  sql_stmt := 'DELETE FROM APPLSYS.FND_LOGINS WHERE USER_ID = ' ||v_user_id;
  EXECUTE IMMEDIATE sql_stmt;
  sql_stmt := NULL;

  sql_stmt := 'DELETE FROM APPLSYS.FND_UNSUCCESSFUL_LOGINS WHERE USER_ID = ' ||v_user_id;
  EXECUTE IMMEDIATE sql_stmt;
  sql_stmt := NULL;

  sql_stmt := 'DELETE FROM APPLSYS.FND_LOG_TRANSACTION_CONTEXT WHERE USER_ID = ' ||v_user_id;
  EXECUTE IMMEDIATE sql_stmt;
  sql_stmt := NULL;

  DELETE from APPLSYS.wf_local_user_roles
  where user_name in (select user_name from fnd_user
                      where user_id  = v_user_id);

  DELETE from APPLSYS.WF_USER_ROLE_ASSIGNMENTS
  where user_name in (select user_name from fnd_user
                      where user_id  = v_user_id);


  DELETE from APPLSYS.FND_USER_PREFERENCES
  where user_name in (select user_name from fnd_user
                      where user_id  = v_user_id);

 DELETE from APPLSYS.WF_LOCAL_ROLES
  where NAME in (select user_name from fnd_user
                      where user_id  = v_user_id);
  
 DELETE from APPLSYS.WF_LOCAL_ROLES_OLD
  where NAME in (select user_name from fnd_user
                      where user_id  = v_user_id); 
  
END LOOP;
close c_user;

SELECT COUNT(*)
INTO v_pst_cnt
FROM FND_USER 
WHERE (employee_id is not null or customer_id is not null or supplier_id is not null);

utl_file.put_line(l_fileid,'Record Count After the Purge is: '||v_pst_cnt);
utl_file.put_line(l_fileid,'Number of FND Users Purged: '||to_char(v_pre_cnt - v_pst_cnt));



utl_file.put_line(l_fileid,'Completed- Apps User Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));


utl_file.put_line(l_fileid,'Starting - Enableing Constraints at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
OPEN c_constraint;
loop
FETCH c_constraint INTO v_owner,v_table_name,v_constraint_name;
EXIT WHEN c_constraint%NOTFOUND;

sql_stmt := 'ALTER TABLE ' ||v_owner||'.'||v_table_name||' ENABLE CONSTRAINT '||v_constraint_name;
EXECUTE IMMEDIATE sql_stmt;
end loop;
close c_constraint;
utl_file.put_line(l_fileid,'Done - Enableing Constraints at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));


utl_file.put_line(l_fileid,'STARTING - Rebuilding Indexs at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
OPEN C2;
loop
FETCH C2 INTO v_owner,v_table_name,v_index_name;
EXIT WHEN C2%NOTFOUND;

sql_stmt := 'ALTER index ' ||v_owner||'.'||v_index_name||' rebuild';
EXECUTE IMMEDIATE sql_stmt;
end loop;
close c2;
utl_file.put_line(l_fileid,'Done - Rebuilding Indexs at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid,'Ending Apps User Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.fclose(l_fileid);

end;
/







