set head off
set feedback off
set serveroutput on;
set pages 0

declare

v_owner varchar2(30);
v_index_name varchar2(30);
v_table_name varchar2(100);
v_constraint_name varchar2(100);
sql_stmt    VARCHAR2(2000);
x_return_status VARCHAR2(10);
x_msg_count     NUMBER;
x_msg_data VARCHAR2(1000);

l_fileid    utl_file.file_type;
ws_file_name  varchar2(50) := 'Egov_alters_Purge_'||to_char(sysdate,'YYYYMMDD')||'.log';

begin

l_fileid:=utl_file.fopen('/usr/tmp',ws_file_name,'a');
utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid, 'Starting Egov Alerts Schema Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');



sql_stmt := 'TRUNCATE TABLE ALERT';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE ALERT_AUDIT';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE ALERT_OBJECT_HIST';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE ALERT_PRIORITY';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE ALERT_PROPERTY';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE ALERT_RECIPIENT_BRIDGE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE ALERT_SESSION';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE DBLOG_ERRORS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE DISTRIBUTION_LIST';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE DISTRIBUTION_LIST_CACHE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE DISTRIBUTION_PERSONS_BRIDGE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

/*sql_stmt := 'TRUNCATE TABLE GROUPS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL; */

sql_stmt := 'TRUNCATE TABLE RECIPIENT';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE RECIPIENT_CACHE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

/* sql_stmt := 'TRUNCATE TABLE RULE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;
sql_stmt := 'TRUNCATE TABLE RULE_CONVERSION';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL; */

sql_stmt := 'TRUNCATE TABLE TEMP_DISTRIBUTION_LIST';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE TEMP_PARTY_LIST';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE TEMP_RECIPIENT_LIST';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE TEMP_V_PERSON';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE TEMP_V_PERSON_SORTED';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE THEME';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;



utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid, 'End Egov alerts Schema Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.fclose(l_fileid);

end;
/


