set head off
set feedback off
set serveroutput on;
set pages 0

declare

v_owner varchar2(30);
v_index_name varchar2(30);
v_table_name varchar2(100);
v_constraint_name varchar2(100);
sql_stmt    VARCHAR2(2000);

v_person_id NUMBER;
v_party_id NUMBER;
v_pre_cnt NUMBER;
v_pst_cnt NUMBER;

l_fileid    utl_file.file_type;
ws_file_name  varchar2(50) := 'Employee_purge_API_'||to_char(sysdate,'YYYYMMDD')||'.log';


CURSOR C2 IS
SELECT OWNER,TABLE_NAME,INDEX_NAME FROM ALL_INDEXES 
WHERE TABLE_NAME IN ('HZ_PARTIES','HZ_PERSON_PROFILES','PER_ALL_PEOPLE_F','PER_ADDRESSES',
                     'PER_ALL_ASSIGNMENTS_F','PER_PEOPLE_F',
                     'PER_PERSON_TYPE_USAGES_F');

CURSOR C_EMP IS
SELECT PERSON_ID,PARTY_ID
FROM PER_ALL_PEOPLE_F;

begin

SELECT COUNT(*)
INTO v_pre_cnt
FROM PER_ALL_PEOPLE_F;

l_fileid:=utl_file.fopen('/usr/tmp',ws_file_name,'a');
utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid, 'Staring Employee Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid,'Record Count in PER_ALL_PEOPLE_F Before the Purge is: '||v_pre_cnt);

utl_file.put_line(l_fileid,'Starting  Employee Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));

OPEN C_EMP;
loop
  FETCH C_EMP INTO v_person_id,v_party_id;
  EXIT WHEN C_EMP%NOTFOUND;

  --Validate if we can Delete this HR Person.
    HR_PERSON_DELETE.weak_predel_validation(v_person_id,SYSDATE);

  --cALL THE ACTUAL delete Procedure
    HR_PERSON_DELETE.delete_a_person(v_person_id,FALSE,SYSDATE);

  -- The Above API will not delete from HZ_PARTIES Table..manually deleting the party records.
  sql_stmt := 'DELETE FROM HZ_PARTIES WHERE PARTY_ID = ' ||v_party_id;
  EXECUTE IMMEDIATE sql_stmt;
  sql_stmt := NULL;

  sql_stmt := 'DELETE FROM HZ_PERSON_PROFILES WHERE PARTY_ID = ' ||v_party_id;
  EXECUTE IMMEDIATE sql_stmt;
  sql_stmt := NULL;


END LOOP;
close C_EMP;

SELECT COUNT(*)
INTO v_pst_cnt
FROM PER_ALL_PEOPLE_F;
utl_file.put_line(l_fileid,'Record Count in PER_ALL_PEOPLE_F After the Purge is: '||v_pst_cnt);
utl_file.put_line(l_fileid,'Total Records purged from PER_ALL_PEOPLE_F: '|| TO_CHAR(v_pre_cnt - v_pst_cnt));
   


utl_file.put_line(l_fileid,'Completed- Employee Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));

utl_file.put_line(l_fileid,'STARTING - Rebuilding Indexs at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
OPEN C2;
loop
FETCH C2 INTO v_owner,v_table_name,v_index_name;
EXIT WHEN C2%NOTFOUND;

sql_stmt := 'ALTER index ' ||v_owner||'.'||v_index_name||' rebuild';
EXECUTE IMMEDIATE sql_stmt;
end loop;
close c2;
utl_file.put_line(l_fileid,'Done - Rebuilding Indexs at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid,'Ending Employee Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.fclose(l_fileid);

end;
/








