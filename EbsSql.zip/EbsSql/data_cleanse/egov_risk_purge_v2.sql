set head off
set feedback off
set serveroutput on;
set pages 0

declare

v_owner varchar2(30);
v_index_name varchar2(30);
v_table_name varchar2(100);
v_constraint_name varchar2(100);
sql_stmt    VARCHAR2(2000);
x_return_status VARCHAR2(10);
x_msg_count     NUMBER;
x_msg_data VARCHAR2(1000);

l_fileid    utl_file.file_type;
ws_file_name  varchar2(50) := 'Egov_Risk_Purge_'||to_char(sysdate,'YYYYMMDD')||'.log';

begin

l_fileid:=utl_file.fopen('/usr/tmp',ws_file_name,'a');
utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid, 'Starting Egov Risk Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid,'Starting  to Truncate tables at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));


sql_stmt := 'TRUNCATE TABLE EGOV_ASSET_POC';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE DBLOG_ERRORS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_SUPP_ITEM';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_SUPP_ITEM_HELP_BRIDGE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_ASSET_PROFILE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_EVALUATION';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_OBJECT_HIST';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_ASSET_PROFILE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_POINT_OF_CONTACT';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_SUPP_INVENTORY';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE TEMP_REFERENCE_ID';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_ATTACHMENTS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_ATTACHMENT_SITES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_EVAL_NOTES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE PROPERTIES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE SCENARIO_ITEM_LIST';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_TRANSFER_STORAGE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_TRANSFER_OUTPUT';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_ASSET_MAP';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_OBJECT_HIST';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_HELP_DETAIL_BACKUP';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;


/* TRUNCATE TABLE EGOV_ASSET_ATTRIBUTE ; */
/* TRUNCATE TABLE  DBLOG_ERRORS; */
/* TRUNCATE TABLE EGOV_ASSET_MAP ; */
/* TRUNCATE TABLE EGOV_ASSET_PROFILE_CATEGORIES ; */
/* TRUNCATE TABLE EGOV_ASSET_TYPE ; */
/* TRUNCATE TABLE EGOV_CALCULATIONS ; */
/* TRUNCATE TABLE EGOV_HELP ; */
/*TRUNCATE TABLE EGOV_HELP_DETAIL ; */
/* TRUNCATE TABLE EGOV_HELP_DETAIL_BACKUP ; */
/* TRUNCATE TABLE EGOV_SUPP_ITEM ; */
/* TRUNCATE TABLE EGOV_SUPP_ITEM_HELP_BRIDGE ; */
/* TRUNCATE TABLE EGOV_SUPP_ITEM_VERSION ; */
/* TRUNCATE TABLE EGOV_SUPP_ITEM_VER_AUDIT ; */
/* TRUNCATE TABLE GT_COPY_TREE ; */
/* TRUNCATE TABLE GT_SUPP_ITEM_VERSION ; */
/* TRUNCATE TABLE THEME ; */

utl_file.put_line(l_fileid,'Ending Truncate tables at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid, 'Ending  Egov Risk Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');

utl_file.fclose(l_fileid);

end;
/
