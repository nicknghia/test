set head off
set feedback off
set serveroutput on;
set pages 0

declare

v_owner varchar2(30);
v_index_name varchar2(30);
v_table_name varchar2(100);
v_constraint_name varchar2(100);
sql_stmt    VARCHAR2(2000);
x_return_status VARCHAR2(10);
x_msg_count     NUMBER;
x_msg_data VARCHAR2(1000);

l_fileid    utl_file.file_type;
ws_file_name  varchar2(50) := 'Egov_schema_Purge_'||to_char(sysdate,'YYYYMMDD')||'.log';

begin

l_fileid:=utl_file.fopen('/usr/tmp',ws_file_name,'a');
utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid, 'Staring Egov Schema Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');



sql_stmt := 'TRUNCATE TABLE EGOV_CARRIER_PROFILE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_EVALUATION';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_ALLEGED_VIOLATION';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;


sql_stmt := 'TRUNCATE TABLE EGOV_AGENTS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_INDIRECT_CARRIER_PROFILE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_STATION_CARGO';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_INDIRECT_STATION';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_EXPUNGE_LOG';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_OBJECT_HIST_NOTES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE REPAIRED_TRACKING_IDS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_WRKBK_LEO_AGENCIES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_WRKBK_LEO_CRIM_VIOL';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_WRKBK';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_WRKBK_OTHER_ENTITY';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_WRKBK_INVOLVED_ENTITY';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_WRKBK_NOTES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_WRKBK_EVENTS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_WRKBK_OTHER';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_WRKBK_OWNERS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE RAK_MV_IMS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE NOV_TEMP';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE TEMP_DUPLICATE_STATIONS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE TEMP_INVALID_ENTRY_STATIONS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE REMOVED_EGOV_INDIRECT_STATION';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_SCREENING_DEVICE_PROFILE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_AGENTS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_ALLEGED_VIOLATION';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_ATTACHMENTS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_ATTACHMENT_SITES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_ATTACHMENT_STAGING';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_CARRIER_PROFILE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_EVALUATION';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_EVALUATION_FINDINGS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_EXPUNGE_LOG';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_FACILITY_PROFILE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_INCIDENT';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_INCIDENT_REPORTER';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_INCIDENT_VIOLATORS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_INDIRECT_CARRIER_PROFILE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_INDIRECT_STATION';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_INVESTIGATION';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_INVESTIGATION_FILES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_LOCATION_PROFILE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_RECOMMENDATION';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_INVESTIGATION_FILES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_SCREENING_DEVICE_PROFILE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_SECURITY_PGM';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_STATION_CARGO';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_STATION_PROFILE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_TRANS_ELEMENT';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_EMAIL_THREAT_FILES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;


sql_stmt := 'TRUNCATE TABLE EGOV_EMAIL_THREAT_DUPLICATES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;


sql_stmt := 'TRUNCATE TABLE EGOV_OBJECT_HIST';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;


sql_stmt := 'TRUNCATE TABLE TEMP_DUPLICATES_NO_REMOVE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;


sql_stmt := 'TRUNCATE TABLE EGOV_CARRIER_TYPE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_CHIEF_COUNSELS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;






/* Need to verify if these lookups or transactional tables before we truncate them
   If lookups do not truncate them */
/* TRUNCATE TABLE EGOV_PORTLETS ;*/
/* TRUNCATE TABLE EGOV_PORTLETS_ROLES ;*/
/* TRUNCATE TABLE EGOV_REPORTS_ROLES ;*/
/* TRUNCATE TABLE EGOV_ROLES ;*/
/* TRUNCATE TABLE EGOV_SUPP_ITEM ;*/
/* TRUNCATE TABLE EGOV_SUPP_ITEM_VERSION_HISTORY ; */
/* TRUNCATE TABLE EGOV_REPORTS ;*/
/* TRUNCATE TABLE ERROR_LEVEL; */
/* TRUNCATE TABLE EGOV_TRANS_ELEMENT_TYPE; */
/* TRUNCATE TABLE EGOV_CARRIER_TYPE;*/


utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid, 'End Egov Schema Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.fclose(l_fileid);

end;
/


