REM Master purge script created by Kirby Kraft
REM 09-27-05
REM modified by HMARPU to add additional scripts 

connect apps/apps

REM Step 1
@@purge_fndusers.sql

REM Step 2
@@purge_resources.sql

REM Step 3
@@disable_vpdDML.sql
@@Disable_egov_constraints

connect egov_schema/tsa

REM Step 4
@@egov_schema_purge_v3.sql


connect egov_risk/tsa

REM Step 5
@@egov_risk_purge_v2.sql

connect egov_iac/tsa

REM Step 6
@@egov_iac_purge.sql

connect egov_web/tsa

REM Step 7
@@egov_web_purge_v3.sql

connect egov_alerts/tsa

REM Step 7
@@egov_alerts_purge.sql

connect apps/apps 

REM Step 8
@@purge_employees_API.sql
REM @@purge_employees.sql

connect applsys/apps

REM Step 9
@@purge_wf_tables_v2.sql

connect ar/ar 

REM Step 10
@@truncate_parties.sql
REM@@purge_parties_API.sql
REM @@purge_parties.sql


connect apps/apps 

REM Step 11
@@trunc_incidents.sql

REM Step 12
REM @@rebuild_egov_Index.sql
REM @@Enable_egov_constraints.sql

REM Step 13
@@enable_vpdDML.sql

