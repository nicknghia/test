set head off
set feedback off
set serveroutput on;
set pages 0

declare

v_owner varchar2(30);
v_index_name varchar2(30);
v_table_name varchar2(100);
v_constraint_name varchar2(100);
sql_stmt    VARCHAR2(2000);
x_return_status VARCHAR2(10);
x_msg_count     NUMBER;
x_msg_data VARCHAR2(1000);

v_pre_cnt NUMBER;
v_pst_cnt NUMBER;
v_party_id NUMBER;

l_fileid    utl_file.file_type;
ws_file_name  varchar2(50) := 'Purge_parties_by_truncate'||to_char(sysdate,'YYYYMMDD')||'.log';


CURSOR C2 IS
SELECT OWNER,TABLE_NAME,INDEX_NAME FROM ALL_INDEXES 
WHERE TABLE_NAME IN ('HZ_CONTACT_POINTS','HZ_PARTIES',
'HZ_ORGANIZATION_PROFILES','HZ_PERSON_PROFILES',
'HZ_LOCATIONS','JTF_IH_INTERACTIONS',
'HZ_DQM_SYNC_INTERFACE','HZ_CREDIT_RATINGS','HZ_CERTIFICATIONS','HZ_PARTY_SITES','HZ_RELATIONSHIPS');



begin

execute immediate 'alter session set optimizer_index_cost_adj = 10';

l_fileid:=utl_file.fopen('/usr/tmp',ws_file_name,'a');
utl_file.put_line(l_fileid,'***********************************************');
utl_file.put_line(l_fileid, 'Staring Party Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');


select COUNT(*) into v_pre_cnt 
from hz_parties;


utl_file.put_line(l_fileid,'Record Count Before the Purge is: '||v_pre_cnt);

sql_stmt := 'TRUNCATE TABLE HZ_ORGANIZATION_PROFILES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_CONTACT_PREFERENCES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_CONTACT_POINTS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_ORG_CONTACT_ROLES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_STAGED_CONTACTS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_ORG_CONTACTS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_PARTY_SITE_USES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_CODE_ASSIGNMENTS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_STAGED_PARTY_SITES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_PARTY_SITES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_CONTACT_POINTS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_PERSON_PROFILES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_FINANCIAL_PROFILE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_REFERENCES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_CERTIFICATIONS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_CREDIT_RATINGS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_SECURITY_ISSUED';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_FINANCIAL_NUMBERS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_FINANCIAL_REPORTS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_ORGANIZATION_INDICATORS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_PERSON_INTEREST';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_CITIZENSHIP';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_WORK_CLASS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_EMPLOYMENT_HISTORY';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_PERSON_LANGUAGE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_EDUCATION';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_INDUSTRIAL_REFERENCE';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_CODE_ASSIGNMENTS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_STAGED_PARTIES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_LOCATIONS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_LOCATION_PROFILES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_PARAM_TAB';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE HZ_PARTY_RELATIONSHIPS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;


sql_stmt := 'TRUNCATE TABLE HZ_RELATIONSHIPS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;


sql_stmt := 'TRUNCATE TABLE HZ_PARTIES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;


select COUNT(*) into v_pst_cnt 
from hz_parties;

utl_file.put_line(l_fileid,'Record Count After the Purge is: '||v_pst_cnt);
utl_file.put_line(l_fileid,'Number of Parties Purged: '||to_char(v_pre_cnt - v_pst_cnt));


utl_file.put_line(l_fileid,'Completed- Party Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));

utl_file.put_line(l_fileid,'STARTING - Rebuilding Indexs at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
OPEN C2;
loop
FETCH C2 INTO v_owner,v_table_name,v_index_name;
EXIT WHEN C2%NOTFOUND;

sql_stmt := 'ALTER index ' ||v_owner||'.'||v_index_name||' rebuild';
EXECUTE IMMEDIATE sql_stmt;
end loop;
close c2;
utl_file.put_line(l_fileid,'Done - Rebuilding Indexs at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid,'Ending Party Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.fclose(l_fileid);

end;
/








