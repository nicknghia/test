set head off
set feedback off
set serveroutput on;
set pages 0

declare

v_owner varchar2(30);
v_index_name varchar2(30);
v_table_name varchar2(100);
v_constraint_name varchar2(100);
sql_stmt    VARCHAR2(2000);
x_return_status VARCHAR2(10);
x_msg_count     NUMBER;
x_msg_data VARCHAR2(1000);

v_pst_cnt NUMBER;
v_resource_id NUMBER;
v_item_type VARCHAR2(1000);
v_item_key VARCHAR2(1000);
v_pre_cnt NUMBER;

l_fileid    utl_file.file_type;
ws_file_name  varchar2(50) := 'Workflow_Purge_'||to_char(sysdate,'YYYYMMDD')||'.log';


CURSOR c_constraint IS 
select owner,TABLE_NAME,CONSTRAINT_NAME from all_constraints  
where table_name IN ('WF_NOTIFICATIONS','WF_NOTIFICATION_ATTRIBUTES','WF_LOCAL_USERS','WF_LOCAL_ROLES',
                     'WF_LOCAL_ROLES_TL','WF_ITEM_ACTIVITY_STATUSES_H','WF_ITEM_ACTIVITY_STATUSES','WF_ITEMS');


CURSOR C2 IS
SELECT OWNER,TABLE_NAME,INDEX_NAME FROM ALL_INDEXES 
WHERE TABLE_NAME IN ('WF_NOTIFICATIONS','WF_NOTIFICATION_ATTRIBUTES','WF_LOCAL_USERS','WF_LOCAL_ROLES',
                     'WF_LOCAL_ROLES_TL','WF_ITEM_ACTIVITY_STATUSES_H','WF_ITEM_ACTIVITY_STATUSES','WF_ITEMS');


CURSOR c_items is
SELECT item_type,item_key 
from WF_ITEMS; 

begin

l_fileid:=utl_file.fopen('/usr/tmp',ws_file_name,'a');
utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid, 'Staring Workflow Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');


utl_file.put_line(l_fileid,'Starting - Disabling Constraints at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
OPEN c_constraint;
loop
  FETCH c_constraint INTO v_owner,v_table_name,v_constraint_name;
  EXIT WHEN c_constraint%NOTFOUND;
  sql_stmt := 'ALTER TABLE ' ||v_owner||'.'||v_table_name||' DISABLE CONSTRAINT '||v_constraint_name;
  EXECUTE IMMEDIATE sql_stmt;
  sql_stmt := NULL;
END LOOP;
close c_constraint;
utl_file.put_line(l_fileid,'Done - Disabling Constraints at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));


SELECT COUNT(*)
INTO v_pre_cnt
FROM WF_ITEMS;

utl_file.put_line(l_fileid,'Number Of Records Before Purge:'||v_pre_cnt);
utl_file.put_line(l_fileid,'Starting  Workflow Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));


/*utl_file.put_line(l_fileid,'Starting - Purge By API :'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
OPEN c_items;
loop
  FETCH c_items INTO v_item_type,v_item_key;
  EXIT WHEN c_items%NOTFOUND;
  v_pre_cnt := WF_PURGE.GetPurgeableCount(v_item_type);
  IF(v_pre_cnt > 0) THEN
     WF_PURGE.Total(v_item_type,v_item_key,SYSDATE);
  END IF;
END LOOP;
close c_items;
utl_file.put_line(l_fileid,'Done - Purge By API at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS')); */


sql_stmt := 'TRUNCATE TABLE WF_NOTIFICATIONS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE WF_ITEMS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE WF_NOTIFICATION_ATTRIBUTES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE WF_LOCAL_ROLES_TL';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE WF_ITEM_ACTIVITY_STATUSES_H';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE WF_ITEM_ACTIVITY_STATUSES';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

utl_file.put_line(l_fileid,'Completed- Workflow Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));

SELECT COUNT(*)
INTO v_pst_cnt
FROM WF_ITEMS;

utl_file.put_line(l_fileid,'Number Of Records After the Purge:'||v_pst_cnt);
utl_file.put_line(l_fileid,'Number of Records Purged From WF_ITEMS: '||to_char(v_pre_cnt - v_pst_cnt));

utl_file.put_line(l_fileid,'Starting - Enableing Constraints at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
OPEN c_constraint;
loop
FETCH c_constraint INTO v_owner,v_table_name,v_constraint_name;
EXIT WHEN c_constraint%NOTFOUND;

sql_stmt := 'ALTER TABLE ' ||v_owner||'.'||v_table_name||' ENABLE CONSTRAINT '||v_constraint_name;
EXECUTE IMMEDIATE sql_stmt;
end loop;
close c_constraint;
utl_file.put_line(l_fileid,'Done - Enableing Constraints at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));


/*utl_file.put_line(l_fileid,'STARTING - Rebuilding Indexs at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
OPEN C2;
loop
FETCH C2 INTO v_owner,v_table_name,v_index_name;
EXIT WHEN C2%NOTFOUND;
sql_stmt := 'ALTER index ' ||v_owner||'.'||v_index_name||' rebuild';
EXECUTE IMMEDIATE sql_stmt;
end loop;
close c2; */

utl_file.put_line(l_fileid,'Done - Rebuilding Indexs at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid,'Ending Workflow Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.fclose(l_fileid);

end;
/








