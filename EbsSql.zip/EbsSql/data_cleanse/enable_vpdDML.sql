REM   *************************************************************************************************
REM   Name:    enable_vpdDML.sql
REM   Purpose: Script to enable enabling vpd policies
REM   Constraints:  Run as tsasys/tsasys
REM
REM
REM    MODIFICATION HISTORY
REM
REM    Date          Person         cr num        Comments
REM    -----------   -----------    -------      ---------------------------------
REM    24-MAR-2005   John Gostel    NONE         Initial Creation.
REM    24-MAR-2005   Sanjai Bhargava    NONE     Made it AMSS compliant.
REM    ************************************************************************************************/

REM WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

spool enable_vpdDML.log
set serveroutput on size 1000000
set define off

PROMPT ************************************************************************************
PROMPT Enabling enabling vpd policies
PROMPT ************************************************************************************
PROMPT

REM -- enable_policy - enable or disable a security policy for a table or view
REM  --
REM  -- INPUT PARAMETERS
REM  --   object_schema   - schema owning the table/view, current user if NULL
REM  --   object_name     - name of table or view
REM  --   policy_name     - name of policy to be enabled or disabled
REM  --   enable          - TRUE to enable the policy, FALSE to disable the policy

begin
dbms_rls.enable_policy(
          object_schema => 'CS' ,
	  OBJECT_NAME     =>'CS_INCIDENTS_ALL_B',
	  POLICY_NAME     =>'CASE_VIEW_SECURITY',
          enable          => true);
dbms_rls.enable_policy(
          object_schema => 'CS' ,
	  OBJECT_NAME     =>'CS_INCIDENTS_ALL_B',
	  POLICY_NAME     =>'CASE_EDIT_SECURITY',
          enable          => true);
dbms_rls.enable_policy(
          object_schema => 'CS' ,
	  OBJECT_NAME     =>'CS_INCIDENTS_ALL_TL',
	  POLICY_NAME     =>'CASE_TL_SECURITY',
          enable          => true);
end;
/




PROMPT
PROMPT *************************************************
PROMPT THIS SCRIPT DOES NOT COMMIT.  A COMMIT OR ROLLBACK IS REQUIRED.
PROMPT *************************************************

spool off
set define on
