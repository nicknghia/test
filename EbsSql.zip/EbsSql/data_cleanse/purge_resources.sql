set head off
set feedback off
set serveroutput on;
set pages 0

declare

v_owner varchar2(30);
v_index_name varchar2(30);
v_table_name varchar2(100);
v_constraint_name varchar2(100);
sql_stmt    VARCHAR2(2000);
x_return_status VARCHAR2(10);
x_msg_count     NUMBER;
x_msg_data VARCHAR2(1000);

v_pre_cnt NUMBER;
v_pst_cnt NUMBER;
v_resource_id NUMBER;

l_fileid    utl_file.file_type;
ws_file_name  varchar2(50) := 'Resource_Purge_'||to_char(sysdate,'YYYYMMDD')||'.log';


CURSOR c_constraint IS 
select owner,TABLE_NAME,CONSTRAINT_NAME from all_constraints  
where table_name IN ('JTF_RS_RESOURCE_EXTNS','JTF_RS_RESOURCE_EXTNS_TL','JTF_RS_RESOURCE_EXTN_AUD','JTF_RS_RESOURCE_SKILLS',
                     'JTF_RS_RESOURCE_VALUES','JTF_RS_RES_AVAILABILITY','JTF_RS_REP_MANAGERS','JTF_RS_GROUP_MEMBERS',
                     'JTF_RS_ACTIVE_GRP_MBRS','JTF_RS_RESOURCE_SKILLS','JTF_RS_RESOURCE_PICTURES');


CURSOR C2 IS
SELECT OWNER,TABLE_NAME,INDEX_NAME FROM ALL_INDEXES 
WHERE TABLE_NAME IN ('JTF_RS_RESOURCE_EXTNS','JTF_RS_RESOURCE_EXTNS_TL','JTF_RS_RESOURCE_EXTN_AUD','JTF_RS_RESOURCE_SKILLS',
                     'JTF_RS_RESOURCE_VALUES','JTF_RS_RES_AVAILABILITY','JTF_RS_REP_MANAGERS','JTF_RS_GROUP_MEMBERS',
                     'JTF_RS_ACTIVE_GRP_MBRS','JTF_RS_RESOURCE_SKILLS','JTF_RS_RESOURCE_PICTURES');

CURSOR C_RESOURCE IS
SELECT RESOURCE_ID
FROM JTF_RS_RESOURCE_EXTNS
WHERE CATEGORY = 'EMPLOYEE';



begin

l_fileid:=utl_file.fopen('/usr/tmp',ws_file_name,'a');
utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid, 'Staring JTF resource Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');


utl_file.put_line(l_fileid,'Starting - Disabling Constraints at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
OPEN c_constraint;
loop
  FETCH c_constraint INTO v_owner,v_table_name,v_constraint_name;
  EXIT WHEN c_constraint%NOTFOUND;
  sql_stmt := 'ALTER TABLE ' ||v_owner||'.'||v_table_name||' DISABLE CONSTRAINT '||v_constraint_name;
  EXECUTE IMMEDIATE sql_stmt;
  sql_stmt := NULL;
END LOOP;
close c_constraint;
utl_file.put_line(l_fileid,'Done - Disabling Constraints at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));


utl_file.put_line(l_fileid,'Starting  JTF Resource Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));

SELECT COUNT(*)
INTO v_pre_cnt
FROM JTF_RS_RESOURCE_EXTNS
WHERE CATEGORY = 'EMPLOYEE';

utl_file.put_line(l_fileid,'Record Count in JTF_RS_RESOURCE_EXTNS Before the Purge is: '||v_pre_cnt);

OPEN C_RESOURCE;
loop
  FETCH C_RESOURCE INTO v_resource_id;
  EXIT WHEN C_RESOURCE%NOTFOUND;


-- Call the public API to delete the resource
JTF_RS_RESOURCE_PUB.delete_resource
  (P_API_VERSION => 1.0
   ,P_INIT_MSG_LIST => FND_API.G_FALSE
   ,P_COMMIT  => FND_API.G_FALSE             
   ,P_RESOURCE_ID   => v_resource_id 
   ,X_RETURN_STATUS => X_RETURN_STATUS
   ,X_MSG_COUNT => X_MSG_COUNT
   ,X_MSG_DATA  => X_MSG_DATA); 

sql_stmt := 'DELETE FROM JTF_RS_RESOURCE_EXTNS WHERE RESOURCE_ID = '||v_resource_id;
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'DELETE FROM JTF_RS_RESOURCE_EXTNS_TL WHERE RESOURCE_ID = '||v_resource_id;
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;
 
sql_stmt := 'DELETE FROM JTF_RS_RESOURCE_EXTN_AUD WHERE RESOURCE_ID = '||v_resource_id;
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'DELETE FROM JTF_RS_RESOURCE_SKILLS WHERE RESOURCE_ID = '||v_resource_id;
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;
 
sql_stmt := 'DELETE FROM JTF_RS_RESOURCE_VALUES WHERE RESOURCE_ID = '||v_resource_id;
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;
 
sql_stmt := 'DELETE FROM JTF_RS_RES_AVAILABILITY WHERE RESOURCE_ID = '||v_resource_id;
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'DELETE FROM JTF_RS_REP_MANAGERS WHERE RESOURCE_ID = '||v_resource_id;
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;
 
sql_stmt := 'DELETE FROM JTF_RS_GROUP_MEMBERS WHERE RESOURCE_ID = '||v_resource_id;
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'DELETE FROM JTF_RS_ACTIVE_GRP_MBRS WHERE RESOURCE_ID = '||v_resource_id;
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'DELETE FROM JTF_RS_RESOURCE_SKILLS WHERE RESOURCE_ID = '||v_resource_id;
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'DELETE FROM JTF_RS_RESOURCE_PICTURES WHERE RESOURCE_ID = '||v_resource_id;
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

 
END LOOP;
close C_RESOURCE;

SELECT COUNT(*)
INTO v_pst_cnt
FROM JTF_RS_RESOURCE_EXTNS
WHERE CATEGORY = 'EMPLOYEE';

utl_file.put_line(l_fileid,'Record Count in JTF_RS_RESOURCE_EXTNS After the Purge is: '||v_pst_cnt);
utl_file.put_line(l_fileid,'Number of Resources Purged from JTF_RS_RESOURCE_EXTNS: '||to_char(v_pre_cnt - v_pst_cnt));


utl_file.put_line(l_fileid,'Completed- JTF Resource Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));


utl_file.put_line(l_fileid,'Starting - Enableing Constraints at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
OPEN c_constraint;
loop
FETCH c_constraint INTO v_owner,v_table_name,v_constraint_name;
EXIT WHEN c_constraint%NOTFOUND;

sql_stmt := 'ALTER TABLE ' ||v_owner||'.'||v_table_name||' ENABLE CONSTRAINT '||v_constraint_name;
EXECUTE IMMEDIATE sql_stmt;
end loop;
close c_constraint;
utl_file.put_line(l_fileid,'Done - Enableing Constraints at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));


utl_file.put_line(l_fileid,'STARTING - Rebuilding Indexs at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
OPEN C2;
loop
FETCH C2 INTO v_owner,v_table_name,v_index_name;
EXIT WHEN C2%NOTFOUND;

sql_stmt := 'ALTER index ' ||v_owner||'.'||v_index_name||' rebuild';
EXECUTE IMMEDIATE sql_stmt;
end loop;
close c2;
utl_file.put_line(l_fileid,'Done - Rebuilding Indexs at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid,'Ending JTF Resource Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.fclose(l_fileid);

end;
/








