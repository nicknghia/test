set head off
set feedback off
set serveroutput on;
set pages 0

declare

v_owner varchar2(30);
v_index_name varchar2(30);
v_table_name varchar2(100);
v_constraint_name varchar2(100);
sql_stmt    VARCHAR2(2000);

v_pre_cnt NUMBER;
v_pst_cnt NUMBER;

l_fileid    utl_file.file_type;
ws_file_name  varchar2(50) := 'Incident_purge_'||to_char(sysdate,'YYYYMMDD')||'.log';


CURSOR C2 IS
SELECT OWNER,TABLE_NAME,INDEX_NAME FROM ALL_INDEXES 
WHERE TABLE_NAME IN ('CS_INCIDENTS_ALL_B','CS_INCIDENTS_ALL_TL',
'CS_INCIDENTS_AUDIT_B','CS_INCIDENTS_AUDIT_TL',
'CS_HZ_SR_CONTACT_POINTS','EGOV_CS_INCIDENT_EXTNS',
'JTF_NOTES_TL','JTF_NOTES_B','JTF_TASKS_TL','JTF_TASKS_TL',
'FND_LOBS','FND_DOCUMENTS_TL','FND_DOCUMENTS','FND_ATTACHED_DOCUMENTS');



begin

select count(INCIDENT_ID)
into v_pre_cnt
FROM CS_INCIDENTS_ALL_B;

l_fileid:=utl_file.fopen('/usr/tmp',ws_file_name,'a');
utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid, 'Staring Incident Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');


utl_file.put_line(l_fileid,'Number Of records in CS_INCIDENTS_ALL_B Before the Purge: '||v_pre_cnt);

utl_file.put_line(l_fileid,'Starting  to Purge the CS tables at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
sql_stmt := 'TRUNCATE TABLE cs.cs_INCIDENTS_ALL_B';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE cs.cs_INCIDENTS_ALL_TL';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE cs.cs_INCIDENTS_ALL_EXT_B';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE cs.cs_INCIDENTS_ALL_EXT_TL';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;


sql_stmt := 'TRUNCATE TABLE cs.CS_INCIDENTS_AUDIT_B';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;


sql_stmt := 'TRUNCATE TABLE cs.CS_INCIDENTS_AUDIT_TL';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE cs.CS_HZ_SR_CONTACT_POINTS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE cs.CS_HZ_SR_CONTACT_POINTS_EXT';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE cs.CS_INCIDENT_LINKS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE cs.CS_INCIDENT_LINKS_EXT';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;


sql_stmt := 'TRUNCATE TABLE cs.CS_SR_LOG_DATA_TEMP';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE EGOV_SCHEMA.EGOV_CS_INCIDENT_EXTNS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE JTF.JTF_NOTES_TL';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE JTF.JTF_NOTES_B';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE JTF.JTF_NOTE_CONTEXTS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE JTF.JTF_TASKS_TL';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE JTF.JTF_TASKS_B';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE APPLSYS.FND_LOBS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE APPLSYS.FND_DOCUMENTS_TL';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE APPLSYS.FND_DOCUMENTS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

sql_stmt := 'TRUNCATE TABLE APPLSYS.FND_ATTACHED_DOCUMENTS';
EXECUTE IMMEDIATE sql_stmt;
sql_stmt := NULL;

select count(*)
into v_pst_cnt
FROM CS.cs_INCIDENTS_ALL_B;

utl_file.put_line(l_fileid,'Number Of records in CS_INCIDENTS_ALL_B Before the Purge:'||v_pst_cnt);
utl_file.put_line(l_fileid,'Number of Incidents Purged: '||to_char(v_pre_cnt - v_pst_cnt));


utl_file.put_line(l_fileid,'Done- Purging the CS tables at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));


utl_file.put_line(l_fileid,'STARTING - Rebuilding Indexs at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
OPEN C2;
loop
FETCH C2 INTO v_owner,v_table_name,v_index_name;
EXIT WHEN C2%NOTFOUND;

sql_stmt := 'ALTER index ' ||v_owner||'.'||v_index_name||' rebuild';
EXECUTE IMMEDIATE sql_stmt;
end loop;
close c2;
utl_file.put_line(l_fileid,'Done - Rebuilding Indexs at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid,'Ending Incident Purge at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.fclose(l_fileid);

end;
/








