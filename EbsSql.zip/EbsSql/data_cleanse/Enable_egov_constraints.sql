set head off
set feedback off
set serveroutput on;
set pages 0

declare

v_owner varchar2(30);
v_index_name varchar2(30);
v_table_name varchar2(100);
v_constraint_name varchar2(200);
sql_stmt    VARCHAR2(2000);

l_fileid    utl_file.file_type;
ws_file_name  varchar2(50) := 'Enable_Egov_Constraints_'||to_char(sysdate,'YYYYMMDD')||'.log';

cursor c_constraint
IS
select DC.owner,DC.TABLE_NAME,DC.CONSTRAINT_NAME
from DBA_constraints DC, DBA_TABLES DA
WHERE DC.TABLE_NAME = DA.TABLE_NAME
AND DC.OWNER = DA.OWNER  
AND DC.CONSTRAINT_TYPE !='P'
AND DC.owner in ('EGOV_RISK')
ORDER BY CONSTRAINT_TYPE,owner;


--('EGOV_RISK','EGOV_SCHEMA','EGOV_IAC','EGOV_WEB','EGOV_MGT','EGOV_ALERTS')


begin

l_fileid:=utl_file.fopen('/usr/tmp',ws_file_name,'a');
utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid, 'Staring Enable Egov Constraints at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');

OPEN c_constraint;
loop
  FETCH c_constraint INTO v_owner,v_table_name,v_constraint_name;
  EXIT WHEN c_constraint%NOTFOUND;
  sql_stmt := 'ALTER TABLE ' ||v_owner||'.'||v_table_name||' ENABLE CONSTRAINT '||v_constraint_name;
  EXECUTE IMMEDIATE sql_stmt;END LOOP;
close c_constraint;

utl_file.put_line(l_fileid,'*********************************************');
utl_file.put_line(l_fileid,'Ending Enable Egov Constraints at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.put_line(l_fileid,'*********************************************');
utl_file.fclose(l_fileid);

end;
/








