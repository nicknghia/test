1) Purge_Fndusers: Will Purge all Application User related Information. This is a manual deletion
   from the tables as there are NO delete API's. This Process contains 1 file
            a) Purge_fndusers.sql
                              
  This script will delete all user related data. This Script will
  create a log file in /usr/tmp directory  on the database server. The log file is named
   AppsUser_purge_YYYYMMDD.log the Log file contains process start time, 
   no of records deleted from each table, process end time.
   
   After succesful deletion of records it will rebuild the Indexes on the effected tables.

   Instrunctions On How to run:  1) Login to the database as APPS
                                SQL> @<staging direcotry>:\Purge_fndusers.sql
                                example:  SQL> @C:\PURGE_SCRIPTS\Purge_fndusers.sql




2) Purge_employess: Will Purge all HR data. This script will use both API's and manual deltion(Party Record). 
   This Process contains 1 file
            a) Purge_employess_API.sql

   NOTE: THIS SCRIPT SHOULD RUN AFTER THE SUCCESSFUL PURGE OF APPLICATION USERS.(Purge_Fndusers.sql)
 
  This script( Purge_employess_API.sql) will use the following HR API's.
     a) HR_PERSON_DELETE.weak_predel_validation: Which takes Person_ID and Purge Date(SYSDATE) 
        as parameters and validates if a person is eligable for Delete. 
        For Ex: If a person has Apps User tied to it, It will not flag them.
    
     b) HR_PERSON_DELETE.delete_a_person: This procedure takes person_id, 
        True or falase(False if batch deletion, true if deleting it from Forms)
        and Purge Date(SYSDATE) as input paramters and delets from all HR tables.
 
  After completion of the above procedure call, purge_employees.sql will delete 
  related rows from HZ_PARTIES, HZ_PERSON_PROFILES  tables.. 
          
  This Script will create a log file in /usr/tmp directory on the database server. 
  The Log file name is Employee_purge_API_'YYYYMMDD.log.
  The Log file contains process start time, no of records deleted from each table, Index 
  build start time, index build end time, process end time.
   
  After succesful deletion of records it will rebuild the Indexes on the effected tables.

  Note: I created 2 scripts for Purge Employees as i was not able to test the API script. 
        second scriptjust uses the tables that API is using and delets manually. 
        The Script name is purge_employees.sql

  Instrunctions On How to run:  1) Login to the database as APPS
                                SQL> @<staging direcotry>:\Purge_employess_API.sql
                                example:  SQL> @C:\PURGE_SCRIPTS\Purge_employess_API.sql

3) Purge_resources: Will Purge all Resource related data. This script will use both API's and manual deletion
   This Process contains 1 file
            a) Purge_resources.sql

  This script will use the following JTF API.
     a) JTF_RS_RESOURCE_PUB.delete_resource(resource_id): This procedure will delete resources from 
        JTF_RS_RESOURCE_EXTNS,JTF_RS_RESOURCE_EXTNS_TL 
 
  After completion of the above procedure call, purge_employees.sql will delete 
  related rows from other resource related tables. 
          
  This Script will create a log file in /usr/tmp directory on the database server. 
  The Log file name is Resource_purge_'YYYYMMDD.log.
  The Log file contains process start time, no of records deleted from each table, Index 
  build start time, index build end time, process end time.
   
  After succesful deletion of records it will rebuild the Indexes on the effected tables.

  Instrunctions On How to run:  1) Login to the database as APPS
                                SQL> @<staging direcotry>:\Purge_resources.sql
                                example:  SQL> @C:\PURGE_SCRIPTS\Purge_resources.sql

4) Purge_parties: Will Purge all party related data. This script will use both API's and manual deletion
   This Process contains 1 file
            a) Purge_parties_API.sql ( Will use HZ_PURGE.purge_party)
            b) purge_parties.sql( manual Deletion from tables)

  This script will use the following HZ API.
     a) HZ_PURGE.PURGE_PARTY: Will take party as input parameter and purge from all HZ_tables. 
 
          
  This Script will create a log file in /usr/tmp directory on the database server. 
  The Log file name is Purge_Parties_API_YYYYMMDD.log.
                       purge_parties_YYYYMMDD.log.
  The Log file contains process start time, no of records deleted from each table, Index 
  build start time, index build end time, process end time.
   
  After succesful deletion of records it will rebuild the Indexes on the effected tables.

  Instrunctions On How to run:  1) Login to the database as APPS
                                SQL> @<staging direcotry>:\Purge_parties_API.sql
                                example:  SQL> @C:\PURGE_SCRIPTS\Purge_parties_API.sql


5) trunc_incidents: Will truncate all incident(Matter/Inquiry) related data.
   This Process contains 1 file
            a) trunc_incidents.sql
          
  This script will delete all Incident related data.This Script will create a log file in /usr/tmp 
  directory on the database server. The Log file name is Incident_purge_YYYYMMDD.log.
  The Log file contains process start time, no of records deleted from each table, Index 
  build start time, index build end time, process end time.
   
  After succesful deletion of records it will rebuild the Indexes on the effected tables.

  Instrunctions On How to run:  1) Login to the database as APPS
                                2) Disable VPS using the Script disable_VPDDML.sql
                                   SQL> @<staging direcotry>:\Disable_VPDDML.sql
                                   example:  SQL> @C:\PURGE_SCRIPTS\Disable_VPDDML.sql
                                3) Run trunc_incidents.sql to purge the incident related data.
                                   SQL> @<staging direcotry>:\trunc_incidents.sql
                                   example:  SQL> @C:\PURGE_SCRIPTS\trunc_incidents.sql

6) egov_schema_purge: Will truncate all EGOV_SCHEMA related data.
   This Process contains 1 file
            a) egov_schema_purge.sql
          
  This script will delete all EGOV_SCHEMA related data.This Script will create a log file in /usr/tmp 
  directory on the database server. The Log file name is Egov_schema_Purge_YYYYMMDD.log.
  The Log file contains process start time, no of records deleted from each table,process end time.
  

  Instrunctions On How to run:  1) Login to the database as APPS
                                2) Disable VPS using the Script disable_VPDDML.sql
                                   SQL> @<staging direcotry>:\Disable_VPDDML.sql
                                   example:  SQL> @C:\PURGE_SCRIPTS\Disable_VPDDML.sql
                                3) Run egov_schema_purge.sql to purge the EGOV_SCHEMA related data.
                                   SQL> @<staging direcotry>:\egov_schema_purge.sql
                                   example:  SQL> @C:\PURGE_SCRIPTS\egov_schema_purge.sql

7) egov_risk_purge: Will truncate all EGOV_RISK related data.
   This Process contains 1 file
            a) egov_risk_purge.sql
          
  This script will delete all EGOV_RISK related data.This Script will create a log file in /usr/tmp 
  directory on the database server. The Log file name is Egov_Risk_Purge_YYYYMMDD.log.
  The Log file contains process start time, no of records deleted from each table,
  process end time.
   

  Instrunctions On How to run:  1) Login to the database as APPS
                                2) Disable VPS using the Script disable_VPDDML.sql
                                   SQL> @<staging direcotry>:\Disable_VPDDML.sql
                                   example:  SQL> @C:\PURGE_SCRIPTS\Disable_VPDDML.sql
                                3) Run egov_risk_purge.sql to purge the EGOV_RISK related data.
                                   SQL> @<staging direcotry>:\egov_risk_purge.sql
                                   example:  SQL> @C:\PURGE_SCRIPTS\egov_risk_purge.sql

8) rebuild_egov_index: Will rebuild the indexes on EGOV_SCHEMA,EGOV_RISK related tables.
   This Process contains 1 file
            a) rebuild_egov_index.sql
          
  This script will rebuild the indexes on EGOV_SCHEMA,EGOV_RISK related tables.
  This Script will create a log file in /usr/tmp  directory on the database server. 
  The Log file name is Egov_schema_rebuild_index_YYYYMMDD.log.
  The Log file contains process start time, process end time.
   

  Instrunctions On How to run:  1) Login to the database as APPS
                                2) Disable VPS using the Script disable_VPDDML.sql
                                   SQL> @<staging direcotry>:\Disable_VPDDML.sql
                                   example:  SQL> @C:\PURGE_SCRIPTS\Disable_VPDDML.sql
                                3) Run rebuild_egov_index.sql to rebuild the indexes on EGOV_SCHEMA,EGOV_RISK related tables.
                                   SQL> @<staging direcotry>:\rebuild_egov_index.sql
                                   example:  SQL> @C:\PURGE_SCRIPTS\rebuild_egov_index.sql
                                


8) enable_vpdDML.sql: After successful purging of all the above business objects run this file
   to enable the VPD.
   Instrunctions On How to run:  1) Login to the database as APPS
                                2) Disable VPS using the Script enable_VPDDML.sql
                                   SQL> @<staging direcotry>:\enable_VPDDML.sql
                                   example:  SQL> @C:\PURGE_SCRIPTS\enable_VPDDML.sql




