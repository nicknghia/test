set head off
set feedback off
set serveroutput on;
set pages 0

declare

v_owner varchar2(30);
v_index_name varchar2(30);
v_table_name varchar2(100);
v_constraint_name varchar2(100);
sql_stmt    VARCHAR2(2000);


l_fileid    utl_file.file_type;
ws_file_name  varchar2(50) := 'Egov_schema_rebuild_index_'||to_char(sysdate,'YYYYMMDD')||'.log';


CURSOR C2 IS
SELECT OWNER,TABLE_NAME,INDEX_NAME FROM ALL_INDEXES 
WHERE TABLE_NAME IN ('EGOV_AGENTS','EGOV_ALLEGED_VIOLATION','EGOV_ATTACHMENTS','EGOV_ATTACHMENT_SITES',
                     'EGOV_ATTACHMENT_STAGING','EGOV_CARRIER_PROFILE','EGOV_CARRIER_TYPE','EGOV_CS_FLEX_TAB',
                     'EGOV_EVALUATION','EGOV_EVALUATION_FINDINGS','EGOV_EXPUNGE_LOG','EGOV_FACILITY_PROFILE'
                      ,'EGOV_INCIDENT','EGOV_INCIDENT_NOTIFICATIONS','EGOV_INCIDENT_REPORTER','EGOV_INCIDENT_VIOLATORS'
                      ,'EGOV_INDIRECT_CARRIER_PROFILE','EGOV_INDIRECT_STATION','EGOV_INVESTIGATION','EGOV_INVESTIGATION_FILES'
                      ,'EGOV_LOCATION_PROFILE','EGOV_OBJECT_HIST','EGOV_OBJECT_HIST_NOTES','EGOV_RECOMMENDATION',
           'EGOV_SCREENING_DEVICE_PROFILE','EGOV_SECURITY_PGM','EGOV_STATION_CARGO','EGOV_STATION_PROFILE','EGOV_SUPP_INVENTORY','EGOV_TRANS_ELEMENT'
           ,'EGOV_TRANS_ELEMENT_TYPE','EGOV_VIOLATED_REGULATIONS','EGOV_ASSET_MAP','EGOV_ASSET_PROFILE',
           'EGOV_ASSET_PROFILE_CATEGORIES','EGOV_ASSET_MAP','EGOV_SUPP_INVENTORY','EGOV_HELP_DETAIL','EGOV_SUPP_ITEM_HELP_BRIDGE',
           'EGOV_ASSET_POC','EGOV_SUPP_ITEM_HELP_BRIDGE','EGOV_SUPP_INVENTORY','EGOV_SUPP_ITEM','EGOV_SUPP_ITEM_VERSION','THEME');





begin

l_fileid:=utl_file.fopen('/usr/tmp',ws_file_name,'a');
utl_file.put_line(l_fileid,'STARTING - Rebuilding Indexs at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
OPEN C2;
loop
FETCH C2 INTO v_owner,v_table_name,v_index_name;
EXIT WHEN C2%NOTFOUND;

sql_stmt := 'ALTER index ' ||v_owner||'.'||v_index_name||' rebuild';
EXECUTE IMMEDIATE sql_stmt;
end loop;
close c2;
utl_file.put_line(l_fileid,'Done - Rebuilding Indexs at:'||to_char(sysdate,'DD-MON-YYYY HH:MI:SS'));
utl_file.fclose(l_fileid);

end;
/








