REM   *************************************************************************************************
REM   Name:    create_xparis_search_viewDDL.sql
REM   Purpose: Script to create the XXTSA_PARIS_SEARCH_RESULTS2_V view.
REM            
REM   Constraints:  Run as apps/apps
REM
REM
REM    MODIFICATION HISTORY
REM
REM    Date          Person         cr num        Comments
REM    -----------   -----------    -------      ---------------------------------
REM    21-DEC-2005   ZAN/S yang      NONE        Initial Creation of the view script 
REM    ************************************************************************************************/

REM WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

spool create_xparis_search_viewDDL.log
set serveroutput on size 1000000

PROMPT ************************************************************************************
PROMPT Creating the HZ_PARTIES_NX_ATTTRIBUTE1 index.
PROMPT ************************************************************************************
PROMPT


CREATE OR REPLACE FORCE VIEW APPS.XXTSA_PARIS_SEARCH_RESULTS2_V
(INCIDENT_ID, PARTY_ID, PERSON_LAST_NAME, PERSON_MIDDLE_NAME, PERSON_FIRST_NAME, 
 INCIDENT_DT, AIRPORT_LOCATION_CODE, DATE_OF_BIRTH, 
 INCIDENT_DESCRIPTION, P_NOTE1, DETAILS, P_NOTE2, DISPOSITION, 
 LOCATION_CODE, INCIDENT_TYPE, MATTER_ID, CAUSE_OF_ARREST, CHARGES_FILED, AIRPORT_PARTY_ID, 
 EIR)
AS 
select ei.incident_id
      ,(select hzp.party_id from HZ_PARTIES HZP where hzp.party_id=EIV.party_id
	) party_id 
	, (select  hzp.person_last_name from HZ_PARTIES HZP where hzp.party_id=EIV.party_id
	) person_last_name
, (select  hzp.person_middle_name from HZ_PARTIES HZP where hzp.party_id=EIV.party_id
	) person_middle_name
, (select  hzp.person_first_name from HZ_PARTIES HZP where hzp.party_id=EIV.party_id
	) person_first_name
   ,EI.INCIDENT_DT INCIDENT_DT
   ,(SELECT  hz.attribute1  from HZ_PARTIES hz where hz.party_id=EI.PARTY_ID) AIRPORT_LOCATION_CODE
   ,(select HZPP.DATE_OF_BIRTH from HZ_PERSON_PROFILES HZPP where hzpp.party_id=eiv.party_id
   AND (NVL(HZPP.EFFECTIVE_END_DATE,SYSDATE+1) > SYSDATE) ) DATE_OF_BIRTH
   ,SUBSTR(EI.DETAILS,1,600) "INCIDENT_DESCRIPTION"
   ,SUBSTR(EI.DETAILS,1,2000)
   ,EI.DETAILS
   ,SUBSTR(EI.DISPOSITION,1,2000)
   ,EI.DISPOSITION
   ,EI.LOCATION_CODE "LOCATION_CODE"
   ,EI.INCIDENT_TYPE
   ,EIV.matter_id
   ,EIV.CAUSE_OF_ARREST
   ,EIV.CHARGES_FILED
   ,EI.PARTY_ID "AIRPORT_PARTY_ID"
   ,EI.TRACKING_ID
FROM EGOV_INCIDENT EI,
     EGOV_INCIDENT_VIOLATORS EIV
WHERE EIV.INCIDENT_ID = EI.INCIDENT_ID;



spool off;

PROMPT
PROMPT ******************************************************************************************
PROMPT 
PROMPT Please Issue a EXIT command to continue to next step
PROMPT ******************************************************************************************
PROMPT
