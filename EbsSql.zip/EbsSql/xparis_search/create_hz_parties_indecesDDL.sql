REM   *************************************************************************************************
REM   Name:    create_hz_parties_indecesDDL.sql
REM   Purpose: Script to create the HZ_PARTIES_NX_ATTTRIBUTE1 index.
REM            
REM   Constraints:  Run as apps/apps
REM
REM
REM    MODIFICATION HISTORY
REM
REM    Date          Person         cr num        Comments
REM    -----------   -----------    -------      ---------------------------------
REM    21-DEC-2005   ZAN/S yang      NONE        Initial Creation of the view script 
REM    ************************************************************************************************/

REM WHENEVER SQLERROR EXIT FAILURE ROLLBACK
WHENEVER OSERROR EXIT FAILURE ROLLBACK

spool create_hz_parties_indecesDDL.log
set serveroutput on size 1000000

PROMPT ************************************************************************************
PROMPT Creating the HZ_PARTIES_NX_ATTTRIBUTE1 index.
PROMPT ************************************************************************************
PROMPT

CREATE INDEX HZ_PARTIES_NX_ATTTRIBUTE1 ON HZ_PARTIES
(ATTRIBUTE1)
LOGGING
TABLESPACE ARX
PCTFREE    10
INITRANS   2
MAXTRANS   255
STORAGE    (
            INITIAL          40K
            NEXT             64K
            MINEXTENTS       1
            MAXEXTENTS       505
            PCTINCREASE      50
            FREELISTS        1
            FREELIST GROUPS  1
            BUFFER_POOL      DEFAULT
           )
NOPARALLEL;

spool off;

PROMPT
PROMPT ******************************************************************************************
PROMPT 
PROMPT Please Issue a EXIT command to continue to next step
PROMPT ******************************************************************************************
PROMPT
