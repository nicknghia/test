package crt.com.freightdesk.fdfolio.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdfolio.useraccess.model.SystemUserModel;

public class QuartzDao
{
    protected Logger logger = Logger.getLogger (getClass());
	
	private Connection connection = null;
	
	protected Connection getConnection()
	{
		return connection;
	}
	
	public void setConnection( Connection connection )
	{
		this.connection = connection;
	}
	
	String noSubmissionsICSFQry =
		"SELECT  " + 
		"		orgC.CONTACTFIRSTNAME, " + 
		"		orgC.CONTACTLASTNAME, " + 
		"		orgH.ORGNAME, " + 
		"		orgC.EMAIL, " + 
		"		orgRef.ORGREFERENCEVALUE, " + 
		"		sysdate, " + 
		"		last_day( add_months( TRUNC(  sysdate ) , -1 ) ) + 10 as DUEDATE " + 
		"FROM  " + 
		"		ORGREFERENCE orgRef, " + 
		"		ORGHIERARCHY orgH, " + 
		"		SYSTEMUSER   sysU, " + 
		"		ORGHIERARCHY orgC " + 
		"WHERE 		 " + 
		"     	orgH.ORGID       = orgRef.ORGID " + 
		"     AND  orgH.status    = 'ACTIVE' " + 
		"	AND  orgC.PARENTORGID = orgH.orgid " + 
		"	AND  sysU.ORGID       = orgC.ORGID " + 
		"	AND  sysU.ISACTIVE	  = 'Y' " + 
		"	AND  orgRef.ORGREFERENCEVALUE in " + 
		"( " + 
		"	SELECT  " + 
		"			DISTINCT ORGREFERENCEVALUE  " + 
		"	FROM  " + 
		"			ORGREFERENCE orgRef, " + 
		"			ORGHIERARCHY orgHie " + 
		"	WHERE " + 
		"			orgRef.ORGREFERENCETYPECODE = 'CRTNM' " + 
		"		 AND orgRef.orgid = orgHie.ORGID " + 
		"		 AND orgHie.ORGROLECODE in ( 'ICSF', 'SHIP' ) " + 
		"	MINUS " + 
		"	SELECT  " + 
		"			DISTINCT CERTNUM  " + 
		"	FROM  " + 
		"			V_ICSF  " + 
		"	WHERE  " + 
		"			START_DATE >= last_day( add_months( TRUNC( sysdate ), -2 ) ) + 1 " + 
		") " + 
		"UNION " + 
		"SELECT  " + 
		"		orgC.CONTACTFIRSTNAME, " + 
		"		orgC.CONTACTLASTNAME, " + 
		"		orgH.ORGNAME, " + 
		"		orgC.EMAIL, " + 
		"		orgRef.ORGREFERENCEVALUE, " + 
		"		sysdate, " + 
		"		last_day( add_months( TRUNC( sysdate ), -1 ) ) + 10 as DUEDATE " + 
		"FROM  " + 
		"		ORGREFERENCE orgRef, " + 
		"		ORGHIERARCHY orgH, " + 
		"		ORGHIERARCHY locH, " + 
		"		SYSTEMUSER   sysU, " + 
		"		ORGHIERARCHY orgC " + 
		"WHERE 		 " + 
		"     	locH.ORGID       = orgRef.ORGID " + 
		"	AND  orgH.orgid       = locH.PARENTORGID " + 
		"	AND  locH.status    = 'ACTIVE' " + 
		"	AND  orgC.PARENTORGID = orgH.orgid " + 
		"	AND  sysU.ORGID       = orgC.ORGID " + 
		"	AND  sysU.ISACTIVE	  = 'Y' " + 
		"	AND  orgRef.ORGREFERENCEVALUE in " + 
		"( " + 
		"	SELECT  " + 
		"			DISTINCT ORGREFERENCEVALUE  " + 
		"	FROM  " + 
		"			ORGREFERENCE orgRef, " + 
		"			ORGHIERARCHY orgHie " + 
		"	WHERE " + 
		"			orgRef.ORGREFERENCETYPECODE = 'CRTNM' " + 
		"		 AND orgRef.orgid = orgHie.ORGID " + 
		"		 AND orgHie.ORGROLECODE in ( 'ICSF', 'SHIP' ) " + 
		"	MINUS " + 
		"	SELECT  " + 
		"			DISTINCT CERTNUM  " + 
		"	FROM  " + 
		"			V_ICSF  " + 
		"	WHERE  " + 
		"			START_DATE >= last_day( add_months( TRUNC(  sysdate ), -2 ) ) + 1 " + 
		") " + 
		"ORDER BY  " + 
		"		ORGNAME ";



	/**
	 * Find the Contact info ( FirstName, LastName, Certnum, Orgname, Email ) of ICSF/SHIP users who have not submitted data in the last month 
	 * 
	 * @return List of SystemUsersModels represent the users who have not submitted
	 */
	public List<SystemUserModel> noSubmissionsICSF()
	{
        PreparedStatement pStmt        = null;
        Connection        connection   = null;
    	ResultSet 		  rs		   = null;
    	SystemUserModel  user		   = null;
    	List<SystemUserModel> userList = new ArrayList<SystemUserModel>();
    	
    	String pattern = "MM.dd.yyyy HH:mm:ss z";
    	SimpleDateFormat format = new SimpleDateFormat(pattern);

    	String dayPattern = "MM.dd.yyyy";
    	SimpleDateFormat dayFormat = new SimpleDateFormat( dayPattern );
    	
    	Calendar cal = Calendar.getInstance();
    	cal.setTimeInMillis( System.currentTimeMillis() );
    	
        try
        {
        	connection = getConnection();
        	pStmt	   = connection.prepareStatement( noSubmissionsICSFQry );
        	
        	rs = pStmt.executeQuery();
        	
        	while ( rs.next() )
        	{
        		user =  new SystemUserModel();
        		user.setContactFirstName( rs.getString( "CONTACTFIRSTNAME" ) );
        		user.setContactLastName ( rs.getString( "CONTACTLASTNAME"  ) );
        		user.setOrgName			( rs.getString( "ORGNAME"          ) );
        		user.setEmail			( rs.getString( "EMAIL"            ) );
        		
        		// SystemUserModel Doesn't have a cerntnum, sysdate, duedate
        		//    fields so we just use status, dateFormat and lastupdateUserId instead
        		//
        		user.setStatus          ( rs.getString( "ORGREFERENCEVALUE" ) );
        		user.setDateFormat      ( format.format( rs.getTimestamp( "SYSDATE", cal ) ) );
        		user.setLastUpdateUserId( dayFormat.format( rs.getDate( "DUEDATE", cal ) ) );
       		
        		userList.add( user );
        	}
        } 
        catch (SQLException e)
		{
			//e.printStackTrace();
			logger.error("Exception: " + e.getMessage());
		}        
        finally
        {
        	// We don't close the conection, we share a connection and close in the calling function
        	//
            ConnectionUtil.closeResources(null, pStmt, rs );
        }        
        
		return userList;
	}
	
	String noSubmissionsIACQry =
		"SELECT  " + 
		"		orgC.CONTACTFIRSTNAME, " + 
		"		orgC.CONTACTLASTNAME, " + 
		"		orgH.ORGNAME, " + 
		"		orgC.EMAIL, " + 
		"		orgRef.ORGREFERENCEVALUE, " + 
		"		sysdate, " + 
		"		last_day( add_months( TRUNC( sysdate ), -1 ) ) + 10 as DUEDATE " + 
		"FROM  " + 
		"		ORGREFERENCE orgRef, " + 
		"		ORGHIERARCHY orgH, " + 
		"		SYSTEMUSER   sysU, " + 
		"		ORGHIERARCHY orgC " + 
		"WHERE 		 " + 
		"     	orgH.ORGID       = orgRef.ORGID " + 
		"   AND  orgH.status    = 'ACTIVE' " + 
		"	AND  orgC.PARENTORGID = orgH.orgid " + 
		"	AND  sysU.ORGID       = orgC.ORGID " + 
		"	AND  sysU.ISACTIVE	  = 'Y' " + 
		"	AND  orgRef.ORGREFERENCEVALUE in " + 
		"( " + 
		"	SELECT  " + 
		"			DISTINCT ORGREFERENCEVALUE  " + 
		"	FROM  " + 
		"			ORGREFERENCE orgRef, " + 
		"			ORGHIERARCHY orgHie " + 
		"	WHERE " + 
		"			orgRef.ORGREFERENCETYPECODE = 'CRTNM' " + 
		"		 AND orgRef.orgid = orgHie.ORGID " + 
		"		 AND orgHie.ORGROLECODE = 'IAC' " + 
		"	MINUS " + 
		"	SELECT  " + 
		"			DISTINCT CERTNUM  " + 
		"	FROM  " + 
		"			V_IAC " + 
		"	WHERE  " + 
		"			START_DATE >= last_day( add_months( TRUNC( sysdate ), -2 ) ) + 1 " + 
		") " + 
		"UNION " + 
		"SELECT  " + 
		"		orgC.CONTACTFIRSTNAME, " + 
		"		orgC.CONTACTLASTNAME, " + 
		"		orgH.ORGNAME, " + 
		"		orgC.EMAIL, " + 
		"		orgRef.ORGREFERENCEVALUE, " + 
		"		sysdate, " + 
		"		last_day( add_months( TRUNC( sysdate ), -1 ) ) + 10 as DUEDATE " + 
		"FROM  " + 
		"		ORGREFERENCE orgRef, " + 
		"		ORGHIERARCHY orgH, " + 
		"		ORGHIERARCHY locH, " + 
		"		SYSTEMUSER   sysU, " + 
		"		ORGHIERARCHY orgC " + 
		"WHERE 		 " + 
		"     	locH.ORGID       = orgRef.ORGID " + 
		"	AND  orgH.orgid       = locH.PARENTORGID " + 
		"	AND  orgC.PARENTORGID = orgH.orgid " + 
		"	AND  locH.status      = 'ACTIVE' " + 
		"	AND  sysU.ORGID       = orgC.ORGID " + 
		"	AND  sysU.ISACTIVE	  = 'Y' " + 
		"	AND  orgRef.ORGREFERENCEVALUE in " + 
		"( " + 
		"	SELECT  " + 
		"			DISTINCT ORGREFERENCEVALUE  " + 
		"	FROM  " + 
		"			ORGREFERENCE orgRef, " + 
		"			ORGHIERARCHY orgHie " + 
		"	WHERE " + 
		"			orgRef.ORGREFERENCETYPECODE = 'CRTNM' " + 
		"		 AND orgRef.orgid = orgHie.ORGID " + 
		"		 AND orgHie.ORGROLECODE =  'IAC' " + 
		"	MINUS " + 
		"	SELECT  " + 
		"			DISTINCT CERTNUM  " + 
		"	FROM  " + 
		"			V_IAC  " + 
		"	WHERE  " + 
		"			START_DATE >= last_day( add_months( TRUNC( sysdate ), -2 ) ) + 1 " + 
		") " + 
		"ORDER BY  " + 
		"		ORGNAME ";	
	

	public List<SystemUserModel> noSubmissionsIAC()
	{
        PreparedStatement pStmt        = null;
        Connection        connection   = null;
    	ResultSet 		  rs		   = null;
    	SystemUserModel  user		   = null;
    	List<SystemUserModel> userList = new ArrayList<SystemUserModel>();
    	
    	String pattern = "MM.dd.yyyy HH:mm:ss z";
    	SimpleDateFormat format = new SimpleDateFormat(pattern);

    	String dayPattern = "MM.dd.yyyy";
    	SimpleDateFormat dayFormat = new SimpleDateFormat( dayPattern );
    	
    	Calendar cal = Calendar.getInstance();
    	cal.setTimeInMillis( System.currentTimeMillis() );
    	
        try
        {
        	connection = getConnection();
        	pStmt	   = connection.prepareStatement( noSubmissionsIACQry );
        	
        	rs = pStmt.executeQuery();
        	
        	while ( rs.next() )
        	{
        		user =  new SystemUserModel();
        		user.setContactFirstName( rs.getString( "CONTACTFIRSTNAME" ) );
        		user.setContactLastName ( rs.getString( "CONTACTLASTNAME"  ) );
        		user.setOrgName			( rs.getString( "ORGNAME"          ) );
        		user.setEmail			( rs.getString( "EMAIL"            ) );		
        		
        		// SystemUserModel Doesn't have a cerntnum, sysdate, duedate
        		//    fields so we just use status, dateFormat and lastupdateUserId instead
        		//
        		user.setStatus          ( rs.getString( "ORGREFERENCEVALUE" ) );
        		user.setDateFormat      ( format.format( rs.getTimestamp( "SYSDATE", cal ) ) );
        		user.setLastUpdateUserId( dayFormat.format( rs.getDate( "DUEDATE", cal ) ) );
        		
        		userList.add( user );
        	}
        } 
        catch (SQLException e)
		{
			//e.printStackTrace();
			logger.error("Exception: " + e.getMessage());
		}        
        finally
        {
        	// We don't close the conection, we share a connection and close in the calling function
        	//
            ConnectionUtil.closeResources(null, pStmt, rs );
        }        
        
		return userList;
	}
	
	String noSubmissionsAIRQry = 
		"SELECT " + 
		"		orgC.ORGNAME, orgC.CONTACTFIRSTNAME, orgC.CONTACTLASTNAME, orgH.SCACCODE, orgC.EMAIL, sysdate, " + 
		"		last_day( add_months( sysdate, -1 ) ) + 10 as DUEDATE " + 
		"FROM " + 
		"		ORGHIERARCHY orgH, " + 
		"		ORGHIERARCHY orgC " + 
		"WHERE " + 
		"	     orgC.PARENTORGID = orgH.ORGID " + 
		"	AND  orgH.scaccode in  " + 
		"	( " + 
		"		SELECT  " + 
		"				DISTINCT SCACCODE " + 
		"		FROM " + 
		"				ORGHIERARCHY " + 
		"		MINUS " + 
		"		SELECT  " + 
		"				DISTINCT CARRIER_CODE  " + 
		"		FROM  " + 
		"				V_AIRCARRIER  " + 
		"		WHERE  " + 
		"				START_DATE >= last_day( add_months( sysdate, -2 ) ) + 1 " + 
		"	) ";
	
	
	public List<SystemUserModel> noSubmissionsAIR()
	{
        PreparedStatement pStmt        = null;
        Connection        connection   = null;
    	ResultSet 		  rs		   = null;
    	SystemUserModel  user		   = null;
    	List<SystemUserModel> userList = new ArrayList<SystemUserModel>();
    	
        try
        {
        	connection = getConnection();
        	pStmt	   = connection.prepareStatement( noSubmissionsAIRQry );
        	
        	rs = pStmt.executeQuery();
        	
        	while ( rs.next() )
        	{
        		user =  new SystemUserModel();
        		user.setContactFirstName( rs.getString( "CONTACTFIRSTNAME" ) );
        		user.setContactLastName ( rs.getString( "CONTACTLASTNAME"  ) );
        		user.setOrgName			( rs.getString( "ORGNAME"          ) );
        		user.setEmail			( rs.getString( "EMAIL"            ) );
        		
        		// SystemUserModel Doesn't have a SCACCODE
        		//    field so we just use status instead
        		//
        		user.setStatus( rs.getString( "SCACCODE" ) );
        		
        		userList.add( user );
        	}
        } 
        catch (SQLException e)
		{
			//e.printStackTrace();
			logger.error("Exception: " + e.getMessage());
		}        
        finally
        {
        	// We don't close the conection, we share a connection and close in the calling function
        	//
            ConnectionUtil.closeResources(null, pStmt, rs );
        }        
        
		return userList;
	}
	
	// changed to 46 days to account for hour rounding and one calendar month checking.  ctrl+f7 in sqldeveloper to format
	String notLoggedInQry = "UPDATE SYSTEMUSER SET ISACTIVE = 'N',LASTUPDATEUSERID='SYSTEM',LASTUPDATETIMESTAMP=SYSDATE WHERE ( (LASTLOGINTIMESTAMP < (sysdate - 46)) or (LASTLOGINTIMESTAMP is null AND (LASTUPDATETIMESTAMP < sysdate - 46) ) ) and ISACTIVE = 'Y'";
	
	/**
	 * De-active any users who have not logged in in 30 days.
	 * 
	 * @return	Number of users de-activated
	 */
	public int deactiveNotLoggedIn()
	{
        PreparedStatement pStmt        = null;
        Connection        connection   = null;
        int 			  countUpdated = 0;	
        
        try
        {
        	connection = getConnection();
        	pStmt	   = connection.prepareStatement( notLoggedInQry );

        	countUpdated = pStmt.executeUpdate();
        }        
        catch (SQLException e)
		{
			//e.printStackTrace();
			logger.error("Exception: " + e.getMessage());
		}        
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, null );
        }  
        
        return countUpdated;
	}
	
	
	
	//Reciept Email
	//
	String receiptUserIdsQry = 
		"SELECT  " + 
		"		evnt.CREATEUSERID,      conOrg.CONTACTFIRSTNAME,  " + 
		"		conOrg.CONTACTLASTNAME, conOrg.EMAIL  " + 
		"FROM  " + 
		"		EVENT        evnt, " + 
		"		ORGHIERARCHY conOrg, " + 
		"		SYSTEMUSER   sysUsr " + 
		"WHERE  " + 
		"	     evnt.EVENTDATETIME >= last_day( add_months( TRUNC(  sysdate ), -2 ) ) + 1  " + 
		"	AND  evnt.certnum is not null  " + 
		"	AND  sysUsr.USERID     = evnt.CREATEUSERID " + 
		"	AND  conOrg.ORGID      = sysUsr.ORGID " + 
		"  	AND  evnt.EVENTCATEGORYCODE in ( 'IAC', 'SHIP', 'ICSF' ) " + 
		"GROUP BY  " + 
		"		evnt.CREATEUSERID, conOrg.CONTACTFIRSTNAME, conOrg.CONTACTLASTNAME, conOrg.EMAIL " + 
		"ORDER BY  " + 
		"		evnt.CREATEUSERID ";
	
	public List<SystemUserModel> retrieveReceiptUserIds()
	{

        PreparedStatement     pStmt        = null;
        Connection            connection   = null;
    	ResultSet 		      rs		   = null;
    	SystemUserModel       user		   = null;
    	List<SystemUserModel> userList   = new ArrayList<SystemUserModel>();
    	
        try
        {
        	connection = getConnection();
        	pStmt	   = connection.prepareStatement( receiptUserIdsQry );
        	
        	rs = pStmt.executeQuery();

        	while ( rs.next() )
        	{
        		user =  new SystemUserModel();
        		user.setUserId          ( rs.getString( "CREATEUSERID"     ) );
        		user.setContactFirstName( rs.getString( "CONTACTFIRSTNAME" ) );
        		user.setContactLastName ( rs.getString( "CONTACTLASTNAME"  ) );
        		user.setEmail           ( rs.getString( "EMAIL"            ) );
        		
        		userList.add( user );
        	}
        } 
        catch (SQLException e)
		{
			//e.printStackTrace();
			logger.error("Exception: " + e.getMessage());
		}        
        finally
        {
        	// We don't close the conection, we share a connection and close in the calling function
        	//
            ConnectionUtil.closeResources(null, pStmt, rs );
        }        

		return userList;
	}
	
	
	String retrieveRecentCertsByUserIDQry =
		"SELECT  " + 
		"		evnt.CERTNUM " + 
		"FROM  " + 
		"		EVENT evnt " + 
		"WHERE  " + 
		"		evnt.CREATEUSERID = ? " + 
		"	AND  evnt.EVENTDATETIME >= last_day( add_months( TRUNC(  sysdate ), -2 ) ) + 1 "; 

	
	public List<String> retrieveRecentCertsByUserID( String userid )
	{

        PreparedStatement     pStmt        = null;
        Connection            connection   = null;
    	ResultSet 		      rs		   = null;
    	List<String>          certList     = new ArrayList<String>();
    	
        try
        {
        	connection = getConnection();
        	pStmt	   = connection.prepareStatement( retrieveRecentCertsByUserIDQry );
        	
        	pStmt.setString( 1, userid );
        	
        	rs = pStmt.executeQuery();

        	while ( rs.next() )
        	{
        		certList.add( rs.getString( "CERTNUM" ) );
        	}
        } 
        catch (SQLException e)
		{
			//e.printStackTrace();
			logger.error("Exception: " + e.getMessage());
		}        
        finally
        {
        	// We don't close the conection, we share a connection and close in the calling function
        	//
            ConnectionUtil.closeResources(null, pStmt, rs );
        }        

		return certList;
	}
	
	public List<SystemUserModel> getPasswordExpireUsers() {

		PreparedStatement pStmt = null;
		Connection connection = null;
		ResultSet rs = null;

		SystemUserModel login = null;
		List<SystemUserModel> loginList = new ArrayList<SystemUserModel>();

		int allowedFailed = Integer.valueOf(ApplicationProperties.getProperty("password.allowedFailedLogins"));
		int daysUntilExpire = Integer.valueOf(ApplicationProperties.getProperty("password.emailWarningDays"));
		
		// format in sqldeveloper with ctrl+f7
    	String sql = "SELECT s.domainname,s.userid,c.contactfirstname AS firstname,c.contactlastname  AS lastname,c.email FROM systemuser s,orghierarchy c WHERE s.isactive = 'Y' AND s.ispasswordautoexpire = 1 AND s.numfailedlogin < ? AND TRUNC(s.lastupdatetimestamp + s.autoexpiredays) = TRUNC(sysdate - ?) AND s.orgid = c.orgid ";
    	
		logger.info("Retreiving list of logins where password will expire in " + daysUntilExpire + " days");

		try {
			connection = getConnection();
			pStmt = connection.prepareStatement(sql);

			pStmt.setInt(1, allowedFailed + 1);
			pStmt.setInt(2, daysUntilExpire);

			rs = pStmt.executeQuery();

			while (rs.next()) {
				login = new SystemUserModel();

				login.setDomainName(rs.getString("DOMAINNAME"));
				login.setUserId(rs.getString("USERID"));
				login.setContactFirstName(rs.getString("FIRSTNAME"));
				login.setContactLastName(rs.getString("LASTNAME"));
				login.setEmail(rs.getString("EMAIL"));

				loginList.add(login);
			}
		} catch (Exception e) {
			logger.error("Error executing: " + sql);
			//e.printStackTrace();
		} finally {
			// We don't close the connection, we share a connection and close in the calling function
			//
			ConnectionUtil.closeResources(null, pStmt, rs);
		}

		logger.info(loginList.size() + " logins will expire in " + daysUntilExpire + " days");
		return loginList;
	}

}
