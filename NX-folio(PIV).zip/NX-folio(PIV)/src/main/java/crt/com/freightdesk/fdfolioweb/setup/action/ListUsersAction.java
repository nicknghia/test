/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/setup/action/ListUsersAction.java,v 1.8.2.16 2010/12/02 15:54:27 jhansford Exp $
 * 
 *  Modification History:
 *  $Log: ListUsersAction.java,v $
 *  Revision 1.8.2.16  2010/12/02 15:54:27  jhansford
 *  Add UserID search
 *
 *  Revision 1.8.2.15  2010/09/04 19:48:09  mechevarria
 *  changes for yui select on domain
 *
 *  Revision 1.8.2.14  2010/08/22 23:08:38  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.8.2.13  2010/02/11 22:12:43  mechevarria
 *  moved systemusermodel to commons
 *
 *  Revision 1.8.2.12  2010/02/03 20:32:08  mechevarria
 *  use stringescapeutils
 *
 *  Revision 1.8.2.11  2009/11/05 14:48:30  mechevarria
 *  correct typo in domainslist call
 *
 *  Revision 1.8.2.10  2009/11/02 21:15:06  mechevarria
 *  use the optioncollectionmanager
 *
 *  Revision 1.8.2.9  2009/10/29 21:39:48  mechevarria
 *  use OptionCollectionManager in fdcommons
 *
 *  Revision 1.8.2.8  2009/10/05 19:35:15  jhansford
 *  RESOLVED - issue FAS-66: when deleting users, the listusers.jsp loads for your domain, not selected domain
 *  http://jira.ntelx.net/browse/FAS-66
 *
 *  Had to add a small change to make sure domain was saved when user was deleted as well as edited.
 *
 *  Revision 1.8.2.7  2009/10/05 19:11:58  jhansford
 *  OPEN - issue FAS-66: when deleting users, the listusers.jsp loads for your domain, not selected domain
 *  http://jira.ntelx.net/browse/FAS-66
 *
 *  Revision 1.8.2.6  2009/09/22 19:32:42  mechevarria
 *  updated user management
 *
 *  Revision 1.8.2.5  2009/08/12 18:16:14  jhansford
 *  Added Pull Down to switch domains on edit user page.
 *
 *  Revision 1.8.2.4  2009/01/23 15:10:34  mechevarria
 *  updated code to be compatible with struts 1.3.10
 *
 *  Revision 1.8.2.3  2007/12/13 15:15:53  mechevarria
 *  removed possible bad characters from xss vulnerable fields
 *
 *  Revision 1.8.2.2  2007/08/16 13:12:43  mechevarria
 *  added async logging to user deletion
 *
 *  Revision 1.8.2.1  2007/03/28 20:25:13  mechevarria
 *  merged changes from head branch to fix domain admin rights issue
 *
 *  Revision 1.8  2007/01/12 11:59:12  atripathi
 *  user feedback messages added
 *
 *  Revision 1.7  2006/05/27 03:20:16  aarora
 *  Removed unnecessary code, organized imports and formatted
 *
 *  Revision 1.6  2006/05/11 22:19:02  aarora
 *  Small change as the SessionKey class has been added to com.freightdesk.fdfolio.commons
 *
 *  Revision 1.5  2006/04/12 23:38:30  aarora
 *  Organized imports
 *
 *  Revision 1.4  2006/03/28 21:22:59  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.3  2005/09/09 00:31:16  amrinder
 *  Removing dependancy on System Role, and allowing the system admin to only modify the users within the corresponding domain
 *
 *  Revision 1.2  2004/09/21 08:47:42  ranand
 *  package of Manager classes  changed from folioweb to folio
 *
 *  Revision 1.1  2004/09/15 13:36:28  asingh
 *  2.6 Baseline
 */

package crt.com.freightdesk.fdfolioweb.setup.action;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang.StringEscapeUtils;

import com.freightdesk.fdcommons.ActionErrors;
import com.freightdesk.fdcommons.ActionMessage;
import com.freightdesk.fdcommons.ActionMessages;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.log4j.Logger;

import crt.com.freightdesk.fdfolio.setup.UserSetupManager;

import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.LoggedInAction;
import com.freightdesk.fdcommons.OperationInfo;
import com.freightdesk.fdcommons.OptionBean;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.StackManager;
import com.freightdesk.fdfolio.useraccess.model.SystemUserModel;

import crt.com.ntelx.nxcommons.reporting.OptionCollectionManager;
import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import crt.com.freightdesk.fdfolio.setup.SystemMessageManager;
import crt.com.freightdesk.fdfolio.setup.model.SystemMessageModel;

import com.opensymphony.xwork2.ActionSupport;

/**
 * The Struts Action class associated with ListUsers.jsp and the ListUsersForm.
 *
 * The execute method is the only method that needs to be declared public.
 *
 * @author Sangeeta Taneja
 * @author Amrinder Arora
 */
public class ListUsersAction extends ActionSupport implements ServletRequestAware {
    class pager{
        public String offset;
		
    }
    private ListUsersAction.pager pager = new ListUsersAction.pager();
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();
    private String messageText;
    private String faqTxt;
    private String loginTimeRoleMsg;
    /** An instance of UserSetupManager */
    protected UserSetupManager userSetupManager = new UserSetupManager();
    
    // Properties
    private String process = "";

    // variables used for sorting
    private String sortingOrder = "";
    private String sortingAttribute = "";

    private long orgId = 0;
    private String userId = "";
    private long systemUserId = 0;
    private List<SystemUserModel> usersList;
    private List<SystemUserModel> usersListMap;
    private String index = "";
    private String tableName = "";
    private String usersDomainName = com.freightdesk.fdcommons.GlobalConstants.FAS_DOMAIN;
    private String domJsArray = "";
    private String selectedDomain = com.freightdesk.fdcommons.GlobalConstants.FAS_DOMAIN;
    private String domLabel = "";
    private String userIDSearch = "";
    private String lastName = "";
    private String email = "";
    private String invokedFrom = "";    
    private String btnUpdate = "";
    private String pagerOffset;

    /**
     * Executes the request.
     * @return The ActionForward that the Struts Action servlet should use to serve the response
     */
    public String execute() throws Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
        logger.info("starting Users and Roles");
        
        // POAM HttpOnly Secure
        HttpServletResponse response = (HttpServletResponse)ServletActionContext.getResponse();
        String secure = "";
        if (request.isSecure()) {
          secure = "; Secure";
        }
        response.setHeader("SET-COOKIE", "JSESSIONID=" + request.getSession().getId()
                         + "; Path=" + request.getContextPath() + "; HttpOnly" + secure);      
        
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);

        SystemMessageManager messageManager = SystemMessageManager.getInstance();
        SystemMessageModel model = new SystemMessageModel();
        faqTxt = messageManager.getMessageModel().getFaqTxt();
        messageText = messageManager.getMessageModel().getMessageText();
                
        
        process = getProcess();
        
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        
        List<SystemUserModel> usersList = new ArrayList<SystemUserModel>();
        if(sessionStore.get(SessionKey.USER_LIST) != null) {
          usersList = (List) sessionStore.get(SessionKey.USER_LIST);         
        }
        
        // Clean variables to fix XSS vulnerability
        setSortingOrder(StringEscapeUtils.escapeHtml(sortingOrder));
        setSortingAttribute(StringEscapeUtils.escapeHtml(sortingAttribute));

        logger.debug("ListUserAction.execute() process is " + process);
        

        if ("delete".equalsIgnoreCase(process)) {
            return deleteUser() ;
        } else if ("sort".equalsIgnoreCase(process)) {
            return sortPage() ;
        } else if ( "searchUser".equalsIgnoreCase( process ) ) {           	
			String searchStr = StringEscapeUtils.escapeHtml(getUserIDSearch().toUpperCase().replaceAll("&lt;", "").replaceAll("&quot;", "").replaceAll("&gt;", ""));						
			String searchLastName = StringEscapeUtils.escapeHtml(getLastName().toUpperCase().replaceAll("&lt;", "").replaceAll("&quot;", "").replaceAll("&gt;", ""));			
			String searchEmail = StringEscapeUtils.escapeHtml(getEmail().toUpperCase().replaceAll("&lt;", "").replaceAll("&quot;", "").replaceAll("&gt;", ""));
        	
        	usersList = userSetupManager.searchSystemUsers( searchStr,searchLastName,getSelectedDomain(),searchEmail,credentials);                
                //For Paging
                if ((request.getParameter("pager.offset") != null) && (request.getParameter("pager.offset") != "")) {                  
                    setPagerOffset(request.getParameter("pager.offset"));
                    store.put (SessionKey.INDEX, pagerOffset);
                }
            
        } else if ("cancel".equalsIgnoreCase(process)) {            
			addActionMessage(getText("setup.operation.cancel"));
            return "cancel";
        } else if ("UserEdit".equalsIgnoreCase(process)) {           
            SystemUserModel systemUserModel = new SystemUserModel();
			
            systemUserModel.setSystemUserId(getSystemUserId());           
            
            systemUserModel.setOrgId(getOrgId());
            
            logger.debug("getSystemUserId(): " + getSystemUserId() + 
                    ", getOrgId(): " + getOrgId());
			
            sessionStore.put(SessionKey.USER_MODEL,systemUserModel);
                        
            return "edit";
        } else if ("UserAdd".equalsIgnoreCase(process)) {            
            sessionStore.put(SessionKey.IS_FORWARDED, "YES");
            StackManager sm = (StackManager)sessionStore.get(SessionKey.STACK);
            logger.debug("Stack Manager IS  "+sm);
            sm.createEvent(new OperationInfo("SetUpManager", "SetUpDetails", process,"", "", ""));            
            
            return "add";
        } else if ( "user_display".equalsIgnoreCase( process ) ){
            if ((request.getParameter("pager.offset") != null) && (request.getParameter("pager.offset") != "")) {
                setPagerOffset(request.getParameter("pager.offset"));
                store.put (SessionKey.INDEX, pagerOffset);
            }
        }
                       
        long count = usersList.size();
        sessionStore.put (SessionKey.TOTAL_COUNT, new Long(count));
        sessionStore.put(SessionKey.USER_LIST, usersList);
        setUsersList(usersList);
        setUsersListMap (convertToUsersListMap(usersList));		
		request.setAttribute("UsersList", usersList);                
		request.setAttribute("SortingOrder", sortingOrder);
		request.setAttribute("SortingAttribute", sortingAttribute);
		request.setAttribute("SelectedDomain", selectedDomain);
		
        return displayPage();
    }

    /**
     * Displays the list of system users.
     */
    public String displayPage() throws Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());        
    	logger.debug("starting method");
        
    	ActionMessage actionError=null;
    	OptionCollectionManager collectionManager = OptionCollectionManager.getInstance();
        try {
            setDomJsArray(collectionManager.getJSON("domainslist"));
            
            if ((getSortingAttribute()!= null) && (getSortingAttribute().trim().length()> 0)) {			    
                List usersList = (List) (sessionStore.get(SessionKey.USER_LIST));						
				setUsersList(usersList);
				setUsersListMap (convertToUsersListMap(usersList));
			    
                userSetupManager.doSortByColumn(getUsersList(), getSortingAttribute(), getSortingOrder().equals("up")?true:false);				
		        request.setAttribute("UsersList", usersList);                
                request.setAttribute("SortingOrder", sortingOrder);
                request.setAttribute("SortingAttribute", sortingAttribute);
                request.setAttribute("SelectedDomain", selectedDomain);	
				sessionStore.put(SessionKey.USER_LIST, usersList);				
            }
        } catch (Exception e) {
            logger.error("caught exception");
            actionError = new ActionMessage("error.listusers.displaymessage");
        }
        
        if ( getUsersDomainName() == null )
            setUsersDomainName( credentials.getDomainName() );
        
        if( getSelectedDomain() == null)
            setSelectedDomain(getUsersDomainName());
        
        // set the domainselect label
        for (OptionBean ob : collectionManager.getCollection("domainslist")) {
            if (ob.getValue().equalsIgnoreCase(getSelectedDomain())) {
                setDomLabel( ob.getLabel());				
                break;
            }
        }
                
        if (actionError != null) {
            setErrors(request, actionError,"ListUsers");
        }
        logger.debug("displaying jsp");       
        return "display";
    }

    /**
     * Sorts the data in the order specified by the user
     */
    public String sortPage() throws Exception{
        logger.info("sortPage.begin()");       

        HttpSession session = request.getSession();
        SessionStore sessionStore = SessionStore.getInstance(session);

        String sortingAttribute = getSortingAttribute();
        String sortingOrder = getSortingOrder();
        List usersList = (List) (sessionStore.get(SessionKey.USER_LIST));

        logger.debug("Sorting action on " + sortingAttribute + "; " + sortingOrder);
        
        try {
		   userSetupManager.doSortByColumn(usersList, sortingAttribute,sortingOrder.equals("up")?true:false);
		} catch (Exception e) {
            logger.error("caught exception");
            
        }
        setUsersList(usersList);				
        setUsersListMap (convertToUsersListMap(usersList));
		
        return displayPage();       
    }

    public String deleteUser() throws Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
        logger.info("deleteUser(): begin");       

        ActionMessage actionError=null;

        SystemUserModel systemUserModel = new SystemUserModel();
        systemUserModel.setSystemUserId(getSystemUserId());
        systemUserModel.setUserId(getUserId());
        systemUserModel.setDomainName(getUsersDomainName());

        try {
            userSetupManager.deleteUser(systemUserModel, credentials);            
            addActionMessage(getText("setup.user.delete"));
        } catch (Exception e) {
            actionError = new ActionMessage("error.listusers.deletemessage");
            addActionMessage(getText("error.listusers.deletemessage"));
        }
        if (actionError != null) {
            setErrors(request, actionError,"deleteUser");
            addActionError("deleteUser");        
		}
        
        List<SystemUserModel> usersList =  new ArrayList<SystemUserModel>();
        
        store.put(SessionKey.USER_LIST, usersList);
        setUsersList(usersList);
        setUsersListMap (convertToUsersListMap(usersList));
        
        return displayPage();
    }

    private void setErrors(HttpServletRequest request,ActionMessage actionError,String errorKey) {
        ActionErrors actionErrors=null;
        actionErrors = new ActionErrors();
        actionErrors.add(errorKey, actionError);      
    }
    
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }
 
    public HttpServletRequest getServletRequest() {
        return this.request;
    }
    
    public String getFaqTxt() {
        if (faqTxt == null) {
            this.faqTxt = "";
        }
        return faqTxt;
    }
    
    public void setFaqTxt(String faqTxt) {
        this.faqTxt = faqTxt;
    }
        
    public String getMessageText() {
        return messageText;
    }
        
    public void setMessageText(String messageText) {
        this.messageText = messageText; 
    }
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
    
    public String getEmail() {
        if(email == null)
            return "";
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getInvokedFrom() {
        return invokedFrom;
    }

    public void setInvokedFrom(String invokedFrom) {
        this.invokedFrom = invokedFrom;
    }

    public String getLastName() {
    	if(lastName == null)
            return "";
        return lastName;
    }	

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserIDSearch() {
    	if (userIDSearch == null)
            return "";
        return userIDSearch;
    }

    public void setUserIDSearch(String userIDSearch) {
        this.userIDSearch = userIDSearch;
    }

    public String getDomJsArray() {
        return domJsArray;
    }

    public void setDomJsArray(String domJsArray) {
        this.domJsArray = domJsArray;
    }
    
    public String getDomLabel() {
        return domLabel;
    }

    public void setDomLabel(String domLabel) {
        this.domLabel = domLabel;
    }

    public String getUsersDomainName() {
        return usersDomainName;
    }

    public void setUsersDomainName(String usersDomainName) {
        this.usersDomainName = usersDomainName;
    }

    public String getSelectedDomain() {
    	if(selectedDomain == null)
            return com.freightdesk.fdcommons.GlobalConstants.FAS_DOMAIN;
        return com.freightdesk.fdcommons.GlobalConstants.FAS_DOMAIN;
    }

    public void setSelectedDomain(String selectedDomain) {
        this.selectedDomain = com.freightdesk.fdcommons.GlobalConstants.FAS_DOMAIN;
    }

    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }
    
    public String getSortingOrder() {
        return sortingOrder;
    }

    public void setSortingOrder(String argSortingOrder) {
        this.sortingOrder = argSortingOrder;
    }

    public String getSortingAttribute() {
        return sortingAttribute;
    }

    public void setSortingAttribute(String argSortingAttribute) {
        this.sortingAttribute = argSortingAttribute;
    }

    public String getProcess() {
        return process;
    }

    public void setProcess(String process) {
        this.process = process;
    }

    public long getOrgId() {
        return orgId;
    }

    public void setOrgId(long orgId) {
        this.orgId = orgId;
    }
    
    public long getSystemUserId() {
        return systemUserId;
    }

    public void setSystemUserId(long systemUserId) {
        this.systemUserId = systemUserId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public void setUsersList(List<SystemUserModel> usersList) {
        this.usersList = usersList;
    }

    public List<SystemUserModel> getUsersList() {
        return usersList;
    }
    
    public void setUsersListMap(List<SystemUserModel> usersListMap) {
        this.usersListMap = usersListMap;
    }

    public List<SystemUserModel> getUsersListMap() {
        return usersListMap;
    }
    
    public String getIndex() {
        return index;
    }

    public void setIndex(String index) {
        this.index = index;
    }
       
    
    public String getBtnUpdate() {
        return btnUpdate;
    }

    public void setBtnUpdate(String btnUpdate) {
        this.btnUpdate = btnUpdate;
    }
    
    public void setActionMessage(HttpServletRequest request, String[] messageKeyObject) {
        int length = messageKeyObject.length;	
	ActionMessage actionMessage;
        
	switch (length) {
            case 2:		
            	actionMessage = new ActionMessage(messageKeyObject[0], (Object) messageKeyObject[1]);
		break;
            case 3:
		actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2]);
		break;
            case 4:
		actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3]);
		break;
            case 5:
		actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3], messageKeyObject[4]);
		break;
            default:
		actionMessage = new ActionMessage(messageKeyObject[0]);
        }

        ActionMessages messages = new ActionMessages();
	messages.add(ActionMessages.GLOBAL_MESSAGE, actionMessage);
	
	logger.debug("message has been set on request");
    }
    
    public String getPagerOffset() {
        return pagerOffset;
    }

    public void setPagerOffset(String pagerOffset) {
        this.pagerOffset = pagerOffset;
    }
    
    public String getOffset() {
        return pager.offset;
    }

    public void setOffset(String pagerOffset) {
        this.pager.offset = pagerOffset;
    }
    
    List<SystemUserModel> convertToUsersListMap(List<SystemUserModel> theUsersList){
        int starting_idx=0;
        int counter=0;
        List<SystemUserModel> theUsersListMap = new ArrayList();
        Iterator<SystemUserModel>  itrList = theUsersList.iterator();
        SystemUserModel userModel = new SystemUserModel();
               
        
        request = ServletActionContext.getRequest();
        
        try {
            if ((request != null) && (request.getParameter("pager.offset") != null)&& 
                    (request.getParameter("pager.offset") != "")) {
                starting_idx = Integer.parseInt((String)request.getParameter("pager.offset"));                
            } else {
                logger.debug("pager.offset=" + "null");				
            }
        } catch (Exception e) {
		    logger.debug("Exception=" + e);          
        }
        
        while (itrList.hasNext()) {
            userModel = (SystemUserModel)itrList.next();
            if ((counter) >=  starting_idx){
			   
                if (userModel.getSystemRoleCode().equalsIgnoreCase("Read-Only User")) {
				    userModel.setSystemRoleCode("Read Only (RDONL)");
				}
				else if (userModel.getSystemRoleCode().equalsIgnoreCase("Targeter")) {                 
				    userModel.setSystemRoleCode("Targeter (TAR)");
				}
				else if (userModel.getSystemRoleCode().equalsIgnoreCase("Application Administrator")) {                 
				    userModel.setSystemRoleCode("Application Administrator (APAD)");
				}
				
                theUsersListMap.add(userModel);
            }
            counter = counter + 1;
        }
        
        return (theUsersListMap);
    }
}

