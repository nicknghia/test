/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/dashboard/Attic/DashBoardTile.java,v 1.2.6.1 2010/08/22 23:08:47 mechevarria Exp $ 
 * 
 *  Modification History:
 *  $Log: DashBoardTile.java,v $
 *  Revision 1.2.6.1  2010/08/22 23:08:47  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.2  2006/03/28 21:23:01  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.1  2005/10/05 12:04:13  nsehra
 *  first version
 *
 */
package crt.com.freightdesk.fdfolio.dashboard;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.ApplicationProperties;

/**
 * @author Nitin Sehra
 *
 */
public class DashBoardTile
{
	public static transient Logger logger = Logger.getLogger("crt.com.freightdesk.fdfolio.dashboard.DashBoardTile");
	String query;
	String noOfRecords;
	String labels;
	String key;
	
	public DashBoardTile(String prefValue)
	{
			this.key = prefValue;
			this.noOfRecords = ApplicationProperties.getProperty ("dashboard."+prefValue+".noOfRecords");
			this.query =  ApplicationProperties.getProperty ("dashboard."+prefValue+".query");
			this.labels = ApplicationProperties.getProperty ("dashboard."+prefValue+".label");
	}
	
    /**
     * @key
     */
    public String getKey()
    {
        return key;
    }

    /**
     * @labels
     */
    public String getLabels()
    {
        return labels;
    }

    /**
     * @noOfRecords
     */
    public String getNoOfRecords()
    {
        return noOfRecords;
    }

    /**
     * @query
     */
    public String getQuery()
    {
        return query;
    }

}
