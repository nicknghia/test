/** 
* Copyright (c) NTELX 
*  All rights reserved. 
* 
* This software is the confidential and proprietary information of NTELX 
* ("Confidential Information").  You shall not disclose such Confidential Information 
* and shall use it only in accordance with the terms of the license agreement you entered 
* into with NTELX. 
* 
* 
*  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/setup/action/Attic/OnlineUsersAction.java,v 1.5.2.4 2010/08/22 23:08:38 mechevarria Exp $ 
* 
*  Modification History:
*  $Log: OnlineUsersAction.java,v $
*  Revision 1.5.2.4  2010/08/22 23:08:38  mechevarria
*  update with company name in copyright
*
*  Revision 1.5.2.3  2010/08/16 14:23:26  mechevarria
*  add the domain name to userid listing field
*
*  Revision 1.5.2.2  2010/07/19 20:18:19  mechevarria
*  get extra info for online users
*
*  Revision 1.5.2.1  2009/09/23 18:02:17  mechevarria
*  import clean via eclipse
*
*  Revision 1.5  2007/01/12 11:59:12  atripathi
*  user feedback messages added
*
*  Revision 1.4  2006/05/11 22:18:55  aarora
*  Small change as the SessionKey class has been added to com.freightdesk.fdfolio.commons
*
*  Revision 1.3  2006/04/26 11:22:21  dkumar
*  changes for adding two new columns currentModule and onlineSince
*
*  Revision 1.2  2006/04/24 15:47:29  ranand
*  retrieving only one role from List
*
*  Revision 1.1  2006/04/17 16:09:18  dkumar
*  added new link"Who is Online" in SetupHome
*
*/
package crt.com.freightdesk.fdfolioweb.setup.action;

import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.freightdesk.fdcommons.ApplicationTabs;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.OptionBean;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.SessionKey;

import crt.com.freightdesk.fdfolio.common.UserSetupReferenceData;

import com.freightdesk.fdfolio.dao.UserAccessDAO;

import javax.servlet.http.HttpSession;

import crt.com.freightdesk.fdfolio.common.IncludesUtil;

import com.freightdesk.fdcommons.ActionMessage;
import com.freightdesk.fdcommons.ActionMessages;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.log4j.Logger;

import com.opensymphony.xwork2.ActionSupport;

import org.apache.struts2.ServletActionContext;

import java.util.Date;
import java.util.Collection;
import java.util.Hashtable;


/**
 * This class retrieves all online users and their corresponding roles from SessionStorejust a min..
 * @author Deepak Kumar 
 **/

public class OnlineUsersAction extends ActionSupport implements ServletRequestAware
{
    protected static Map onlineUserPropMap = new HashMap();
    protected static Map userIdRoleMap = new HashMap();
	
    protected static HashMap allSessionStores = new HashMap();
    
    private String loginTimeRoleMsg;
    HttpServletRequest request = getServletRequest();
	
    private String process="";
    protected Logger logger = Logger.getLogger(getClass());
    private String systemRoleCode="";	
    protected static Map userIdPropertyMap = new HashMap();


    private int numLogins=0;
    private int totalNumberOnline=0;
    private String systemRoleName="";
    private String currentModule="";
    private String userId="";
    private Date onlineSince;	       

        	
    /** Executes the request. */
    public String execute() throws Exception {
        
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance (session);
        Credentials credentials = (Credentials) (store.get (SessionKey.CREDENTIALS)); 

        // POAM HttpOnly Secure
        HttpServletResponse response = (HttpServletResponse)ServletActionContext.getResponse();
        String secure = "";
        if (request.isSecure()) {
          secure = "; Secure";
        }
        response.setHeader("SET-COOKIE", "JSESSIONID=" + request.getSession().getId()
                         + "; Path=" + request.getContextPath() + "; HttpOnly" + secure);      

        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);
		
        process = getProcess();
        logger.info("execute OnlineUsersAction");
		
        if ("CANCEL".equalsIgnoreCase(process)) {
            addActionMessage(getText("setup.operation.cancel"));
            loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);

            return "cancel";
        }
		
	loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);
		
        UserSetupReferenceData userSetupReferenceData = UserSetupReferenceData.getInstance(credentials.getDomainName());
        List roleList=userSetupReferenceData.getRoleList() ; 
        Map systemRoleMap = new HashMap();
        for(int j=0;j<roleList.size();j++) {
        	OptionBean roleOptionBean= (OptionBean)roleList.get(j);
        	systemRoleMap.put(roleOptionBean.getValue(),roleOptionBean.getLabel());
        }
		           
        Collection sessions = SessionStore.getAllSessions();
        
        userIdPropertyMap = new HashMap();
        
        Iterator itr = sessions.iterator();
        while (itr.hasNext()){
            SessionStore sessionStore = (SessionStore)itr.next();
            Credentials eachCredentials= (Credentials)sessionStore.get(SessionKey.CREDENTIALS );
            currentModule = ApplicationTabs.getTabKey((Integer)sessionStore.get(SessionKey.CURRENT_TAB)) ;
            systemRoleName="";
            
            if(eachCredentials!=null) {
                setSystemRoleCode(eachCredentials.getRole());
                systemRoleName=(String)systemRoleMap.get( getSystemRoleCode() );

                onlineUserPropMap =new HashMap();
                onlineUserPropMap.put("systemRole",getSystemRoleName());
                
                onlineUserPropMap.put("currentModule",getCurrentModule().substring(10).toUpperCase());
                
                onlineUserPropMap.put("onlineSince",
                        eachCredentials.getLastLoginTime().toString().substring(0, eachCredentials.getLastLoginTime().toString().indexOf('.')));
                
                userIdPropertyMap.put(eachCredentials.getUserId(),onlineUserPropMap);
            }
        }
        
        setUserIdPropertyMap (userIdPropertyMap);
		
	setNumLogins(new UserAccessDAO().getNumLoginsIn24());
	setTotalNumberOnline(sessions.size());       
        return "display";
    }
	
	public void setActionMessage(HttpServletRequest request, String[] messageKeyObject) {
        int length = messageKeyObject.length;
        ActionMessage actionMessage = null;
        switch (length) {
            case 2:
                actionMessage = new ActionMessage(messageKeyObject[0], (Object) messageKeyObject[1]);
                break;
            case 3:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2]);
                break;
            case 4:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3]);
                break;
            case 5:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3], messageKeyObject[4]);
                break;
            default:
                actionMessage = new ActionMessage(messageKeyObject[0]);
        }

        ActionMessages messages = new ActionMessages();
        messages.add(ActionMessages.GLOBAL_MESSAGE, actionMessage);
    }
	
    public String getSystemRoleCode() {
        return systemRoleCode;
    }

    public void setSystemRoleCode(String systemRoleCode) {
        this.systemRoleCode = systemRoleCode;
    }
	
    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }
    
    public Date getOnlineSince() {
        return onlineSince;
    }

    public void setOnlineSince(Date onlineSince) {
        this.onlineSince = onlineSince;
    }
    
    public String getCurrentModule() {
        return currentModule;
    }

    public void setCurrentModule(String currentModule) {
        this.currentModule = currentModule;
    }
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
	
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
	
    public int getNumLogins() {
	    return numLogins;
    }
    
    public void setNumLogins(int numLogins) {
	   this.numLogins = numLogins;
    }
    
    public int getTotalNumberOnline() {
	    return totalNumberOnline;
    }
    
    public void setTotalNumberOnline(int totalNumberOnline) {
	   this.totalNumberOnline = totalNumberOnline;
    }
	
    public String getProcess() {
	   return process;
    }
    
    public void setProcess(String process) {
	   this.process = process;
    }
    
    public String getSystemRoleName() {
	  return systemRoleName;
    }
    
    public void setSystemRoleName(String systemRoleName) {
	  this.systemRoleName = systemRoleName;
    }
    
    public Map getUserIdPropertyMap() {
	return userIdPropertyMap;
    }
    public void setUserIdPropertyMap(Map userIdPropertyMap) {
	this.userIdPropertyMap = userIdPropertyMap;
    }
}
