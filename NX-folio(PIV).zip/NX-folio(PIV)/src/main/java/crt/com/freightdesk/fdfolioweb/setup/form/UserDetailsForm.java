/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/setup/form/UserDetailsForm.java,v 1.1.10.9 2010/09/27 20:30:33 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: UserDetailsForm.java,v $
 *  Revision 1.1.10.9  2010/09/27 20:30:33  mechevarria
 *  add field for createtimestamp and lastupdatetimestamp
 *
 *  Revision 1.1.10.8  2010/08/22 23:08:39  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.1.10.7  2009/10/29 21:38:29  mechevarria
 *  use optionsbeans for picklist
 *
 *  Revision 1.1.10.6  2009/10/09 14:03:25  jhansford
 *  OPEN - issue FAS-80: Add ability to Send Mail
 *  http://jira.ntelx.net/browse/FAS-80
 *
 *  Revision 1.1.10.5  2009/10/06 18:21:44  mechevarria
 *  add email field
 *
 *  Revision 1.1.10.4  2009/09/23 18:03:32  mechevarria
 *  import cleanup via eclipse
 *
 *  Revision 1.1.10.3  2009/09/22 19:32:42  mechevarria
 *  updated user management
 *
 *  Revision 1.1.10.2  2009/05/08 20:31:11  mechevarria
 *  added element to edit isActive
 *
 *  Revision 1.1.10.1  2009/02/23 20:49:01  mechevarria
 *  security updates
 *
 *  Revision 1.1  2004/09/15 13:36:28  asingh
 *  2.6 Baseline
 *
 * 
 */

package crt.com.freightdesk.fdfolioweb.setup.form;

import java.util.List;

import org.apache.commons.lang.StringEscapeUtils;
//import org.apache.struts.action.ActionErrors;
//import org.apache.struts.action.ActionMapping;
//import org.apache.struts.action.ActionMessage;
import com.freightdesk.fdcommons.ActionErrors;
import com.freightdesk.fdcommons.ActionMessage;
import com.freightdesk.fdcommons.OptionBean;
import crt.com.ntelx.nxcommons.PasswordUtils;
import com.freightdesk.fdfolio.common.BasicButtonsForm;
import com.freightdesk.fdfolio.dao.OrghierarchyDAO;
import crt.com.freightdesk.fdfolio.event.FasEventUtil;
import crt.com.freightdesk.fdfolioweb.setup.PasswordStatus;

/**
 * The UserDetailsForm is associated with UserDetails.jsp and the
 * UserDetailsAction.
 * 
 * @author Sangeeta
 */

public class UserDetailsForm extends BasicButtonsForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1526446059345935041L;
	private String firstName;
	private String lastName;
	private String userId;
	private String newPassword;
	private String confirmPassword;
	private String orgName;
	private String systemRoleCode;
	private long userSystemRoleId;
	private String passwordExpirationDate;
	private String active;
	private String passwordAutoExpire = "0";
	private String autoExpireDays;
	private String currencyCode;
	private String preferredDateFormat;
	private String uomCode;
	private String timeZoneId;
	private List roleList;
	private String process;
	private String subProcess;
	private String orgId;
	private String systemUserId;
	private String invokedFrom;
	private String passwordReset;
	private List<OptionBean> statusList;
	private String usersDomainName;
	private String selectedDomainName;
	private List<OptionBean> domainList;
	private String newDomainButton;
	private String email;
	private String sendEmail;
	private String createTimestamp;
	private String lastUpdateTimestamp;
	private String createUserId;
	private String lastUpdateUserId;
	private String lastLoginTimestamp;
	private String numFailedLogin;

	public String getNumFailedLogin() {
		return numFailedLogin;
	}

	public void setNumFailedLogin(String numFailedLogin) {
		this.numFailedLogin = numFailedLogin;
	}

	public String getLastLoginTimestamp() {
		if(lastLoginTimestamp == null || lastLoginTimestamp.length() < 1)
			return "Never logged in";
		return lastLoginTimestamp;
	}

	public void setLastLoginTimestamp(String lastLoginTimestamp) {
		this.lastLoginTimestamp = lastLoginTimestamp;
	}

	public String getCreateTimestamp() {
		return createTimestamp;
	}

	public void setCreateTimestamp(String createTimestamp) {
		this.createTimestamp = createTimestamp;
	}

	public String getLastUpdateTimestamp() {
		return lastUpdateTimestamp;
	}

	public void setLastUpdateTimestamp(String lastUpdateTimestamp) {
		this.lastUpdateTimestamp = lastUpdateTimestamp;
	}

	public String getCreateUserId() {
		if(createUserId == null)
			return "";
		return createUserId;
	}

	public void setCreateUserId(String createUserId) {
		this.createUserId = createUserId;
	}

	public String getLastUpdateUserId() {
		if(lastUpdateUserId == null)
			return "";
		return lastUpdateUserId;
	}

	public void setLastUpdateUserId(String lastUpdateUserId) {
		this.lastUpdateUserId = lastUpdateUserId;
	}

	public String getSendEmail() {
		return sendEmail;
	}

	public void setSendEmail(String sendEmail) {
		this.sendEmail = sendEmail;
	}

	public UserDetailsForm() {
	}
	
	public String getEmail() {
		if(email == null)
			return "";
		else
			return StringEscapeUtils.escapeHtml(email);
	}
	public void setEmail(String email) {
		this.email = email;
	}

	public String getSelectedDomainName() {
		if (selectedDomainName == null)
			return "";
		return selectedDomainName;
	}

	public void setSelectedDomainName(String selectedDomainName) {
		this.selectedDomainName = selectedDomainName;
	}

	public String getNewDomainButton() {
		return newDomainButton;
	}

	public void setNewDomainButton(String newDomainButton) {
		this.newDomainButton = newDomainButton;
	}

	public String getUsersDomainName() {
		if (usersDomainName == null)
			return "";
		return usersDomainName;
	}

	public void setUsersDomainName(String usersDomainName) {
		this.usersDomainName = usersDomainName;
	}

	public List<OptionBean> getDomainList() {
		return domainList;
	}

	public void setDomainList(List<OptionBean> domainList) {
		this.domainList = domainList;
	}

	public List<OptionBean> getStatusList() {
		return statusList;
	}

	public void setStatusList(List<OptionBean> statusList) {
		this.statusList = statusList;
	}

	public String getPasswordReset() {
		return passwordReset;
	}

	public void setPasswordReset(String passwordReset) {
		this.passwordReset = passwordReset;
	}

	public String getFirstName() {
		return this.firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return this.lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUserId() {
		return this.userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getOrgName() {
		return this.orgName;
	}

	public void setOrgName(String orgName) {
		this.orgName = orgName;
	}

	public String getNewPassword() {
		return this.newPassword;
	}

	public void setNewPassword(String newPassword) {
		this.newPassword = newPassword;
	}

	public String getConfirmPassword() {
		return this.confirmPassword;
	}

	public void setConfirmPassword(String confirmPassword) {
		this.confirmPassword = confirmPassword;
	}

	public String getSystemRoleCode() {
		return this.systemRoleCode;
	}

	public void setSystemRoleCode(String systemRoleCode) {
		this.systemRoleCode = systemRoleCode;
	}

	public String getPasswordExpirationDate() {
		return this.passwordExpirationDate;
	}

	public void setPasswordExpirationDate(String passwordExpirationDate) {
		this.passwordExpirationDate = passwordExpirationDate;
	}

	public String getActive() {
		return this.active;
	}

	public void setActive(String active) {
		this.active = active;
	}

	public String getPasswordAutoExpire() {
		return this.passwordAutoExpire;
	}

	public void setPasswordAutoExpire(String passwordAutoExpire) {
		this.passwordAutoExpire = passwordAutoExpire;
	}

	public String getAutoExpireDays() {
		return this.autoExpireDays;
	}

	public void setAutoExpireDays(String autoExpireDays) {
		this.autoExpireDays = autoExpireDays;
	}

	public String getCurrencyCode() {
		return this.currencyCode;
	}

	public void setCurrencyCode(String currencyCode) {
		this.currencyCode = currencyCode;
	}

	public String getPreferredDateFormat() {
		return this.preferredDateFormat;
	}

	public void setPreferredDateFormat(String preferredDateFormat) {
		this.preferredDateFormat = preferredDateFormat;
	}

	public String getUomCode() {
		return this.uomCode;
	}

	public void setUomCode(String uomCode) {
		this.uomCode = uomCode;
	}

	public String getTimeZoneId() {
		return this.timeZoneId;
	}

	public void setTimeZoneId(String timeZoneId) {
		this.timeZoneId = timeZoneId;
	}

	public List getRoleList() {
		return this.roleList;
	}

	public void setRoleList(List roleList) {
		this.roleList = roleList;
	}

	public String getProcess() {
		return (this.process);
	}

	public void setProcess(String process) {
		this.process = process;
	}

	public String getSubProcess() {
		return StringEscapeUtils.escapeHtml(subProcess);
	}

	public void setSubProcess(String subProcess) {
		this.subProcess = subProcess;
	}

	public String getOrgId() {
		return (this.orgId);
	}

	public void setOrgId(String orgId) {
		this.orgId = orgId;
	}

	public String getSystemUserId() {
		return (this.systemUserId);
	}

	public void setSystemUserId(String systemUserId) {
		this.systemUserId = systemUserId;
	}

	/**
	 * This method resets all bean properties to their default state. It is
	 * called before the properties are repopulated by the Action Class.
	 * 
	 * @param mapping
	 *            The ActionMapping used to select this instance
	 * @param request
	 *            The HTTP request we are processing
	 * 
	 */
//	public void reset(ActionMapping mapping, javax.servlet.http.HttpServletRequest request) {
//
//		super.reset(mapping, request);
//		firstName = null;
//		lastName = null;
//		userId = null;
//		newPassword = null;
//		confirmPassword = null;
//		orgName = null;
//		passwordExpirationDate = null;
//		active = null;
//		passwordAutoExpire = "0";
//		autoExpireDays = null;
//		currencyCode = null;
//		preferredDateFormat = null;
//		uomCode = null;
//		timeZoneId = null;
//		roleList = null;
//		process = null;
//		subProcess = null;
//		orgId = null;
//		systemUserId = null;
//		usersDomainName = null;
//		passwordReset = "OFF";
//		newDomainButton = "OFF";
//		sendEmail = "OFF";
//		createTimestamp = null;
//		lastUpdateTimestamp = null;
//		createUserId = null;
//		lastUpdateUserId = null;
//	}

	private ActionErrors addError(ActionErrors errors, String text) {
		errors.add("error.filecontent", new ActionMessage("error.file.content", text));
		return errors;
	}

	/**
	 * Validates the user input...had to home roll.
	 */
	public ActionErrors validateForm(String process) {
		ActionErrors errors = new ActionErrors();

		if (process.equalsIgnoreCase("userAdd") || process.equalsIgnoreCase("userEdit")) {
			
			if (orgId == null || Long.parseLong(orgId) < 1) {
				errors = addError(errors, "Please use the finder to lookup a profile last name");
			}
			else {
				OrghierarchyDAO orgDAO = new OrghierarchyDAO();
				if(orgDAO.isOrgInActive(Long.parseLong(orgId)))
					errors = addError(errors, "Profile is not ACTIVE.  Please use the finder to lookup a active profile last name");
			}

			if (userId == null || userId.equalsIgnoreCase("")) {
				errors = addError(errors, "Login is required");
			} 
                        /* ***
                        else {
				if(FasEventUtil.isBadUserId(userId))
					errors = addError(errors, "UserId can only be letters and numbers.  No special characters");
			}
                        *** */
			
			if (lastName == null || lastName.equalsIgnoreCase("")) {
				errors = addError(errors, "Last Name lookup is required");
			}
			if (systemRoleCode == null || systemRoleCode.equalsIgnoreCase("")) {
				errors = addError(errors, "User Role must be selected");
			}
			// domain validation
			if (newDomainButton.equalsIgnoreCase("ON")) {
				if (usersDomainName == null || usersDomainName.equalsIgnoreCase("")) {
					errors = addError(errors, "Domain/Company must be entered");
				}
				if(FasEventUtil.isBadDomainName(usersDomainName)) {
					errors = addError(errors, "Domain/company should only be letters.  No numbers or special characters");
				}
			} else if (newDomainButton.equalsIgnoreCase("OFF")) {
				if (selectedDomainName == null || selectedDomainName.equalsIgnoreCase("")) {
					errors = addError(errors, "Domain/Company must be selected");
				}
			} else {
				errors = addError(errors, "New Domain Button value corrupt");
			}

			// password validation on user creation and password reset
			if (process.equalsIgnoreCase("userAdd") || passwordReset.equalsIgnoreCase("ON")) {
				
				PasswordStatus passStatus = PasswordUtils.checkPasswords(newPassword, "", confirmPassword, 0L);
				if(!passStatus.complexityAndConfirmTrue()) {
					logger.debug("Password did not pass complexity and/or confirm password did not match.");
					passwordReset = "OFF";
					errors = addError(errors, "Password requirements were not met.");
				}
			}
			
		}

		return errors;
	}

	/**
	 * @return invokedFrom
	 */
	public String getInvokedFrom() {
		return invokedFrom;
	}

	/**
	 * @param invokedFrom
	 */
	public void setInvokedFrom(String invokedFrom) {
		this.invokedFrom = invokedFrom;
	}

	/**
	 * @return
	 */
	public long getUserSystemRoleId() {
		return userSystemRoleId;
	}

	/**
	 * @param userSystemRoleId
	 */
	public void setUserSystemRoleId(long userSystemRoleId) {
		this.userSystemRoleId = userSystemRoleId;
	}

}
