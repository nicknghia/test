/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/event/form/EventForm.java,v 1.1.10.39 2010/08/30 15:56:49 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: EventForm.java,v $
 *  Revision 1.1.10.39  2010/08/30 15:56:49  mechevarria
 *  more support for autocomplete
 *
 *  Revision 1.1.10.38  2010/08/30 00:57:37  mechevarria
 *  add carrier fieldsw
 *
 *  Revision 1.1.10.37  2010/08/29 23:18:19  mechevarria
 *  changes for autocomplete pulldown
 *
 *  Revision 1.1.10.36  2010/08/25 15:56:57  mechevarria
 *  null safe get
 *
 *  Revision 1.1.10.35  2010/08/22 23:08:44  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.1.10.34  2010/05/27 13:37:12  jhansford
 *  Changed a few 0.0s to 0
 *
 *  Revision 1.1.10.33  2010/04/18 21:01:01  mechevarria
 *  updates for status change buttons
 *
 *  Revision 1.1.10.32  2010/04/14 19:44:25  jhansford
 *  Made adjustments for 75% level, and alt category for IACs
 *
 *  Revision 1.1.10.31  2010/03/19 19:51:59  mechevarria
 *  placeholder for extra admin actions
 *
 *  Revision 1.1.10.30  2010/02/09 20:09:42  mechevarria
 *  int inb. support
 *
 *  Revision 1.1.10.29  2010/01/28 01:52:38  mechevarria
 *  uom update
 *
 *  Revision 1.1.10.28  2010/01/26 22:35:26  mechevarria
 *  tweaked uom changes
 *
 *  Revision 1.1.10.27  2010/01/25 21:17:02  mechevarria
 *  add uom fields to form
 *
 *  Revision 1.1.10.26  2009/10/23 14:07:44  mechevarria
 *  add timestamps to the form
 *
 *  Revision 1.1.10.25  2009/10/22 20:10:51  mechevarria
 *  add create and edit user
 *
 *  Revision 1.1.10.24  2009/10/21 15:27:23  mechevarria
 *  add pick list for certnums
 *
 *  Revision 1.1.10.23  2009/09/22 17:29:40  jhansford
 *  Added a few zeros to the reset function
 *
 *  Revision 1.1.10.22  2009/09/14 21:17:43  jhansford
 *  no message
 *
 *  Revision 1.1.10.21  2009/09/09 13:45:27  jhansford
 *  UAT changes
 *
 *  Revision 1.1.10.20  2009/09/02 19:34:48  jhansford
 *  Changes for UAT on 9/3/2009
 *
 *  Revision 1.1.10.19  2009/08/28 18:18:12  mechevarria
 *  additional validation and tracking updates
 *
 *  Revision 1.1.10.18  2009/05/01 17:22:46  mechevarria
 *  fixes for new air carrier sheet
 *
 *  Revision 1.1.10.17  2009/04/14 18:33:59  jhansford
 *  Added False Alarm field to web form and file upload
 *
 *  Revision 1.1.10.16  2009/03/24 16:40:16  mechevarria
 *  add hour and minute fields
 *
 *  Revision 1.1.10.15  2009/03/11 20:43:22  mechevarria
 *  set defaults
 *
 *  Revision 1.1.10.14  2009/03/09 14:05:17  jhansford
 *  STD can COC Jsp are added
 *
 *  Revision 1.1.10.13  2009/03/05 16:56:06  mechevarria
 *  added iacsp attributes
 *
 *  Revision 1.1.10.12  2009/02/12 21:14:51  mechevarria
 *  updates to support excel uploading
 *
 *  Revision 1.1.10.11  2009/02/10 21:51:58  mechevarria
 *  dev update
 *
 *  Revision 1.1.10.10  2009/02/10 14:38:30  mechevarria
 *  dev updates
 *
 *  Revision 1.1.10.9  2009/02/09 21:08:08  mechevarria
 *  development stop
 *
 *  Revision 1.1.10.8  2009/02/09 18:54:00  mechevarria
 *  fix getter setter typo
 *
 *  Revision 1.1.10.7  2009/02/09 18:45:41  mechevarria
 *  proper names for carrier and airport id
 *
 *  Revision 1.1.10.6  2009/02/08 23:12:11  mechevarria
 *  development commit.  incomplete
 *
 *  Revision 1.1.10.5  2009/01/30 15:35:36  mechevarria
 *  remove old fas demo fields
 *
 *  Revision 1.1.10.4  2009/01/23 15:10:35  mechevarria
 *  updated code to be compatible with struts 1.3.10
 *
 *  Revision 1.1.10.3  2008/12/18 20:29:51  mechevarria
 *  additional updates for the eventhomepage and industry reporting modifications
 *
 *  Revision 1.1.10.2  2008/06/18 13:44:32  mechevarria
 *  updates from HEAD to fix security devices and complete new event types of SCR and COC
 *
 *  Revision 1.1.10.1  2008/06/09 16:32:02  mechevarria
 *  arraylist to list fixes
 *
 *  Revision 1.1  2004/09/15 13:36:28  asingh
 *  2.6 Baseline
 *
 * 
 */

package crt.com.freightdesk.fdfolioweb.event.form;

//import org.apache.struts.action.ActionMapping;

import com.freightdesk.fdfolio.common.BasicButtonsForm;

/**
 * @author Mike Echevarria
 *
 */
public class EventForm extends BasicButtonsForm {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String eventId;
	private String shipmentId;
	private String legId;
	private String legcontainerId;
	private String packageId;

	private String eventTypeCode;

	private String version;
	private String remarks;

	private String eventCategoryCode;

	/* Evnt Date,Time */
	private String eventDateTime;
	private String eventEndDateTime;
	private String selectedEventDateTimeZone;

	// selected weightUOM
	private String grossWeightUOM;

	// EventStop
	private String[] eventStopList;

	private int index;

	// variable used to store the current operation type
	private String hdnProcess;
	private String hdnSubProcess;
	private String invokedFrom;

	// Added for TSA FAS
	private String createDomainUser;
	private String lastUpdateDomainUser;
	private String createTimeStamp;
	private String lastUpdateTimeStamp;
	private String carrierOrgId;
	private String airportOrgId;
	private String airportJsArray;
	private String carrierJsArray;
	private String airportName;
	private String carrierName;
	private String certNum;
	private String certNumJsArray;
	// reporting metrics
	private String totalWeight;
	private String totalCount;
	private String partScreenWgt;
	private String partScreenAwb;
	private String screenWeight;
	private String screenAwb;
	private String receivedWeight;
	private String weightAlt;
	private String countAlt;
    private String totalScreened;
    
    private String companyName;
    
    // administrative buttons
    private String lockBtn;
    private String unlockBtn;
    private String lateBtn;
    private String notLateBtn;
    // to display administrative buttons
    private String showLockBtn;
    private String showUnlockBtn;
    private String showLateBtn;
    private String showNotLateBtn; 
    
    private String flagLate;
    private String flagRemove;
    private String flagUnlock;
    private String flagScreen;
    private String flagVarW;
    private String flagVarA;
    // End of new variables
   
	private String usLocationTotalMAWBElementTip;
	private String usLocationTotalWeightElementTip;
	private String usLocationScreenedMAWBElementTip;
	private String usLocationScreenedWeightElementTip;
	private String usLocationAlternateMAWBElementTip;
	private String usLocationAlternateWeightElementTip;
	private String usLocationOGSScreenedMAWBElementTip;
	private String usLocationOGSScreenedWeightElementTip;
	private String nonUSLocationTotalWeightElementTip;
	private String nonUSLocationScreenedWeightElementTip;
	private String nonUSLocationAlternateWeightElementTip;
	private String nonUSLocationOGSScreenedWeightElementTip;
	private String iacTotalMAWBElementTip;
	private String iacTotalWeightElementTip;
	private String iacScreenedMAWBElementTip;
	private String iacScreenedWeightElementTip;
	private String iacAlternateMAWBElementTip;
	private String iacAlternateWeightElementTip;
	private String iacToalWeightReceivedElementTip;	
	private String shipperTotalScreenedHAWBElementTip;
	private String shipperTotalScreenedWeightElementTip;
	private String icsfTotalScreenedHAWBElementTip;
	private String icsfTotalScreenedWeightElementTip;
	
    public String getCertNumJsArray() {
		return certNumJsArray;
	}

	public String getFlagRemove() {
		if(flagRemove == null)
			return "";
		else
			return flagRemove;
	}

	public void setFlagRemove(String flagRemove) {
		this.flagRemove = flagRemove;
	}

	public String getFlagVarW() {
		if(flagVarW == null)
			return "";
		else
			return flagVarW;
	}

	public void setFlagVarW(String flagVarW) {
		this.flagVarW = flagVarW;
	}

	public String getFlagVarA() {
		if(flagVarA == null)
			return "";
		else
			return flagVarA;
	}

	public void setFlagVarA(String flagVarA) {
		this.flagVarA = flagVarA;
	}

	public String getFlagUnlock() {
		if(flagUnlock == null)
			return "";
		else
			return flagUnlock;
	}

	public void setFlagUnlock(String flagUnlock) {
		this.flagUnlock = flagUnlock;
	}

	public String getFlagScreen() {
		return flagScreen;
	}

	public void setFlagScreen(String flagScreen) {
		this.flagScreen = flagScreen;
	}

	public void setCertNumJsArray(String certNumJsArray) {
		this.certNumJsArray = certNumJsArray;
	}

	public String getCarrierJsArray() {
		return carrierJsArray;
	}

	public void setCarrierJsArray(String carrierJsArray) {
		this.carrierJsArray = carrierJsArray;
	}

	public String getCarrierName() {
		return carrierName;
	}

	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}

	
    public String getAirportName() {
		return airportName;
	}

	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}
	
    public String getAirportJsArray() {
		return airportJsArray;
	}

	public String getReceivedWeight() {
		return receivedWeight;
	}

	public void setReceivedWeight(String receivedWeight) {
		this.receivedWeight = receivedWeight;
	}

	public void setAirportJsArray(String airportJsArray) {
		this.airportJsArray = airportJsArray;
	}
    
    
	public String getLockBtn() {
		return lockBtn;
	}

	public String getShowLockBtn() {
		return showLockBtn;
	}

	public void setShowLockBtn(String showLockBtn) {
		this.showLockBtn = showLockBtn;
	}

	public String getShowUnlockBtn() {
		return showUnlockBtn;
	}

	public void setShowUnlockBtn(String showUnlockBtn) {
		this.showUnlockBtn = showUnlockBtn;
	}

	public String getShowLateBtn() {
		return showLateBtn;
	}

	public void setShowLateBtn(String showLateBtn) {
		this.showLateBtn = showLateBtn;
	}

	public String getShowNotLateBtn() {
		return showNotLateBtn;
	}

	public void setShowNotLateBtn(String showNotLateBtn) {
		this.showNotLateBtn = showNotLateBtn;
	}

	public void setLockBtn(String lockBtn) {
		this.lockBtn = lockBtn;
	}

	public String getUnlockBtn() {
		return unlockBtn;
	}

	public void setUnlockBtn(String unlockBtn) {
		this.unlockBtn = unlockBtn;
	}

	public String getLateBtn() {
		return lateBtn;
	}

	public void setLateBtn(String lateBtn) {
		this.lateBtn = lateBtn;
	}

	public String getNotLateBtn() {
		return notLateBtn;
	}

	public void setNotLateBtn(String notLateBtn) {
		this.notLateBtn = notLateBtn;
	}

	public String getCreateTimeStamp() {
		return createTimeStamp;
	}

	public void setCreateTimeStamp(String createTimeStamp) {
		this.createTimeStamp = createTimeStamp;
	}

	public String getLastUpdateTimeStamp() {
		return lastUpdateTimeStamp;
	}

	public void setLastUpdateTimeStamp(String lastUpdateTimeStamp) {
		this.lastUpdateTimeStamp = lastUpdateTimeStamp;
	}

	public String getCreateDomainUser() {
		return createDomainUser;
	}

	public void setCreateDomainUser(String createDomainUser) {
		this.createDomainUser = createDomainUser;
	}

	public String getLastUpdateDomainUser() {
		return lastUpdateDomainUser;
	}

	public void setLastUpdateDomainUser(String lastUpdateDomainUser) {
		this.lastUpdateDomainUser = lastUpdateDomainUser;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getFlagLate() {
		return flagLate;
	}

	public void setFlagLate(String flag) {
		this.flagLate = flag;
	}

	public String getWeightAlt() {
		return weightAlt;
	}

	public void setWeightAlt(String weightAlt) {
		this.weightAlt = weightAlt;
	}

	public String getCountAlt() {
		return countAlt;
	}

	public void setCountAlt(String countAlt) {
		this.countAlt = countAlt;
	}

	public String getCertNum() {
		return certNum;
	}

	public void setCertNum(String certnum) {
		this.certNum = certnum;
	}
	
	public String getTotalWeight() {
		return totalWeight;
	}
	public void setTotalWeight(String totalWeight) {
		this.totalWeight = totalWeight;
	}


	public String getTotalCount() {
			return totalCount;
	}


	public void setTotalCount(String totalCount) {
		this.totalCount = totalCount;
	}


	public String getPartScreenWgt() {
		return partScreenWgt;
	}


	public void setPartScreenWgt(String weight50p) {
		this.partScreenWgt = weight50p;
	}


	public String getPartScreenAwb() {
		return partScreenAwb;
	}


	public void setPartScreenAwb(String count50p) {
		this.partScreenAwb = count50p;
	}

	public String getScreenWeight() {
		return screenWeight;
	}

	public void setScreenWeight(String screenWeight) {
		this.screenWeight = screenWeight;
	}

	public String getEventEndDateTime() {
		return eventEndDateTime;
	}

	public void setEventEndDateTime(String eventEndDateTime) {
		this.eventEndDateTime = eventEndDateTime;
	}

	public String getEventId() {
		return eventId;
	}

	public void setEventId(String eventId) {
		if (eventId != null && !"".equals(eventId))
			this.eventId = eventId;
	}

	public String getShipmentId() {
		return shipmentId;
	}

	public void setShipmentId(String shipmentId) {

		if (shipmentId != null && !"".equals(shipmentId))
			this.shipmentId = shipmentId;
	}

	public String getLegId() {
		return legId;
	}

	public void setLegId(String legId) {

		if (legId != null && !"".equals(legId))
			this.legId = legId;
	}

	public String getLegcontainerId() {
		return legcontainerId;
	}

	public void setLegcontainerId(String legcontainerId) {

		if (legcontainerId != null && !"".equals(legcontainerId))
			this.legcontainerId = legcontainerId;
	}

	public String getPackageId() {
		return packageId;
	}

	public void setPackageId(String packageId) {

		if (packageId != null && !"".equals(packageId))
			this.packageId = packageId;
	}

	public String getEventTypeCode() {
		return eventTypeCode;
	}

	public void setEventTypeCode(String eventTypeCode) {
		this.eventTypeCode = eventTypeCode;
	}
	public String getVersion() {
		return version;
	}

	public void setVersion(String version ) {
		this.version = version;
	}

	public String getEventCategoryCode() {
		return eventCategoryCode;
	}

	public void setEventCategoryCode(String eventCategoryCode) {
		this.eventCategoryCode = eventCategoryCode;
	}

	public String getRemarks() {
		if (remarks == null)
			return "";
		return remarks.toUpperCase();
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getEventDateTime() {
		return eventDateTime;
	}

	public void setEventDateTime(String eventDate) {
		this.eventDateTime = eventDate;
	}

	public String getGrossWeightUOM() {
		return grossWeightUOM;
	}

	public void setGrossWeightUOM(String grossWeightUOM) {
		this.grossWeightUOM = grossWeightUOM;
	}

	public void setEventStopList(String[] eventStopList) {
		this.eventStopList = eventStopList;
	}

	public String[] getEventStopList() {
		return eventStopList;
	}

	public void setIndex(int index) {
		this.index = index;
	}

	public int getIndex() {
		return index;
	}

	public void setHdnProcess(String hdnProcess) {
		this.hdnProcess = hdnProcess;
	}

	public String getHdnProcess() {
		return hdnProcess;
	}

	/**
	 * This method resets all bean properties to their default state. It is
	 * called before the properties are repopulated by the Action Class.
	 * 
	 * @param mapping
	 *            The ActionMapping used to select this instance
	 * @param request
	 *            The HTTP request we are processing
	 * 
	 */
//	public void reset(ActionMapping mapping, javax.servlet.http.HttpServletRequest request) {
//
//		super.reset(mapping, request);
//		eventId = null;
//		shipmentId = null;
//		legId = null;
//		legcontainerId = null;
//		packageId = null;
//		eventTypeCode = null;
//		version = null;
//		remarks = null;
//		eventCategoryCode = null;
//		eventDateTime = null;
//		grossWeightUOM = null;
//		eventStopList = null;
//		index = 0;
//		hdnProcess = null;
//		hdnSubProcess = null;
//		// for TSA FAS
//		airportOrgId = null;
//		carrierOrgId = null;
//		totalWeight = null;
//		totalCount = null;
//		partScreenWgt = null;
//		partScreenAwb = null;
//		screenWeight = null;
//		screenAwb = null;
//		eventEndDateTime = null;
//		certNum = null;
//		receivedWeight = null;
//		weightAlt = null;
//		countAlt = null;
//		createDomainUser = "";
//		lastUpdateDomainUser = "";
//		
//		showLockBtn = "n";
//	    showUnlockBtn = "n";
//	    showLateBtn = "n";
//	    showNotLateBtn = "n";
//	    flagRemove = "";
//	}

	/**
	 * @return
	 */
	public String getHdnSubProcess() {
		return hdnSubProcess;
	}

	/**
	 * @param hdnSubProcess
	 */
	public void setHdnSubProcess(String hdnSubProcess) {
		this.hdnSubProcess = hdnSubProcess;
	}

	/**
	 * @return
	 */
	public String getInvokedFrom() {
		return invokedFrom;
	}

	/**
	 * @param invokedFrom
	 */
	public void setInvokedFrom(String invokedFrom) {
		this.invokedFrom = invokedFrom;
	}

	/**
	 * @return selectedEventDateTimeZone
	 */
	public String getSelectedEventDateTimeZone() {
		return selectedEventDateTimeZone;
	}

	/**
	 * @param argSelectedEventDateTimeZone
	 */
	public void setSelectedEventDateTimeZone(String argSelectedEventDateTimeZone) {
		selectedEventDateTimeZone = argSelectedEventDateTimeZone;
	}

	public String getCarrierOrgId() {
		return carrierOrgId;
	}

	public String getScreenAwb() {
		return screenAwb;
	}

	public void setScreenAwb(String screenAwb) {
		this.screenAwb = screenAwb;
	}

	public void setCarrierOrgId(String carrierOrgId) {
		this.carrierOrgId = carrierOrgId;
	}

	public String getAirportOrgId() {
		return airportOrgId;
	}

	public void setAirportOrgId(String airportOrgId) {
		this.airportOrgId = airportOrgId;
	}

    public String getTotalScreened() {
        return totalScreened;
    }

    public void setTotalScreened(String totalScreened) {
        this.totalScreened = totalScreened;
    }
    
	/**
	 * @return the usLocationTotalMAWBElementTip
	 */
	public String getUsLocationTotalMAWBElementTip() {
		return usLocationTotalMAWBElementTip;
	}

	/**
	 * @param usLocationTotalMAWBElementTip the usLocationTotalMAWBElementTip to set
	 */
	public void setUsLocationTotalMAWBElementTip(
			String usLocationTotalMAWBElementTip) {
		this.usLocationTotalMAWBElementTip = usLocationTotalMAWBElementTip;
	}

	/**
	 * @return the usLocationTotalWeightElementTip
	 */
	public String getUsLocationTotalWeightElementTip() {
		return usLocationTotalWeightElementTip;
	}

	/**
	 * @param usLocationTotalWeightElementTip the usLocationTotalWeightElementTip to set
	 */
	public void setUsLocationTotalWeightElementTip(
			String usLocationTotalWeightElementTip) {
		this.usLocationTotalWeightElementTip = usLocationTotalWeightElementTip;
	}

	/**
	 * @return the usLocationScreenedMAWBElementTip
	 */
	public String getUsLocationScreenedMAWBElementTip() {
		return usLocationScreenedMAWBElementTip;
	}

	/**
	 * @param usLocationScreenedMAWBElementTip the usLocationScreenedMAWBElementTip to set
	 */
	public void setUsLocationScreenedMAWBElementTip(
			String usLocationScreenedMAWBElementTip) {
		this.usLocationScreenedMAWBElementTip = usLocationScreenedMAWBElementTip;
	}

	/**
	 * @return the usLocationScreenedWeightElementTip
	 */
	public String getUsLocationScreenedWeightElementTip() {
		return usLocationScreenedWeightElementTip;
	}

	/**
	 * @param usLocationScreenedWeightElementTip the usLocationScreenedWeightElementTip to set
	 */
	public void setUsLocationScreenedWeightElementTip(
			String usLocationScreenedWeightElementTip) {
		this.usLocationScreenedWeightElementTip = usLocationScreenedWeightElementTip;
	}

	/**
	 * @return the usLocationAlternateMAWBElementTip
	 */
	public String getUsLocationAlternateMAWBElementTip() {
		return usLocationAlternateMAWBElementTip;
	}

	/**
	 * @param usLocationAlternateMAWBElementTip the usLocationAlternateMAWBElementTip to set
	 */
	public void setUsLocationAlternateMAWBElementTip(
			String usLocationAlternateMAWBElementTip) {
		this.usLocationAlternateMAWBElementTip = usLocationAlternateMAWBElementTip;
	}

	/**
	 * @return the usLocationAlternateWeightElementTip
	 */
	public String getUsLocationAlternateWeightElementTip() {
		return usLocationAlternateWeightElementTip;
	}

	/**
	 * @param usLocationAlternateWeightElementTip the usLocationAlternateWeightElementTip to set
	 */
	public void setUsLocationAlternateWeightElementTip(
			String usLocationAlternateWeightElementTip) {
		this.usLocationAlternateWeightElementTip = usLocationAlternateWeightElementTip;
	}

	/**
	 * @return the usLocationOGSScreenedMAWBElementTip
	 */
	public String getUsLocationOGSScreenedMAWBElementTip() {
		return usLocationOGSScreenedMAWBElementTip;
	}

	/**
	 * @param usLocationOGSScreenedMAWBElementTip the usLocationOGSScreenedMAWBElementTip to set
	 */
	public void setUsLocationOGSScreenedMAWBElementTip(
			String usLocationOGSScreenedMAWBElementTip) {
		this.usLocationOGSScreenedMAWBElementTip = usLocationOGSScreenedMAWBElementTip;
	}

	/**
	 * @return the usLocationOGSScreenedWeightElementTip
	 */
	public String getUsLocationOGSScreenedWeightElementTip() {
		return usLocationOGSScreenedWeightElementTip;
	}

	/**
	 * @param usLocationOGSScreenedWeightElementTip the usLocationOGSScreenedWeightElementTip to set
	 */
	public void setUsLocationOGSScreenedWeightElementTip(
			String usLocationOGSScreenedWeightElementTip) {
		this.usLocationOGSScreenedWeightElementTip = usLocationOGSScreenedWeightElementTip;
	}

	/**
	 * @return the nonUSLocationTotalWeightElementTip
	 */
	public String getNonUSLocationTotalWeightElementTip() {
		return nonUSLocationTotalWeightElementTip;
	}

	/**
	 * @param nonUSLocationTotalWeightElementTip the nonUSLocationTotalWeightElementTip to set
	 */
	public void setNonUSLocationTotalWeightElementTip(
			String nonUSLocationTotalWeightElementTip) {
		this.nonUSLocationTotalWeightElementTip = nonUSLocationTotalWeightElementTip;
	}

	/**
	 * @return the nonUSLocationScreenedWeightElementTip
	 */
	public String getNonUSLocationScreenedWeightElementTip() {
		return nonUSLocationScreenedWeightElementTip;
	}

	/**
	 * @param nonUSLocationScreenedWeightElementTip the nonUSLocationScreenedWeightElementTip to set
	 */
	public void setNonUSLocationScreenedWeightElementTip(
			String nonUSLocationScreenedWeightElementTip) {
		this.nonUSLocationScreenedWeightElementTip = nonUSLocationScreenedWeightElementTip;
	}

	/**
	 * @return the nonUSLocationAlternateWeightElementTip
	 */
	public String getNonUSLocationAlternateWeightElementTip() {
		return nonUSLocationAlternateWeightElementTip;
	}

	/**
	 * @param nonUSLocationAlternateWeightElementTip the nonUSLocationAlternateWeightElementTip to set
	 */
	public void setNonUSLocationAlternateWeightElementTip(
			String nonUSLocationAlternateWeightElementTip) {
		this.nonUSLocationAlternateWeightElementTip = nonUSLocationAlternateWeightElementTip;
	}

	/**
	 * @return the nonUSLocationOGSScreenedWeightElementTip
	 */
	public String getNonUSLocationOGSScreenedWeightElementTip() {
		return nonUSLocationOGSScreenedWeightElementTip;
	}

	/**
	 * @param nonUSLocationOGSScreenedWeightElementTip the nonUSLocationOGSScreenedWeightElementTip to set
	 */
	public void setNonUSLocationOGSScreenedWeightElementTip(
			String nonUSLocationOGSScreenedWeightElementTip) {
		this.nonUSLocationOGSScreenedWeightElementTip = nonUSLocationOGSScreenedWeightElementTip;
	}

	/**
	 * @return the iacTotalMAWBElementTip
	 */
	public String getIacTotalMAWBElementTip() {
		return iacTotalMAWBElementTip;
	}

	/**
	 * @param iacTotalMAWBElementTip the iacTotalMAWBElementTip to set
	 */
	public void setIacTotalMAWBElementTip(String iacTotalMAWBElementTip) {
		this.iacTotalMAWBElementTip = iacTotalMAWBElementTip;
	}

	/**
	 * @return the iacTotalWeightElementTip
	 */
	public String getIacTotalWeightElementTip() {
		return iacTotalWeightElementTip;
	}

	/**
	 * @param iacTotalWeightElementTip the iacTotalWeightElementTip to set
	 */
	public void setIacTotalWeightElementTip(String iacTotalWeightElementTip) {
		this.iacTotalWeightElementTip = iacTotalWeightElementTip;
	}

	/**
	 * @return the iacScreenedMAWBElementTip
	 */
	public String getIacScreenedMAWBElementTip() {
		return iacScreenedMAWBElementTip;
	}

	/**
	 * @param iacScreenedMAWBElementTip the iacScreenedMAWBElementTip to set
	 */
	public void setIacScreenedMAWBElementTip(String iacScreenedMAWBElementTip) {
		this.iacScreenedMAWBElementTip = iacScreenedMAWBElementTip;
	}

	/**
	 * @return the iacScreenedWeightElementTip
	 */
	public String getIacScreenedWeightElementTip() {
		return iacScreenedWeightElementTip;
	}

	/**
	 * @param iacScreenedWeightElementTip the iacScreenedWeightElementTip to set
	 */
	public void setIacScreenedWeightElementTip(String iacScreenedWeightElementTip) {
		this.iacScreenedWeightElementTip = iacScreenedWeightElementTip;
	}

	/**
	 * @return the iacAlternateMAWBElementTip
	 */
	public String getIacAlternateMAWBElementTip() {
		return iacAlternateMAWBElementTip;
	}

	/**
	 * @param iacAlternateMAWBElementTip the iacAlternateMAWBElementTip to set
	 */
	public void setIacAlternateMAWBElementTip(String iacAlternateMAWBElementTip) {
		this.iacAlternateMAWBElementTip = iacAlternateMAWBElementTip;
	}

	/**
	 * @return the iacAlternateWeightElementTip
	 */
	public String getIacAlternateWeightElementTip() {
		return iacAlternateWeightElementTip;
	}

	/**
	 * @param iacAlternateWeightElementTip the iacAlternateWeightElementTip to set
	 */
	public void setIacAlternateWeightElementTip(String iacAlternateWeightElementTip) {
		this.iacAlternateWeightElementTip = iacAlternateWeightElementTip;
	}

	/**
	 * @return the iacToalWeightReceivedElementTip
	 */
	public String getIacToalWeightReceivedElementTip() {
		return iacToalWeightReceivedElementTip;
	}

	/**
	 * @param iacToalWeightReceivedElementTip the iacToalWeightReceivedElementTip to set
	 */
	public void setIacToalWeightReceivedElementTip(
			String iacToalWeightReceivedElementTip) {
		this.iacToalWeightReceivedElementTip = iacToalWeightReceivedElementTip;
	}

	/**
	 * @return the shipperTotalScreenedHAWBElementTip
	 */
	public String getShipperTotalScreenedHAWBElementTip() {
		return shipperTotalScreenedHAWBElementTip;
	}

	/**
	 * @param shipperTotalScreenedHAWBElementTip the shipperTotalScreenedHAWBElementTip to set
	 */
	public void setShipperTotalScreenedHAWBElementTip(
			String shipperTotalScreenedHAWBElementTip) {
		this.shipperTotalScreenedHAWBElementTip = shipperTotalScreenedHAWBElementTip;
	}

	/**
	 * @return the shipperTotalScreenedWeightElementTip
	 */
	public String getShipperTotalScreenedWeightElementTip() {
		return shipperTotalScreenedWeightElementTip;
	}

	/**
	 * @param shipperTotalScreenedWeightElementTip the shipperTotalScreenedWeightElementTip to set
	 */
	public void setShipperTotalScreenedWeightElementTip(
			String shipperTotalScreenedWeightElementTip) {
		this.shipperTotalScreenedWeightElementTip = shipperTotalScreenedWeightElementTip;
	}

	/**
	 * @return the icsfTotalScreenedHAWBElementTip
	 */
	public String getIcsfTotalScreenedHAWBElementTip() {
		return icsfTotalScreenedHAWBElementTip;
	}

	/**
	 * @param icsfTotalScreenedHAWBElementTip the icsfTotalScreenedHAWBElementTip to set
	 */
	public void setIcsfTotalScreenedHAWBElementTip(
			String icsfTotalScreenedHAWBElementTip) {
		this.icsfTotalScreenedHAWBElementTip = icsfTotalScreenedHAWBElementTip;
	}

	/**
	 * @return the icsfTotalScreenedWeightElementTip
	 */
	public String getIcsfTotalScreenedWeightElementTip() {
		return icsfTotalScreenedWeightElementTip;
	}

	/**
	 * @param icsfTotalScreenedWeightElementTip the icsfTotalScreenedWeightElementTip to set
	 */
	public void setIcsfTotalScreenedWeightElementTip(
			String icsfTotalScreenedWeightElementTip) {
		this.icsfTotalScreenedWeightElementTip = icsfTotalScreenedWeightElementTip;
	}
	
}
