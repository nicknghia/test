package crt.com.freightdesk.fdfolio.dao;

import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import org.apache.log4j.Logger;

import crt.com.ntelx.awb.model.HAWB;
import com.freightdesk.fdcommons.Credentials;

import java.util.Collections;

public class HAWBDao
{
    protected Logger logger = Logger.getLogger( getClass() );
	
	private static Map<Long, HAWB> hawbMap = HAWBDaoListStub.getRandomHAWBMap();
	
	
	public HAWBDao()
	{
	
	}
	
	public void addAWB( HAWB hawb )
	{
		Set<Long> ids = hawbMap.keySet();
		
		Long maxID = (Long) Collections.max( ids );
		
		hawbMap.put( maxID.longValue() + 1, hawb );
	}
	
	public void updateAWB( HAWB hawb )
	{
		logger.debug( "GOT A: " + hawb.getHawbID() );
		Set<Long> keys = hawbMap.keySet();
		
		for ( Long l : keys )
		{
			logger.debug( "Key: " + l );
		}
		
		HAWB hawbOld= hawbMap.get( hawb.getHawbID() );
		if ( hawbOld == null )
		{
			logger.debug( "HAWB old is null" );
		}
		else
		{
			logger.debug( "RefNum: " + hawb.getHawbID() + " + " + hawbOld.getRefNum() );
		}
		
		hawbMap.put( hawb.getHawbID(), hawb );
	}
	
	
	public List<HAWB> retrieveForAWBHome( Credentials credentials, boolean loadAll, int offset, Timestamp startDate, Timestamp endDate, String searchText) 
	{
		List<HAWB> hawbList = new ArrayList<HAWB>();
		Object [] hawbArray = hawbMap.values().toArray(); 
		
		for ( int i = 0; i < 10; i++ )
		{
			hawbList.add( (HAWB) hawbArray[i] );
		}
		
		return hawbList;
	}
	
	
	public HAWB getAWBByID( long id )
	{
		return hawbMap.get( id );
	}
	
	
}
