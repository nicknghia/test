package crt.com.freightdesk.fdfolio.event.model;

import java.sql.Timestamp;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import org.hibernate.annotations.Cache;
import org.hibernate.annotations.CacheConcurrencyStrategy;

import com.freightdesk.fdcommons.BaseModel;
import com.freightdesk.fdcommons.FormatDate;
import crt.com.ntelx.nxcommons.NxUtils;

@Entity
@Table(name = "V_EVENTHOME")
@Cache(usage = CacheConcurrencyStrategy.READ_ONLY)
public class EventHomeModel extends BaseModel {
	private static final long serialVersionUID = 1L;
	private static String defaultFormat = "MM/dd/yyyy";

	@Id
	private long eventId;
	
	private String eventCategoryCode;
	private String eventCategoryName;
	private String eventTypeCode;
	private String eventTypeName;
	private Timestamp eventDateTime;
	private Timestamp eventEndDateTime;

	@Column(name="AIRPORTID")
	private Long airportOrgId;

	private String airportName;
	private String certNum;
	private String companyName;
	private String flagLate;
	private String flagUnlock;
	private String flagScreen;
	private String flagVarW;
	private String flagVarA;
        private String airportcc;
        private String carriercc;

	public EventHomeModel() {
	}

	public String getFlagVarW() {
		if(flagVarW == null)
			return "";
		else
			return flagVarW;
	}

	public void setFlagVarW(String flagVarW) {
		this.flagVarW = flagVarW;
	}

	public String getFlagVarA() {
		if(flagVarA == null)
			return "";
		else
			return flagVarA;
	}

	public void setFlagVarA(String flagVarA) {
		this.flagVarA = flagVarA;
	}

	public String getFlagScreen() {
		if(flagScreen == null)
			return "";
		else
			return flagScreen;
	}

	public void setFlagScreen(String flagScreen) {
		this.flagScreen = flagScreen;
	}

	public String getFlagUnlock() {
		if (flagUnlock == null)
			return "";
		else
			return flagUnlock;
	}

	public void setFlagUnlock(String flagUnlock) {
		this.flagUnlock = flagUnlock;
	}

	public String getFlagLate() {
		if (flagLate == null)
			return "";
		else
			return flagLate;
	}

	public void setFlag(String flagLate) {
		this.flagLate = flagLate;
	}

	public long getPrimaryKey() {
		return eventId;
	}

	public long getEventId() {
		return eventId;
	}

	public void setEventId(long eventId) {
		this.eventId = eventId;
	}

	public String getEventCategoryCode() {
		return eventCategoryCode;
	}

	public void setEventCategoryCode(String eventCategoryCode) {
		this.eventCategoryCode = eventCategoryCode;
	}

	public String getEventCategoryName() {
		return NxUtils.upperFirst(eventCategoryName);
	}

	public void setEventCategoryName(String eventCategoryName) {
		this.eventCategoryName = eventCategoryName;
	}

	public String getEventTypeCode() {
		return eventTypeCode;
	}

	public void setEventTypeCode(String eventTypeCode) {
		this.eventTypeCode = eventTypeCode;
	}

	public String getEventTypeName() {
		return NxUtils.upperFirst(eventTypeName);
	}

	public void setEventTypeName(String eventTypeName) {
		this.eventTypeName = eventTypeName;
	}

	public Timestamp getEventDateTime() {
		return eventDateTime;
	}

	public void setEventDateTime(Timestamp eventDateTime) {
		this.eventDateTime = eventDateTime;
	}

	public Timestamp getEventEndDateTime() {
		return eventEndDateTime;
	}

	public void setEventEndDateTime(Timestamp eventEndDateTime) {
		this.eventEndDateTime = eventEndDateTime;
	}

	public Long getAirportOrgId() {
		return airportOrgId;
	}

	public void setAirportOrgId(Long airportOrgId) {
		this.airportOrgId = airportOrgId;
	}

	public String getAirportName() {
		return NxUtils.upperFirst(airportName);
	}

	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}

	public String getCertNum() {
		return certNum;
	}

	public void setCertNum(String certNum) {
		this.certNum = certNum;
	}

	public String getCompanyName() {
		return NxUtils.upperFirst(companyName);
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

    public String getAirportcc() {
        return airportcc;
    }

    public void setAirportcc(String airportcc) {
        this.airportcc = airportcc;
    }

    public String getCarriercc() {
        return carriercc;
    }

    public void setCarriercc(String carriercc) {
        this.carriercc = carriercc;
    }
        
        

	public String getFormatEventDateTime() {
		String inFormat = FormatDate.format(eventDateTime, defaultFormat);
		return inFormat;
	}

	public String getFormatEventEndDateTime() {
		String inFormat = FormatDate.format(eventEndDateTime, defaultFormat);
		return inFormat;
	}
}
