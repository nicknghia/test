package crt.com.freightdesk.fdfolio.dao;

import org.apache.log4j.Logger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.ConnectionUtil;
import crt.com.freightdesk.fdfolio.setup.model.SystemMessageModel;

public class SystemMessageDAO extends BaseDao {

	protected final Logger logger = Logger.getLogger("SystemMessageDAO");
	
	public SystemMessageModel retrieve() {
		logger.debug("retrieving");
		String query = "SELECT MESSAGETEXT,FAQTXT,STATUS,CREATEUSERID,LASTUPDATEUSERID,CREATETIMESTAMP,LASTUPDATETIMESTAMP,DOMAINNAME FROM SYSTEMMESSAGE";
		SystemMessageModel model = new SystemMessageModel();

		Connection connection = null;
		PreparedStatement pStmt = null;
		ResultSet rs = null;

		try {
			connection = ConnectionUtil.getConnection();
			pStmt = connection.prepareStatement(query);
			rs = pStmt.executeQuery();

			if (rs.next()) {
				model.setMessageText(rs.getString("MESSAGETEXT"));
				model.setFaqTxt(rs.getString("FAQTXT"));
				model.setStatus(rs.getString("STATUS"));
				model.setCreateUserId(rs.getString("CREATEUSERID"));
				model.setLastUpdateUserId(rs.getString("LASTUPDATEUSERID"));
				model.setCreateTimestamp(rs.getTimestamp("CREATETIMESTAMP"));
				model.setLastUpdateTimestamp(rs.getTimestamp("LASTUPDATETIMESTAMP"));
				model.setDomainName(rs.getString("DOMAINNAME"));
			} else {
				logger.warn("Failed to retrieve system message from db.");
			}

			rs.close();
			pStmt.close();
			connection.close();

		} catch (Exception ex) {
			//logger.error("Failed to load system message from database.");
			//ex.printStackTrace();
			logger.error("Exception - Failed to load system message from database: " + ex.getMessage());
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}
		return model;
	}

	public boolean update(SystemMessageModel model) {
		logger.debug("updating");
		// 													 1		  2		   3			  4				     5				   6 			         7            8
		String query = "UPDATE SYSTEMMESSAGE SET MESSAGETEXT=?,FAQTXT=?,STATUS=?,CREATEUSERID=?,LASTUPDATEUSERID=?,CREATETIMESTAMP=?,LASTUPDATETIMESTAMP=?,DOMAINNAME=?";

		Connection connection = null;
		PreparedStatement pStmt = null;

		try {
			connection = ConnectionUtil.getConnection();
			pStmt = connection.prepareStatement(query);
			
			pStmt.setString(1,model.getMessageText());
			pStmt.setString(2,model.getFaqTxt());
			pStmt.setString(3,model.getStatus());
			pStmt.setString(4,model.getCreateUserId());
			pStmt.setString(5,model.getLastUpdateUserId());
			pStmt.setTimestamp(6,model.getCreateTimestamp());
			pStmt.setTimestamp(7,model.getLastUpdateTimestamp());
			pStmt.setString(8,model.getDomainName());
			
			int numUpdated = pStmt.executeUpdate();
			logger.debug(numUpdated + " rows updated");

			pStmt.close();
			connection.close();
			
			return true;

		} catch (Exception ex) {
			//logger.error("Failed to update system message in database.");
			//ex.printStackTrace();
			logger.error("Exception - Failed to update system message in database: " + ex.getMessage());
			
			return false;
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, null);
		}
	}

}
