/**
 *
 * Copyright (c) NTELX All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the license
 * agreement you entered into with NTELX.
 *
 *
 * $Header:
 * /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/setup/action/Attic/PasswordChangeAction.java,v
 * 1.11.2.10 2010/11/04 19:02:52 mechevarria Exp $
 *
 * Modification History: $Log: PasswordChangeAction.java,v $ Revision 1.11.2.10
 * 2010/11/04 19:02:52 mechevarria remove fdfolio title from loggin
 *
 * Revision 1.11.2.9 2010/08/22 23:08:38 mechevarria update with company name in
 * copyright
 *
 * Revision 1.11.2.8 2010/06/21 22:18:42 mechevarria rewrote to use
 * authentication utils and return actionmessages instead of chaining a series
 * of exceptions
 *
 * Revision 1.11.2.7 2010/03/15 14:45:11 mechevarria fix jdbc methods to use
 * bind vars
 *
 * Revision 1.11.2.6 2009/09/23 18:02:17 mechevarria import clean via eclipse
 *
 * Revision 1.11.2.5 2009/01/23 15:10:34 mechevarria updated code to be
 * compatible with struts 1.3.10
 *
 * Revision 1.11.2.4 2007/08/13 19:20:22 mechevarria added async logging to
 * password change action
 *
 * Revision 1.11.2.3 2007/06/01 16:12:25 mechevarria update action to show error
 * message when new password is in password history
 *
 * Revision 1.11.2.2 2007/03/28 20:25:13 mechevarria merged changes from head
 * branch to fix domain admin rights issue
 *
 * Revision 1.11.2.1 2007/03/23 14:34:22 mechevarria added warn level logging
 * messages for changes in user status, logging in and awb submission
 *
 * Revision 1.11 2007/01/12 11:59:12 atripathi user feedback messages added
 *
 * Revision 1.10 2006/12/11 19:59:16 ranand Handle the case where user change
 * the password when first time logged in
 *
 * Revision 1.9 2006/08/11 20:22:45 dkumar changes for common login
 * functionality in FDSuite
 *
 * Revision 1.8 2006/05/11 22:18:55 aarora Small change as the SessionKey class
 * has been added to com.freightdesk.fdfolio.commons
 *
 * Revision 1.7 2006/05/11 16:55:28 aarora Many changes as the SessionKey class
 * has been added to com.freightdesk.fdfolio.commons
 *
 * Revision 1.6 2006/04/12 23:44:31 aarora Removed extra code
 *
 * Revision 1.5 2006/03/28 21:22:59 aarora Repackaging of fdcommons
 *
 * Revision 1.4 2006/03/28 13:27:56 uvasundhara setActionMethod is called
 *
 * Revision 1.3 2006/03/24 14:52:11 uvasundhara setActionmessage is called
 *
 * Revision 1.2 2004/09/21 08:47:42 ranand package of Manager classes changed
 * from folioweb to folio
 *
 * Revision 1.1 2004/09/15 13:36:28 asingh 2.6 Baseline
 *
 *
 */
package crt.com.freightdesk.fdfolioweb.setup.action;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import crt.com.freightdesk.fdfolio.setup.UserSetupManager;
import crt.com.freightdesk.fdfolioweb.setup.PasswordStatus;

import com.freightdesk.fdcommons.ApplicationTabs;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.OperationInfo;

import crt.com.ntelx.nxcommons.PasswordUtils;

import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.StackManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;
import com.opensymphony.xwork2.ActionSupport;
import com.freightdesk.fdcommons.ActionMessage;
import com.freightdesk.fdcommons.ActionMessages;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import crt.com.freightdesk.fdfolio.setup.SystemMessageManager;

public class PasswordChangeAction extends ActionSupport implements ServletRequestAware {

    private static final long serialVersionUID = 1L;
    private String basicBtnClicked = "";
    private String oldPassword = "";
    private String newPassword = "";
    private String confirmPassword = "";
    private String process = "";
	private String processCancel = "";
    private String updateProcess = "";
    private String systemUserId = "";
    private String product = "";
    private String loginTimeRoleMsg = "";
    private String btnStr = "";
    private String isForwarded = "";
    private String messageKey = "";
    

    protected Logger logger = Logger.getLogger(getClass());
	

        HttpServletRequest request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
        SystemMessageManager messageManager = SystemMessageManager.getInstance();
        

    /**
     * an instance of UserSetupManager
     */
    protected UserSetupManager userSetupManager = new UserSetupManager();

    /**
     *
     */
    public PasswordChangeAction() {
        super();
    }

    public String respondBtnSave() throws Exception {

        return null;
    }
	
    public String respondBtnSaveAndNew() throws Exception {

        return null;
    }

    public String execute() throws Exception {

        logger.debug("entering PasswordChange action.");
        request = ServletActionContext.getRequest();
        session = request.getSession(false);
        store = SessionStore.getInstance(session);
        credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);

        // POAM HttpOnly Secure
        HttpServletResponse response = (HttpServletResponse)ServletActionContext.getResponse();
        String secure = "";
        if (request.isSecure())
        {
          secure = "; Secure";
        }
        response.setHeader("SET-COOKIE", "JSESSIONID=" + request.getSession().getId()
                         + "; Path=" + request.getContextPath() + "; HttpOnly" + secure);
        
		processCancel = getProcessCancel();
		
		if ("CANCEL".equalsIgnoreCase(processCancel)) {
			addActionMessage(getText("setup.operation.cancel"));
			loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);

            return "cancel";
        }
    
		if (null == oldPassword || oldPassword.isEmpty()) {
		    loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials) + "<br>" + IncludesUtil.getExpireMsg(credentials);
            return "display";
        }
		
        if (basicBtnClicked == "CANCEL") {
            return respondBtnCancel();
        } else {
            return respondBtnSaveAndReturn();
        }

    }

    public String respondBtnSaveAndReturn() throws Exception {

        request = ServletActionContext.getRequest();
        session = request.getSession(false);
        store = SessionStore.getInstance(session);
        credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);
        
        logger.debug("respondBtnSaveAndReturn : started .... ");
        setSystemUserId(String.valueOf(credentials.getSystemUserId()));
        
        String[] messageKeyObject = new String[5];
        
        AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
        AsyncProcessManager asyncManager = new AsyncProcessManager();


        PasswordStatus passStatus = PasswordUtils.checkPasswords(getNewPassword(), getOldPassword(), getConfirmPassword(), credentials.getSystemUserId());       

        if (!passStatus.allTrue()) {  
            logger.debug("Valdiation errors in change form.");
            
            addActionError(getText("setuphome.editdata.password.error"));
            reset();
            return "display";
        }

        asyncLogModel.init(credentials.getUserId(), credentials.getDomainName(), "PASSWORD CHANGE", "SECURITY", "In process password change.", credentials.getIpAddress());
        asyncLogModel = asyncManager.createAsyncProcessLog(asyncLogModel);

        // update the password history
        if (!PasswordUtils.updatePasswordHistory(Long.parseLong(getSystemUserId()), credentials.getDomainName(), credentials.getUserId())) {
            logger.error("Failed to update passwordhistory");
            asyncManager.logResult(asyncLogModel, false, "Failed to update password history in database.", "respondBtnSaveAndReturn");
            
            addActionError(getText("setuphome.editdata.history.error"));
            reset();
            return "display";
        }

        // update the password
        if (!PasswordUtils.updatePassword(getNewPassword(), Long.parseLong(getSystemUserId()), credentials.getUserId(), false)) {
            logger.error("Failed to update user password");
            asyncManager.logResult(asyncLogModel, false, "Failed to update user password in database.", "respondBtnSaveAndReturn");
            
            addActionError(getText("setuphome.editdata.update.error"));
            reset();
            return "display";
        }

        // Record successful password changes in the ASYNCPROCESSINGLOG table
        asyncManager.logResult(asyncLogModel, true, "Successful password change.", "respondBtnSaveAndReturn");

        // create the success message
        messageKey = "setuphome.password.changed";
        messageKeyObject[0] = messageKey;
        messageKeyObject[1] = "Password has been successfully updated.";
        logger.debug("UserAccess " + credentials.getDomainName() + "." + credentials.getUserId() + " Password changed");
        
        addActionMessage(getText("setuphome.password.changed"));
      		
        session = request.getSession(false);
        store = SessionStore.getInstance(session);
        store.put(SessionKey.PASSWORD_UPDATED, true);

        return getSuccessPath();
    }

    public String getSuccessPath() throws Exception {

        process = getUpdateProcess();
        logger.debug("Process before forward is " + process);

        if (process != null && process.equalsIgnoreCase("newLogin")) {
            return "display";
        } else {
            return "fasSetupHome";
        }
    }

    public String respondBtnCancel() throws Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);

	loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials) + "<br>" + IncludesUtil.getExpireMsg(credentials);
        
        addActionMessage(getText("setup.operation.cancel"));
        return "cancel";
    }

    public String respondNonBasicBtnClick() throws Exception {
        request = ServletActionContext.getRequest();
        session = request.getSession(false);
        store = SessionStore.getInstance(session);
        credentials = (Credentials) store.get(SessionKey.CREDENTIALS);

	loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials) + "<br>" + IncludesUtil.getExpireMsg(credentials);

        process = getProcess();
        logger.debug("process on entry is " + process);
        return displayPage();

    }

    private String getProcess() {
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        isForwarded = (String) sessionStore.get(SessionKey.IS_FORWARDED);

        if (isForwarded == null || "NO".equalsIgnoreCase(isForwarded)) {
            process = getUpdateProcess();
        } else {
            StackManager sm = (StackManager) (sessionStore.get(SessionKey.STACK));
            OperationInfo operationInfo = (OperationInfo) sm.currentEvent();
            logger.info("isForwarded: " + isForwarded);
            //request is coming from another action
            process = operationInfo.getAction();
            logger.debug("process from else shmpt " + process);
        }
        return process;
    }

    /**
     * Displays the record of the user.
     */
   
    public String displayPage() throws Exception {

        logger.debug("begin()");
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);

	loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials) + "<br>" + IncludesUtil.getExpireMsg(credentials);

        // sets the home tab
        store.put(SessionKey.CURRENT_TAB, ApplicationTabs.SETUP);
        
        setSystemUserId(String.valueOf(credentials.getSystemUserId()));

        return "display";
    }

    public void setActionMessage(HttpServletRequest request, String[] messageKeyObject) {
        int length = messageKeyObject.length;
        logger.debug("messageKeyObject.length = " + length);
        ActionMessage actionMessage = null;
        switch (length) {
            case 2:
                logger.debug("messagekeyvalues" + messageKeyObject[0]);
                actionMessage = new ActionMessage(messageKeyObject[0], (Object) messageKeyObject[1]);
                break;
            case 3:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2]);
                break;
            case 4:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3]);
                break;
            case 5:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3], messageKeyObject[4]);
                break;
            default:
                actionMessage = new ActionMessage(messageKeyObject[0]);
        }

        ActionMessages messages = new ActionMessages();
        messages.add(ActionMessages.GLOBAL_MESSAGE, actionMessage);

        logger.debug("message has been set on request");
    }

    public String getProcessCancel() {
	   return processCancel;
    }
    
    public void setProcessCancel(String processCancel) {
	   this.processCancel = processCancel;
    }
	
	public String getBtnStr() {
        return btnStr;
    }

    public void setBtnStr(String btnStr) {
        this.btnStr = btnStr;
    }

    public String getUpdateProcess() {
        return updateProcess;
    }

    public void setUpdateProcess(String updateProcess) {
        this.updateProcess = updateProcess;
    }

    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return request;
    }

    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public String getOldPassword() {
        return oldPassword;
    }

    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public void setSystemUserId(String systemUserId) {
        this.systemUserId = systemUserId;
    }

    public String getSystemUserId() {
        return systemUserId;
    }

    public String getProduct() {
        return product;
    }

    public void setProduct(String product) {
        this.product = product;
    }

    public void setProcess(String process) {
        this.process = process;
    }


    public String getMessageKey() {
        return messageKey;
    }

    public void setMessageKey(String messageKey) {
        this.messageKey = messageKey;
    }

    public HttpServletRequest getRequest() {
        return request;
    }

    public void setRequest(HttpServletRequest request) {
        this.request = request;
    }

    public String getBasicBtnClicked() {
        return basicBtnClicked;
    }

    public void setBasicBtnClicked(String basicBtnClicked) {
        this.basicBtnClicked = basicBtnClicked;
    }

    public void reset() {
        oldPassword = "";
        newPassword = "";
        confirmPassword = "";
    }
}
