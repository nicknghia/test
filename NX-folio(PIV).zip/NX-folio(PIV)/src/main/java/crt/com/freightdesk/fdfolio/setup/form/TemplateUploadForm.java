package crt.com.freightdesk.fdfolio.setup.form;

//import org.apache.struts.action.ActionForm;
//import org.apache.struts.upload.FormFile;

//public class TemplateUploadForm extends ActionForm {
public class TemplateUploadForm {

    /**
     *
     */
    private static final long serialVersionUID = 1L;
    private FormFile usFile;    
    private FormFile nonusFile;
    private FormFile iacFile;
    private FormFile icsfFile;
    private FormFile shipFile;
    private String maxRequestSize;
    private String btnUpLoad;
    private String btnCancel;
    private String usLastUpdatedBy;
    private String nonusLastUpdatedBy;
    private String iacLastUpdatedBy;
    private String icsfLastUpdatedBy;
    private String shipLastUpdatedBy;
    private String usLastUpdatedDate;
    private String nonusLastUpdatedDate;
    private String iacLastUpdatedDate;
    private String icsfLastUpdatedDate;
    private String shipLastUpdatedDate;
    
    public FormFile getUsFile() {
        return usFile;
    }

    public void setUsFile(FormFile usFile) {
        this.usFile = usFile;
    }

    public FormFile getNonusFile() {
        return nonusFile;
    }

    public void setNonusFile(FormFile nonusFile) {
        this.nonusFile = nonusFile;
    }

    public FormFile getIacFile() {
        return iacFile;
    }

    public void setIacFile(FormFile iacFile) {
        this.iacFile = iacFile;
    }

    public FormFile getIcsfFile() {
        return icsfFile;
    }

    public void setIcsfFile(FormFile icsfFile) {
        this.icsfFile = icsfFile;
    }

    public FormFile getShipFile() {
        return shipFile;
    }

    public void setShipFile(FormFile shipFile) {
        this.shipFile = shipFile;
    }

    public String getMaxRequestSize() {
        return maxRequestSize;
    }

    public void setMaxRequestSize(String maxRequestSize) {
        this.maxRequestSize = maxRequestSize;
    }

    public String getBtnUpLoad() {
        return btnUpLoad;
    }

    public void setBtnUpLoad(String btnUpLoad) {
        this.btnUpLoad = btnUpLoad;
    }

    public String getBtnCancel() {
        return btnCancel;
    }

    public void setBtnCancel(String btnCancel) {
        this.btnCancel = btnCancel;
    }
    
     public String getUsLastUpdatedBy() {
        return usLastUpdatedBy;
    }

    public void setUsLastUpdatedBy(String usLastUpdatedBy) {
        this.usLastUpdatedBy = usLastUpdatedBy;
    }

    public String getNonusLastUpdatedBy() {
        return nonusLastUpdatedBy;
    }

    public void setNonusLastUpdatedBy(String nonusLastUpdatedBy) {
        this.nonusLastUpdatedBy = nonusLastUpdatedBy;
    }

    public String getIacLastUpdatedBy() {
        return iacLastUpdatedBy;
    }

    public void setIacLastUpdatedBy(String iacLastUpdatedBy) {
        this.iacLastUpdatedBy = iacLastUpdatedBy;
    }

    public String getIcsfLastUpdatedBy() {
        return icsfLastUpdatedBy;
    }

    public void setIcsfLastUpdatedBy(String icsfLastUpdatedBy) {
        this.icsfLastUpdatedBy = icsfLastUpdatedBy;
    }

    public String getShipLastUpdatedBy() {
        return shipLastUpdatedBy;
    }

    public void setShipLastUpdatedBy(String shipLastUpdatedBy) {
        this.shipLastUpdatedBy = shipLastUpdatedBy;
    }

    public String getUsLastUpdatedDate() {
        return usLastUpdatedDate;
    }

    public void setUsLastUpdatedDate(String usLastUpdatedDate) {
        this.usLastUpdatedDate = usLastUpdatedDate;
    }

    public String getNonusLastUpdatedDate() {
        return nonusLastUpdatedDate;
    }

    public void setNonusLastUpdatedDate(String nonusLastUpdatedDate) {
        this.nonusLastUpdatedDate = nonusLastUpdatedDate;
    }

    public String getIacLastUpdatedDate() {
        return iacLastUpdatedDate;
    }

    public void setIacLastUpdatedDate(String iacLastUpdatedDate) {
        this.iacLastUpdatedDate = iacLastUpdatedDate;
    }

    public String getIcsfLastUpdatedDate() {
        return icsfLastUpdatedDate;
    }

    public void setIcsfLastUpdatedDate(String icsfLastUpdatedDate) {
        this.icsfLastUpdatedDate = icsfLastUpdatedDate;
    }

    public String getShipLastUpdatedDate() {
        return shipLastUpdatedDate;
    }

    public void setShipLastUpdatedDate(String shipLastUpdatedDate) {
        this.shipLastUpdatedDate = shipLastUpdatedDate;
    }

}
