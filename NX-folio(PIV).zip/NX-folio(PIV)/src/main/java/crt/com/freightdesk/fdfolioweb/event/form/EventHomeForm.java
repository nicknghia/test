package crt.com.freightdesk.fdfolioweb.event.form;

import java.util.List;

//import org.apache.struts.action.ActionForm;

import crt.com.freightdesk.fdfolio.event.model.EventHomeModel;

//public class EventHomeForm extends ActionForm {
public class EventHomeForm {

	private static final long serialVersionUID = 1L;
	private long eventId = 0L;
	private String action;
	private List<EventHomeModel> eventList;
	private int eventCount;
	private String startDate;
	private String endDate;
	private String searchText;
	private String searchCert;
	private int currentPage;
	private int totalPages;
	private String btnUpdate;
	
	public String getSearchCert() {
      return searchCert;
	}

	public void setSearchCert(String searchCert) {
		this.searchCert = searchCert;
	}

	public String getBtnUpdate() {
		return btnUpdate;
	}
	
	public void setBtnUpdate(String btnUpdate) {
		this.btnUpdate = btnUpdate;
	}
	
	public String getAction() {
		if (action == null) {
		  return "";	
		} else {
		  return action;
		}  
	}
	public void setAction(String action) {
		this.action = action;
	}
	
	public List<EventHomeModel> getEventList() {
		return eventList;
	}
	public void setEventList(List<EventHomeModel> eventList) {
		this.eventList = eventList;
	}
	public long getEventId() {
		return eventId;
	}
	public void setEventId(long eventId) {
		this.eventId = eventId;
	}
	public void setEventCount(int eventCount) {
		this.eventCount = eventCount;
	}
	public int getEventCount() {
		return eventCount;
	}
	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}
	public String getStartDate() {
		return startDate;
	}
	public void setEndDate(String endDate) {
		this.endDate = endDate;
	}
	public String getEndDate() {
		return endDate;
	}
	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}
	public int getCurrentPage() {
		return currentPage;
	}
	public void setTotalPages(int totalPages) {
		this.totalPages = totalPages;
	}
	public int getTotalPages() {
		return totalPages;
	}
	public String getSearchText() {
		return searchText;
	}
	public void setSearchText(String searchText) {
		this.searchText = searchText;
	}

}
