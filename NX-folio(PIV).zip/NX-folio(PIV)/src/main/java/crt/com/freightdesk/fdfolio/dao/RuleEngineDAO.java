package crt.com.freightdesk.fdfolio.dao;

import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.HashMap;

import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.ConnectionUtil;

public class RuleEngineDAO extends BaseDao {

	public HashMap<String, Double> getCarMaxMinStats(BigInteger carrierId, BigInteger airportId) {
		String query = "select max_weight_pday,min_weight_pday,max_awb_pday,min_awb_pday from v_carrier_stats where car_id=? and airport_id=?";

		HashMap<Integer, Object> params = new HashMap<Integer, Object>();
		params.put(1, carrierId);
		params.put(2, airportId);

		return getStats(query, params);
	}

	public HashMap<String, Double> getCcsfMaxMinStats(String cert, BigInteger airportId) {
		String query = "select max_weight_pday,min_weight_pday,max_awb_pday,min_awb_pday from v_ccsf_stats where certnum=? and airport_id=?";

		HashMap<Integer, Object> params = new HashMap<Integer, Object>();
		params.put(1, cert);
		params.put(2, airportId);

		return getStats(query, params);
	}

	private HashMap<String, Double> getStats(String query, HashMap<Integer, Object> params) {
		HashMap<String, Double> maxMinStats = new HashMap<String, Double>();

		Connection connection = null;
		PreparedStatement pStmt = null;
		ResultSet rs = null;

		try {
			connection = getConnection();
			pStmt = connection.prepareStatement(query);
			pStmt = bindParams(pStmt, params);
			rs = pStmt.executeQuery();

			if (rs.next()) {
				maxMinStats.put("maxWeight", rs.getDouble("max_weight_pday"));
				maxMinStats.put("minWeight", rs.getDouble("min_weight_pday"));
				maxMinStats.put("maxAwb", rs.getDouble("max_awb_pday"));
				maxMinStats.put("minAwb", rs.getDouble("min_awb_pday"));
			}
			logger.debug("Successfully queried stats view");

		} catch (Exception ex) {
			//logger.error("Query: " + query + "\nParams: " + params);
			//ex.printStackTrace();
			logger.error("Exception : " + ex.getMessage());
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}

		return maxMinStats;
	}
}
