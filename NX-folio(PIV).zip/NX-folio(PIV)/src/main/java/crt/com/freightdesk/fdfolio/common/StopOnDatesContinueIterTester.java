/**
 * 
 */
package crt.com.freightdesk.fdfolio.common;

import crt.com.freightdesk.fdfolio.common.ExcelContinueIterTester;
import org.apache.poi.ss.usermodel.Row;




/**
 * @author jhansford
 *
 */
public class StopOnDatesContinueIterTester implements ExcelContinueIterTester 
{	
	
	/* (non-Javadoc)
	 * @see com.freightdesk.fdfolio.common.ExcelContinueIterTester#continueIter(org.apache.poi.ss.usermodel.Row)
	 */
	@Override
	public boolean continueIter(Row row) 
	{
		
		boolean result = true;		
		if ( row.getCell( 0 ).getColumnIndex() != 0 )
			if ( row.getCell( 1 ).getColumnIndex() != 1 )
				result = false;
		if ( row.getCell( 0 ).toString().trim().equals( "" ) )
			if ( row.getCell( 1 ).toString().trim().equals( "" ) )
				result = false;
		
		return result;
	}

}
