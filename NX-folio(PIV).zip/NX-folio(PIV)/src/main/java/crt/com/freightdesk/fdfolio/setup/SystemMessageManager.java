package crt.com.freightdesk.fdfolio.setup;

import java.sql.Timestamp;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.FormatDate;
import crt.com.freightdesk.fdfolio.dao.SystemMessageDAO;
import crt.com.freightdesk.fdfolio.setup.model.SystemMessageModel;
import crt.com.freightdesk.fdfolioweb.setup.form.SystemMessageForm;


public class SystemMessageManager {
    private static final Logger logger = Logger.getLogger("crt.com.freightdesk.fdfolio.setup.SystemMessageManager");
	private static SystemMessageManager instance = null;
	private static SystemMessageModel systemMessageModel;

	private SystemMessageManager() {
		load();
	}

	public static SystemMessageManager getInstance() {
		if (instance == null) {
			instance = new SystemMessageManager();
		}
		logger.debug("returning instance of SystemMessageManager");
		return instance;
	}
	
	private static void load() {
		logger.debug("loading instance");
		SystemMessageDAO messageDao = new SystemMessageDAO();
		systemMessageModel = messageDao.retrieve();
	}
	
	public SystemMessageModel getMessageModel() {
		return systemMessageModel;
	}
	
	public void reset() {
		load();
	}
	
	public static SystemMessageForm model2form(SystemMessageModel model,SystemMessageForm form, Credentials credentials) {
		form.setMessageText(model.getMessageText());
		form.setFaqTxt(model.getFaqTxt());
		form.setLastUpdateUserId(model.getDomainName()+"."+model.getLastUpdateUserId());
		form.setLastUpdateTimestamp(FormatDate.format(model.getLastUpdateTimestamp(), credentials.getDateFormat()));
		return form;
	}
	
	public static SystemMessageModel form2model(SystemMessageForm form, Credentials credentials) {
		systemMessageModel.setMessageText(form.getMessageText());
		systemMessageModel.setFaqTxt(form.getFaqTxt());
		systemMessageModel.setLastUpdateUserId(credentials.getUserId());
		systemMessageModel.setDomainName(credentials.getDomainName());
		systemMessageModel.setLastUpdateTimestamp(new Timestamp(System.currentTimeMillis()));
		
		return systemMessageModel;
	}

}
