/**
 * Copyright (c) NTELX All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the license
 * agreement you entered into with NTELX.
 *
 *
 * $Header:
 * /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/setup/action/UserDetailsAction.java,v
 * 1.13.2.36 2010/09/28 21:15:13 mechevarria Exp $
 *
 * Modification History: $Log: UserDetailsAction.java,v $ Revision 1.13.2.36
 * 2010/09/28 21:15:13 mechevarria use better time format
 *
 * Revision 1.13.2.35 2010/09/27 20:31:09 mechevarria add field for
 * createtimestamp and lastupdatetimestamp
 *
 * Revision 1.13.2.34 2010/09/27 17:51:18 jhansford Changed text of user detail
 * logging
 *
 * Revision 1.13.2.33 2010/08/26 14:29:55 mechevarria did not use display page
 * method
 *
 * Revision 1.13.2.32 2010/08/22 23:08:38 mechevarria update with company name
 * in copyright
 *
 * Revision 1.13.2.31 2010/08/04 20:11:32 jhansford Now Users get an error
 * message if the email send fails
 *
 * Revision 1.13.2.30 2010/08/04 15:23:04 mechevarria copy over email and
 * orgname to systemusermodel
 *
 * Revision 1.13.2.29 2010/08/02 22:51:45 mechevarria copy form details on
 * validation errors
 *
 * Revision 1.13.2.28 2010/07/19 20:18:08 mechevarria add sendmail for user
 * creation
 *
 * Revision 1.13.2.27 2010/06/21 22:15:23 mechevarria use authenticationutils
 * instead of usesaccess bean
 *
 * Revision 1.13.2.26 2010/04/22 19:48:51 jhansford To display duplicate error
 * message, you call displayPage
 *
 * Revision 1.13.2.25 2010/03/22 20:13:21 mechevarria code cleanup
 *
 * Revision 1.13.2.24 2010/03/15 13:45:32 mechevarria put message to info level
 * since logged in db
 *
 * Revision 1.13.2.23 2010/02/13 18:56:32 mechevarria use email send in
 * fdcommons now
 *
 * Revision 1.13.2.22 2010/02/11 22:12:43 mechevarria moved systemusermodel to
 * commons
 *
 * Revision 1.13.2.21 2009/11/05 14:48:30 mechevarria correct typo in
 * domainslist call
 *
 * Revision 1.13.2.20 2009/11/02 21:15:06 mechevarria use the
 * optioncollectionmanager
 *
 * Revision 1.13.2.19 2009/10/29 21:38:47 mechevarria use
 * OptionCollectionManager in fdcommons
 *
 * Revision 1.13.2.18 2009/10/09 14:03:25 jhansford OPEN - issue FAS-80: Add
 * ability to Send Mail http://jira.ntelx.net/browse/FAS-80
 *
 * Revision 1.13.2.17 2009/10/07 15:52:32 mechevarria get the email from the
 * OrgHierarchyModel
 *
 * Revision 1.13.2.16 2009/10/06 17:36:04 mechevarria set email in the
 * systemusermodel
 *
 * Revision 1.13.2.15 2009/10/05 19:11:58 jhansford OPEN - issue FAS-66: when
 * deleting users, the listusers.jsp loads for your domain, not selected domain
 * http://jira.ntelx.net/browse/FAS-66
 *
 * Revision 1.13.2.14 2009/10/02 19:48:28 mechevarria fix bug where new users
 * had only one day to change password
 *
 * Revision 1.13.2.13 2009/09/30 15:09:48 jhansford Graceful handling of
 * updating and creating users with existing IDs. Previously it was oops.
 *
 * Revision 1.13.2.12 2009/09/23 18:02:17 mechevarria import clean via eclipse
 *
 * Revision 1.13.2.11 2009/09/22 19:32:42 mechevarria updated user management
 *
 * Revision 1.13.2.10 2009/05/08 20:31:22 mechevarria added pulldown to edit
 * isActive
 *
 * Revision 1.13.2.9 2009/02/23 20:49:01 mechevarria security updates
 *
 * Revision 1.13.2.8 2009/01/23 15:10:34 mechevarria updated code to be
 * compatible with struts 1.3.10
 *
 * Revision 1.13.2.7 2008/06/18 13:44:32 mechevarria updates from HEAD to fix
 * security devices and complete new event types of SCR and COC
 *
 * Revision 1.13.2.6 2008/01/04 16:11:29 mechevarria moved warn statements to
 * info level
 *
 * Revision 1.13.2.5 2007/12/07 16:38:22 mechevarria modified copyform2model so
 * that the active field is either y or n. Done for security
 *
 * Revision 1.13.2.4 2007/08/15 15:09:17 mechevarria added credentials to
 * function parameters to support async logging of user creation and user
 * updates
 *
 * Revision 1.13.2.3 2007/06/12 12:12:50 mechevarria removed password from being
 * printed in logs
 *
 * Revision 1.13.2.2 2007/04/02 16:16:45 mechevarria updates to role creation
 * permissions
 *
 * Revision 1.15 2007/03/30 22:18:11 aarora Improved some messages
 *
 * Revision 1.14 2007/03/30 15:29:49 nsehra changes for role access check
 *
 * Revision 1.13 2007/01/12 11:59:12 atripathi user feedback messages added
 *
 * Revision 1.12 2006/12/11 19:57:54 ranand removed password log from info
 *
 * Revision 1.11 2006/10/11 07:52:08 ranand removed dependency on USERSYSTEMROLE
 * table
 *
 * Revision 1.10 2006/06/08 21:14:08 aarora Removed unused method
 *
 * Revision 1.9 2006/05/11 22:18:55 aarora Small change as the SessionKey class
 * has been added to com.freightdesk.fdfolio.commons
 *
 * Revision 1.8 2006/04/11 13:14:23 nsehra removed implementation of
 * respondBtnSaveAndNew() method
 *
 * Revision 1.7 2006/03/29 22:53:14 aarora Due to repackaging of FormatDate
 *
 * Revision 1.6 2006/03/28 21:22:59 aarora Repackaging of fdcommons
 *
 * Revision 1.5 2005/06/20 14:07:43 nsehra change method saveUserDetails , set
 * the createUserId field in systemUsermodel
 *
 * Revision 1.4 2004/10/12 18:24:00 amrinder Only whitespace changes, the bug
 * 1143 was fixed by changing struts config.
 *
 * Revision 1.3 2004/09/21 08:47:42 ranand package of Manager classes changed
 * from folioweb to folio
 *
 * Revision 1.2 2004/09/16 07:25:21 ranand package name changed from
 * organization to orghierarchy in fdfolio
 *
 * Revision 1.1 2004/09/15 13:36:28 asingh 2.6 Baseline
 */
package crt.com.freightdesk.fdfolioweb.setup.action;

import java.sql.Timestamp;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.freightdesk.fdcommons.ActionErrors;
import com.freightdesk.fdcommons.ActionMessage;
import com.freightdesk.fdcommons.ActionMessages;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.ServletActionContext;
import org.apache.log4j.Logger;
import org.apache.commons.lang.StringEscapeUtils;

import crt.com.freightdesk.fdfolio.common.UserSetupReferenceData;

import com.freightdesk.fdfolio.dao.UserAccessDAO;
import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;

import crt.com.freightdesk.fdfolio.setup.UserSetupManager;

import com.freightdesk.fdcommons.ApplicationTabs;

import crt.com.ntelx.nxcommons.AuthenticationUtils;

import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.DuplicateRecordFoundException;
import com.freightdesk.fdcommons.FDSuiteProperties;

import crt.com.ntelx.nxcommons.FasConstants;

import com.freightdesk.fdcommons.FormatDate;
import com.freightdesk.fdcommons.OperationInfo;

import crt.com.ntelx.nxcommons.PasswordUtils;

import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.StackManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;

import crt.com.ntelx.nxcommons.email.EmailUtil;

import com.freightdesk.fdfolio.useraccess.model.SystemUserModel;
import com.freightdesk.fdfolio.dao.OrghierarchyDAO;
import com.freightdesk.fdcommons.OptionBean;

import crt.com.freightdesk.fdfolioweb.setup.PasswordStatus;
import crt.com.ntelx.nxcommons.reporting.OptionCollectionManager;
import crt.com.freightdesk.fdfolio.common.IncludesUtil;

import com.opensymphony.xwork2.ActionSupport;

/**
 * The Struts Action class associated with UserDetails.jsp and the
 * UserDetailsForm. The execute method is the only method that needs to be
 * declared public.
 *
 * @author Sangeeta
 * @author Nitin Sehra
 */
public class UserDetailsAction extends ActionSupport implements ServletRequestAware {

    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();
    /**
     * An instance of UserSetupManager
     */
    protected UserSetupManager userSetupManager = new UserSetupManager();
    private String faqTxt;
    private String loginTimeRoleMsg;
    private static final long serialVersionUID = 1526446059345935041L;
    private String firstName = null;
    private String lastName = null;
    private String userId = null;
    private String newPassword = null;
    private String confirmPassword = null;
    private String orgName = null;
    private String systemRoleCode;
    private long userSystemRoleId;
    private String passwordExpirationDate = null;
    private String active = null;
    private String passwordAutoExpire = "0";
    private String autoExpireDays = null;
    private String currencyCode = null;
    private String preferredDateFormat = null;
    private String uomCode = null;
    private String timeZoneId = null;
    private List<OptionBean> roleList = null;
    private List<String> roleStrList = new ArrayList<String>();
    private String process = null;
    private String subProcess = null;
    private String hdnProcess = null;
    private String type = null;
    private String orgId = null;
    private String systemUserId = null;
    private String invokedFrom;
    private String passwordReset = "FALSE";
    private List<OptionBean> statusList = null;
    private List<String> statusStrList = new ArrayList<String>();
    private String usersDomainName = null;
    private String selectedDomainName;
    private List<OptionBean> domainList;
    private String newDomainButton = "OFF";
    private String email;
    private String sendEmail = "FALSE";
    private String createTimestamp = null;
    private String lastUpdateTimestamp = null;
    private String createUserId = null;
    private String lastUpdateUserId = null;
    private String lastLoginTimestamp;
    private String numFailedLogin;
    private String basicBtnClicked = null;
    private String origin = null;
    private String link = null;
    private String lookup = null;
    private String search = null;
    private static Map<String, String> systemRoleLinkedMap = new LinkedHashMap<String, String>();

    public String respondBtnSave() throws java.lang.Exception {
        logger.debug("begin, not supported any more");
        return null;
    }

    /**
     * Processing save and return event
     */
    public String respondBtnSaveAndReturn() throws java.lang.Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials) + "<br>" + IncludesUtil.getExpireMsg(credentials);

        logger.debug("Starting save and return ");
        

        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        String role = credentials.getRole();
        userSetupManager = new UserSetupManager();
        boolean isAccess = userSetupManager.checkAccess(role, getSystemRoleCode());
        if (!isAccess) {
            logger.debug("access to role is " + isAccess);            
            addActionError(getText("setup.operation.noaccess"));
            return displayPage();
        }

        String process = getProcess();
       
        ActionErrors errors = validateForm(process);
        
        if (hasActionErrors()){
            logger.debug("Caught input validation errors.");
            
            addFieldError("userDetailsErrorsHeader", getText("errors.header"));
            //saveErrors(request, errors);
            // save the current values...hack for core team not doing forms properly
            SystemUserModel systemUserModel = copyForm2Model(credentials, process);
            sessionStore.put(SessionKey.USER_MODEL, systemUserModel);
            // end goddamn hack
            return displayPage();
        } else {
            logger.debug("ActionErrors size is " + errors.size());          
        }

        SystemUserModel systemUserModel = copyForm2Model(credentials, process);

        try {
            if ("userAdd".equalsIgnoreCase(process)) {
                userSetupManager.createUser(systemUserModel, credentials);
                logger.debug("New User " + systemUserModel.getDomainName() + "." + systemUserModel.getUserId() + " Created.");
                

                AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
                AsyncProcessManager asyncRequestManager = new AsyncProcessManager();

                // system wide sendmail is enabled and the sendmail box is checked, email the contact their username and password                               
				if (FDSuiteProperties.getProperty("ENABLE_SENDMAIL").equalsIgnoreCase("true") && getSendEmail().equalsIgnoreCase("true")) {
                    logger.debug("Sending new user account email");
                    
                    if (getEmail() != null) {

                        try {
                            // log sent emails
                            asyncLogModel.init(credentials.getUserId(), credentials.getDomainName(), "EMAIL", "ADMIN", "Attempting to send email to " + getEmail(), credentials.getIpAddress());
                            asyncLogModel = asyncRequestManager.createAsyncProcessLog(asyncLogModel);
                            // end logging initialization

                            EmailUtil.sendNewLoginEmail(systemUserModel.getContactFirstName().split(",")[0] + " " + systemUserModel.getContactLastName(), systemUserModel.getUserId(), getNewPassword(),
                                    "User Account", "User Password", getEmail());

                            // log success
                            asyncRequestManager.logResult(asyncLogModel, true, "Successfully created login sent and email to " + getEmail(), "respondBtnSaveAndReturn");
                            
				            addActionMessage(getText("setup.user.saveEmail"));
							
                        } catch (Exception ex) {                            
                            logger.error("Exception : " + ex.getMessage());
                            asyncRequestManager.logResult(asyncLogModel, false, "Failed to send email to " + getEmail(), "respondBtnSaveAndReturn");

                            ActionErrors actionErrors = new ActionErrors();
                            actionErrors.add("userdetails.create.email.fail", new ActionMessage("userdetails.create.email.fail"));
                            
							addActionError(getText("userdetails.create.email.fail"));
                            systemUserModel = copyForm2Model(credentials, process);

                            sessionStore.put(SessionKey.USER_MODEL, systemUserModel);

                            logger.warn("Failed to send new user email, deleting login from database");
                           
                            // get the user information from the database
                            systemUserModel = AuthenticationUtils.retrieveUserInfo(systemUserModel.getDomainName(), systemUserModel.getUserId());
                            UserAccessDAO userDAO = new UserAccessDAO();
                            userDAO.delete(systemUserModel);

                            return displayPage();
                        }
                    } else {
                        logger.debug("email address is null.  Nothing sent.");                 
						addActionError(getText("setup.user.noEmail"));
                    }
                } else {
                    asyncLogModel.init(credentials.getUserId(), credentials.getDomainName(), "EMAIL", "ADMIN", "Not sending email to  " + getEmail(), credentials.getIpAddress());
                    asyncLogModel = asyncRequestManager.createAsyncProcessLog(asyncLogModel);

                    asyncRequestManager.logResult(asyncLogModel, true, "Successfully created login", "respondBtnSaveAndReturn");
                    
					addActionMessage(getText("setup.user.save"));
					
                }

            } else if ("UserEdit".equalsIgnoreCase(process)) {
                // initiate logging
                AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
                AsyncProcessManager asyncRequestManager = new AsyncProcessManager();
				

                // log user edits
                asyncLogModel.init(credentials.getUserId(), credentials.getDomainName(), "EDIT", "SECURITY", "Modifying user " + systemUserModel.getDomainName() + "." + systemUserModel.getUserId(), credentials.getIpAddress());

                // update the password history  if reset button checked.
                if (getPasswordReset().equalsIgnoreCase("TRUE")) {
                    if (!PasswordUtils.updatePasswordHistory(systemUserModel.getSystemUserId(), credentials.getDomainName(), credentials.getUserId())) {
                        logger.error("Failed to update passwordhistory");
                        
                        asyncRequestManager.logResult(asyncLogModel, false, "Failed to password history in database.", "respondBtnSaveAndReturn");
                        
						addActionError(getText("setuphome.editdata.history.error"));
                        return displayPage();
                    }
                }

                // update the user
                if (!AuthenticationUtils.updateSystemUser(systemUserModel, credentials)) {
                    logger.error("Failed to update user in system");
                    
                    asyncRequestManager.logResult(asyncLogModel, false, "Failed to update user password in database.", "respondBtnSaveAndReturn");
                    
                    addActionError(getText("setuphome.editdata.update.error"));
                    return displayPage();
                }
                asyncRequestManager.logResult(asyncLogModel, true, "Successfully modified user " + systemUserModel.getDomainName() + "." + systemUserModel.getUserId(), "updateUser");
                logger.debug("User " + systemUserModel.getDomainName() + "." + systemUserModel.getUserId() + " edited.");

                // send password reset email if system wide sendmail is enabled AND the reset password box is checked AND the sendmail box is checked.
				if (FDSuiteProperties.getProperty("ENABLE_SENDMAIL").equalsIgnoreCase("true") && getPasswordReset().equalsIgnoreCase("TRUE") && getSendEmail().equalsIgnoreCase("true")) {
                    logger.debug("Attempting to send password reset email.");
                    
                    if (getEmail() != null) {
                        logger.debug("ABOUT TO SEND EMAIL to: " + systemUserModel.getContactFirstName() + " " + systemUserModel.getContactLastName() + " with pass: " + getNewPassword() + " EmailId: " + getEmail());
                        
                        // log sent emails
                        asyncLogModel.init(credentials.getUserId(), credentials.getDomainName(), "EMAIL", "ADMIN", "Attempting to send email to " + getEmail(), credentials.getIpAddress());
                        asyncLogModel = asyncRequestManager.createAsyncProcessLog(asyncLogModel);
                        // end logging initialization

                        try {
                            EmailUtil.sendPassResetEmail(systemUserModel.getContactFirstName().split(",")[0] + " " + systemUserModel.getContactLastName(), getNewPassword(), "Password Reset", getEmail());
                        } catch (Exception ex) {
                            logger.error("Exception - Failed to send email to: " + getEmail());
                            
                            // log error
                            asyncRequestManager.logResult(asyncLogModel, false, "Failed to send email to " + getEmail(), "respondBtnSaveAndReturn");

                            ActionErrors actionErrors = new ActionErrors();
                            actionErrors.add("userdetails.update.email.fail", new ActionMessage("userdetails.update.email.fail"));
                            
							addActionError(getText("userdetails.update.email.fail"));

                            systemUserModel = copyForm2Model(credentials, process);
                            sessionStore.put(SessionKey.USER_MODEL, systemUserModel);

                            return displayPage();
                        }

                        // log success
                        asyncRequestManager.logResult(asyncLogModel, true, "Successfully sent email to " + getEmail(), "respondBtnSaveAndReturn");
                        
						addActionMessage(getText("setup.user.saveEmail"));
						
                    } else {
                        logger.debug("email address is null.  Nothing sent.");
                        
                        asyncRequestManager.logResult(asyncLogModel, false, "Email null for user " + systemUserModel.getDomainName() + "." + systemUserModel.getUserId(), "respondBtnSaveAndReturn");
                        
						addActionError(getText("setup.user.noEmail"));
                    }
                } else {                   
					addActionMessage(getText("setup.user.save"));
                }

            } // end user edit
        } catch (DuplicateRecordFoundException ex) {
            logger.debug("respondBtnSaveAndReturn : .... ");
            
            ActionErrors actionErrors = new ActionErrors();
            actionErrors.add("userdetails.duplicateUser", new ActionMessage("userdetails.duplicateUser"));
            
			addActionError(getText("userdetails.duplicateUser"));
            return displayPage();
        }
        sessionStore.remove(SessionKey.USER_MODEL);
        sessionStore.remove(SessionKey.USER_CONTACT_MODEL);
        sessionStore.remove(SessionKey.USER_ADDRESS);
        
        logger.debug("SessionStore::InvokedFrom::" + (String) sessionStore.get(SessionKey.INVOKED_FROM));
        
        sessionStore.remove(SessionKey.INVOKED_FROM);
        sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
        
        return "fasSetupHome";
    }

    /**
     * Processing cancel event
     */
    public String respondBtnCancel() throws java.lang.Exception {
        request = ServletActionContext.getRequest();
        logger.debug("Cancel button pressed.");       
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());      
        sessionStore.remove(SessionKey.USER_MODEL);       
        sessionStore.remove(SessionKey.USER_CONTACT_MODEL);      
        sessionStore.remove(SessionKey.USER_ADDRESS);       
        sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
        
        return "cancel";
    }

    /**
     * Processes all the actions that do not emanate from any of the 4 basic
     * buttons
     */
    public String respondNonBasicBtnClick() throws java.lang.Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);

        logger.debug("respondNonBasicBtnClick of UserDetailsAction  Begin");
        
        String process = getProcess();
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        logger.debug("process is " + process);

        if (getInvokedFrom() != null && !"".equals(getInvokedFrom())) {
            logger.debug("InvokedFrom::" + getInvokedFrom());
            
            sessionStore.put(SessionKey.INVOKED_FROM, getInvokedFrom());
        }

        if (process != null && !process.equals("")) {

            if ("UserEdit".equalsIgnoreCase(process)) {
                SystemUserModel systemUserModel = (SystemUserModel) sessionStore.get(SessionKey.USER_MODEL);
                SystemUserModel model = userSetupManager.getUserDetails(systemUserModel);
                logger.info("UserAccess " + credentials.getDomainName() + "." + credentials.getUserId() + " User " + systemUserModel.getDomainName() + "." + systemUserModel.getUserId() + " Edited.");
                
                sessionStore.put(SessionKey.USER_MODEL, model);
            }
            return displayPage();
        }
        String subProcess = getSubProcess();
        // process lookup or create actions of address modules
        if (subProcess != null && !subProcess.trim().equals("")) {
            return respondSubProcessActions();
        }

        throw new RuntimeException("respondNonBasicBtnClick : no matching conditions ");
    }

    /**
     * Processes all the actions that do not emanate from any of the 4 basic
     * buttons
     */
    public String respondSubProcessActions() {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);

        logger.debug("executeSubProcess : started .... ");
        
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        String subProcess = getSubProcess();
        
        logger.debug("executeSubProcess : getSearch() " + subProcess);
                
        sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
        SystemUserModel systemUserModel = copyForm2Model(credentials, subProcess);
        sessionStore.put(SessionKey.USER_MODEL, systemUserModel);

        // lookup for address details
        if (subProcess.equalsIgnoreCase("lookup")) {
            pushStack("lookup", "SearchManager", "NewLocation", request);
            
            return "search";
        } else {
            logger.debug("respondSubProcesses : subProcess - shipmentEventModel .... ");
            throw new RuntimeException("respondSubProcessActions : no matching conditions ");
        }
    }

    /**
     * Displays the record of the user.
     */
    protected String displayPage() {
        logger.debug("Method begin");
       
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession();
        SessionStore sessionStore = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) sessionStore.get(SessionKey.CREDENTIALS);

        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials) + "<br>" + IncludesUtil.getExpireMsg(credentials);

        
        StackManager sm;
        if (sessionStore.get(SessionKey.STACK) == null){
            sm = new StackManager();          
        } else {            
            sessionStore.put(SessionKey.IS_FORWARDED, "No");           
        }	

        sessionStore.put(SessionKey.CURRENT_TAB, ApplicationTabs.SETUP);

        setProcess(process);
        OrghierarchyModel orgModel = (OrghierarchyModel) sessionStore.get(SessionKey.USER_CONTACT_MODEL);

        SystemUserModel systemUserModel = (SystemUserModel) sessionStore.get(SessionKey.USER_MODEL);
        if (systemUserModel == null) {
            systemUserModel = new SystemUserModel();
        }

        if (orgModel != null) {
            logger.debug("OrgHierarchyModel:" + orgModel.getContactFirstName() + ", " + orgModel.getContactLastName() + ", " + orgModel.getOrgName() + ", " + orgModel.getOrgId());
            
            systemUserModel.setContactFirstName(orgModel.getContactFirstName());
            systemUserModel.setContactLastName(orgModel.getContactLastName());

            orgModel.setParentOrgName("TSA HQ (LOC)");
			systemUserModel.setOrgName(orgModel.getParentOrgName());
            
			setOrgName(systemUserModel.getOrgName());
                       
            
            setNewPassword("********");
            setConfirmPassword("********");
            
            systemUserModel.setOrgId(orgModel.getOrgId());
            systemUserModel.setEmail(orgModel.getEmail());

        } else {
            logger.info("Contact model is null?");         
        }

        OptionCollectionManager collectionManager = OptionCollectionManager.getInstance();
        setDomainList(collectionManager.getCollection("domainsList"));
        // Sets the drop down lists on the form, using the reference data
        UserSetupReferenceData userSetupReferenceData = UserSetupReferenceData.getInstance(credentials.getDomainName());
        setRoleList(userSetupReferenceData.getRoleList());
        roleStrList = convertRoleListToStringList(roleList);

        setStatusList(userSetupReferenceData.getStatusList());
        statusStrList = convertStatusListToStringList(statusList);
        
        copyModel2Form(systemUserModel, credentials);

        setSendEmail("TRUE");      

       
        sessionStore.remove(SessionKey.USER_CONTACT_MODEL);
        sessionStore.remove(SessionKey.USER_ADDRESS);
        logger.debug("DisplayPage::Finished..... ");
        
        return "display";
    }

    @Override
    public String execute() throws Exception {        
        logger.debug("Selected Domain Name from form: " + getSelectedDomainName());
		

        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);

        // POAM HttpOnly Secure
        HttpServletResponse response = (HttpServletResponse)ServletActionContext.getResponse();
        String secure = "";
        if (request.isSecure()) {
          secure = "; Secure";
        }
        response.setHeader("SET-COOKIE", "JSESSIONID=" + request.getSession().getId()
                         + "; Path=" + request.getContextPath() + "; HttpOnly" + secure);      
        
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials) + "<br>" + IncludesUtil.getExpireMsg(credentials);
       
               
        if (getHdnProcess() != null){
            String[] hdnProcessArray = getHdnProcess().split(",");
            if (hdnProcessArray.length >= 2)
                setHdnProcess(hdnProcessArray[(hdnProcessArray.length)-2]);
            else
                setHdnProcess(hdnProcessArray[0]);
            
            if(getHdnProcess().toString().equalsIgnoreCase("pickup")){
                setProcess("userAdd");
            }
        } else {
            setHdnProcess(request.getParameter("hdnProcess")); 
        }
              
        if (getOrigin() != null) {
            String[] originArray = getOrigin().split(",");
            
            if (originArray.length >= 2)
                setOrigin(originArray[(originArray.length)-2]);
            else
                setOrigin(originArray[0]);
        } else {
            setOrigin(request.getParameter("origin")); 
        }
               
        if (getLink() != null){
            String[] linkArray = getLink().split(",");
            if (linkArray.length >= 2)
                setLink(linkArray[(linkArray.length)-2]);
            else
                setLink(linkArray[0]);
        } else {
            setLink(request.getParameter("link")); 
        }
               
        if (getLookup() != null){
            String[] lookupArray = getLookup().split(",");
            if (lookupArray.length >= 2)
                setLookup(lookupArray[(lookupArray.length)-2]);
            else
                setLookup(lookupArray[0]);
        } else {
            setLookup(request.getParameter("lookup")); 
        }
        
        if (getSearch() != null) {
            String[] searchArray = getSearch().split(",");
            if (searchArray.length >= 2)
                setSearch(searchArray[(searchArray.length)-2]);
            else
                setSearch(searchArray[0]);
        } else {
            setSearch(request.getParameter("search")); 
        }
        
        
        if (getOrgName() != null) {
            String[] orgNameArray = getOrgName().split(",");
            if (orgNameArray.length >= 2)
                setOrgName(orgNameArray[(orgNameArray.length)-2]);
            else
                setOrgName(orgNameArray[0]);
        } else {
            setOrgName(request.getParameter("OrgName")); 
        }
        
        
        
        if ("CANCEL".equalsIgnoreCase(basicBtnClicked)) {           
            return respondBtnCancel();
        } else if ("SAVE_RETURN".equalsIgnoreCase(basicBtnClicked)) {           
            return respondBtnSaveAndReturn();
        } else if ("useraddress".equalsIgnoreCase(getOrigin()) && ("PickUp".equalsIgnoreCase(getLink()))) {           
            return respondSubProcessActions();
        } else if(("UserEdit".equalsIgnoreCase(getProcess())) && ("listusers".equalsIgnoreCase(getInvokedFrom()))){
            respondNonBasicBtnClick();
        }
        
        OptionCollectionManager collectionManager = OptionCollectionManager.getInstance();
        
        UserSetupReferenceData userSetupReferenceData = UserSetupReferenceData.getInstance(credentials.getDomainName());

        setRoleList(userSetupReferenceData.getRoleList());
        roleStrList = convertRoleListToStringList(roleList);

        setStatusList(userSetupReferenceData.getStatusList());
        statusStrList = convertStatusListToStringList(statusList);

        
        return displayPage();
    }

    private List<String> convertRoleListToStringList(List<OptionBean> roleListOptBean) {
        
        List<String> theRoleStrList = new ArrayList<String>();
        Iterator<OptionBean> itrRole = roleListOptBean.iterator();
        OptionBean optBean = new OptionBean();
        while (itrRole.hasNext()) {
            optBean = itrRole.next();
            optBean.setLabel(optBean.getLabel().toUpperCase());
            optBean.setValue(optBean.getValue().toUpperCase());
			if (optBean.getValue().equalsIgnoreCase("RDONL")) {
				   theRoleStrList.add("READ ONLY (RDONL)");
				   systemRoleLinkedMap.put("READ ONLY (RDONL)", optBean.getValue()); 
		    }
			else if (optBean.getValue().equalsIgnoreCase("TAR")) {
				   theRoleStrList.add("TARGETER (TAR)");
				   systemRoleLinkedMap.put("TARGETER (TAR)", optBean.getValue());
			}
			else if (optBean.getValue().equalsIgnoreCase("APAD")) {
				   theRoleStrList.add("APPLICATION ADMINISTRATOR (APAD)");
				   systemRoleLinkedMap.put("APPLICATION ADMINISTRATOR (APAD)", optBean.getValue());
				}
        }
        return theRoleStrList;
    }

    // Alternative way to get value if not using systemRoleLinkedMap
    private String convertRoleLabelToValue(String label, List<OptionBean> roleListOptBean) {
       
        Iterator<OptionBean> itrRole = roleListOptBean.iterator();
        OptionBean optBean = new OptionBean();
        while (itrRole.hasNext()) {
            optBean = itrRole.next();

            if (label.equals(optBean.getLabel())) {               
                return optBean.getValue();
            }
        }
        return null;
    }
    
    private String convertRoleValueToLabel(String value, List<OptionBean> roleListOptBean) {
        
        
        if (value == null){
            return null;
        }
        
        Iterator<OptionBean> itrRole = roleListOptBean.iterator();
        OptionBean optBean = new OptionBean();
        while (itrRole.hasNext()) {
            optBean = itrRole.next();
            if (value.equalsIgnoreCase("RDONL")) {
			    return ("READ ONLY (RDONL)");
			} else if (value.equalsIgnoreCase("TAR")) {
			    return ("TARGETER (TAR)");
			} if (value.equalsIgnoreCase("APAD")) {
			    return ("APPLICATION ADMINISTRATOR (APAD)");
			} else if (value.equals(optBean.getValue())) {               
                return optBean.getLabel();
            }
        }
        return null;
    }
    
    private String convertStatusLabelToValue(String label, List<OptionBean> statusListOptBean) {
        
        Iterator<OptionBean> itrStatus = statusListOptBean.iterator();
        OptionBean optBean = new OptionBean();
        while (itrStatus.hasNext()) {
            optBean = itrStatus.next();

            if (label.equals(optBean.getLabel())) {                
                return optBean.getValue();
            }
        }
        return null;
    }
    
    private String convertStatusValueToLabel(String value, List<OptionBean> statusListOptBean) {
        
        Iterator<OptionBean> itrStatus = statusListOptBean.iterator();
        OptionBean optBean = new OptionBean();
        while (itrStatus.hasNext()) {
            optBean = itrStatus.next();

            if (value.equals(optBean.getValue())) {                
                return optBean.getLabel();
            }
        }
        return null;
    }

    private List<String> convertStatusListToStringList(List<OptionBean> statusListOptBean) {
        List<String> theStatusStrList = new ArrayList<String>();
        Iterator<OptionBean> itrStatus = statusListOptBean.iterator();
        OptionBean optBean = new OptionBean();
        while (itrStatus.hasNext()) {
            optBean = itrStatus.next();
            theStatusStrList.add(optBean.getLabel());           
        }
        return theStatusStrList;
    }

    /**
     * Identifies the action to be taken from Stack or request based on
     * IS_FORWARDED staus
     */  
    private void copyModel2Form(SystemUserModel systemUserModel, Credentials credentials) {
        logger.debug("copyModel2Form: begin()");
        

        String dateTimeFormat = FasConstants.dateTimeFormat;
        setLastLoginTimestamp(FormatDate.format(systemUserModel.getLastLoginTimestamp(), dateTimeFormat));
        setNumFailedLogin(Integer.toString(systemUserModel.getNumFailedLogin()));
        setUserId(systemUserModel.getUserId());
        setSelectedDomainName(systemUserModel.getDomainName());
        
        setNewPassword(systemUserModel.getPassword());
        setConfirmPassword(systemUserModel.getConfirmPassword());
        
        setNewPassword("********");
        setConfirmPassword("********");
        
        Timestamp expiryDate = systemUserModel.getPasswordExpirationDate();
        if (expiryDate != null && !"".equals(expiryDate)) {
            String date = FormatDate.format(expiryDate, FasConstants.simpleDateFormat);
            setPasswordExpirationDate(date);
        }
        setActive("" + systemUserModel.getIsActive());
        setActive(convertStatusValueToLabel(getActive(), statusList));
        
        
        
        setPasswordAutoExpire("" + systemUserModel.getIsPasswordAutoExpire());

        setAutoExpireDays("" + systemUserModel.getAutoExpireDays());
        setSystemUserId("" + systemUserModel.getSystemUserId());

        setSystemRoleCode(systemUserModel.getSystemRoleCode());
        setSystemRoleCode(convertRoleValueToLabel(getSystemRoleCode(), roleList));
        

        setCurrencyCode(systemUserModel.getCurrencyCode());
        setPreferredDateFormat(systemUserModel.getDateFormat());
        setUomCode(systemUserModel.getUomCode());
        setTimeZoneId(systemUserModel.getTimeZoneId());
        setOrgId("" + systemUserModel.getOrgId());
        setFirstName(systemUserModel.getContactFirstName());
        setLastName(systemUserModel.getContactLastName());
        
        if (getOrgName() == null){
            setOrgName(systemUserModel.getOrgName());
        }
        setEmail(systemUserModel.getEmail());
        setCreateUserId(systemUserModel.getCreateUserId());
        setLastUpdateUserId(systemUserModel.getLastUpdateUserId());
        setCreateTimestamp(FormatDate.format(systemUserModel.getCreateTimestamp(), dateTimeFormat));
        setLastUpdateTimestamp(FormatDate.format(systemUserModel.getLastUpdateTimestamp(), dateTimeFormat));

        logger.info("Form values are, userid=" + getUserId() + ", orgid=" + getOrgId() + ", firstName=" + getFirstName() + ", lastName="
                + getLastName());        
    }

    /**
     * Creates a SystemUserModel object based on the form submitted.
     *
     * @param userDetailsForm
     * @param credentials
     * @return
     */
    private SystemUserModel copyForm2Model(Credentials credentials, String process) {
        logger.debug("saveUserDetails --Inside function ");
        
        long userSystemRoleId = 0L;
        long systemUserId = 0L;

        String firstName = getFirstName();
        String lastName = getLastName();
        String userId = getUserId().toUpperCase();
        String orgName = getOrgName();
        String password = getNewPassword();
        String confirmPassword = getConfirmPassword();
        if (getUserSystemRoleId() > 0L) {
            userSystemRoleId = getUserSystemRoleId();
        }
        if (getSystemUserId() != null && !"".equals(getSystemUserId())) {
            systemUserId = Long.parseLong(getSystemUserId());
            logger.debug("System User ID: " + systemUserId);
        }

        String systemRoleCode = getSystemRoleCode();
        Timestamp passwordExpirationDate = null;

        if (!"".equals(getPasswordExpirationDate())) {
            passwordExpirationDate = FormatDate.parse(getPasswordExpirationDate(), credentials.getDateFormat());
        }

        String active = getActive();
        if (active != null) {
            active = active.substring(0, 1);  // Y or N
        }

        // Hardcoded for TSA FAS. All passwords must expire
        long isPasswordAutoExpire = 1L;
        logger.debug("isPasswordAutoExpire hardcoded to " + isPasswordAutoExpire);
        

        long autoExpireDays = 0L;

        if (getPasswordReset() != null && getPasswordReset().equalsIgnoreCase("TRUE")) {
            logger.debug("passwordReset is " + getPasswordReset());
			// If the user had his/her password reset, they have 1 day to update
            // their password from the sys admin
            autoExpireDays = 1L;
        } else {
            // Default auto expire is 90 days for FAS
            autoExpireDays = 90L;
        }
        logger.debug("autoExpireDays is " + autoExpireDays);
        
        String currencyCode = getCurrencyCode();
        String dateFormat = getPreferredDateFormat();
        String uomCode = getUomCode();
        String timeZoneId = getTimeZoneId();
        long orgId = 0L;
        if (getOrgId() != null && !"".equals(getOrgId())) {
            orgId = Long.parseLong(getOrgId());
        }

        String userDomainName;
        if (getUsersDomainName() == null || getUsersDomainName().equalsIgnoreCase("")) {
            userDomainName = getSelectedDomainName().toUpperCase();
        } else {
            userDomainName = getUsersDomainName().toUpperCase();
        }

		
        SystemUserModel systemUserModel = new SystemUserModel(systemUserId, orgId, timeZoneId, userId, password, passwordExpirationDate,
                isPasswordAutoExpire, autoExpireDays, userDomainName, uomCode, currencyCode, dateFormat, active);


        String systemRoleValue = systemRoleLinkedMap.get(systemRoleCode);
        
        systemUserModel.setSystemRoleCode(systemRoleValue);
        systemUserModel.setContactLastName(lastName);
        systemUserModel.setContactFirstName(firstName);
        systemUserModel.setOrgName(orgName);
        systemUserModel.setPassword(password);
        systemUserModel.setConfirmPassword(confirmPassword);
        systemUserModel.setCreateUserId(credentials.getUserId());
        systemUserModel.setEmail(getEmail());
        systemUserModel.setOrgName(getOrgName());
        logger.debug("saveUserDetails : Finished .... ");
        
        return systemUserModel;
    }

    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }

    public String getNumFailedLogin() {
        return numFailedLogin;
    }

    public void setNumFailedLogin(String numFailedLogin) {
        this.numFailedLogin = numFailedLogin;
    }

    public String getLastLoginTimestamp() {
        if (lastLoginTimestamp == null || lastLoginTimestamp.length() < 1) {
            return "Never logged in";
        }
        return lastLoginTimestamp;
    }

    public void setLastLoginTimestamp(String lastLoginTimestamp) {
        this.lastLoginTimestamp = lastLoginTimestamp;
    }

    public String getCreateTimestamp() {
        return createTimestamp;
    }

    public void setCreateTimestamp(String createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    public String getLastUpdateTimestamp() {
        return lastUpdateTimestamp;
    }

    public void setLastUpdateTimestamp(String lastUpdateTimestamp) {
        this.lastUpdateTimestamp = lastUpdateTimestamp;
    }

    public String getCreateUserId() {
        if (createUserId == null) {
            return "";
        }
        return createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public String getLastUpdateUserId() {
        if (lastUpdateUserId == null) {
            return "";
        }
        return lastUpdateUserId;
    }

    public void setLastUpdateUserId(String lastUpdateUserId) {
        this.lastUpdateUserId = lastUpdateUserId;
    }

    public String getSendEmail() {
        return sendEmail;
    }

    public void setSendEmail(String sendEmail) {
        this.sendEmail = sendEmail;
    }

    public String getEmail() {
        if (email == null) {
            return "";
        } else {
            return StringEscapeUtils.escapeHtml(email);
        }
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getSelectedDomainName() {
        if (selectedDomainName == null) {
            return "DEMO";
        }
        return selectedDomainName;
    }

    public void setSelectedDomainName(String selectedDomainName) {
        this.selectedDomainName = selectedDomainName;
    }

    public String getNewDomainButton() {
        return newDomainButton;
    }

    public void setNewDomainButton(String newDomainButton) {
        this.newDomainButton = newDomainButton;
    }

    public String getUsersDomainName() {
        if (usersDomainName == null) {
            return "";
        }
        return usersDomainName;
    }

    public void setUsersDomainName(String usersDomainName) {
        this.usersDomainName = usersDomainName;
    }

    public List<OptionBean> getDomainList() {
        return domainList;
    }

    public void setDomainList(List<OptionBean> domainList) {
        this.domainList = domainList;
    }

    public List<OptionBean> getStatusList() {
        return statusList;
    }

    public void setStatusList(List<OptionBean> statusList) {
        this.statusList = statusList;
    }

    public List<String> getStatusStrList() {
        return statusStrList;
    }

    public void setStatusStrList(List<String> statusStrList) {
        this.statusStrList = statusStrList;
    }

    public String getPasswordReset() {
        return passwordReset;
    }

    public void setPasswordReset(String passwordReset) {
        this.passwordReset = passwordReset;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getOrgName() {
        return orgName;
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    public String getNewPassword() {
        return newPassword;
    }

    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }

    public String getConfirmPassword() {
        return confirmPassword;
    }

    public void setConfirmPassword(String confirmPassword) {
        this.confirmPassword = confirmPassword;
    }

    public String getSystemRoleCode() {
        return systemRoleCode;
    }

    public void setSystemRoleCode(String systemRoleCode) {
        this.systemRoleCode = systemRoleCode;
    }

    public String getPasswordExpirationDate() {
        return passwordExpirationDate;
    }

    public void setPasswordExpirationDate(String passwordExpirationDate) {
        this.passwordExpirationDate = passwordExpirationDate;
    }

    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    public String getPasswordAutoExpire() {
        return passwordAutoExpire;
    }

    public void setPasswordAutoExpire(String passwordAutoExpire) {
        this.passwordAutoExpire = passwordAutoExpire;
    }

    public String getAutoExpireDays() {
        return autoExpireDays;
    }

    public void setAutoExpireDays(String autoExpireDays) {
        this.autoExpireDays = autoExpireDays;
    }

    public String getCurrencyCode() {
        return currencyCode;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public String getPreferredDateFormat() {
        return preferredDateFormat;
    }

    public void setPreferredDateFormat(String preferredDateFormat) {
        this.preferredDateFormat = preferredDateFormat;
    }

    public String getUomCode() {
        return uomCode;
    }

    public void setUomCode(String uomCode) {
        this.uomCode = uomCode;
    }

    public String getTimeZoneId() {
        return timeZoneId;
    }

    public void setTimeZoneId(String timeZoneId) {
        this.timeZoneId = timeZoneId;
    }

    public List<OptionBean> getRoleList() {
        return roleList;
    }

    public void setRoleList(List<OptionBean> roleList) {
        this.roleList = roleList;
    }

    public List<String> getRoleStrList() {
        return roleStrList;
    }

    public void setRoleStrList(List<String> roleStrList) {
        this.roleStrList = roleStrList;
    }

    public String getProcess() {
        return process;
    }

    public void setProcess(String process) {
        this.process = process;
    }
    
    public String getOrigin() {
        return origin;
    }

    public void setOrigin(String origin) {
        this.origin = origin;
    }
    
    public String getLink() {
        return link;
    }

    public void setLink(String link) {
        this.link = link;
    }
    
    public String getLookup() {
        return lookup;
    }

    public void setLookup(String lookup) {
        this.lookup = lookup;
    }
    
    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }
    
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getSubProcess() {
        return StringEscapeUtils.escapeHtml(subProcess);
    }

    public void setSubProcess(String subProcess) {
        this.subProcess = subProcess;
    }
    
    public String getHdnProcess() {
        return StringEscapeUtils.escapeHtml(hdnProcess);
    }

    public void setHdnProcess(String hdnProcess) {
        this.hdnProcess = hdnProcess;
    }

    public String getOrgId() {
        return orgId;
    }

    public void setOrgId(String orgId) {
        this.orgId = orgId;
    }

    public String getSystemUserId() {
        return systemUserId;
    }

    public void setSystemUserId(String systemUserId) {
        this.systemUserId = systemUserId;
    }

    /**
     * @return invokedFrom
     */
    public String getInvokedFrom() {
        return invokedFrom;
    }

    /**
     * @param invokedFrom
     */
    public void setInvokedFrom(String invokedFrom) {
        this.invokedFrom = invokedFrom;
    }

    /**
     * @return
     */
    public long getUserSystemRoleId() {
        return userSystemRoleId;
    }

    /**
     * @param userSystemRoleId
     */
    public void setUserSystemRoleId(long userSystemRoleId) {
        this.userSystemRoleId = userSystemRoleId;
    }

    public String getFaqTxt() {
        return faqTxt;
    }

    public void setFaqTxt(String faqTxt) {
        this.faqTxt = faqTxt;
    }

    public String getBasicBtnClicked() {
        return basicBtnClicked;
    }

    public void setBasicBtnClicked(String basicBtnClicked) {
        this.basicBtnClicked = basicBtnClicked;
    }

    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }

    public void setActionMessage(HttpServletRequest request, String[] messageKeyObject) {
        int length = messageKeyObject.length;
        logger.debug("messageKeyObject.length = " + length);
        ActionMessage actionMessage = null;
        switch (length) {
            case 2:
                logger.debug("messagekeyvalues" + messageKeyObject[0]);
                actionMessage = new ActionMessage(messageKeyObject[0], (Object) messageKeyObject[1]);
                break;
            case 3:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2]);
                break;
            case 4:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3]);
                break;
            case 5:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3], messageKeyObject[4]);
                break;
            default:
                actionMessage = new ActionMessage(messageKeyObject[0]);
        }

        ActionMessages messages = new ActionMessages();
        messages.add(ActionMessages.GLOBAL_MESSAGE, actionMessage);

        logger.debug("message has been set on request");
    }

    private ActionErrors addError(ActionErrors errors, String text) {
        errors.add("error.filecontent", new ActionMessage("error.file.content", text));
        return errors;
    }


    /**
     * Validates the user input...had to home roll.
     */
    public ActionErrors validateForm(String process) {
        ActionErrors errors = new ActionErrors();
        String fullName = getFirstName() + "." + getLastName() + "@";

        if (process.equalsIgnoreCase("userAdd") || process.equalsIgnoreCase("userEdit")) {
                     
            if (orgId == null || Long.parseLong(orgId) < 1) {
                
                addActionError("Please use the finder to lookup a profile last name");                
            } else {
                OrghierarchyDAO orgDAO = new OrghierarchyDAO();
                if(orgDAO.isOrgInActive(Long.parseLong(orgId))){                    
                    addActionError("Profile is not ACTIVE.  Please use the finder to lookup a active profile last name");                   
                }
            }
            

            if (userId == null || userId.equalsIgnoreCase("")) {              
                addActionError("Login-ID is required");
            }                  
            logger.info(userId)	;
//          	setUserId(StringEscapeUtils.escapeHtml(userId));
            logger.info(StringEscapeUtils.escapeHtml(userId))	;

            if (userId.startsWith("@") || userId.endsWith("@") || !userId.contains("@") || userId.indexOf ("@") != userId.lastIndexOf ("@")) {
                addActionError("Only one @ in the middle of Login-ID");               
            } 
            else if (userId.contains("`") || userId.contains("'") || userId.contains("\"") || userId.contains("\\")) {
                addActionError("Invalid symbol(s) in Login-ID");
            }

            if (lastName == null || lastName.equalsIgnoreCase("")) {              
                addActionError("Last Name lookup is required");               
            }
            
            if (systemRoleCode == null || systemRoleCode.equalsIgnoreCase("") || systemRoleCode.equals("-1")) {               
                addActionError("User Role must be selected");              
            }
            
            // password validation on user creation and password reset
            if (process.equalsIgnoreCase("userAdd") || passwordReset.equalsIgnoreCase("TRUE")) {

                PasswordStatus passStatus = PasswordUtils.checkPasswords(newPassword, "", confirmPassword, 0L);
                if (!passStatus.complexityAndConfirmTrue()) {
                    logger.debug("Password did not pass complexity and/or confirm password did not match.");                    
                    passwordReset = "FALSE";              
                    addActionError("Password requirements were not met.");
                }
            }

        }

        return errors;
    }

    /**
     * A convenience method to popcom.freightdesk.fdfolio.utiluses
     * {@link com.ntelx.nxcommons.StackManager#closeEvent()}for the StackManager
     * object stored in the session.
     */
    public void popStack(HttpServletRequest request) {
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        StackManager stackManager = (StackManager) sessionStore.get(SessionKey.STACK);
        if (stackManager != null) {
            stackManager.closeEvent();
        }
    }

    /**
     * A convenience method to create a new event on the stack
     */
    public void pushStack(String newAction, String newMgr, String newOprType, HttpServletRequest request) {
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        StackManager stackManager = (StackManager) (sessionStore.get(SessionKey.STACK));
        if (stackManager == null) {
            stackManager = new StackManager();
            sessionStore.put(SessionKey.STACK, stackManager);
        }

        if (newAction != null && !newAction.trim().equals("")) {
            stackManager.createEvent(new OperationInfo(newMgr, newOprType, newAction, "", "", ""));
        }
    }
}
