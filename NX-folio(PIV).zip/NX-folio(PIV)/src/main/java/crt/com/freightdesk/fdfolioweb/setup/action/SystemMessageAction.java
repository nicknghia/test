package crt.com.freightdesk.fdfolioweb.setup.action;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.util.*;
import java.text.*;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.ActionMessage;
import com.freightdesk.fdcommons.ActionMessages;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;

import com.opensymphony.xwork2.ActionSupport;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;

import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import crt.com.freightdesk.fdfolio.dao.SystemMessageDAO;
import crt.com.freightdesk.fdfolio.setup.SystemMessageManager;
import crt.com.freightdesk.fdfolio.setup.model.SystemMessageModel;

import java.sql.Timestamp;

import org.apache.commons.lang.StringEscapeUtils;

public class SystemMessageAction extends ActionSupport implements ServletRequestAware{
        protected Logger logger = Logger.getLogger(getClass());
        HttpServletRequest request = ServletActionContext.getRequest();
        private String messageText;
	    private String faqTxt;
	    private String lastUpdateUserId;
	    private String lastUpdateTimestamp;
        private String loginTimeRoleMsg;
        private String basicBtnClicked;

	/* returns to setupHome */
	public String respondBtnCancel() throws Exception {
		logger.debug("Cancelling");		
		addActionMessage(getText("Organization.Cancel"));
		return "cancel";
	}

	/* save and finish editing */
	public String respondBtnSaveAndReturn() throws Exception {
                request = ServletActionContext.getRequest();
                HttpSession session = request.getSession(false);
                SessionStore store = SessionStore.getInstance(session);
                Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
                
		logger.debug("Saving and Returning");
                SystemMessageManager messageManager = SystemMessageManager.getInstance();
                SystemMessageModel model = new SystemMessageModel();
                
                model.setFaqTxt(faqTxt);
                
                model.setMessageText(messageText);
                model.setLastUpdateUserId(credentials.getUserId());
                model.setLastUpdateTimestamp(new Timestamp(System.currentTimeMillis()));
                model.setCreateTimestamp(new Timestamp(System.currentTimeMillis()));
                model.setDomainName(credentials.getDomainName());
                
		SystemMessageDAO messageDao = new SystemMessageDAO();
		if (!messageDao.update(model)) {			
			addActionError(getText("setuphome.message.save.fail"));
			return "fasSetupHome";
		}
		
		// reload singleton instance from DB
		SystemMessageManager.getInstance().reset();
		
		// set success message		
		addActionMessage(getText("setuphome.editdata.save.success"));
		return "fasSetupHome";
	}

	/* load and display page */
	public String execute() throws Exception {
                request = ServletActionContext.getRequest();
                HttpSession session = request.getSession(false);
                SessionStore store = SessionStore.getInstance(session);
                Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
                String DATE_FORMAT = "MM/dd/yyyy";
                Date date = new Date();
                SimpleDateFormat sdf = new SimpleDateFormat(DATE_FORMAT);
                
		logger.debug("entering systemMessage action.");
                loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);
                
                // POAM HttpOnly Secure
                HttpServletResponse response = (HttpServletResponse)ServletActionContext.getResponse();
                String secure = "";
                if (request.isSecure())
                {
                  secure = "; Secure";
                }
                response.setHeader("SET-COOKIE", "JSESSIONID=" + request.getSession().getId()
                                 + "; Path=" + request.getContextPath() + "; HttpOnly" + secure);
                
                String btnStr = getBasicBtnClicked();
                
                if ((btnStr != null) && (btnStr.equals("CANCEL"))) {
				    addActionMessage(getText("Organization.Cancel"));
                    return "cancel";
                } else if ((btnStr != null) &&  (btnStr.equals("SAVE_RETURN"))){
                    return respondBtnSaveAndReturn();
                }
                
                SystemMessageManager messageManager = SystemMessageManager.getInstance();
                SystemMessageModel model = new SystemMessageModel();
                faqTxt = messageManager.getMessageModel().getFaqTxt();
                
                messageText = messageManager.getMessageModel().getMessageText();
                date = messageManager.getMessageModel().getLastUpdateTimestamp();
                lastUpdateTimestamp = sdf.format(date);
                lastUpdateUserId = messageManager.getMessageModel().getLastUpdateUserId();
		
                return "display";
	}

    public void setActionMessage(HttpServletRequest request, String[] messageKeyObject) {
        int length = messageKeyObject.length;
        logger.debug("messageKeyObject.length = " + length);
        ActionMessage actionMessage = null;
        switch (length) {
            case 2:
                logger.debug("messagekeyvalues" + messageKeyObject[0]);
                actionMessage = new ActionMessage(messageKeyObject[0], (Object) messageKeyObject[1]);
                break;
            case 3:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2]);
                break;
            case 4:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3]);
                break;
            case 5:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3], messageKeyObject[4]);
                break;
            default:
                actionMessage = new ActionMessage(messageKeyObject[0]);
        }

        ActionMessages messages = new ActionMessages();
        messages.add(ActionMessages.GLOBAL_MESSAGE, actionMessage);

        logger.debug("message has been set on request");
    }
        
    public String getFaqTxt() {
        if (faqTxt == null) {
            this.faqTxt = "";
	    }
		
	return faqTxt;
    }
    
    public void setFaqTxt(String faqTxt) {
	this.faqTxt = faqTxt;
    }
        
    public String getMessageText() {
	return messageText;
    }
        
    public void setMessageText(String messageText) {
	this.messageText = messageText; 
    }
        
    public String getLastUpdateUserId() {
	return lastUpdateUserId;
    }
        
    public void setLastUpdateUserId(String lastUpdateUserId) {
	this.lastUpdateUserId = lastUpdateUserId;
    }
        
    public String getLastUpdateTimestamp() {
	if (lastUpdateTimestamp == null) {
            this.lastUpdateTimestamp = "";
	} else {
            this.lastUpdateTimestamp = StringEscapeUtils.escapeHtml(lastUpdateTimestamp);
	}
	return lastUpdateTimestamp;
    }
    
    public void setLastUpdateTimestamp(String lastUpdateTimestamp) {
	this.lastUpdateTimestamp = lastUpdateTimestamp;
    }
    
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return request;
    }
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
    
    public String getBasicBtnClicked() {
        return basicBtnClicked;
    }

    public void setBasicBtnClicked(String basicBtnClicked) {
        this.basicBtnClicked = basicBtnClicked;
    }
}
