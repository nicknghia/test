package crt.com.freightdesk.fdfolio.jobs;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdcommons.FDSuiteProperties;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;
import crt.com.ntelx.nxcommons.email.EmailUtil;
import com.freightdesk.fdfolio.useraccess.model.SystemUserModel;
import crt.com.freightdesk.fdfolio.dao.QuartzDao;
import org.apache.log4j.Logger;

public class NoSubmissionCCSFJob implements Job
{
	protected QuartzDao quartzDao = null; 
    protected Logger logger = Logger.getLogger ( getClass() );
     
	@Override
	public void execute( JobExecutionContext exeContext ) throws JobExecutionException
	{
		Connection connection = null;
		
		try
		{
			DataSource dataSource = (DataSource) exeContext.getMergedJobDataMap().get( "dataSource" );			
			String     sendEmails = FDSuiteProperties.getProperty( "ENABLE_SENDMAIL" );	
			
			connection = dataSource.getConnection();
		
			quartzDao = new QuartzDao();			
			quartzDao.setConnection( connection );
			
			List<SystemUserModel> userList = quartzDao.noSubmissionsICSF();
			processList(sendEmails, userList);
						
			logger.debug( "Not Submitting IACS...." );
			userList = quartzDao.noSubmissionsIAC();
			processList(sendEmails, userList);	

			/*
			logger.debug( "Not Submitting Air Cars...." );
			userList = quartzDao.noSubmissionsAIR();
			processListAIR( sendEmails, userList );
			*/		
		}
		catch ( SQLException sqlEx )
		{
			throw new JobExecutionException( "Had Problem with connection: " + sqlEx.getMessage() );
		}
		finally 
		{
			ConnectionUtil.closeResources(connection, null, null );			
		}

	}

	private void processList(String sendEmails, List<SystemUserModel> userList)
	{
		// objects for logging in database
		//
		AsyncProcessingLogModel asyncLogModel   = new AsyncProcessingLogModel();
		AsyncProcessManager asyncRequestManager = new AsyncProcessManager();
		
		for ( int i = 0; i < userList.size(); i++ )
		{
			SystemUserModel userModel =  userList.get( i );
			logger.info( "Found: " + userModel.getFullName() + ", Orgname: " + userModel.getOrgName() + " Certnum: " 
					     + userModel.getStatus() + ", Email: " + userModel.getEmail() + ", SYSDate: " + userModel.getDateFormat() );
			
			if ( sendEmails.equalsIgnoreCase( "true") )
			{				
				try
				{
					
					// log sent emails
					//
					asyncLogModel.init( "QUARTZ", "PUBLIC", "EMAIL", "ADMIN", 
										"Attempting to send email to " + userModel.getEmail(), "0.0.0.0" );
					
					asyncLogModel = asyncRequestManager.createAsyncProcessLog(asyncLogModel);									
					
					EmailUtil.sendNoSubCCSFEmail( userModel.getContactFirstName(), userModel.getContactLastName(), userModel.getOrgName(),
												  // CertNum is in Status
												  userModel.getStatus(),
												  // SysDate is in dateFormat, due date is in lastUpdateUserid
												  userModel.getDateFormat(), userModel.getLastUpdateUserId(),
												   "CRT Submissions", userModel.getEmail() );
					
					// log success
					asyncRequestManager.logResult(asyncLogModel, true, "Email: " + userModel.getEmail() + " for not submitting for " + userModel.getStatus(), 
							                      "doPasswordReset");
							                   
				}
				catch ( Exception e )
				{
					logger.error( "Error With asyncLog Model: " + e );
				}				
			}
		}
	}
	
	private void processListAIR( String sendEmails, List<SystemUserModel> userList )
	{
		// objects for logging in database
		//
		AsyncProcessingLogModel asyncLogModel   = new AsyncProcessingLogModel();
		AsyncProcessManager asyncRequestManager = new AsyncProcessManager();
		
		for ( int i = 0; i < userList.size(); i++ )
		{
			SystemUserModel userModel =  userList.get( i );
			logger.info( "Found: " + userModel.getFullName() + ", Orgname: " + userModel.getOrgName() + " SCACCODE: " 
					     + userModel.getStatus() + ", Email: " + userModel.getEmail() );
			
			if ( sendEmails.equalsIgnoreCase( "true") )
			{
				try
				{
				// log sent emails
				//
				asyncLogModel.init( "QUARTZ", "PUBLIC", "EMAIL", "ADMIN", 
									"Attempting to send email to " + userModel.getEmail(), "0.0.0.0" );
				
				asyncLogModel = asyncRequestManager.createAsyncProcessLog(asyncLogModel);
								
				
				//EmailUtil.sendNoSubCCSFEmail( userModel.getContactFirstName(), userModel.getContactLastName(), userModel.getOrgName(), 
				//								  userModel.getStatus(), "CRT Submissions", userModel.getEmail() );
				
				// log success
				asyncRequestManager.logResult(asyncLogModel, true, "Email: " + userModel.getEmail() + " for not submitting for " + userModel.getOrgName(), 
						                      "doPasswordReset");
				}				
				catch ( Exception e )
				{
					logger.error( "Error With asyncLog Model: " + e );
				}
						                   
			}
		}
	}

}
