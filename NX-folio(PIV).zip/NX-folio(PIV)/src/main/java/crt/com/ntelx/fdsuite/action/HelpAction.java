package crt.com.ntelx.fdsuite.action;

import javax.servlet.http.HttpServletRequest;
import org.apache.commons.lang.RandomStringUtils;
import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.ActionMessages;
import com.freightdesk.fdcommons.ApplicationProperties;
import crt.com.ntelx.nxcommons.AuthenticationUtils;
import com.freightdesk.fdcommons.FDSuiteProperties;
import com.freightdesk.fdcommons.PasswordHasher;
import crt.com.ntelx.nxcommons.PasswordUtils;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;
import crt.com.ntelx.nxcommons.email.EmailUtil;
import com.freightdesk.fdfolio.useraccess.model.SystemUserModel;
import com.octo.captcha.module.servlet.image.SimpleImageCaptchaServlet;
import com.octo.captcha.module.servlet.SimpleSoundCaptchaServlet;
import org.apache.struts2.interceptor.ServletRequestAware;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.ServletActionContext;
import crt.com.ntelx.fdsuite.common.RequestDetails;
import org.apache.commons.lang.StringEscapeUtils;


public class HelpAction extends ActionSupport implements ServletRequestAware {

	HttpServletRequest request = ServletActionContext.getRequest();
	protected Logger logger = Logger.getLogger(getClass());
	SystemUserModel systemUser;
	PasswordHasher hasher = new PasswordHasher();
	
	private String domainUser;
	private String btnReset;
        private String jcaptcha;

	public String execute() throws Exception {
                request = ServletActionContext.getRequest();
                RequestDetails requestDetails = new RequestDetails(request);
	  
                logger.debug("HelpAction start.");
                
        
		btnReset = getBtnReset();
				
		// proceed to attempt password reset if button is pressed
		if ((btnReset != null) && (btnReset.length() > 0)) {
			// is password reset via email enabled in the system?			
			setJcaptcha(getJcaptcha().toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt"));
			if ( FDSuiteProperties.getProperty("ENABLE_SENDMAIL").equalsIgnoreCase( "true" ) ) {
				logger.debug("Password reset button pressed.");
				
				return doPasswordReset();
			} else {
				// inform the user that option is not available
				ActionMessages messages = new ActionMessages();
				
				addActionError("Password reset through your system email account is not currently enabled.  Please contact the help desk to find out when this feature will be available.");
			}
		} 
		return "display";
	}
	
	public String doPasswordReset() throws Exception {
                request = ServletActionContext.getRequest();
		systemUser = new SystemUserModel();
                
                systemUser.setDomainName(com.freightdesk.fdcommons.GlobalConstants.FAS_DOMAIN);
		systemUser.setUserId(getDomainUser().toUpperCase());
                
		// validate
		ActionMessages messages = new ActionMessages();
                
		actionMessages();
		
		
                if (hasActionErrors()){
			logger.debug("validation errors found.");
                        
			return "display";
		}
		
		// get user from database
		try {
			systemUser = AuthenticationUtils.retrieveUserInfo(com.freightdesk.fdcommons.GlobalConstants.FAS_DOMAIN, systemUser.getUserId());
			
			
			// if the systemUserId is 0 or null, the query did not return a value
			if(systemUser.getSystemUserId() < 1)
				throw new Exception();
			
			// does the user have email?
			if(systemUser.getEmail() == null)
				
                                addActionError("No email associated with account.  Unable to reset password.  Please call the help desk.");
		} catch (Exception ex) {
			
                        addActionError("Failed to find username in the database.  Please check spelling and try again.");
		}
		
		
                if (hasActionErrors()){
			logger.debug("failed to find user in database.  returning to page.");
			
			return "display";
		}
		
		// is the user active?
		if(!systemUser.getIsActive().equalsIgnoreCase("Y")) {
			
                        addActionError("Account not currently active.  Unable to reset password.  Please call the help desk.");
		}
			
		// has the user locked their account?
		int failedLoginLimit = Integer.parseInt(ApplicationProperties.getProperty("password.allowedFailedLogins"));
		
		if(systemUser.getNumFailedLogin() > failedLoginLimit) {
			  
                          addActionError("Account locked due to number of failed login attempts.  Unable to reset password.  Please call the help desk.");
		}
		
		
                if (hasActionErrors()){
			logger.debug("Password reset is not allowed for account.  returning to page.");
			
			return "display";
		}
		
		// make a new random password with upper, lower, special and number
		char[] charList = {'!','%','@','-','+','.','?','='};
		String newPass = RandomStringUtils.randomAlphabetic(4) + RandomStringUtils.random(1,charList) + RandomStringUtils.randomAlphabetic(2) + RandomStringUtils.random(1,charList) + RandomStringUtils.randomAlphabetic(2) + RandomStringUtils.randomNumeric(2);
		logger.debug(newPass);

		// objects for logging in database
		AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
		AsyncProcessManager asyncRequestManager = new AsyncProcessManager();
		
		// update user password history
		if(!PasswordUtils.updatePasswordHistory(systemUser.getSystemUserId(), systemUser.getDomainName(), systemUser.getUserId())) {
			logger.error("Failed to update password history for user "+systemUser.getDomainName()+"."+systemUser.getUserId());
			
                        addActionError("Error while updating password history.  Your password has not been reset.  If this is a continuing issue, contact the help desk");
			return "display";
		}
		
		// update password, set the temporary password flag to true
		if(!PasswordUtils.updatePassword(newPass,systemUser.getSystemUserId(),systemUser.getUserId(),true)) {
			logger.error("Failed to update password to temporary for user "+systemUser.getDomainName()+"."+systemUser.getUserId());
			
                        addActionError("Error while updating password.  Your password has not been reset.  If this is a continuing issue, contact the help desk");
			return "display";
		}
		
		try {
			// log sent emails
			asyncLogModel.init(systemUser.getUserId(), systemUser.getDomainName(), "EMAIL", "ADMIN", "Attempting to send email to " + systemUser.getEmail(),request.getRemoteAddr());
			asyncLogModel = asyncRequestManager.createAsyncProcessLog(asyncLogModel);
			
			EmailUtil.sendPassResetEmail( systemUser.getContactFirstName(), newPass, "FAS Password Reset", systemUser.getEmail() );
			
			// log success
			asyncRequestManager.logResult(asyncLogModel, true, "Successfully sent temp password to " + systemUser.getEmail(), "doPasswordReset");
			
			
			
			
		} catch (Exception ex) {
			
                        addActionError("Error occurred while emailing temporary password.  Please reset password again.  If this is a continuing issue, contact the help desk"); 
			
			logger.error("Exception Error while updating user. Returning to page: " + ex.getMessage());
			asyncRequestManager.logResult(asyncLogModel, false, "Failed to send email to " + systemUser.getEmail(), "doPasswordReset");
			
			return "display";
		}
		
		// set success message
		
		addActionMessage(getText("help.success"));
        request.setAttribute("isCorrect","true");
		
		return "display";
	}
	
	public String actionMessages() throws Exception {
                
		
		String userCaptchaResponse = request.getParameter("jcaptcha");
		domainUser = getDomainUser().toUpperCase();
		
		//parse the domainUser value and set the values
		try {
			
                        systemUser.setDomainName(com.freightdesk.fdcommons.GlobalConstants.FAS_DOMAIN);
                        systemUser.setUserId(getDomainUser().toUpperCase());
			
		} catch (Exception ex) {
			logger.debug("failed to parse the domaina and username");
                        
                        addActionError("Username is not in the correct format.  Check the spelling and try again.");
			
		}
		
		//validate captcha
		boolean captchaPassed = SimpleImageCaptchaServlet.validateResponse(request, userCaptchaResponse)
                        || SimpleSoundCaptchaServlet.validateResponse(request, userCaptchaResponse);
		if (!captchaPassed) {
			logger.debug("captcha validation failed.");
                        
                        addActionError("Captcha verification failed.  Please try again.");
			
                        request.setAttribute("isCorrect","false");
		} 
		return "validated";
	}
	
	public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
            
    public String getJcaptcha() {
        if (jcaptcha == null) {
            return "";
        } else {
            return StringEscapeUtils.escapeHtml(jcaptcha.toUpperCase());
        }
    }
	
	public void setJcaptcha(String jcaptcha) {
		this.jcaptcha = jcaptcha;
	}
	
	public String getDomainUser() {
		return domainUser;
	}

	public void setDomainUser(String domainUser) {
		this.domainUser = domainUser;
	}

	public String getBtnReset() {
		return btnReset;
	}

	public void setBtnReset(String btnReset) {
		this.btnReset = btnReset;
	}
	
	public void reset () {
	        domainUser = "";
	        btnReset = "";
	}
}
