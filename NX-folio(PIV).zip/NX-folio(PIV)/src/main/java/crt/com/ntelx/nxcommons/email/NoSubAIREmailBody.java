package crt.com.ntelx.nxcommons.email;

public class NoSubAIREmailBody extends AbstractEmailBody
{
	private String firstName = "";
	private String lastName  = "";
	private String orgName   = "";
	private String scaccode  = "";
	
	public String getFirstName()
	{
		return firstName;
	}
	public void setFirstName(String firstName)
	{
		this.firstName = firstName;
	}
	public String getLastName()
	{
		return lastName;
	}
	public void setLastName(String lastName)
	{
		this.lastName = lastName;
	}
	public String getOrgName()
	{
		return orgName;
	}
	public void setOrgName(String orgName)
	{
		this.orgName = orgName;
	}	
	public String getScaccode()
	{
		return scaccode;
	}
	public void setScaccode(String scaccode)
	{
		this.scaccode = scaccode;
	}
	
	public String getBody() {
		String body = null;

		body = replaceGDPattern(template, "<firstname>", firstName );
		body = replaceGDPattern(body,     "<lastname>",  lastName  );
		body = replaceGDPattern(body,     "<scaccode>",  scaccode  );
		body = replaceGDPattern(body,     "<orgname>",   orgName   );
		
		return body;
	}
}
