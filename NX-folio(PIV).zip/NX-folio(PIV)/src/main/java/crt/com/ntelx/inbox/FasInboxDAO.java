package crt.com.ntelx.inbox;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import crt.com.freightdesk.fdfolio.dao.HAWBDaoListStub;
import crt.com.ntelx.awb.model.HAWB;

public class FasInboxDAO
{
	private static Map<Long, FaEntry> inboxMap =  CookedDaoListStub.getRandomInbox(); //InboxDaoListStub.getRandomInbox();
	
	public List<FaEntry> getEntriesOrderedDate()
	{				
		return new ArrayList<FaEntry>( inboxMap.values() );
	}
	
	public FaEntry getEntryByID( long id )
	{
		return inboxMap.get( id );
	}
	
}
