package crt.com.ntelx.nxcommons.reporting;

import org.apache.log4j.Logger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdcommons.OptionBean;

public class OptionCollectionDAO extends BaseDao {

	protected Logger logger = Logger.getLogger("OptionCollectionDAO");
	
	public OptionCollectionDAO() {
		super();
	}

	public List<OptionBean> getOptionCollectionFromDB(String query) {
		Connection connection = null;
		PreparedStatement pStmt = null;
		ResultSet rs = null;
		List<OptionBean> optionCollection = new ArrayList<OptionBean>();

		if (query != null && !query.trim().equalsIgnoreCase("")) {
			try {
				logger.debug("query: " + query);
				connection = getConnection();
				pStmt = connection.prepareStatement(query);
				for (rs = pStmt.executeQuery(); rs.next();) {
					// query must have LABEL and VALUE in expression
					optionCollection.add(new OptionBean(rs.getString("LABEL"), rs.getString("VALUE")));
				}
			} catch (Exception ex) {
				//logger.error("Failed to load OptionBeans from database.");
				//ex.printStackTrace();
				logger.error("Exception Failed to load OptionBeans from database: " + ex.getMessage());
			} finally {
				ConnectionUtil.closeResources(connection, pStmt, rs);
			}
		} else {
			logger.warn("query is not set, did not lookup.");
		}
		return optionCollection;
	}

}
