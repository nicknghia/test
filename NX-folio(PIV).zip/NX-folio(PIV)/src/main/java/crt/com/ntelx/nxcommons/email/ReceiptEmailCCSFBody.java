package crt.com.ntelx.nxcommons.email;

import java.util.ArrayList;
import java.util.List;

public class ReceiptEmailCCSFBody extends AbstractEmailBody
{
	private String       contact  = "";
	private List<String> certList = new ArrayList<String>();
	
	
	
	public String getContact()
	{
		return contact;
	}

	public void setContact(String contact)
	{
		this.contact = contact;
	}

	public List<String> getCertList()
	{
		return certList;
	}

	public void setCertList(List<String> certList)
	{
		this.certList = certList;
	}

	public String getBody() 
	{
		String body = null;

		body = replaceGDPattern(template, "<contact>",   contact  );
		
		String htmlCerts = createCertListHTML( certList );
		body = replaceGDPattern( body,   "<certlist>",  htmlCerts );	

		return body;
	}
	
	protected String createCertListHTML( List<String> certList  )
	{
		if ( certList == null || certList.size() < 1 )
		{
			return "Zero Certification Numbers";
		}
		
		StringBuffer buf = new StringBuffer();
				
		buf.append( "<ul>\n" );
		for ( String cert : certList )
		{
			buf.append( "   <li>" + cert + "</li>\n" );
		}
		buf.append( "</ul>\n" );
		
		return buf.toString();
	}
}
