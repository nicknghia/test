package crt.com.ntelx.query.model;

import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Table(name="QTPARAMETER")
public class SavedQueryParameterBean {

	public SavedQueryParameterBean () {};
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "QTPARAMETERID")
	@SequenceGenerator(name = "QTPARAMETERID", sequenceName = "QTPARAMETERID")
	private long qtParameterID;
	
	@JoinColumn(name = "queryToolID")
    @ManyToOne(optional = true)
    private SavedQueryModel savedQueryModel;
	
	@Column(name="QTPARMTYPECODE")
	private String qtParmeterTypeCode;
	
	@Column(name="QTPARMVALUE")
	private String qtParmeterValue;
	
	@Column(name="CREATEUSERID")
	private String createUserID;
	
	@Column(name = "CREATETIMESTAMP")
	private Date createTimeStamp;
	
	@Column(name = "LASTUPDATEUSERID")
	private String lastUpdateUserID;

	@Column(name = "LASTUPDATETIMESTAMP")
	private Date lastUpdateTimeStamp;
	
	@Column(name = "STATUS")
	private String status;

	/**
	 * @return the qtParameterID
	 */
	public long getQtParameterID() {
		return qtParameterID;
	}

	/**
	 * @param qtParameterID the qtParameterID to set
	 */
	public void setQtParameterID(long qtParameterID) {
		this.qtParameterID = qtParameterID;
	}

	/**
	 * @return the savedQueryModel
	 */
	public SavedQueryModel getSavedQueryModel() {
		return savedQueryModel;
	}

	/**
	 * @param savedQueryModel the savedQueryModel to set
	 */
	public void setSavedQueryModel(SavedQueryModel savedQueryModel) {
		this.savedQueryModel = savedQueryModel;
	}

	/**
	 * @return the qtParmeterTypeCode
	 */
	public String getQtParmeterTypeCode() {
		return qtParmeterTypeCode;
	}

	/**
	 * @param qtParmeterTypeCode the qtParmeterTypeCode to set
	 */
	public void setQtParmeterTypeCode(String qtParmeterTypeCode) {
		this.qtParmeterTypeCode = qtParmeterTypeCode;
	}

	/**
	 * @return the qtParmeterValue
	 */
	public String getQtParmeterValue() {
		return qtParmeterValue;
	}

	/**
	 * @param qtParmeterValue the qtParmeterValue to set
	 */
	public void setQtParmeterValue(String qtParmeterValue) {
		this.qtParmeterValue = qtParmeterValue;
	}

	/**
	 * @return the createUserID
	 */
	public String getCreateUserID() {
		return createUserID;
	}

	/**
	 * @param createUserID the createUserID to set
	 */
	public void setCreateUserID(String createUserID) {
		this.createUserID = createUserID;
	}

	/**
	 * @return the createTimeStamp
	 */
	public Date getCreateTimeStamp() {
		return createTimeStamp;
	}

	/**
	 * @param createTimeStamp the createTimeStamp to set
	 */
	public void setCreateTimeStamp(Date createTimeStamp) {
		this.createTimeStamp = createTimeStamp;
	}

	/**
	 * @return the lastUpdateUserID
	 */
	public String getLastUpdateUserID() {
		return lastUpdateUserID;
	}

	/**
	 * @param lastUpdateUserID the lastUpdateUserID to set
	 */
	public void setLastUpdateUserID(String lastUpdateUserID) {
		this.lastUpdateUserID = lastUpdateUserID;
	}

	/**
	 * @return the lastUpdateTimeStamp
	 */
	public Date getLastUpdateTimeStamp() {
		return lastUpdateTimeStamp;
	}

	/**
	 * @param lastUpdateTimeStamp the lastUpdateTimeStamp to set
	 */
	public void setLastUpdateTimeStamp(Date lastUpdateTimeStamp) {
		this.lastUpdateTimeStamp = lastUpdateTimeStamp;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	public SavedQueryParameterBean(String qtParmeterTypeCode,
			String qtParmeterValue) {
		super();
		this.qtParmeterTypeCode = qtParmeterTypeCode;
		this.qtParmeterValue = qtParmeterValue;
	}
	
	
	
}
