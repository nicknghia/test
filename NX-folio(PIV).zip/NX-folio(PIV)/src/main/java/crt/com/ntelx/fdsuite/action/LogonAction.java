/**
 * Copyright (c) 2000-2002 NTELX
 *  All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with NTELX.
 *
 *
 

 */

package crt.com.ntelx.fdsuite.action;

import java.util.HashMap;

import javax.security.auth.login.AccountExpiredException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
//import org.apache.struts.action.Action;
//import org.apache.struts.action.ActionErrors;
//import org.apache.struts.action.ActionForm;
//import org.apache.struts.action.ActionForward;
//import org.apache.struts.action.ActionMapping;
//import org.apache.struts.action.ActionMessage;
//import org.apache.struts.action.ActionMessages;

import crt.com.ntelx.fdsuite.common.RequestDetails;
//import crt.com.ntelx.fdsuite.form.LogonForm;
import crt.com.ntelx.nxcommons.AuthenticationUtils;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.InvalidUserException;
import com.freightdesk.fdcommons.LicenseProperties;
import com.freightdesk.fdcommons.PasswordExpiredException;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.UserNotActiveException;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;

/**
 * The logon Struts Action class for LCP Application.
 * 
 * This class is used in conjunction with logon.jsp and {@link com.ntelx.fdsuite.form.common.LogonForm LogonForm}.
 * 
 * @author Amrinder Arora
 */
//public class LogonAction extends Action {
	/** A logger */
//	protected Logger logger = Logger.getLogger(getClass());
//
//	/**
//	 * Processes all requests for the logon.do URL.
//	 * 
//	 * <UL>
//	 * <LI>If the request is from a different page, and the user is not currently logged in, it forwards the user to the login page.
//	 * <LI>If the request corresponds to user's clicking Login button, then it validates the credentials, and initializes the session for the user and forwards the user to the home page. If the user's
//	 * credentials cannot be validated, it gives an error message and forwards the user back to the login page.
//	 * <LI>If the request is for Logout, it invalidates user's current session, and forwards the user back to the login page.
//	 * </UL>
//	 */
//	public final ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response) {
//		logger.debug("beginning logon action");
//
//		LogonForm logonForm = (LogonForm) form;
//
//		// If the request is for logout
//		String action = request.getParameter("action");
//		if ((action != null) && (action.equalsIgnoreCase("logout"))) {
//			return respondBtnLogout(mapping, logonForm, request, response);
//		}
//                
//                // plugins are handled separately.  do not invalidate the session.
//                if ((action != null) && (action.equalsIgnoreCase("plugins"))) {
//			return displayPlugins(mapping, logonForm, request, response);
//		}
//
//		// If request is for fresh login, validate the product license before validating credentials.
//		if (!hasValidLicense()) {
//			logger.debug("License for NXsuite is not valid or expired, redirecting to login page");
//			ActionErrors errors = new ActionErrors();
//			errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("error.licenseExpired"));
//			this.saveErrors(request, errors);
//			return mapping.findForward("licenseExpired");
//		}
//		
//		// check if browser version is supported
//		RequestDetails requestDetails = new RequestDetails(request);
//		if (requestDetails.browserNotSupported()) {
//			logger.debug(requestDetails);
//			// forward to not supported page
//			return mapping.findForward("help");
//		}
//
//		// If the request is for login
//		if ((logonForm.getBtnLogin() != null) && (logonForm.getBtnLogin().length() > 0)) {
//			// check for valid token
//			if(isInvalidToken(mapping,request))
//			  return displayPage(mapping, logonForm, request, response);
//			
//			return respondBtnLogin(mapping, logonForm, request, response);
//		}
//
//		// if request is just a brand new one for this page
//		return displayPage(mapping, logonForm, request, response);
//	}
//
//	public boolean hasValidLicense() {
//		return LicenseProperties.isProductLicensed("FDSuite");
//	}
//
//	/**
//	 * A method that should be called to display the login page
//	 */
//	public final ActionForward displayPage(ActionMapping mapping, LogonForm logonForm, 
//                HttpServletRequest request, HttpServletResponse response) {
//		logger.debug("preparing to display page");
//
//		logonForm.setBtnLogin(null);
//		
//		// invalidating any active sessions before display
//		HttpSession session = request.getSession(false);
//		if (session != null) {
//			logger.debug("!! invalidating active session");
//
//			SessionStore store = SessionStore.getInstance(session);
//			store.invalidateSessions(request);
//		}
//		
//		// save request token
//		saveToken(request);
//		
//		return mapping.findForward("display");
//	}
//        
//        /**
//	 * A method that should be called to display the plugins page
//	 */
//	public final ActionForward displayPlugins(ActionMapping mapping, LogonForm logonForm, HttpServletRequest request, HttpServletResponse response) {
//		logger.info("preparing to display plugins page");
//
//		logonForm.setBtnLogin(null);
//		
//		return mapping.findForward("display");
//	}
//
//	/**
//	 * Processes the log in action.
//	 */
//	private final ActionForward respondBtnLogin(ActionMapping mapping, LogonForm logonForm, HttpServletRequest request, HttpServletResponse response) {
//		String userId = logonForm.getUserId();
//		if (userId != null)
//			userId = userId.toUpperCase();
//		String password = logonForm.getPassword();
//		logger.debug("userId, password retrieved from form: " + userId);
//
//		return respondCredentials(mapping, request, response, userId, password);
//	}
//
//	/**
//	* Method to retreive user credentials and load in session store 
//    */
//	private ActionForward respondCredentials(ActionMapping mapping, HttpServletRequest request, HttpServletResponse response, String userId, String password) {
//		String userName = null;
//		String domainName = null;
//		AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
//		AsyncProcessManager asyncManager = new AsyncProcessManager();
//
//		/**
//		 * The following try catch blocks are sequenced so that different error conditions can be handled differently.
//		 */
//		try {
//			// separates the userName and domainName from userId
//			int index = userId.indexOf('.');
//			userName = userId.substring(index + 1, userId.length());
//			domainName = userId.substring(0, index);
//			// The User Name column has max length of 8 characters.
//			if (userName.length() > 8) {
//				logger.debug("User name " + userName + " will be truncated to 8 characters in length.");
//				userName = userName.substring(0, 8);
//				// rebuild the userId
//				userId = domainName + "." + userName;
//			}
//
//		} catch (Exception e) {
//			logger.error("Exception in parsing username and domain, " + e);
//			setActionMessage(request, new String[] { "error.login.generic" });
//			return mapping.findForward("display");
//		}
//
//		try {
//			// Record attempted logins in the ASYNCPROCESSINGLOG table
//			asyncLogModel.init(userName, domainName, "LOGIN", "SECURITY", "In process login", request.getRemoteAddr());
//
//			// add the browser details to the login
//			RequestDetails requestDetails = new RequestDetails(request);
//			asyncLogModel.setBrowser(requestDetails.getBrowser().toUpperCase());
//			asyncLogModel.setBrowserVersion(requestDetails.getVersion());
//			asyncLogModel = asyncManager.createAsyncProcessLog(asyncLogModel);
//
//			Credentials credentials = AuthenticationUtils.getCredentials(userName, password, domainName, request.getRemoteAddr());
//			
//			HttpSession session = request.getSession();
//			
//			// Record successful login in the ASYNCPROCESSINGLOG table
//			asyncManager.logResult(asyncLogModel, true, "Successful login", "respondCredentials");
//
//			// only for debugging purposes
//			session.setAttribute("TimeUserLoggedIn", new java.util.Date());
//
//			// Stores the credentials in the SessionStore
//			if (credentials.getDateFormat() == null || credentials.getDateFormat().equals(""))
//				credentials.setDateFormat("yyyy-MM-dd");
//			
//			SessionStore store = SessionStore.getInstance(session);
//			store.put(SessionKey.CREDENTIALS, credentials);
//
//			// Stores the access list in the SessionStore
//			HashMap<String, String> accessList = AuthenticationUtils.getNxRolePermissionList(credentials.getRole());
//			store.put(SessionKey.ACCESS_CONTROL_LIST, accessList);
//
//			AuthenticationUtils.updateLastLoginTimestamp(credentials.getSystemUserId());
//			
//			return getSuccessPath(request, mapping, credentials, response);
//		}
//		// catches all exceptions and logs
//		// all business exceptions are logged with logger.debug, system exceptions with logger.error
//		catch (UserNotActiveException unaEx) {
//			logger.info("UserAccess " + userId + ". Login Error " + "User Not Active.");
//			logger.error("respondBtnCredentials(): UserNotActiveException");
//			asyncManager.logResult(asyncLogModel, false, "Failed login due to user not being active.", "UserNotActiveException");
//			setActionMessage(request, new String[] { "error.login.userNotActive" });
//		} catch (PasswordExpiredException peEx) {
//			logger.info("UserAccess " + userId + ". Login Error " + "Password Expired.");
//			logger.error("threw PasswordExpiredException");
//			asyncManager.logResult(asyncLogModel, false, "Failed login due to password expiration.", "PasswordExpiredException");
//			setActionMessage(request, new String[] { "jsp.login.message" });
//		} catch (InvalidUserException ivEx) {
//			if (ivEx.getMessage().equals("-1")) {
//				logger.info("UserAccess " + userId + ". Login Error " + "Username Does Not Exist.");
//				asyncManager.logResult(asyncLogModel, false, "Failed login due to unknown user id.", "InvalidUserException");
//				setActionMessage(request, new String[] { "error.login.generic" });
//			} else {
//				//
//				logger.debug("UserAccess " + userId + ". Login Error " + "Invalid Password.");
//				asyncManager.logResult(asyncLogModel, false, "Failed login due to invalid password.", "InvalidUserException");
//				setActionMessage(request, new String[] { "error.login.generic" });
//			}
//		} catch (AccountExpiredException auEx) {
//			logger.error("UserAccess " + userId + ". Login Error " + "Account Locked.");
//			asyncManager.logResult(asyncLogModel, false, "Failed login due to excessive failed login attempts.", "AccountExpiredException");
//			setActionMessage(request, new String[] { "error.login.failedLoginExceeded" });
//		} catch (RuntimeException ex) {
//			logger.error("respondBtnCredentials(): ConnectionException", ex);
//			asyncManager.logResult(asyncLogModel, false, "Failed login due to runtime exception.", "RuntimeException");
//			setActionMessage(request, new String[] { "error.login.connectionFailed" });
//		} catch (Exception systemException) {
//			logger.error("respondBtnCredentials(): SystemException", systemException);
//			asyncManager.logResult(asyncLogModel, false, "Failed login due to system exception.", "systemException");
//			setActionMessage(request, new String[] { "error.serverexception" });
//		}
//		return mapping.findForward("display");
//	}
//
//	/**
//	 * Gets the path based upon the request.
//	 */
//	protected ActionForward getSuccessPath(HttpServletRequest request, ActionMapping mapping, Credentials credentials, HttpServletResponse response) {
//		logger.debug("determining welcome page");
//		
//		// reset token since request is complete
//		resetToken(request);
//
//		if (credentials.getLastLoginTime() == null)
//			return mapping.findForward("changePassword");
//		else
//			return mapping.findForward("userHome");
//	}
//
//	/**
//	 * Processes the log out action.
//	 */
//	public final ActionForward respondBtnLogout(ActionMapping mapping, LogonForm logonForm, HttpServletRequest request, HttpServletResponse response) {
//		logger.debug("respondBtnLogout: begin()");
//		HttpSession session = request.getSession();
//		// Variables for ASYNCPROCESSINGLOG
//		AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
//		AsyncProcessManager asyncManager = new AsyncProcessManager();
//		SessionStore store = SessionStore.getInstance(session);
//		Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
//		try {
//			// Log session logouts in the ASYNCPROCESSINGLOG table
//			asyncLogModel.init(credentials.getUserId(), credentials.getDomainName(), "LOGOUT", "SECURITY", "In process logout", request.getRemoteAddr());
//			asyncLogModel = asyncManager.createAsyncProcessLog(asyncLogModel);
//			// invalidates the session
//			store.invalidateSessions(request);
//			// record success in the ASYNCPROCESSINGLOG table
//			asyncManager.logResult(asyncLogModel, true, "Successful logout of user " + credentials.getDomainName() + "." + credentials.getUserId(), "respondBtnLogout");
//		} catch (Exception ex) {
//			asyncManager.logResult(asyncLogModel, false, "Failed logout of user, unable to read credentials", "Exception");
//			// logger.error ("Unexpected Exception in logout", ex);
//		}
//		// sends the user back to the login page
//		return displayPage(mapping, logonForm, request, response);
//	}
//
//	public void setActionMessage(HttpServletRequest request, String[] messageKeyObject) {
//		int length = messageKeyObject.length;
//		logger.debug("messageKeyObject.length = " + length);
//		ActionMessage actionMessage = null;
//		switch (length) {
//		case 2:
//			logger.debug("messagekeyvalues" + messageKeyObject[0]);
//			actionMessage = new ActionMessage(messageKeyObject[0], (Object) messageKeyObject[1]);
//			break;
//		case 3:
//			actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2]);
//			break;
//		case 4:
//			actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3]);
//			break;
//		case 5:
//			actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3], messageKeyObject[4]);
//			break;
//		default:
//			actionMessage = new ActionMessage(messageKeyObject[0]);
//		}
//
//		ActionMessages messages = new ActionMessages();
//		messages.add(ActionMessages.GLOBAL_MESSAGE, actionMessage);
//		this.saveMessages(request, messages);
//		logger.debug("message has been set on request");
//	}
//	
//	private boolean isInvalidToken(ActionMapping mapping, HttpServletRequest request) {
//		if (isTokenValid(request))
//			return false;
//
//		logger.info("Form token is invalid");
//		setActionMessage(request, new String[] { "message.invalidSource" });
//		return true;
//	}

//}
