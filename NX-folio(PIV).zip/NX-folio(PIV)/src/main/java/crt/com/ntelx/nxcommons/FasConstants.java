package crt.com.ntelx.nxcommons;

public class FasConstants {
	// version
	public static final String version = "Version 4.2";
	//public static final String version = "v4.1 07/30/2012";
	
	// event categories
	public static final String carCategory = "CAR";
	public static final String inbCategory = "INB";
	public static final String iacCategory = "IAC";
	public static final String icsfCategory = "ICSF";
	public static final String shipCategory = "SHIP";

	// event types
	public static final String carType = "CAR1";
	public static final String carUploadType = "CAR2";
	public static final String inbType = "INB1";
	public static final String inbUploadType = "INB2";
	public static final String iacType = "IAC1";
	public static final String iacUploadType = "IAC2";
	public static final String icsfType = "ICSF1";
	public static final String icsfUploadType = "ICSF2";
	public static final String stdType = "STD1";
	public static final String stdUploadType = "STD2";
	public static final String cocType = "COC1";
	public static final String cocUploadType = "COC2";
	public static final String arType = "AR1";
	public static final String arUploadType = "AR2";
	public static final String shipType = "SHIP1";
	public static final String shipUploadType = "SHIP2";
	public static final String genInfoType = "GI1";
	public static final String genInfoUploadType = "GI2";

	// eventhome vars
	public static final String addCar = "AddCarEvent";
	public static final String addInb = "AddInbEvent";
	public static final String addIac = "AddIacEvent";
	public static final String addIcsf = "AddIcsfEvent";
	public static final String addStd = "AddStdEvent";
	public static final String addCoc = "AddCocEvent";
	public static final String addAr = "AddArEvent";
	public static final String addShip = "AddShipEvent";
	public static final String addGI = "AddGenInfoEvent";

	// Excel Template Sheet names
	//
	public static final String INTER_INBOUND_SHEETNAME = "International Inbound template";
	public static final String AIR_CARRIER_SHEETNAME = "Aircraft Operator, Air Carrier";
	public static final String IAC_SHEETNAME = "CCSF-IACs";
	public static final String GENERAL_INFO_SHEETNAME = "General Information Data";
	public static final String ALARM_RESOLUTION_SHEETNAME = "Alarm Resolution Data";
	public static final String CHAIN_OF_CUSTODY_SHEETNAME = "Chain of Custody Data";
	public static final String SCREEN_THROUGHPUT_SHEETNAME = "Screening Throughput Data";
	public static final String ICSF_SHEETNAME = "CCSF-ICSF (Non-IAC)";
	public static final String SHIPPER_SHEETNAME = "CCSF-Shipper (Non-IAC)";

	// CCSF-ICSF (Non-IAC)

	// Current Version, used in 50%, 75%, 100% conversion
	//
	public static final String CUR_VERSION = "3";
	public static final String LEGACY_50_PERC_VERSION = "1";
	public static final String LEGACY_75_PERC_VERSION = "2";
	
	// Date format
	public static final String dateTimeFormat = "MM/dd/yyyy, HH:mm:ss";
	public static final String simpleDateFormat = "MM/dd/yyyy";
}
