package crt.com.ntelx.servlets;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileNotFoundException;
import java.io.InputStream;
import java.io.OutputStream;
import java.sql.SQLException;
import java.util.logging.Level;
//import org.apache.struts.Globals;
//import org.apache.struts.action.ActionErrors;
//import org.apache.struts.action.ActionMessage;
//import org.apache.struts2.interceptor.ServletRequestAware; //binh add

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;

import crt.com.freightdesk.fdfolio.dao.TemplateUploadDAO;
import crt.com.freightdesk.fdfolio.setup.TemplateUploadAction;
import crt.com.freightdesk.fdfolio.setup.model.TemplateUploadModel;

/*
 * For security, downloads are set only to the downloads directory in FDfolio-runtime
 */
public class DownloadServlet extends HttpServlet {

	private static final long serialVersionUID = 1L;

	protected Logger logger = Logger.getLogger(getClass());

	/** Path to FDFolio home */
	protected String downloadDir = System.getProperty("RUNTIME_HOME")
			+ File.separator + "downloads" + File.separator;

	public void init() throws ServletException {
		super.init();
	}

	/** Responds to a post request. Delegates to #doGet. */
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		logger.debug("doPost(): begin, delegating to doGet");
		doGet(request, response);
	}

	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException, FileNotFoundException {

		HttpSession session = request.getSession(false);
		SessionStore store = SessionStore.getInstance(session);
		Credentials credentials = (Credentials) store
				.get(SessionKey.CREDENTIALS);

		// check for active credentials. In other words, make sure you are
		// logged into the application
			String param = request.getParameter("filename");
			String rawPath = downloadDir + param;
			boolean isTemplate = TemplateUploadAction.usTemplateFileName
					.equals(param)
					|| TemplateUploadAction.nonusTemplateFileName.equals(param)
					|| TemplateUploadAction.iacTemplateFileName.equals(param)
					|| TemplateUploadAction.icsfTemplateFileName.equals(param)
					|| TemplateUploadAction.shipTemplateFileName.equals(param);

			File dlFileObject = new File(rawPath);
			String dlFileName = dlFileObject.getName();

			response.setContentType("application/x-download");
			response.setHeader("Content-Disposition", "attachment; filename="
					+ dlFileName);

			// to make sure we are not leaving the download directory
			// (../../someFile.txt) re-create the file path with only the file
			// name
			String securePath = downloadDir + dlFileName;

			if (new File(securePath).exists() == false && !isTemplate) {
				logger.error("File " + securePath + " does not exist");
				response.sendError(HttpServletResponse.SC_NOT_FOUND);  /// add return and interceptor...
				throw new FileNotFoundException();
			}

			InputStream in;
			OutputStream os = response.getOutputStream();
			byte[] bytes = new byte[1024];
			

			logger.debug("downloading " + securePath);
			try {

				if (isTemplate) {
					TemplateUploadModel tempModel = null;
					TemplateUploadDAO tempDAO = new TemplateUploadDAO();
					if (TemplateUploadAction.usTemplateFileName.equals(param))
						tempModel = tempDAO
								.retrieveTemplate(TemplateUploadAction.usTemplateName);
					else if (TemplateUploadAction.nonusTemplateFileName
							.equals(param))
						tempModel = tempDAO
								.retrieveTemplate(TemplateUploadAction.nonusTemplateName);
					else if (TemplateUploadAction.iacTemplateFileName
							.equals(param))
						tempModel = tempDAO
								.retrieveTemplate(TemplateUploadAction.iacTemplateName);
					else if (TemplateUploadAction.icsfTemplateFileName
							.equals(param))
						tempModel = tempDAO
								.retrieveTemplate(TemplateUploadAction.icsfTemplateName);
					else if (TemplateUploadAction.shipTemplateFileName
							.equals(param))
						tempModel = tempDAO
								.retrieveTemplate(TemplateUploadAction.shipTemplateName);

					if (tempModel != null) {

						bytes = tempModel.getTemplateData();
						os.write(bytes);
					} else {
						response.setHeader("Content-Disposition",
								"attachment; filename=" + "File_Not_Found");
					}
				} else {
					in = new FileInputStream(securePath);
					int read = 0;

					while ((read = in.read(bytes)) != -1) {
						os.write(bytes, 0, read);
					}
					in.close();
				}

				logger.debug("finishing preparing download stream, flushing output stream to browser");

				// os.flush();
				// recommend not to close output stream

			} catch (IOException ex) {
				logger.error("Failed to download file");
				response.sendError(HttpServletResponse.SC_NOT_FOUND);
			} catch (SQLException ex) {
				logger.error("Failed to download file");
				java.util.logging.Logger.getLogger(
						DownloadServlet.class.getName()).log(Level.SEVERE,
						null, ex);
			} finally {
				os.flush();
			}

	}

}
