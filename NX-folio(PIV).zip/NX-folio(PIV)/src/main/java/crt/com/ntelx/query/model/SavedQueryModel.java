/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 *
 */

package crt.com.ntelx.query.model;

import java.io.Serializable;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

/**
 * SavedQueryModel associated with QueryForm. This class is a
 * Value Object to transfer the data from presentation layer to the Database.
 * 
 * May have to transfer to DTO in the future.
 * 
 * @author Tom Chang
 */
@Entity
@Table(name="QUERYTOOL")
@NamedQueries({
	@NamedQuery(name = SavedQueryModel.deactivateQueryID, query = "update SavedQueryModel set status = '" + SavedQueryTransfer.inactiveStatus + "' where querytoolid = :" + SavedQueryModel.queryIDField)
})
public class SavedQueryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	public static final String deactivateQueryID = "DEACTIVATE_QUERY";
	public static final String queryIDField = "queryID";
	
	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "QUERYTOOLID")
	@SequenceGenerator(name = "QUERYTOOLID", sequenceName = "QUERYTOOLID")
	private long queryToolID;
	
	@Column(name="QUERYTOOLNAME")
	private String queryName;
	
	@Column(name="DESCRIPTION")
	private String description;
	
	@Column(name="CREATEUSERID")
	private String createUserID;
	
	@Column(name = "CREATETIMESTAMP")
	private Date createTimeStamp;
	
	@Column(name = "LASTUPDATEUSERID")
	private String lastUpdateUserID;

	@Column(name = "LASTUPDATETIMESTAMP")
	private Date lastUpdateTimeStamp;
	
	@Column(name = "STATUS")
	private String status;

    @OneToMany(mappedBy = "savedQueryModel", fetch = FetchType.EAGER, cascade = CascadeType.ALL)
    private Set<SavedQueryParameterBean> parameterList = new HashSet<SavedQueryParameterBean>();

	/**
	 * @return the queryToolID
	 */
	public long getQueryToolID() {
		return queryToolID;
	}

	/**
	 * @param queryToolID the queryToolID to set
	 */
	public void setQueryToolID(long queryToolID) {
		this.queryToolID = queryToolID;
	}

	/**
	 * @return the queryName
	 */
	public String getQueryName() {
		return queryName;
	}

	/**
	 * @param queryName the queryName to set
	 */
	public void setQueryName(String queryName) {
		this.queryName = queryName;
	}

	/**
	 * @return the description
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * @param description the description to set
	 */
	public void setDescription(String description) {
		this.description = description;
	}

	/**
	 * @return the createUserID
	 */
	public String getCreateUserID() {
		return createUserID;
	}

	/**
	 * @param createUserID the createUserID to set
	 */
	public void setCreateUserID(String createUserID) {
		this.createUserID = createUserID;
	}

	/**
	 * @return the createTimeStamp
	 */
	public Date getCreateTimeStamp() {
		return createTimeStamp;
	}

	/**
	 * @param createTimeStamp the createTimeStamp to set
	 */
	public void setCreateTimeStamp(Date createTimeStamp) {
		this.createTimeStamp = createTimeStamp;
	}

	/**
	 * @return the lastUpdateUserID
	 */
	public String getLastUpdateUserID() {
		return lastUpdateUserID;
	}

	/**
	 * @param lastUpdateUserID the lastUpdateUserID to set
	 */
	public void setLastUpdateUserID(String lastUpdateUserID) {
		this.lastUpdateUserID = lastUpdateUserID;
	}

	/**
	 * @return the lastUpdateTimeStamp
	 */
	public Date getLastUpdateTimeStamp() {
		return lastUpdateTimeStamp;
	}

	/**
	 * @param lastUpdateTimeStamp the lastUpdateTimeStamp to set
	 */
	public void setLastUpdateTimeStamp(Date lastUpdateTimeStamp) {
		this.lastUpdateTimeStamp = lastUpdateTimeStamp;
	}

	/**
	 * @return the status
	 */
	public String getStatus() {
		return status;
	}

	/**
	 * @param status the status to set
	 */
	public void setStatus(String status) {
		this.status = status;
	}

	/**
	 * @return the parameterList
	 */
	public Set<SavedQueryParameterBean> getParameterList() {
		return parameterList;
	}

	/**
	 * @param parameterList the parameterList to set
	 */
	public void setParameterList(Set<SavedQueryParameterBean> parameterList) {
		this.parameterList = parameterList;
	}

}
