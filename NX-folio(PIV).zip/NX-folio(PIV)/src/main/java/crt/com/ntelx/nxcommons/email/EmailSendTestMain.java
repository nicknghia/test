package crt.com.ntelx.nxcommons.email;

public class EmailSendTestMain
{
    
	public static void main( String args [ ] ) throws Exception
	{
		EmailUtil.sendPassResetEmail( "", "", "Test Email", "jhansford@ntelx.com" );
	}
}
