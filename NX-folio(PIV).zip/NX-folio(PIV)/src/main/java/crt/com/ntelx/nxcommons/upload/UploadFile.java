package crt.com.ntelx.nxcommons.upload;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.io.FileUtils;
import org.apache.log4j.Logger;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.PackagePart;
import org.apache.poi.xslf.XSLFSlideShow;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.xwpf.usermodel.XWPFDocument;
import org.apache.struts2.ServletActionContext;

import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.opensymphony.xwork2.ActionSupport;

import crt.com.freightdesk.fdfolio.common.IncludesUtil;

public class UploadFile extends ActionSupport{
	  
   protected static Logger logger = Logger.getLogger("crt.com.ntelx.nxcommons.upload.UploadFile");   
   private File fileUpload;
   private String fileUploadContentType;
   private String fileUploadFileName;
   private List<String> results;
   private String destPath;   
   private String loginTimeRoleMsg;
   HttpServletRequest request = ServletActionContext.getRequest();
   
   public String execute()
   {
      /* Copy file to a safe location */
   	 logger.info("Temp File name: " + fileUpload);
   	 logger.info("File name: " + fileUploadFileName);
      
	  destPath = System.getProperty("RUNTIME_HOME") + File.separator + "downloads" + File.separator;
	  request = ServletActionContext.getRequest();
	  HttpSession session = request.getSession(false);
      SessionStore store = SessionStore.getInstance(session);
	  Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
	  loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);
	  
      // POAM HttpOnly Secure
      HttpServletResponse response = (HttpServletResponse)ServletActionContext.getResponse();
      String secure = "";
      if (request.isSecure())
      {
        secure = "; Secure";
      }
      response.setHeader("SET-COOKIE", "JSESSIONID=" + request.getSession().getId()
                       + "; Path=" + request.getContextPath() + "; HttpOnly" + secure);	  
	  
      logger.info("Dest File Location:" + destPath);
        
      try{
     	    	 
     	 File destDir  = new File(destPath);
     	 
     	 if (!destDir.exists()) {
     	 	destDir.mkdirs();
     	 }
     	 
     	 File destFile  = new File(destPath, fileUploadFileName);

   	 	 logger.info("File size: " + destFile.length());
   	 	 
     	 
     	 if (destFile.length() > 2097152) {
     	 	 logger.info("File size: " + destFile.length());
	    	 addActionError("Error uploading " + fileUploadFileName + ". Maximum file size is 2,097,152 bytes");
	    	 return INPUT;
     	 }

     	 
     	 // Get log files for errors
     	 if (fileUploadFileName.equals("getServerLog.txt")) {
     		 String logPath = System.getenv("JBOSS_HOME") + File.separator + "standalone" + File.separator + "log" + File.separator;
         	 File logDir  = new File(logPath);
         	 File logFile  = new File(logDir, "server.log");

        	 FileUtils.copyFile(logFile, destFile);    // copy server.log to getServerLog.txt
     	 }
     	 else if (fileUploadFileName.equals("getStandaloneXml.txt")) {
     		 String logPath = System.getenv("JBOSS_HOME") + File.separator + "standalone" + File.separator + "configuration" + File.separator;
         	 File logDir  = new File(logPath);
         	 File logFile  = new File(logDir, "standalone.xml");

        	 FileUtils.copyFile(logFile, destFile);    // copy to getStandaloneXml.txt
     	 }
     	 else if (fileUploadFileName.equals("removeDebugFiles.txt")) {

        	 File fileToDelete = FileUtils.getFile(destPath + "getServerLog.txt");
        	 FileUtils.deleteQuietly(fileToDelete);

        	 fileToDelete = FileUtils.getFile(destPath + "getStandaloneXml.txt");
        	 FileUtils.deleteQuietly(fileToDelete);
     	 }
     	 else {

     		 try {
         		 FileInputStream fis = new FileInputStream(fileUpload);	    	     
	     		 XSSFWorkbook document = new XSSFWorkbook(fis);
	     		 
	     	     List<PackagePart> embeddedDocs = document.getAllEmbedds();

	             if (embeddedDocs != null && !embeddedDocs.isEmpty()) {    
	    	    	 logger.warn("Cannot upload " + fileUploadFileName + " with attachments");
	    	    	 addActionError("Cannot upload file: " + fileUploadFileName + ", with attachments");
	    	         return INPUT;
	    	     }	    	     
     		 }
    	     catch (Exception e1) {
    	         logger.warn("Excel Exception:" + e1.getMessage());   
    	     }

     		 try {
         		 FileInputStream fis = new FileInputStream(fileUpload);	    	     
	     		 XWPFDocument document = new XWPFDocument(fis);
	     		 
	     		 //listEmbeds (document);	     		 
	     	     List<PackagePart> embeddedDocs = document.getAllEmbedds();

	     	     if (embeddedDocs != null && !embeddedDocs.isEmpty()) {    
	    	    	 logger.warn("Cannot upload " + fileUploadFileName + " with attachments");
	    	    	 addActionError("Cannot upload file: " + fileUploadFileName + ", with attachments");
	    	         return INPUT;
	    	     }
      		 }
    	      catch (Exception e1) {
    	         logger.warn("Word Exception:" + e1.getMessage());   
    	     }

     		 try {
	     		 XSLFSlideShow document = new XSLFSlideShow(fileUpload.getAbsolutePath());
	     		 List<PackagePart> embeddedDocs = document.getAllEmbedds();

	     	     if (embeddedDocs != null && !embeddedDocs.isEmpty()) {    
	    	    	 logger.warn("Cannot upload " + fileUploadFileName + " with attachments");
	    	    	 addActionError("Cannot upload file: " + fileUploadFileName + ", with attachments");
	    	         return INPUT;
	    	     }
      		 }
    	     catch (Exception e1) {
    	         logger.warn("PPT Exception:" + e1.getMessage());   
    	     }
     		 
     			      		 
     		 FileUtils.copyFile(fileUpload, destFile);
	    	 

     		 addActionMessage("File: " + fileUploadFileName + " is uploaded successfully");
     	 }
    	 
      } catch (IOException e) {
         logger.warn("IOException:" + e.getMessage());
    	 addActionError("Error uploading " + fileUploadFileName );
         return ERROR;
      }

      return SUCCESS;
   }

   

	private static void listEmbeds (XWPFDocument doc) throws OpenXML4JException {

	    List<PackagePart> embeddedDocs = doc.getAllEmbedds();
	    if (embeddedDocs != null && !embeddedDocs.isEmpty()) {
	        Iterator<PackagePart> pIter = embeddedDocs.iterator();
	        while (pIter.hasNext()) {
	            PackagePart pPart = pIter.next();
	            logger.info("name:" + pPart.getPartName().getName() +", ");

	            logger.info(" - type:" + pPart.getContentType()+", ");
	        }
	    }
	}
	
	public void setFileUpload (File fileUpload) {
		this.fileUpload = fileUpload; 
	}

	public void setFileUploadContentType (String fileUploadContentType) {
		this.fileUploadContentType = fileUploadContentType; 
	}

	public void setFileUploadFileName (String fileUploadFileName) {
		this.fileUploadFileName = fileUploadFileName; 
	}

	public void setDestPath (String destPath) {
		this.destPath = destPath; 
	}

	public File getFileUpload () {
		return (this.fileUpload); 
	}

	public String getFileUploadContentType () {
		return (this.fileUploadContentType); 
	}

	public String getFileUploadFileName () {
		return (this.fileUploadFileName); 
	}

	public String getDestPath () {
		return (this.destPath); 
	}

	public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
}

