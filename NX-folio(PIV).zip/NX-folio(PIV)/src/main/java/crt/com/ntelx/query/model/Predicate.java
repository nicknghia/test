package crt.com.ntelx.query.model;

public enum Predicate {

	/*
	 * To change this template, choose Tools | Templates and open the template
	 * in the editor.
	 */

	/**
	 * 
	 * @author mbegley
	 */
	EQ("Equals"), NEQ("Not Equals"), LIKE("Like"), GT("Greater Than"), LT(
			"Less Than"), IN("In"), GTE("Greater Than or Equal"), LTE("Less Than or Equal");

	private String label;

	private Predicate(String label) {
		this.label = label;
	}

	public String getLabel() {
		return label;
	}
}
