package crt.com.ntelx.query.model;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Set;

import org.apache.commons.beanutils.*;

import com.freightdesk.fdcommons.Credentials;


public class SavedQueryTransfer{
	
	public static final String activeStatus = "ACTIVE";
	public static final String inactiveStatus = "INACTIVE";
	
	public enum SavedQueryProperties {
		queryToolID(SearchFilter.ValueDataType.STRING),
		queryName(SearchFilter.ValueDataType.STRING),
		description(SearchFilter.ValueDataType.STRING),
		qtParameterID(SearchFilter.ValueDataType.STRING),
		qtParmeterTypeCode(SearchFilter.ValueDataType.STRING),
		qtParmeterValue(SearchFilter.ValueDataType.STRING),
		createUserID(SearchFilter.ValueDataType.STRING),
		createTimeStamp(SearchFilter.ValueDataType.DATE),
		lastUpdateUserID(SearchFilter.ValueDataType.STRING),
		lastUpdateTimeStamp(SearchFilter.ValueDataType.DATE),
		status(SearchFilter.ValueDataType.STRING);
		
	private SearchFilter.ValueDataType type;
	
	private SavedQueryProperties(SearchFilter.ValueDataType type) {
		this.type = type;
	}

	public SearchFilter.ValueDataType getType() {
		return type;
	}	
	}    

	private static void makeGenericCriteria(SavedQueryModel model, String field, String value) {
		if (value != null && !value.isEmpty())
		{
			SavedQueryParameterBean criteria = new SavedQueryParameterBean(field, value);
			criteria.setCreateUserID(model.getCreateUserID());
			criteria.setCreateTimeStamp(model.getCreateTimeStamp());
			criteria.setLastUpdateUserID(model.getLastUpdateUserID());
			criteria.setLastUpdateTimeStamp(model.getLastUpdateTimeStamp());
			criteria.setStatus(SavedQueryTransfer.activeStatus);
			criteria.setSavedQueryModel(model);

			model.getParameterList().add(criteria);
			
		}
	}
	
	private static void makeBooleanCriteria(SavedQueryModel model, String field, Boolean value) {
		if (value)
		{
			SavedQueryParameterBean criteria = new SavedQueryParameterBean(field, "Y");
			criteria.setCreateUserID(model.getCreateUserID());
			criteria.setCreateTimeStamp(model.getCreateTimeStamp());
			criteria.setLastUpdateUserID(model.getLastUpdateUserID());
			criteria.setLastUpdateTimeStamp(model.getLastUpdateTimeStamp());
			criteria.setStatus(SavedQueryTransfer.activeStatus);
			criteria.setSavedQueryModel(model);
			
			model.getParameterList().add(criteria);
		}
	}
	
	private static void makeDateCriteria(SavedQueryModel model, String field, String value) {
		if (value != null && !value.isEmpty() && QueryModelTransfer.isValidDate(value)) 
		{
			SavedQueryParameterBean criteria = new SavedQueryParameterBean(field, value);
			criteria.setCreateUserID(model.getCreateUserID());
			criteria.setCreateTimeStamp(model.getCreateTimeStamp());
			criteria.setLastUpdateUserID(model.getLastUpdateUserID());
			criteria.setLastUpdateTimeStamp(model.getLastUpdateTimeStamp());
			criteria.setStatus(SavedQueryTransfer.activeStatus);
			criteria.setSavedQueryModel(model);
			
			model.getParameterList().add(criteria);
		}
	}

	private static void makeInCriteria(SavedQueryModel model, String field, String[] strings) {
		if (strings != null && strings.toString().length() != 0) 
		{
			SavedQueryParameterBean criteria;

			for (String value : strings)
			{
				criteria = new SavedQueryParameterBean(field, value);
				criteria.setCreateUserID(model.getCreateUserID());
				criteria.setCreateTimeStamp(model.getCreateTimeStamp());
				criteria.setLastUpdateUserID(model.getLastUpdateUserID());
				criteria.setLastUpdateTimeStamp(model.getLastUpdateTimeStamp());
				criteria.setStatus(SavedQueryTransfer.activeStatus);
				criteria.setSavedQueryModel(model);
				
				model.getParameterList().add(criteria);
			}
		}
	}
	
	private static void makeDisplayCriteria(SavedQueryModel model, String field, String[] strings) {
		if (strings != null && strings.toString().length() != 0) 
		{
			SavedQueryParameterBean criteria;

			String value = "";

			for (String values : strings)
			{
				value = value + ":" + values.trim();
			}
			
			value = value.substring(1, value.length());
			
			criteria = new SavedQueryParameterBean(field, value);
			criteria.setCreateUserID(model.getCreateUserID());
			criteria.setCreateTimeStamp(model.getCreateTimeStamp());
			criteria.setLastUpdateUserID(model.getLastUpdateUserID());
			criteria.setLastUpdateTimeStamp(model.getLastUpdateTimeStamp());
			criteria.setStatus(SavedQueryTransfer.activeStatus);
			criteria.setSavedQueryModel(model);
			
			model.getParameterList().add(criteria);
		}
	}		
}
