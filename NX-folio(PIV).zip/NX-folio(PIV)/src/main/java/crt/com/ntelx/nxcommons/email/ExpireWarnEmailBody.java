package crt.com.ntelx.nxcommons.email;

public class ExpireWarnEmailBody extends AbstractEmailBody {
	private String contact;
	private String login;
	private String expireDays;
	
	public ExpireWarnEmailBody() {
		
	}

	public String getContact() {
		return contact;
	}

	public void setContact(String contact) {
		this.contact = contact;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getExpireDays() {
		return expireDays;
	}

	public void setExpireDays(String expireDays) {
		this.expireDays = expireDays;
	}

	public String getBody() {
		String body = null;

		body = replaceGDPattern(template, "<contact>", contact);
		body = replaceGDPattern(body, "<login>", login);
		body = replaceGDPattern(body, "<expire>", expireDays);

		return body;
	}
}
