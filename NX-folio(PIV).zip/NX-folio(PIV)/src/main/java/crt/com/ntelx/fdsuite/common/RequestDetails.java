package crt.com.ntelx.fdsuite.common;

import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;

public class RequestDetails {
	private Logger logger = Logger.getLogger (getClass());
	
	private static final String msie = "msie ";
	private static final Double minIE = 7.0;
	
	private static final String firefox = "firefox/";
	private static final Double minFF = 3.0;
	
	private static final String safari = "version/";
	private static final Double minSF = 4.0;
	private static final String chrome = "chrome/";
	private static final Double minCR = 4.0;
	
	private static final String opera = "opera/";
	private static final Double minOP = 9.0;
	
	private static final String unk = "unknown";
	
	private String browser;
	private double version;
	private double minVersion;
	private String agentIdentifier;
	
	
	public RequestDetails(HttpServletRequest request) {
		agentIdentifier = new String();
		browser = unk;
		version = 0.0;
		minVersion = 0.0;
		setBrowserDetails(findUserAgent(request));
	}
	
	public void setBrowserDetails(String userAgent) {
		logger.debug("User-Agent: " + userAgent);
		
		if(userAgent.indexOf(msie) != -1) {
        	browser = "Internet Explorer";
        	agentIdentifier = msie;   
        	minVersion = minIE;
        }
        if(userAgent.indexOf(firefox) != -1) {
        	browser = "Mozilla Firefox";
        	agentIdentifier = firefox; 
        	minVersion = minFF;
        }
        // chrome and safari both have the word safari in their userAgent string
        if(userAgent.indexOf("safari") != -1) {
            if(userAgent.indexOf(chrome) != -1) {
              browser = "Google Chrome";
              agentIdentifier = chrome;
              minVersion = minCR;
            } else {
        	  browser = "Apple Safari";
        	  agentIdentifier = safari;
        	  minVersion = minSF;
            }
        }

        if(userAgent.indexOf(opera) != -1) {
        	browser = "Opera";
        	agentIdentifier = opera;
        	minVersion = minOP;
        }
        
        if(!browser.equalsIgnoreCase(unk)) {
        	setBrowserVersion(userAgent);
        }
	}
	
	public String findUserAgent(HttpServletRequest request) {
		String userAgent = "Unknown";
		try {
		  userAgent = request.getHeader("User-Agent").toLowerCase();
		} catch (Exception ex) {
			logger.debug("Failed to parse User-Agent from request.  User-Agent set to 'Unknown'");
		}
		return userAgent;
	}
	
	private void setBrowserVersion(String userAgent) {
		int startIndex = 0;
		try {
			startIndex = userAgent.indexOf(agentIdentifier)+agentIdentifier.length();
	    	version = Double.parseDouble(userAgent.substring(startIndex,startIndex + 3));
		} catch(Exception ex) {
			logger.info("Failed to detect version of " + browser + " in " + userAgent);
		}
	}
	
	public boolean browserNotSupported() {
		// don't do this check for unknown browsers
		if(browser.equalsIgnoreCase(unk))
			return false;
		
		// is the browser version less than the minimum supported version?
		if(version < minVersion)
			return true;
		else
			return false;
	}
	
	public boolean browserUnknown() {
		if(browser.equalsIgnoreCase(unk))
			return true;
		else
			return false;
	}
	
	public String toString() {
		return "Detected " + browser + " version " + version + ".  Minimum supported version is " + minVersion;
	}

	public double getMinVersion() {
		return minVersion;
	}

	public void setMinVersion(double minVersion) {
		this.minVersion = minVersion;
	}

	public String getBrowser() {
		return browser;
	}

	public void setBrowser(String browser) {
		this.browser = browser;
	}

	public double getVersion() {
		return version;
	}

	public void setVersion(double version) {
		this.version = version;
	}

	public static Double getMinie() {
		return minIE;
	}

	public static Double getMinff() {
		return minFF;
	}

	public static Double getMinsf() {
		return minSF;
	}

	public static Double getMincr() {
		return minCR;
	}

	public static Double getMinop() {
		return minOP;
	}
	
}
