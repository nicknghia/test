/** 
 * 
 * Copyright (c) 2010 NTELX 
 *  All rights reserved. e
 * 
 * This software is the confidential and proprietary information of NTELX, LLC 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/setup/action/UserPreferencesAction.java,v 1.14.2.5 2010/02/11 22:12:43 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: UserPreferencesAction.java,v $
 *  Revision 1.14.2.5  2010/02/11 22:12:43  mechevarria
 *  moved systemusermodel to commons
 *
 *  Revision 1.14.2.4  2010/02/05 15:59:49  mechevarria
 *  store preferences in credentials
 *
 *  Revision 1.14.2.3  2010/02/03 22:35:09  mechevarria
 *  remove import
 *
 *  Revision 1.14.2.2  2010/02/03 20:33:38  mechevarria
 *  re-write for FAS
 *
 *  Revision 1.14.2.1  2008/06/03 12:40:21  mechevarria
 *  gov_solutions merge updates
 * 
 */


package com.freightdesk.fdmonitor.action;   

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.freightdesk.fdcommons.ActionErrors;
import com.freightdesk.fdcommons.ActionMessage;
import com.freightdesk.fdcommons.ActionMessages;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdfolio.common.BasicButtonsAction;
import com.freightdesk.fdfolio.common.BasicButtonsForm;
import com.freightdesk.fdcommons.SessionKey;

import crt.com.freightdesk.fdfolio.common.UserSetupReferenceData;

import com.freightdesk.fdfolio.dao.UserAccessDAO;
import com.freightdesk.fdfolio.useraccess.model.SystemUserModel;
import com.freightdesk.fdmonitor.form.UserPreferencesForm;

import javax.servlet.http.HttpSession;

import com.opensymphony.xwork2.ActionSupport;

import org.apache.log4j.Logger;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.ServletActionContext;

import com.freightdesk.fdcommons.OptionBean;

import crt.com.freightdesk.fdfolio.common.IncludesUtil;

import java.util.*;

/**
 * @author Mike Echevarria
 */

public class UserPreferencesAction extends ActionSupport implements ServletRequestAware {
	
	private UserAccessDAO userAccessDAO = new UserAccessDAO();
        private String loginTimeRoleMsg;
        private String faqTxt;
	protected Logger logger = Logger.getLogger(getClass());
        private static final long serialVersionUID = 1L;
	private long systemUserId;
	private String uomCode;
	private List<OptionBean> uomList = null;
        private List<String> uomStrList = new ArrayList<String>();
        private String basicBtnClicked;
        
        HttpServletRequest request = getServletRequest();
	
	// main method when action is called.
	public String execute() throws Exception {
                request = ServletActionContext.getRequest();
                HttpSession session = request.getSession(false);
                SessionStore store = SessionStore.getInstance(session);
                Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
		logger.debug("Entering 'My Preferences' action");
                
                loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);
                
                UserSetupReferenceData userSetupReferenceData = UserSetupReferenceData.getInstance(credentials.getDomainName());
		setUomList(userSetupReferenceData.getUomList());
                uomStrList = convertUomListToStringList(uomList);
                
                // POAM HttpOnly Secure
                HttpServletResponse response = (HttpServletResponse)ServletActionContext.getResponse();
                String secure = "";
                if (request.isSecure())
                {
                  secure = "; Secure";
                }
                response.setHeader("SET-COOKIE", "JSESSIONID=" + request.getSession().getId()
                                 + "; Path=" + request.getContextPath() + "; HttpOnly" + secure);

                
		
                if ("CANCEL".equalsIgnoreCase(basicBtnClicked)) {
                        logger.debug("basicBtnClicked CANCEL ");
                        return respondBtnCancel();
                }  else if ("SAVE_RETURN".equalsIgnoreCase(basicBtnClicked)) {
                        logger.debug("basicBtnClicked SAVE_RETURN ");
                        return respondBtnSaveAndReturn();
                }
                
		// get the model from database
		SystemUserModel systemUserModel = userAccessDAO.getUserPreferenceDetails(credentials.getSystemUserId());
		
		// populate the form from the model
		model2form(systemUserModel);
		
		// display the page
		return displayPage();
	}

	public String respondBtnCancel() throws Exception {
		logger.debug("Cancel button pressed.");
		addActionMessage(getText("setup.operation.cancel"));
		return "cancel";
	}

	public String respondBtnSave() throws Exception {
		logger.debug("Not currently using save action.");
		return null;
	}
	
	public String respondBtnSaveAndReturn() throws Exception {
                request = ServletActionContext.getRequest();
                HttpSession session = request.getSession(false);
                SessionStore store = SessionStore.getInstance(session);
                Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
		logger.debug("Saving and Returning.");
		UserPreferencesForm prefForm = new UserPreferencesForm();
		// validate the form
		
		// if errors, save them and displayPage
		ActionErrors errors = validate(prefForm);
		if (errors.size() > 0) {
			logger.debug("Caught validation errors.");
			addActionError("Form validation errors.");
			return displayPage();
		}
		
		// copy form to model
		SystemUserModel systemUserModel = form2model(credentials);
		
		// save model
		userAccessDAO.updateUserPreferences(systemUserModel);
		
		// copy the new preferences to active credentials
		credentials.setUomCode(systemUserModel.getUomCode());
		
		
		// set saved message and return to setup home
		addActionMessage(getText("preference.save"));
		logger.debug("No validation errors, returning to setup home.");
		return  "setupHome";
	}

	public String respondBtnSaveAndNew(Credentials credentials) throws Exception {
		logger.debug("Not using Save and New");
		return null;
	}
	
	private String displayPage() {
                request = ServletActionContext.getRequest();
                HttpSession session = request.getSession(false);
                SessionStore store = SessionStore.getInstance(session);
                Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
                
		logger.debug("preparing page for display.");
		// Sets the drop down lists on the form, using the reference data
		UserSetupReferenceData userSetupReferenceData = UserSetupReferenceData.getInstance(credentials.getDomainName());
		setUomList(userSetupReferenceData.getUomList());
                uomStrList = convertUomListToStringList(uomList);
		
		return "display";
	}
	
	private SystemUserModel form2model(Credentials credentials){
		logger.debug("copying form values to model");
		SystemUserModel model = new SystemUserModel();
		model.setUomCode(convertUomLabelToValue(getUomCode(), uomList));
		model.setSystemUserId(credentials.getSystemUserId());
		return model;
	}
	
	private void model2form(SystemUserModel model) {
		logger.debug("populating form from model values.");
                setUomCode(convertUomValueToLabel(model.getUomCode(), uomList));
		return;
	}
	
	private ActionErrors validate(UserPreferencesForm form) {
		logger.debug("validating UserPreferencesForm");
		ActionErrors errors = new ActionErrors();
		return errors;
	}
        
        public void setServletRequest(HttpServletRequest request) {
                this.request = request;
        }

        public HttpServletRequest getServletRequest() {
                return this.request;
        }	
        
    public String getFaqTxt() {
        return faqTxt;
    }

    public void setFaqTxt(String faqTxt) {
        this.faqTxt = faqTxt;
    }
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
    
    public String getBasicBtnClicked() {
        return basicBtnClicked;
    }

    public void setBasicBtnClicked(String basicBtnClicked) {
        this.basicBtnClicked = basicBtnClicked;
    }
    
        public long getSystemUserId() {
		return systemUserId;
	}

	public void setSystemUserId(long systemUserId) {
		this.systemUserId = systemUserId;
	}

	public String getUomCode() {
		return uomCode;
	}

	public void setUomCode(String uomCode) {
		this.uomCode = uomCode;
	}

	public List<OptionBean> getUomList() {
		return uomList;
	}

	public void setUomList(List<OptionBean> uomList) {
		this.uomList = uomList;
	}
        
        public List<String> getUomStrList() {
                return uomStrList;
        }

        public void setUomStrList(List<String> uomStrList) {
                this.uomStrList = uomStrList;
        }
        
    private String convertUomLabelToValue(String label, List<OptionBean> uomListOptBean) {
        Iterator<OptionBean> itrUom = uomListOptBean.iterator();
        OptionBean optBean = new OptionBean();
        while (itrUom.hasNext()) {
            optBean = itrUom.next();

            if (label.equals(optBean.getLabel())) {
                return optBean.getValue();
            }
        }
        return null;
    }
    
    private String convertUomValueToLabel(String value, List<OptionBean> uomListOptBean) {
        Iterator<OptionBean> itrUom = uomListOptBean.iterator();
        OptionBean optBean = new OptionBean();
        while (itrUom.hasNext()) {
            optBean = itrUom.next();

            if (value.equals(optBean.getValue())) {
                return optBean.getLabel();
            }
        }
        return null;
    }
    
    private List<String> convertUomListToStringList(List<OptionBean> uomListOptBean) {
        List<String> theUomStrList = new ArrayList<String>();
        Iterator<OptionBean> itrUom = uomListOptBean.iterator();
        OptionBean optBean = new OptionBean();
        while (itrUom.hasNext()) {
            optBean = itrUom.next();
            theUomStrList.add(optBean.getLabel());
        }
        return theUomStrList;
    }

}
