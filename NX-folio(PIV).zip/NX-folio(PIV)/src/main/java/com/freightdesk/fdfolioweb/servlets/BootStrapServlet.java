/**
 * Copyright (c) NTELX
 *  All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with NTELX.
 */
package com.freightdesk.fdfolioweb.servlets;

import static org.quartz.CronScheduleBuilder.cronSchedule;
import static org.quartz.JobBuilder.newJob;
import static org.quartz.TriggerBuilder.newTrigger;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.UnsupportedEncodingException;
import java.security.GeneralSecurityException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Properties;
import java.util.Set;

import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.quartz.CronTrigger;
import org.quartz.JobDetail;
import org.quartz.JobKey;
import org.quartz.Scheduler;
import org.quartz.impl.StdScheduler;
import org.quartz.impl.matchers.GroupMatcher;

import crt.com.freightdesk.fdfolio.jobs.NoLoginJob;
import crt.com.freightdesk.fdfolio.jobs.NoSubmissionCAR;
import crt.com.freightdesk.fdfolio.jobs.NoSubmissionCCSFJob;
import crt.com.freightdesk.fdfolio.jobs.NoSubmissionINB;
import crt.com.freightdesk.fdfolio.jobs.passExpireWarnJob;
import crt.com.freightdesk.fdfolio.setup.AppPropertiesManager;
import com.freightdesk.fdcommons.FDSuiteProperties;
import com.freightdesk.fdcommons.LicenseProperties;
import com.freightdesk.fdcommons.ServiceLocator;
import com.freightdesk.fdcommons.licensing.InvalidLicenseException;
import com.freightdesk.fdcommons.licensing.LicenseConstants;
import com.freightdesk.fdcommons.licensing.LicenseKey;
import com.freightdesk.fdcommons.licensing.LicenseValidator;

/**
 * Servlet that initializes runtime information when .war file is deployed
 * @author Mike Echevarria
 */
public class BootStrapServlet extends HttpServlet
{
    /**
	 * 
	 */
	protected static Logger logger = Logger.getLogger("BootStrapSerlet");
	
	private static final long serialVersionUID = 1789430L;

	/** Path to FD runtime home */
    protected String FD_RUNTIME_HOME = System.getProperty ("RUNTIME_HOME") +  File.separator;

    protected LicenseValidator licValidator = new LicenseValidator();

    /**
     * Initializes FDSuite properties.
     */
    protected void initializeFDSuiteProperties()
    {
        // Gets the location of the Lcp Properties file
        String suitePropsFilePath = FD_RUNTIME_HOME + "FDSuite.properties";

        try {
            InputStream suitePropsStream = new FileInputStream (suitePropsFilePath);

            try {
                FDSuiteProperties.reset();
                System.out.println ("BOOTSTRAP Servlet: loaded FDSuiteProperties from given stream");

                // After loading Application Properties, set all references to null that chache or store Application
                // Properties.

            } catch (Exception e) {
                System.err.println("BOOTSTRAP Servlet: An unexpected error has occured.");
                //e.printStackTrace(System.err);
				logger.error("Exception: " + e.getMessage());
            }

            // closes file stream
            try { suitePropsStream.close(); }
            catch (Exception e) { System.err.println ("[Ignoring]:: Exception closing file stream: " + e); }
        } catch (Exception e) {
            System.err.println ("[Ignoring]:: Exception closing file stream: " + e);
        }
    }

    /**
     * Initializes license properties.
     */
    protected void initializeLicenseProperties()
    {
        // Gets the location of the License Properties file
        String licensePropsFilePath = FD_RUNTIME_HOME + "SuiteLicense.properties";
        LicenseProperties licenseProps = LicenseProperties.getInstance();

        try {
            InputStream licensePropsStream = new FileInputStream (licensePropsFilePath);

            try {
                Properties props = new Properties();
                props.load(licensePropsStream);
                String[] products = LicenseConstants.getProductNames();
                for(int i =0; i<products.length; i++)
                {
                    evaluateProductLicense(licenseProps, props, products[i]);
                }
                System.out.println ("BOOTSTRAP Servlet: loaded LicenseProperties from given stream ");
            } catch (Exception e) {
                System.err.println("BOOTSTRAP Servlet: An unexpected error has occured.");
                //e.printStackTrace(System.err);
				logger.error("Exception: " + e.getMessage());
            }

            // closes file stream
            try { licensePropsStream.close(); }
            catch (Exception e) { System.err.println ("[Ignoring]:: Exception closing file stream: " + e); }
        } catch (Exception e) {
            System.err.println ("[Ignoring]:: Exception closing file stream: " + e);
        }
    }


    /**
     * Evaluates the license and sets the corresponding properties in LicenseProperties object.
     * @param licenseProps
     * @param props
     * @param product
     * @throws GeneralSecurityException
     * @throws UnsupportedEncodingException
     * @throws GeneralSecurityException
     * @throws UnsupportedEncodingException
     */
    private void evaluateProductLicense(LicenseProperties licenseProps, Properties props, String product) throws UnsupportedEncodingException, GeneralSecurityException
    {
        String productKeyStr = props.getProperty(product);
        boolean productEnabled = false;
        LicenseKey productkey = null;
        if(productKeyStr!=null)
        {
            try {
                productkey =licValidator.createLicenseKey(productKeyStr);
            } catch (Exception e) {
                System.err.println("BOOTSTRAP Servlet: Exception in creating License Key for product :"+product);
                //e.printStackTrace(System.err);
				logger.error("Exception: " + e.getMessage());
            }
            try
            {
                if(productkey!=null)
                {
                    productEnabled = licValidator.validateLicense(productkey, product);
                }
            }
            catch (InvalidLicenseException e) {
                System.err.println("BOOTSTRAP Servlet: Invalid product License: " + product);
            }
        }
        System.out.println("Product License -> "+product+" : "+productEnabled);
        String productEnabledPropName = product + LicenseProperties.LIC_ENABLED_EXT;
        licenseProps.put(productEnabledPropName , new Boolean(productEnabled));
        if(productEnabled)
        {
            String expDatePropName = product+LicenseProperties.LIC_EXP_DATE_EXT ;
            Timestamp productExpireDate = productkey.getExpirationDate();
            licenseProps.put(expDatePropName , productExpireDate);

            String licTypePropName = product + LicenseProperties.LIC_TYPE_EXT;
            String licenseType = LicenseConstants.LicenseType.getLicenseType(productkey.getLicenseType());
            licenseProps.put(licTypePropName , licenseType);
        }
    }


    /**
     * Initializes the bootstrap servlet. All of these processes are necessary for proper startup
     *
     * ** NOTE: **
     * ** Do not output info/debug messages until after LOG4J has been initialized **
     */
    public void init() throws ServletException
    {
        super.init();

        System.out.println("\n\nInitializing Application Properties and Quartz jobs\n");

        try {

            initializeFDSuiteProperties();
            
            Logger logger = Logger.getLogger (getClass());

            // initializes license properties
            initializeLicenseProperties ();
            
            // initialize the folio properties
            initializeApplicationProperties ();
            
            ServiceLocator.reset();
            logger.debug("Reset service locator.");

            if ( FDSuiteProperties.getProperty( "quartz.runQuartz" ).equalsIgnoreCase( "true" ) )
            	startQuartz();
            else
            	logger.debug( "Skipping Quartz Jobs" ); 
            
            
            logger.debug("Finished initializing application properties and quartz jobs");

        } catch (Exception t) {
            System.err.println("Unexpected error in BootStrapServlet.init() " + t);
            //t.printStackTrace();
			logger.error("Exception: " + t.getMessage());
        }
    }
    
    protected void initializeApplicationProperties()
    {

        System.out.println("loading Application Properties from database");
        try {

            try 
            {
            	//HERE
            	AppPropertiesManager propManager = new AppPropertiesManager();                
            	propManager.resetAppProperties();
            	

            } catch (Exception e) {
                //e.printStackTrace();
				logger.error("Exception: " + e.getMessage());
            }
        } catch (Exception e) {
            System.err.println ("[Ignoring]:: Exception closing file stream: " + e);
        }
    }
    
    
    public void startQuartz()
    {
		try
		{
            System.out.println("Starting Quartz...");
			InitialContext ctx = new InitialContext();
			StdScheduler scheduler = (StdScheduler) ctx.lookup("Quartz");
			
			clearJobs( scheduler, Scheduler.DEFAULT_GROUP );

			//  We need to retrieve a data set to pass to our jobs because
			//  they will not have access to JBoss Container when
			//  they are run
			//
			DataSource dataSource      = (DataSource) ctx.lookup( "java:comp/env/oraclePool" );
			
			// Setup NoSubmission CCSF Job
			//
			JobDetail noCCSFsubJob = newJob(NoSubmissionCCSFJob.class)
					.withIdentity("NoSubJob", Scheduler.DEFAULT_GROUP)
					.build();			
			
			noCCSFsubJob.getJobDataMap().put("dataSource", dataSource);
			
			CronTrigger noSubmissionTrigger = newTrigger()
					.withIdentity( "noSubmissionTrigger", null )
					.withSchedule(cronSchedule(FDSuiteProperties.getProperty( "quartz.noSubmissionTrigger" )))
					.build();
			
			scheduler.scheduleJob( noCCSFsubJob, noSubmissionTrigger );
			
			// Setup no submission US air carrier job
			//
			JobDetail noCARsubJob = newJob(NoSubmissionCAR.class)
					.withIdentity("noCARsubJob", Scheduler.DEFAULT_GROUP)
					.build();			
			
			noCARsubJob.getJobDataMap().put("dataSource", dataSource);
			
			CronTrigger noCarTrigger = newTrigger()
					.withIdentity( "noCarTrigger", null )
					.withSchedule(cronSchedule(FDSuiteProperties.getProperty( "quartz.noCarTrigger" )))
					.build();
			
			scheduler.scheduleJob( noCARsubJob, noCarTrigger );
			
			// Setup no submission Non-US air carrier job
			JobDetail noINBsubJob = newJob(NoSubmissionINB.class)
					.withIdentity("noINBsubJob", Scheduler.DEFAULT_GROUP)
					.build();			
			
			noINBsubJob.getJobDataMap().put("dataSource", dataSource);
			
			CronTrigger noInbTrigger = newTrigger()
					.withIdentity( "noInbTrigger", null )
					.withSchedule(cronSchedule(FDSuiteProperties.getProperty( "quartz.noInbTrigger" )))
					.build();
			
			scheduler.scheduleJob( noINBsubJob, noInbTrigger );
				
			// Setup Deactivate User Job.  This Job will deactive any users that have not logged in 30 days
			//
			JobDetail deactiveJob = newJob(NoLoginJob.class)
					.withIdentity("DeactiveJob", Scheduler.DEFAULT_GROUP)
					.build();
			
			deactiveJob.getJobDataMap().put("dataSource", dataSource);
			
			CronTrigger deativateUsersTrigger = newTrigger()
					.withIdentity( "deativateUsersTrigger", null )
					.withSchedule(cronSchedule(FDSuiteProperties.getProperty( "quartz.deativateUsersTrigger" )))
					.build();
			
			scheduler.scheduleJob( deactiveJob, deativateUsersTrigger );	
			
			// Setup Email expiration warning Job.  Job will warn users when their login is about to expire
			JobDetail passWarnExpireJob = newJob(passExpireWarnJob.class)
					.withIdentity("passWarnExpireJob", Scheduler.DEFAULT_GROUP)
					.build();
			
			passWarnExpireJob.getJobDataMap().put("dataSource", dataSource);
								
			CronTrigger passWarnExpireTrigger = newTrigger()
					.withIdentity( "passWarnExpireTrigger", null )
					.withSchedule(cronSchedule(FDSuiteProperties.getProperty( "quartz.passWarnExpireTrigger" )))
					.build();
			
			scheduler.scheduleJob( passWarnExpireJob, passWarnExpireTrigger );	
					
		} 
		catch (Exception exc)
		{
			//exc.printStackTrace();
			logger.error("Exception: " + exc.getMessage());
		}
    }
    
    public void clearJobs( StdScheduler scheduler, String groupName )
    {
    		System.out.println("Clearing all jobs from quartz scheduler");
    		try
			{
				Set<JobKey> jobKeys = scheduler.getJobKeys(GroupMatcher.jobGroupEquals(groupName));
				
				scheduler.deleteJobs(new ArrayList<JobKey>(jobKeys));
			} 
    		catch (Exception e)
			{
				//e.printStackTrace();
				logger.error("Exception: " + e.getMessage());
			}
    }

    /**
     * Responds to a get request.  Calls the initialize() methods again, which
     * provides the user a handy method to re-read the properties.
     */
    public void doGet(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        System.out.println ("doGet(): begin");
        init();
        res.sendRedirect ("logon.do");
    }

    /** Responds to a post request.  Delegates to #doGet. */
    public void doPost(HttpServletRequest req, HttpServletResponse res)
        throws ServletException, IOException
    {
        System.out.println ("doPost(): begin, delegating to doGet");
        doGet(req, res);
    }

}
