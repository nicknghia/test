/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/applet/GeoMap.java,v 1.3.6.1 2010/08/22 23:08:28 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: 
 */
package com.freightdesk.fdfolioweb.applet;

import java.net.URL;

import javax.swing.ImageIcon;

/**
 * Encapsulates a geographical map. 
 *
 * @author Amrinder Arora
 */
public class GeoMap
{
    /** A constant for world map */
    public static final GeoMap WORLD = new GeoMap ("/maps/World.gif", -180.0, 180.0, 90.0, -90.0);

    /** A constant for north america map */
    public static final int NORTH_AMERICA = 1;

    /** A constant for Europe map */
    public static final int EUROPE = 2;

    /** Map image for the background */
    protected ImageIcon mapImage = null;

    /** Longitudinal left bound of map image */
    protected double mapImageLeftLongitude;

    /** Longitudinal right bound of map image */
    protected double mapImageRightLongitude;

    /** Latitudinal upper bound of map image */
    protected double mapImageUpperLatitude;

    /** Latitudinal lower bound of map image */
    protected double mapImageLowerLatitude;

    /** Width of the map image, in pixels */
    protected double mapWidth;

    /** Height of the map image, in pixels */
    protected double mapHeight;

    /**
     * Creates a geographical map. 
     */
    public GeoMap (String mapImageUrl, double mapImageLeftLongitudeArg, double mapImageRightLongitudeArg,
            double mapImageUpperLatitudeArg, double mapImageLowerLatitudeArg)
    {
        System.out.println ("GeoMap(): version 6");
        if (mapImageRightLongitudeArg < mapImageLeftLongitudeArg)
            throw new IllegalArgumentException ("Right longitude limit cannot be less than left longitude limit");

        if (mapImageUpperLatitudeArg < mapImageLowerLatitudeArg)
            throw new IllegalArgumentException ("Upper latitude limit cannot be less than lower latitude limit");

        URL mapUrl = getClass().getResource(mapImageUrl);
        System.out.println ("URL: " + mapUrl);
        mapImage = new ImageIcon(mapUrl);

        this.mapImageLeftLongitude = mapImageLeftLongitudeArg;
        this.mapImageRightLongitude = mapImageRightLongitudeArg;
        this.mapImageUpperLatitude = mapImageUpperLatitudeArg;
        this.mapImageLowerLatitude = mapImageLowerLatitudeArg;
    }

    /** Gets the map image of this geographical map. */
    public ImageIcon getImageIcon ()
    {
        return mapImage;
    }

    /**
     * Returns the X coordinate based on longitude.
     * 
     * @param longitude
     * @return x coordinate if the longitude of the object is within
     * the longitude bounds of the image,
     * -1 if the longitude of the object is not within the longitude 
     *  bounds of the image.
     */
    public int getXCoordinate(double longitude)
    {
        if ((longitude < mapImageLeftLongitude) || (longitude > mapImageRightLongitude))
            return -1;
        int x = (int)(((longitude - mapImageLeftLongitude) * mapImage.getIconWidth()) / (mapImageRightLongitude - mapImageLeftLongitude));
        System.out.println ("longitude: " + longitude + ", width: " + mapImage.getIconWidth() + ", X is: " + x);
        return x;
    }

    /**
     * Returns the Y coordinate based on latitude.
     * 
     * @param latitude
     * @return y coordinate
     */
    public int getYCoordinate(double latitude)
    {
        if ((latitude < mapImageLowerLatitude) || (latitude > mapImageUpperLatitude))
            return -1;
        int y = (int)(mapImage.getIconHeight() - ((latitude - mapImageLowerLatitude) * mapImage.getIconHeight()) / (mapImageUpperLatitude - mapImageLowerLatitude));
        System.out.println ("latitude: " + latitude + ", height: " + mapImage.getIconHeight() + ", Y is: " + y);
        return y;
    }

    /** Gets an instance of geographical map. */
    public static GeoMap getInstance (String geoMapKey)
    {
        if ("World".equals (geoMapKey)) {
            return WORLD;
        }
        if ("North America".equals (geoMapKey)) {
            return new GeoMap ("/maps/NorthAmerica.gif", -180.0, -90.0, 90.0, 20.0);
        }
        if ("Europe".equals (geoMapKey)) {
            return new GeoMap ("/maps/Europe.gif", -10.0, 80.0, 90.0, 30.0);
        }
        throw new IllegalArgumentException ("Map Key " + geoMapKey + " not a known value");
    }

    /** Map options */
    public static String[] mapOptions = {"World", "North America", "Europe"};
}

