/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/applet/Chart.java,v 1.2.6.1 2010/08/22 23:08:28 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: Chart.java,v $
 *  Revision 1.2.6.1  2010/08/22 23:08:28  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.2  2006/04/07 21:51:04  ranand
 *  changed import  due to new JfreeChart jar
 *
 *  Revision 1.1  2004/12/17 12:34:10  ranand
 *  Package changed
 *
 *  Revision 1.1  2004/09/15 13:36:27  asingh
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdfolioweb.applet;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.StringTokenizer;

import javax.swing.JApplet;
import javax.swing.JPanel;

import org.jfree.chart.ChartFactory;
import org.jfree.chart.ChartPanel;
import org.jfree.chart.JFreeChart;
import org.jfree.data.general.Dataset;
import org.jfree.data.general.DefaultPieDataset;

/**
 * This applet creates a Chart.  The data for the chart comes
 * from a query that is specified in the runtime, and the user
 * preferences are used to select the appropriate query.
 *
 * <P>To make changes to the chart, the user will need to:
 * <OL>
 * <LI>Change the property in lcp-runtime to have the exact query
 * <LI>Change the user preference
 * </OL>
 *
 * @author Rajender Anand
 */
public class Chart extends JApplet
{
    /**
     * Init method is called  every time applet is executed.
     */
    public void init()
    {
        //creating a Panel for the applet
        JPanel panel = new JPanel(new GridLayout(1, 1));

        Dataset dataset = createPieDataSet();

        // create a Chart
        JFreeChart chart = createChart(dataset);

        //add the Pie Chart in the Panel
        panel.add (new ChartPanel(chart));
        panel.setPreferredSize(new Dimension(450, 400));
        setContentPane(panel);
    }

    /**
     * Prepares the Dataset for the Pie Chart.
     *
     * @return Dataset
     */
    public Dataset createPieDataSet()
    {
        // create DataSet for the Pie Chart
        DefaultPieDataset dataset = new DefaultPieDataset();

        // adding the data in the DataSet for the Pie Chart
        int count = Integer.parseInt (getParameter ("count"));
        for (int i = 0; i < count; i++){
            String value = getParameter("status" + i);
            StringTokenizer st = new StringTokenizer(value,",");
            while (st.hasMoreTokens()) {
                dataset.setValue(st.nextToken(),Integer.parseInt(st.nextToken()));
            }
        }
        return dataset;
    }

    /**
     * It creates the Chart based on the type of Dataset passed as argument.
     *
     * @param Dataset dataset
     * @return JFreeChart
     */
    public JFreeChart createChart(Dataset dataset)
    {
        if (dataset instanceof DefaultPieDataset) {
            DefaultPieDataset set = (DefaultPieDataset) dataset;
            JFreeChart chart = ChartFactory.createPieChart("", set, false, false, false);
            return chart;
        }
        return null;
    }
}

