/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/ConnectionUtil.java,v 1.1.2.1.2.6 2010/11/15 21:12:01 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: ConnectionUtil.java,v $
 *  Revision 1.1.2.1.2.6  2010/11/15 21:12:01  mechevarria
 *  remove lobhandler
 *
 *  Revision 1.1.2.1.2.5  2010/08/27 14:34:54  jhansford
 *  Changes for Quartz jobs
 *
 *  Revision 1.1.2.1.2.4  2010/04/22 15:22:49  mechevarria
 *  undo the close statement on the oracleprepared...really should use that oraclepreparedstatement method
 *
 *  Revision 1.1.2.1.2.3  2010/04/21 20:27:55  mechevarria
 *  fix open jdbc statement
 *
 *  Revision 1.1.2.1.2.2  2008/07/16 18:46:22  mechevarria
 *  moved member to protected to support monitor 3.8.2
 *
 *  Revision 1.1.2.1.2.1  2008/07/15 14:36:12  mbegley
 *  added external connection resource
 *
 *  Revision 1.1.2.1  2007/05/18 18:52:00  mechevarria
 *  merge with main branch
 *
 *  Revision 1.2  2007/03/02 10:12:15  dkumar
 *  minor change for logger class
 *
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.2  2005/08/19 09:36:22  pjain
 *  added getOraclePreparedStatement method
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdcommons;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

public class ConnectionUtil
{
    private static Logger logger = Logger.getLogger ("com.freightdesk.fdcommons.ConnectionUtil");

	private static InitialContext ic;
    private static DataSource dataSource;
    private static DataSource dataSourceIacms;
    private static DataSource dataSourceKsms;
    private static DataSource dataSourceStat;
    private static DataSource dataSourceCcsf;

	private static final String DATA_SOURCE_JNDI_NAME = "java:/oraclePool";
	private static final String DATA_SOURCE_JNDI_NAME_IACMS = "java:/oraclePoolIacms";
	private static final String DATA_SOURCE_JNDI_NAME_KSMS = "java:/oraclePoolKsms";
	private static final String DATA_SOURCE_JNDI_NAME_STAT = "java:/oraclePoolStat";
	private static final String DATA_SOURCE_JNDI_NAME_CCSF = "java:/sqlserverPoolCcsf";
	
    protected ConnectionUtil()
    {
    }
	
	

    /** Gets a connection to the FAS DB */
    public static Connection getConnection() throws SQLException {
    	logger.info("getConnection FAS");
		try	{
			if(dataSource == null) {
				ic = new InitialContext();
				dataSource = (DataSource) ic.lookup(DATA_SOURCE_JNDI_NAME);
				logger.info(dataSource.toString());
			}
			return dataSource.getConnection();
		}
		catch (NamingException nex) {
			logger.error("naming exception ",nex);
			throw new RuntimeException(nex);
		}		
    }
    

    /** Gets a connection to the IACMS Oracle DB */
    public static Connection getConnectionIacms() throws SQLException {
    	
    	logger.info("getConnectionIacms ES");
		try	{
			if(dataSourceIacms == null) {
				ic = new InitialContext();
				dataSourceIacms = (DataSource) ic.lookup(DATA_SOURCE_JNDI_NAME_IACMS);
				logger.info(dataSourceIacms.toString());
			}
			return dataSourceIacms.getConnection();
		}
		catch (NamingException nex) {
			logger.error("naming exception ",nex);
			throw new RuntimeException(nex);
		}		
    }
    
    /** Gets a connection to the KSMS Oracle DB */
    public static Connection getConnectionKsms() throws SQLException {
    	
    	logger.info("getConnectionKsms ES");
		try	{
			if(dataSourceKsms == null) {
				ic = new InitialContext();
				dataSourceKsms = (DataSource) ic.lookup(DATA_SOURCE_JNDI_NAME_KSMS);
				logger.info(dataSourceKsms.toString());
			}
			return dataSourceKsms.getConnection();
		}
		catch (NamingException nex) {
			logger.error("naming exception ",nex);
			throw new RuntimeException(nex);
		}		
    }
    
    /** Gets a connection to the STAT Oracle DB */
    public static Connection getConnectionStat() throws SQLException {
    	
    	logger.info("getConnectionStat ES");
		try	{
			if(dataSourceStat == null) {
				ic = new InitialContext();
				dataSourceStat = (DataSource) ic.lookup(DATA_SOURCE_JNDI_NAME_STAT);
				logger.info(dataSourceStat.toString());
			}
			return dataSourceStat.getConnection();
		}
		catch (NamingException nex) {
			logger.error("naming exception ",nex);
			throw new RuntimeException(nex);
		}		
    }
    
    /** Gets a connection to the ES MsSQL DB */
    public static Connection getConnectionCcsf() throws SQLException {
            	
    	logger.info("getConnectionCcsf");
		try	{
			if(dataSourceCcsf == null) {
				ic = new InitialContext();
				dataSourceCcsf = (DataSource) ic.lookup(DATA_SOURCE_JNDI_NAME_CCSF);
				logger.info(dataSourceCcsf.toString());
			}
		
			return dataSourceCcsf.getConnection();
		}
		catch (Exception nex) {			
			logger.error("naming exception ",nex);
			throw new RuntimeException(nex);
		}		
    }
    


    /** Gets a external connection a DB used for Debug mostly*/
    public static Connection getExternalConnection(String userid,String url,String password) throws SQLException {
       Connection con=null;
		try {
			Class.forName("oracle.jdbc.driver.OracleDriver");	

		} catch(java.lang.ClassNotFoundException e) {
		    logger.error("ClassNotFoundException: ", e);			
		}

		try {		
		 con = DriverManager.getConnection(url, userid, password);
		 return con;
		} catch(SQLException ex) {
		    logger.error("FATAL ERROR:External connection is invalid and will return NULL! ", ex);			
			return con;
		}
    	
    }

    /**
     * A utility method to close resources.
     * It checks for nullness, so passing null to any subset of the parameters will not cause
     * a NullPointerException.  It also catches the SQLExceptions, not rethrowing them,
     * so no try catch block is necessary in the calling method.
     */
    public static void closeResources (Connection connection, Statement stmt, ResultSet rs)
    {
    	   	
        // closes the result set
        if (rs != null)
            try {
                rs.close();
            } catch (SQLException sqEx) {
                logger.error ("Exception closing the result set", sqEx);
            }

        // closes the statement
        if (stmt != null)
            try {
                stmt.close();
            } catch (SQLException sqEx) {
                logger.error ("Exception closing statement", sqEx);
            }

        // closes the connection
        if (connection != null)
            try {
                connection.close();
            } catch (SQLException sqEx) {
                logger.error ("Exception closing connection", sqEx);
            }
    }

}

