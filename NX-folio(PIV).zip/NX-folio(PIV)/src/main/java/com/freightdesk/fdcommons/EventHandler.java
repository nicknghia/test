/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/EventHandler.java,v 1.1 2006/03/29 23:57:54 aarora Exp $
 * 
 *  Modification History:
 *  $Log: EventHandler.java,v $
 *  Revision 1.1  2006/03/29 23:57:54  aarora
 *  new files into fdcommons
 *
 *  Revision 1.3  2006/03/29 23:33:33  ranand
 *  removed dependancy on CommunicationMethod model
 *
 *  Revision 1.2  2006/03/28 21:23:01  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons;
import java.util.List;

/**
 * EventHandler is interface. This interface will be implemented by various 
 * event handlers like EmailSender 
 * @author Ravi Kant Gupta, Ajeet Singh Sachan
 */
public interface EventHandler {
	public void processEvent(EventHandlerProperties eventHandlerProperties, List recipients) throws LcpApplicationException;
}

