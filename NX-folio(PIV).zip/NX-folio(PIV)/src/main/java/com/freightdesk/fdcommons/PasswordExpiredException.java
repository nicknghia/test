/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/PasswordExpiredException.java,v 1.1 2006/08/11 20:56:27 dkumar Exp $
 * 
 *  Modification History:
 *  $Log: PasswordExpiredException.java,v $
 *  Revision 1.1  2006/08/11 20:56:27  dkumar
 *  chages for making fdsuite struts based application
 *
 *  Revision 1.4  2006/03/28 21:23:00  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons;





public class PasswordExpiredException extends LcpApplicationException 
{
    /**
     * 
     */
    public PasswordExpiredException()
    {
        super();
    }


	/**
	 * @param message
	 */
	public PasswordExpiredException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public PasswordExpiredException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public PasswordExpiredException(Throwable cause) {
		super(cause);
	}


}
