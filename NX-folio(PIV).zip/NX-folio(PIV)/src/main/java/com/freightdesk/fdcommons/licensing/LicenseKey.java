/** 
* Copyright (c) 2000-2002 NTELX 
*  All rights reserved. 
* 
* This software is the confidential and proprietary information of NTELX 
* ("Confidential Information").  You shall not disclose such Confidential Information 
* and shall use it only in accordance with the terms of the license agreement you entered 
* into with NTELX. 
* 
* 
*  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/licensing/LicenseKey.java,v 1.1.4.1 2007/05/18 18:51:04 mechevarria Exp $ 
* 
*  Modification History:
*  $Log: LicenseKey.java,v $
*  Revision 1.1.4.1  2007/05/18 18:51:04  mechevarria
*  add new licensing
*
*  Revision 1.1  2007/04/12 16:31:14  dkumar
*  base version
*
*/
package com.freightdesk.fdcommons.licensing;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.sql.Timestamp;

import com.freightdesk.fdcommons.FormatDate;

public class LicenseKey
{
    
    private byte majorKeyVersion;
    private byte minorKeyVersion;
    private byte configurationCode;
    private byte licenseType;
    private Timestamp expirationDate;

    public LicenseKey()
    {
    }

    /**
     * @param majorKeyVersion
     * @param minorKeyVersion
     * @param licenseType
     * @param configurationCode
     * @param expirationDate
     */
    public LicenseKey(byte majorKeyVersion, byte minorKeyVersion, byte licenseType, byte configurationCode, Timestamp expirationDate)
    {
        this.majorKeyVersion = majorKeyVersion;
        this.minorKeyVersion = minorKeyVersion;
        this.configurationCode = configurationCode;
        this.licenseType = licenseType;
        this.expirationDate = expirationDate;
    }

    public byte getConfigurationCode()
    {
        return configurationCode;
    }

    public byte getLicenseType()
    {
        return licenseType;
    }

    public Timestamp getExpirationDate()
    {
        return expirationDate;
    }

    public byte getMajorKeyVersion()
    {
        return majorKeyVersion;
    }


    public byte getMinorKeyVersion()
    {
        return minorKeyVersion;
    }

    public void readFromStream(DataInputStream in)
        throws IOException, ClassNotFoundException
    {
        majorKeyVersion = in.readByte();
        minorKeyVersion = in.readByte();
        configurationCode = in.readByte();
        licenseType = in.readByte();
        String expirationDateStr = in.readUTF();
        expirationDate = FormatDate.parse(expirationDateStr,LicenseConstants.DATE_FORMAT);
    }

    public void writeToStream(DataOutputStream out)
        throws IOException
    {
        out.writeByte(majorKeyVersion);
        out.writeByte(minorKeyVersion);
        out.writeByte(configurationCode);
        out.writeByte(licenseType);
        String expirationDateStr = FormatDate.format(expirationDate,LicenseConstants.DATE_FORMAT);
        out.writeUTF(expirationDateStr);
    }
    
    public String toString()
    {
        return "" + majorKeyVersion +":"+ minorKeyVersion +":"+ configurationCode +":"+ licenseType +":"+ FormatDate.format(expirationDate,LicenseConstants.DATE_FORMAT);
    }

}
