/**
 * Copyright (c) NTELX
 *  All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with NTELX.
 *
 *
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/Credentials.java,v 1.5.2.1.2.8 2010/03/15 14:45:42 mechevarria Exp $
 *
 *  Modification History:
 *  $Log: Credentials.java,v $
 *  Revision 1.5.2.1.2.8  2010/03/15 14:45:42  mechevarria
 *  add ipaddress
 *
 *  Revision 1.5.2.1.2.7  2009/10/14 19:25:07  mechevarria
 *  add expirationdate
 *
 *  Revision 1.5.2.1.2.6  2009/09/18 19:30:44  mechevarria
 *  boolean var and function to return true once
 *
 *  Revision 1.5.2.1.2.5  2009/03/20 14:32:55  cdoan
 *  Merged head and GS branch
 *
 *  Revision 1.5.2.1.2.4  2009/03/18 13:30:21  mechevarria
 *  additional field for userids
 *
 *  Revision 1.5.2.1.2.3  2009/02/06 17:07:27  cdoan
 *  Rolled back to GS
 *
 *  Revision 1.5.2.1.2.1  2007/06/12 15:21:46  mechevarria
 *  added field to hold number of days until password expiration
 *
 *  Revision 1.5.2.1  2007/06/01 16:09:53  mechevarria
 *  add numfailedlogin field
 *
 *  Revision 1.5  2006/10/11 12:31:01  ranand
 *  removed dependency on SYSTEMNAVIGATIONTYPE
 *
 *  Revision 1.4  2006/06/09 10:01:04  dkumar
 *  new property dashBoardTilesMap for dashboard tiles
 *
 *  Revision 1.3  2006/05/24 18:19:31  dkumar
 *  added method getSkinCode()
 *
 *  Revision 1.2  2006/04/26 11:04:08  dkumar
 *  added lastLoginTime Property
 *
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.2  2006/03/28 21:27:37  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.9  2006/02/10 19:00:12  ranand
 *  changed getOrgIds method
 *
 *  Revision 1.8  2005/09/29 20:01:42  amrinder
 *  Changed logging from warn to debug when chart code is unknown
 *
 *  Revision 1.7  2005/08/31 11:04:36  ranand
 *  replaceAll method implemented
 *
 *  Revision 1.6  2005/08/30 02:46:36  amrinder
 *  Added some implicit variables and substiution
 *
 *  Revision 1.5  2005/08/23 12:14:15  pjain
 *  added isActive field
 *
 *  Revision 1.4  2005/08/11 05:37:14  ranand
 *  fixed compilation error
 *
 *  Revision 1.3  2005/08/11 05:35:55  ranand
 *  added a method to create a string of orgids in credentials
 *
 *  Revision 1.2  2005/06/23 22:44:32  amrinder
 *  Added some javadoc
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdcommons;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.List;

import org.apache.log4j.Logger;


/**
 * Models the security credentials for the user logged into the application
 * (or the message sender).
 *
 * Also includes the security permissions and role related information,
 * as well as user's preferences.
 */
/**
 * @author Mike Echevarria
 *
 */
public class Credentials
    implements Serializable
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 17815L;

	protected static Logger logger = Logger.getLogger(Credentials.class);
    
    public static final String SYSTEM_USER_ID = "$SYSTEM_USER_ID$";
    public static final String USER_ID = "$USER_ID$";
    public static final String DOMAIN_NAME = "$DOMAIN_NAME$";
    public static final String SYSTEM_USER_LOC_ID = "$SYSTEM_USER_LOC_ID$";
    public static final String SYSTEM_USER_ORGID = "$SYSTEM_USER_ORG_ID$";

    private long systemUserId;
    private String userId;
    private String domainName;
    private String uomCode;
    private String currencyCode;
    private String dateFormat;
    private String timeZoneId;
    private long orgId;
    private long parentOrgId;
    private String parentOrgType;
    private long parentLocId;
    private String emailId;
    private String role;
    private String systemRoleName;
    private String isActive;
    private String orgRoleCode;
    private Timestamp lastLoginTime;
    private int numFailedLogin;
    private Timestamp expirationDate;
    private String ipAddress;
    
    // attribute to keep track of the welcome msg.  Only shown once
    private boolean showMsg=true;
    
    // list of userids from systemuser table that share your parentOrgId
    private List<String> relatedUserIds;

    public Credentials() {
    	this.lastLoginTime=new Timestamp(System.currentTimeMillis());
    }

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getSystemRoleName() {
		return systemRoleName;
	}

	public void setSystemRoleName(String systemRoleName) {
		this.systemRoleName = systemRoleName;
	}

	public String getParentOrgType() {
		if(parentOrgType == null)
			return "";
		else
		    return parentOrgType;
	}

	public void setParentOrgType(String parentOrgType) {
		this.parentOrgType = parentOrgType;
	}

	public String getIpAddress() {
		return ipAddress;
	}

	public void setIpAddress(String ipAddress) {
		this.ipAddress = ipAddress;
	}

	public List<String> getRelatedUserIds() {
		return relatedUserIds;
	}

	public void setRelatedUserIds(List<String> relatedUserIds) {
		this.relatedUserIds = relatedUserIds;
	}

	public String getCurrencyCode() {
         return (this.currencyCode==null?"":this.currencyCode);
    }

    public String getDateFormat() {
        return (this.dateFormat==null?"":this.dateFormat);
    }

    public String getDomainName() {
        return domainName;
    }

    public long getOrgId() {
        return orgId;
    }

    public long getParentOrgId() {
        return parentOrgId;
    }

    public long getParentLocId() {
        return parentLocId;
    }

    public String getTimeZoneId() {
       return (this.timeZoneId==null?"":this.timeZoneId);
    }

    public String getUomCode() {
       return (this.uomCode==null?"":this.uomCode);
    }

    public String getUserId() {
        return userId;
    }

    public void setCurrencyCode(String currencyCode) {
        this.currencyCode = currencyCode;
    }

    public void setDateFormat(String dateFormat)
    {
        this.dateFormat = dateFormat;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }

    public void setOrgId(long orgId) {
        this.orgId = orgId;
    }

    public void setParentOrgId(long parentOrgId) {
        this.parentOrgId = parentOrgId;
    }

    public void setParentLocId(long parentLocId) {
        this.parentLocId = parentLocId;
    }

    public void setTimeZoneId(String timeZoneId) {
        this.timeZoneId = timeZoneId;
    }

    public void setUomCode(String uomCode) {
        this.uomCode = uomCode;
    }

    /**
     * Sets the user id
     */
    public void setUserId(String userId) {
        this.userId = userId;
    }

    /**
     * Gets the systemUserId
     */
    public long getSystemUserId () {
        return systemUserId;
    }
    
    public void setSystemUserId(long systemUserId) {
    	this.systemUserId = systemUserId;
    }

    public void setNumFailedLogin(int numPreviousFailedLogins) {
    	numFailedLogin = numPreviousFailedLogins;
    }

    public int getNumFailedLogin() {
		return numFailedLogin;
	}

	public void setExpirationDate(Timestamp expirationDate) {
		this.expirationDate = expirationDate;
    }

    public Timestamp getExpirationDate() {
		return expirationDate;
    }

//    public String toString() {
//        return "Credentials for " + userId + " of " + domainName;
//    }

    /**
     * @return Returns the isActive.
     */
    public String getIsActive() {
        return isActive;
    }
    /**
     * @param isActive The isActive to set.
     */
    public void setIsActive(String isActive) {
        this.isActive = isActive;
    }

    /** Replaces all occurences of implicit variables in the
     * argument by the values from this Credentials object. */
    public String substituteValues (String rawString) {
        String s = rawString.replaceAll (SYSTEM_USER_ID,"" + systemUserId);
        s = s.replaceAll (USER_ID, userId);
        s = s.replaceAll (DOMAIN_NAME, domainName);
        s = s.replaceAll (SYSTEM_USER_LOC_ID,"" + parentLocId);
        s = s.replaceAll (SYSTEM_USER_ORGID,"" + orgId);
        return s;
    }

	public Timestamp getLastLoginTime() {
		return lastLoginTime;
	}

	public void setLastLoginTime(Timestamp lastLoginTime) {
		this.lastLoginTime = lastLoginTime;
	}
    
    public String getOrgRoleCode() {
        return orgRoleCode;
    }
    
    public void setOrgRoleCode(String orgRoleCode) {
        this.orgRoleCode = orgRoleCode;
    }

    public String getEmailId() {
        return emailId;
    }

    public void setEmailId(String emailId) {
        this.emailId = emailId;
    }

	@Override
	public String toString() {
		return "Credentials [systemUserId=" + systemUserId + ", userId="
				+ userId + ", domainName=" + domainName + ", uomCode="
				+ uomCode + ", currencyCode=" + currencyCode + ", dateFormat="
				+ dateFormat + ", timeZoneId=" + timeZoneId + ", orgId="
				+ orgId + ", parentOrgId=" + parentOrgId + ", parentOrgType="
				+ parentOrgType + ", parentLocId=" + parentLocId + ", emailId="
				+ emailId + ", role=" + role + ", systemRoleName="
				+ systemRoleName + ", isActive=" + isActive + ", orgRoleCode="
				+ orgRoleCode + ", lastLoginTime=" + lastLoginTime
				+ ", numFailedLogin=" + numFailedLogin + ", expirationDate="
				+ expirationDate + ", ipAddress=" + ipAddress + ", showMsg="
				+ showMsg + "]";
	}

}

