/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/BaseHomeAction.java,v 1.2.4.2 2008/12/11 13:50:44 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: BaseHomeAction.java,v $
 *  Revision 1.2.4.2  2008/12/11 13:50:44  mechevarria
 *  brought over from head
 *
 *  Revision 1.6  2008/02/22 08:56:35  atripathi
 *  viewContext specific methods moved from BaseAction to BaseHomeAction and BaseAction of Commons removed.
 *
 *  Revision 1.5  2008/02/20 21:54:52  aarora
 *  Allowing a Safe Exit option in system availability
 *
 *  Revision 1.4  2007/10/01 19:40:11  ranand
 *  Added new method getViewContext
 *
 *  Revision 1.3  2007/06/18 19:43:41  ranand
 *  removed unnecessary cast
 *
 *  Revision 1.2  2006/03/29 22:33:38  aarora
 *  organized imports
 *
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.8  2005/06/23 18:52:11  amrinder
 *  Minor changes in getPagingIndex method
 *
 *  Revision 1.7  2005/06/16 13:27:35  nsehra
 *  changed getPagingIndex method added null condition for startIndex
 *
 *  Revision 1.6  2005/06/13 18:53:01  amrinder
 *  Restructured the method to get paging index, for readability
 *
 *  Revision 1.5  2005/04/12 05:15:52  nsehra
 *  no message
 *
 *  Revision 1.4  2005/04/07 06:58:28  nsehra
 *  Paging enhancement
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdcommons;

import java.util.ArrayList;
import java.util.Enumeration;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import com.freightdesk.fdcommons.search.FilterContext;
import com.freightdesk.fdcommons.search.PropertyMatch;
import com.freightdesk.fdcommons.search.SearchConstants;
import com.freightdesk.fdcommons.search.ViewContext;
import com.freightdesk.fdcommons.searchquery.SearchQueryDao;

/**
 * The base Home Struts Action class for FreightDesk Application.
 *
 * All concrete subclasses must implement execute method.
 * It is possible that AddressHomeAction does not call clearState
 */
public abstract class BaseHomeAction
    extends LoggedInAction
{
    protected Logger logger = Logger.getLogger (getClass());
	protected SearchQueryDao searchQueryDao = new SearchQueryDao();

	/** The clearState method.  Declared final. */
    protected final void clearState(HttpServletRequest request)
    {
        // clear any state info from request and session
        logger.info ("clearState(): begin");
        HttpSession session = request.getSession();
        SessionStore sessionStore = SessionStore.getInstance (session);
        Credentials credentials = (Credentials)sessionStore.get(SessionKey.CREDENTIALS);
        if (credentials != null)
        {
           ObjectLock objectLock = (ObjectLock)sessionStore.get(SessionKey.OBJECT_LOCK);
            if (objectLock != null)
            {   logger.info("Object lock is not null");
                objectLock.releaseAllLocksForUser(credentials.getSystemUserId());
            }
        }
        sessionStore.retainOnlyGeneralKeys();
        if ("SE".equals(FDSuiteProperties.getProperty("system.availability.status"))) {
            throw new SystemUnavailableException("SE");
        }
    }

    /** Method to serve paging request. Declared final. */
    protected final boolean isRequestForPaging(HttpServletRequest request)
    {
        // See if pager.offset attribute is in the query?
        logger.info ("searching pager.offset");
        String valAttribute = request.getParameter("pager.offset");
        if (valAttribute != null) {
            // yes, request is for paging.
            return true;
        }
        return false;
    }
    
    /**
     *  Responds to search button in home pages.
     */
    protected void respondBtnSearch(HttpServletRequest request, String searchType)
    {
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        StackManager stackManager = (StackManager)sessionStore.get(SessionKey.STACK);
        stackManager.createEvent(new OperationInfo("Home", "search_home", searchType, "", "", ""));
    }
    
    /**
     * Gets the starting and ending index for fetching the records between this range.
     * 
     * @param request HttpServletRequest
     * @return long[] array containg the staringIndex as first element and endingIndex as second element
     */
    protected long[] getPagingIndex(HttpServletRequest request, long noOfItemToLoad, boolean fromSession)
    {
        long startIndex = LcpConstants.Paging.START;
        long endIndex = 1;

        String requestStartIndexStr = request.getParameter("startIndex");
        logger.debug("request.startIndex: " + requestStartIndexStr);

        SessionStore ss = SessionStore.getInstance(request.getSession());

        if (requestStartIndexStr != null && !"".equals(requestStartIndexStr)) {
            try {
                startIndex = Long.parseLong(requestStartIndexStr);
            } catch (Exception _ignored) {}
        } else if (fromSession) {
            Object sessionStartIndexObj = ss.get(SessionKey.START_INDEX);
            logger.debug("session.startIndex: " + sessionStartIndexObj);
            if (sessionStartIndexObj != null)
                startIndex =  Long.parseLong(sessionStartIndexObj.toString());   
        }

        endIndex = startIndex + noOfItemToLoad - 1;
        logger.debug("start index: " + startIndex + ", endIndex: " + endIndex);
        ss.put(SessionKey.START_INDEX, new Long(startIndex));

        long index[] = {startIndex, endIndex};
        return index;
    }

    /**
     * 
     * Return View Context Instance for the Home page.
     *  
     * @param propertyMatchList
     * @param credentials
     * @return
     */
    public ViewContext getViewContext(String sortingOrder, String sortingAttribute, String maxResultProperty, Class classType){
        
        logger.debug("getViewContext(): begin");
        
        //create View Context
        ViewContext viewContext = new ViewContext();
        viewContext.setClassType(classType);

        viewContext.setAttribute1(sortingAttribute);
        viewContext.setOrder1(sortingOrder);

        int maxResults = 100;
        try{
            maxResults = Integer.parseInt(maxResultProperty);
        }catch(Exception e){}

        viewContext.setMaxResult(maxResults);
        logger.debug("getViewContext(): end");
        return viewContext;
    }

	/**
	 * Gets the parameters from Request and prepares FilterPropertyMatchList
	 * @param request
	 * @param credentials
	 * @return propertyMatchList
	 */
	protected List getFilterPropertyMatchList(HttpServletRequest request, Credentials credentials) {
	
	    int count = 1;
	    List propertyMatchList = new ArrayList();
	    
	    PropertyMatch defPropertyMatch = new PropertyMatch("domainName", credentials.getDomainName(), SearchConstants.EQUALS, null);
	    propertyMatchList.add(defPropertyMatch);
	    
	    //Count the number of parameter starts with param_name
	    int paramCount = 0;
	
	    Enumeration paramEnum = request.getParameterNames();
	    while(paramEnum.hasMoreElements())
	    {
	        String str = (String) paramEnum.nextElement();
	        logger.debug("Param Name: "+str);
	        if(str.startsWith("param_name")){
	            paramCount++;
	        }
	    }
	    for(int i = 0; i < paramCount; )
	    {
	        i++;
	        String property = request.getParameter("param_name" + i);
	        int operator = -1;
	        try {
	            operator = Integer.parseInt(request.getParameter("param_op" + i));
	        } catch (Exception e) {
	        }
	
	        String value = request.getParameter("param_value" + i);
	        String matchMode = request.getParameter("match_mode");
	        logger.debug("count: " + i);
	        logger.debug("param_name: " + property + ", param_op: " + operator + ", param_value: " + value);
	        PropertyMatch propertyMatch = new PropertyMatch(property, value, operator, matchMode);
	        propertyMatchList.add(propertyMatch);
	        count++;
	    }
	    return propertyMatchList;
	}

	/**
	 * Method for preparing a default list using a PropertyMatch 
	 * @param credentials
	 * @return Returns default propertyMatchList
	 */
	public List getDefaultPropertyMatchList(Credentials credentials) {
	    List list = new ArrayList();
	    PropertyMatch match1 = new PropertyMatch("domainName", credentials.getDomainName(), SearchConstants.EQUALS, null);
	    list.add(match1);
	    return list;
	}

	/**
	 * get the EntityClass used be ViewContext.
	 *  
	 * @return  Class
	 */
	public Class getEntityClass() {
		return null;
	}

	/**
	 * 
	 * Managing View Context depending on action.
	 * 
	 * @param inboxForm
	 * @param sessionStore
	 * @param action
	 * @return
	 */
	public ViewContext manageViewContext(BaseHomeForm baseHomeForm, ViewContext viewContext) {
	    
	    logger.debug("manageViewContext(): begin");
	    String action = baseHomeForm.getAction();
	    
	    if("prevMaxResult".equalsIgnoreCase(action))
	    {
	        viewContext.setViewOffsetIndex(0);
	        int newStartIndex = viewContext.getDbStartIndex()-viewContext.getMaxResult();
	        viewContext.setDbStartIndex(newStartIndex);
	    }else if("nextMaxResult".equalsIgnoreCase(action))
	    {
	        viewContext.setViewOffsetIndex(0);
	        int newStartIndex = viewContext.getDbStartIndex()+viewContext.getMaxResult();
	        viewContext.setDbStartIndex(newStartIndex);
	    }else if ("sort".equals(action)){
	        
	        viewContext.setViewOffsetIndex(0);
	        String sortingOrder = baseHomeForm.getSortOrder();
	        String sortingColumn = baseHomeForm.getSortColumn();
	        logger.debug("sortingOrder: "+sortingOrder+" , sortingColumn: "+sortingColumn);
	        viewContext.setAttribute1(sortingColumn);
	        if ("up".equalsIgnoreCase(sortingOrder.trim())) {
	            viewContext.setOrder1(SearchConstants.DESC);
	        }else {
	            viewContext.setOrder1(SearchConstants.ASC);
	        }
	        viewContext.setDbStartIndex(0);
	    }
	    return viewContext;
	}

    
}

