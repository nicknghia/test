/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/ObjectValue.java,v 1.1 2006/03/29 22:05:35 ranand Exp $
 * 
 *  Modification History:
 *  $Log: ObjectValue.java,v $
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 * 
 */


/**
 *  *
 * @author Sangeeta
 */
package com.freightdesk.fdcommons;

import java.io.Serializable;

public class ObjectValue implements Serializable {
    private long userId;
    private long lockId;

    // constructors
    public ObjectValue () 
    {
    }

 
	/** Constructor for creating the an instance of ObjectValue
	 * @param userId -uniquely identifies the user
	 * @param lockId - identifies the lock obtained by the user.
	*/    
    public ObjectValue (long userId, long lockId) {
        this.userId = userId;
        this.lockId = lockId;
        
     }

    // getters and setters
    public long getUserId()
    {
       return this.userId;
    }
    
    public void setUserId(long userId) 
    {
    	this.userId = userId;
    	
    }
    public long getLockId()
    {
    	return this.lockId;
    }
    
    public void setLockId(long lockId)
    {
    	this.lockId = lockId;
    }
    
	public boolean equals(Object object1)
    {
    		
	   ObjectValue objectValue =(ObjectValue)object1;
    	
		   if ((this.userId== objectValue.getUserId()) && (this.lockId== objectValue.getLockId()))
		   {
			
				   return true;
		   }
		   	
	
		   return false;
	   }
	   public int hashCode()
	   {
			   return (int)this.lockId;		   		
	   }
   }


    
