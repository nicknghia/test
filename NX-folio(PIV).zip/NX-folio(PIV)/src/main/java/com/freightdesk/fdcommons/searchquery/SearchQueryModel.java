/**
 * Copyright (c) 2000-2002 NTELX
 *  All rights reserved. 
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with NTELX. 
 *
 *
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/searchquery/SearchQueryModel.java,v 1.2 2007/08/07 19:53:11 ranand Exp $
 *
 *  Modification History:
 *  $Log: SearchQueryModel.java,v $
 *  Revision 1.2  2007/08/07 19:53:11  ranand
 *  SearchQueryModel
 *
 *  Revision 1.1  2007/07/30 23:25:11  ranand
 *  Added for save Search Query framework
 *
 */


package com.freightdesk.fdcommons.searchquery;

import java.util.List;

import com.freightdesk.fdcommons.BaseModel;


/**
 * 
 * 
 * SearchQueryModel
 * 
 * @author Rajender  Anand
 *
 */
public class SearchQueryModel  extends BaseModel
{

    private long searchQueryId;

    private String query;

    private String name;

    private String objectType;
    
    private String countQuery;
    
    private List queryParam;
    

    public String getCountQuery()
    {
        return countQuery;
    }

    public void setCountQuery(String countQuery)
    {
        this.countQuery = countQuery;
    }

    public long getPrimaryKey() {
    
        return searchQueryId;
    }
    
    public String getName()
    {
        return name;
    }

    public void setName(String name)
    {
        this.name = name;
    }

    public String getObjectType()
    {
        return objectType;
    }

    public void setObjectType(String objectType)
    {
        this.objectType = objectType;
    }

    public String getQuery()
    {
        return query;
    }

    public void setQuery(String query)
    {
        this.query = query;
    }

    public long getSearchQueryId()
    {
        return searchQueryId;
    }

    public void setSearchQueryId(long searchQueryId)
    {
        this.searchQueryId = searchQueryId;
    }

    /**
     * @return the queryParam
     */
    public List getQueryParam()
    {
        return queryParam;
    }

    /**
     * @param queryParam the queryParam to set
     */
    public void setQueryParam(List queryParam)
    {
        this.queryParam = queryParam;
    }


}