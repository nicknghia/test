/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/BaseModel.java,v 1.2.2.2.2.5 2009/04/29 19:59:14 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: BaseModel.java,v $
 *  Revision 1.2.2.2.2.5  2009/04/29 19:59:14  mechevarria
 *  needed to prevent errors in hibernate
 *
 *  Revision 1.2.2.2.2.4  2008/08/08 21:44:58  cdoan
 *  Fixed ObjectCreateTimeStamp
 *
 *  Revision 1.2.2.2.2.3  2008/06/18 19:40:49  mechevarria
 *  merge updates from head
 *
 *  Revision 1.25  2007/07/17 08:14:57  atripathi
 *  new file containing check for empty string for domainName.
 *
 *  Revision 1.24  2007/07/06 07:07:27  atripathi
 *  imports organized and getDomainName() method modified to avod setting domain empty string.
 *
 *  Revision 1.23  2007/06/29 00:01:49  ranand
 *  Added ew method setBaseProperties
 *
 *  Revision 1.22  2007/04/17 11:53:33  dkumar
 *  new field ObjectCreateTimestamp added.
 *
 *  Revision 1.21  2007/03/19 13:38:26  mechevarria
 *  Casting of null object to exact.  Ensures compatibility with JDK 1.5 and 1.6
 *
 *  Revision 1.2  2006/10/09 12:12:47  dkumar
 *  created seperate FDSuite properties
 *
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.3  2005/09/28 18:22:09  amrinder
 *  Changed this method to public
 *
 *  Revision 1.2  2005/08/02 06:40:57  pjain
 *  changed lcp properties to Application properties
 *
 *  Revision 1.1  2005/08/01 16:39:09  amrinder
 *  Added a missing file
 *
 *  Revision 1.9  2005/02/23 18:21:00  agarg
 *  removed FusionPKid
 *
 *  Revision 1.8  2005/02/17 16:18:23  agarg
 *  added propertyChangeListeners Support to the Folio models
 *
 *  Revision 1.7  2005/02/14 19:36:46  amrinder
 *  Added transient BaseModel
 *
 *  Revision 1.6  2005/01/21 00:09:09  amrinder
 *  Now using setBaseProperties method instead
 *
 *  Revision 1.5  2005/01/19 15:41:14  agarg
 *  Added field "fusionPKId" for Data fusion
 *
 *  Revision 1.4  2005/01/18 22:02:50  amrinder
 *  Added setBaseProperties method
 *
 *  Revision 1.3  2005/01/04 12:06:54  ranand
 *  method setModelDefaultProperties added in BaseModel class
 *
 *  Revision 1.2  2004/12/20 21:15:36  amrinder
 *  Added the entity dao table ejb map as javadoc
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 */


package com.freightdesk.fdcommons;

import java.io.Serializable;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.sql.Timestamp;
import java.util.Collection;
import java.util.Iterator;

import javax.persistence.MappedSuperclass;
import javax.persistence.Transient;

import org.apache.log4j.Logger;


/**
 * Encapsulates a persistable model element.  All attributes
 * map to some column in the DB.
 *
 * <P>
 * BaseModel is the abstract base class for all LCP model elements.  
 * The six attributes in the BaseModel are present in ALL tables.
 *
 * <P>
 * Distinct subclasses of BaseModel are typically persisted in different 
 * tables and are persisted using different Data Access Objects (DAOs),
 * that are wrapped in different EJBs.  Following table provides a
 * quick summary of the Entity-Table-DAO-EJB that are tied together.
 *

 * @author Amrinder Arora
 */

@MappedSuperclass
public abstract class BaseModel implements Serializable, Cloneable
{

	private static final long serialVersionUID = 1L;

	public String createUserId;

    public Timestamp createTimestamp;

    public String lastUpdateUserId;

    public Timestamp lastUpdateTimestamp;

    public String domainName;

    public String status = "ACTIVE"; // default value
    
    @Transient
    public transient static Logger logger = Logger.getLogger(BaseModel.class);

    public BaseModel()
    {
    }

    /**
     * Creates a BaseModel.  This constructor is useful when objects are 
     * retrieved from the database.
     */
    public BaseModel(String createUserId, Timestamp createTimestamp, String lastUpdateUserId, Timestamp lastUpdateTimestamp, String domainName)
    {
        this.createUserId = createUserId;
        this.createTimestamp = createTimestamp;
        this.lastUpdateUserId = lastUpdateUserId;
        this.lastUpdateTimestamp = lastUpdateTimestamp;
        this.domainName = domainName;
    }

    /**
     * Creates a BaseModel.  This constructor is useful when objects are 
     * created for inserting into the database.
     */
    public BaseModel(String createUserId, String domainName)
    {
        Timestamp initTimestamp = new Timestamp(System.currentTimeMillis());
        this.createUserId = createUserId;
        this.createTimestamp = initTimestamp;
        this.lastUpdateUserId = createUserId;
        this.lastUpdateTimestamp = initTimestamp;
        this.domainName = domainName;
    }

    /**
     * All subclasses needs to implement the abstract method defined by BaseModel.
     * @return primaryKey  the unique id key for model object.
     */
    public abstract long getPrimaryKey();

    public Timestamp getCreateTimestamp()
    {
        return createTimestamp;
    }

    public String getCreateUserId()
    {
        return createUserId;
    }

    public String getDomainName()
    { 
    	if(domainName == null)
    		domainName="";
        return domainName;
    }

    public String getStatus()
    {
        return status;
    }

    public void setStatus(String newStatus)
    {
        this.status = newStatus;
    }

    public Timestamp getLastUpdateTimestamp()
    {
        return lastUpdateTimestamp;
    }

    public String getLastUpdateUserId()
    {
        if (lastUpdateUserId == null)
            lastUpdateUserId = "";
        return lastUpdateUserId;
    }

    public void setCreateTimestamp(Timestamp createTimestamp)
    {
        this.createTimestamp = createTimestamp;
    }

    public void setCreateUserId(String createUserId)
    {
        this.createUserId = createUserId;
    }

    public void setDomainName(String domainName)
    {
        this.domainName = domainName;
    }

    public void setLastUpdateTimestamp(Timestamp lastUpdateTimestamp)
    {
        this.lastUpdateTimestamp = lastUpdateTimestamp;
    }

    public void setLastUpdateUserId(String lastUpdateUserId)
    {
        this.lastUpdateUserId = lastUpdateUserId;
    }

    /**
     * Sets the base properties.
     * @param createUserId
     * @param createTimestamp
     * @param lastUpdateUserId.
     * @param lastUpdateTimestamp
     * @param domainName
     */
    public void setBaseProperties(String createUserId, Timestamp createTimestamp, String lastUpdateUserId, Timestamp lastUpdateTimestamp, String domainName)
    {
        this.createUserId = createUserId;
        this.createTimestamp = createTimestamp;
        this.lastUpdateUserId = lastUpdateUserId;
        this.lastUpdateTimestamp = lastUpdateTimestamp;
        this.domainName = domainName;
    }

    /**
     * Sets the base properties from the given Credentials object, as follows:
     * <UL>
     * <LI>Sets the last update timestamp to the current time.
     * <LI>If the createtimestamp is null, sets it to current time.
     * <LI>Sets the last update userid to userid from credentials.
     * <LI>If the create user ID is null, sets it to userid from credentials.
     * <LI>If the domainname is null, sets it to domainname from credentials.
     * </UL>
     * @param credentials
     */
    public void setBaseProperties(Credentials credentials)
    {
        Timestamp currTs = new Timestamp(System.currentTimeMillis());
        this.setLastUpdateTimestamp(currTs);
        if (getCreateTimestamp() == null) {
            this.setCreateTimestamp(currTs);
        }
        this.setLastUpdateUserId(credentials.getUserId());
        if (getCreateUserId() == null) {
            this.setCreateUserId(credentials.getUserId());
        }
        if (getDomainName() == null || "".equalsIgnoreCase(getDomainName())) {
            this.setDomainName(credentials.getDomainName());
        }
    }

    /**
     * A convenience method that returns this BaseModel as a String.
     * Subclasses may use this method if they override the toString() method.
     *
     * @param nestingSeparator The String that is used to separate nested 
     * BaseModel objects
     * @param fieldSeparator The String that is used to separate different fields 
     * in a BaseModel object
     * @return a String representation of the model object
     */
    public String getStringRepresentation(String nestingSeparator, String fieldSeparator)
    {
        StringBuffer stringBuffer = new StringBuffer("[");
        Class userModelClass = getClass();
        // System.out.println ("userModelClass:" + userModelClass.getName());
        try {
            Field[] fields = userModelClass.getFields();
            for (int i = 0; i < fields.length; i++) {
                Object fieldValue = fields[i].get(this);
                stringBuffer.append(fields[i].getName() + " = ");
                if (fieldValue instanceof BaseModel) {
                    BaseModel innerFieldBaseModel = (BaseModel) fieldValue;
                    stringBuffer.append(innerFieldBaseModel.getStringRepresentation(nestingSeparator, fieldSeparator));
                    stringBuffer.append(nestingSeparator);
                } else if (fieldValue instanceof Collection) {
                    Collection innerCollectionFieldValue = (Collection) fieldValue;
                    Iterator iterator = innerCollectionFieldValue.iterator();
                    stringBuffer.append("[");
                    while (iterator.hasNext()) {
                        stringBuffer.append(iterator.next());
                        // this should be modified, it does not use the custom separators
                        // (the object in collection may be a BaseModel object)
                    }
                    stringBuffer.append("]");
                    stringBuffer.append(fieldSeparator);
                } else {
                    stringBuffer.append(fieldValue);
                    stringBuffer.append(fieldSeparator);
                }
            }

            stringBuffer = new StringBuffer("[");
            Method[] methods = userModelClass.getMethods();
            for (int i = 0; i < methods.length; i++) {
                try {
                    Method currentMethod = methods[i];
                    // disregard methods that do not begin with get
                    if (!currentMethod.getName().startsWith("get")) {
                        // System.out.println ("disregarding method : " + currentMethod.getName());
                        continue;
                    } else {
                        // System.out.println ("invoking this method: "+ currentMethod.getName());
                    }
                    stringBuffer.append(currentMethod.getName() + " = ");
                    Object result = currentMethod.invoke(this, (Object[]) null);
                    if (result instanceof BaseModel) {
                        BaseModel innerFieldBaseModel = (BaseModel) result;
                        stringBuffer.append(innerFieldBaseModel.getStringRepresentation(nestingSeparator, fieldSeparator));
                        stringBuffer.append(nestingSeparator);
                    } else if (result instanceof Collection) {
                        // System.out.println ("invoking this method returned a Collection");
                        Collection innerCollectionFieldValue = (Collection) result;
                        Iterator iterator = innerCollectionFieldValue.iterator();
                        stringBuffer.append("[");
                        while (iterator.hasNext()) {
                            stringBuffer.append(iterator.next());
                            // this should be modified, it does not use the custom separators
                            // (the object in collection may be a BaseModel object)
                        }
                        stringBuffer.append("]");
                        stringBuffer.append(fieldSeparator);
                    } else {
                        stringBuffer.append(result);
                        stringBuffer.append(fieldSeparator);
                    }
                } catch (Exception t) {
                    // logger.debug ("ignoring this exception : " + t);
                }
            }
        } catch (SecurityException se) {
            // logger.error ("SecurityException: " + se);
        } catch (Exception e) {
            // logger.error ("Exception: " + e);
        }
        stringBuffer.append("]");

        return stringBuffer.toString();
    }

    /**
     * Method compares current model with other simialar model for equality.
     * Method is declared final to protect it from overriding.
     * @param otherBaseModel BaseModel
     * @return
     */
    public final boolean isEquals(BaseModel otherBaseModel)
    {
        //Collect Class information from both models
        Class currentObjectClass = this.getClass();
        Class otherObjectClass = otherBaseModel.getClass();
        //Check both instance are of same object type.
        if (!currentObjectClass.getName().equals(otherObjectClass.getName())) {
            return false;
        }
        //Collect field information from their Class information.
        Field[] currentObjectFields = currentObjectClass.getFields();
        Field[] otherObjectFields = otherObjectClass.getFields();
        //Check if number of fields are same.
        if (currentObjectFields.length != otherObjectFields.length) {
            return false;
        }
        try {
            Method[] methods = currentObjectClass.getMethods();
            for (int i = 0; i < methods.length; i++) {
                Method currentMethod = methods[i];
                //ignore methods that do not begin with get
                if (!currentMethod.getName().startsWith("get")) {
                    continue;
                } else {
                    Object resultCurrentObject = currentMethod.invoke(this, (Object[]) null);
                    Object resultOtherObject = currentMethod.invoke(otherBaseModel, (Object[]) null);
                    //Comapare these object.
                    if (compare(resultCurrentObject, resultOtherObject) != true) {
                        return false;
                    }
                }
            }
        } catch (Exception throwable) {
            System.out.println("Ignore exception: " + throwable.getMessage());
            return false;
        }
        //All test has been passed returning true;
        return true;
    }

    /**
     * Compare two resultant object for equality;
     * @param currentResult
     * @param otherResult
     * @return true/false boolean
     */
    private boolean compare(Object currentResult, Object otherResult)
    {
        // Null is lesser than anything else.
        if ((currentResult == null) && (otherResult == null)) {
            return true;
        } else if (currentResult instanceof Comparable) {
            // the attribute values are Comparable, we have hit
            // the JackPot.  We have absolutely nothing intelligent to do
            System.out.println("currentResult " + currentResult + " otherResult " + otherResult);
            Comparable comp1 = (Comparable) currentResult;
            Comparable comp2 = (Comparable) otherResult;
            if (comp1.compareTo(comp2) == 0) {
                return true;
            }
        } else {
            // if the attribute values are not Comparable
            // we must write custom cases (Java != Magic)
            throw new RuntimeException("Dont know how to compare currentResult [" + currentResult + "] with otherResult [" + otherResult + "]");
        }
        return false;
    }

}
