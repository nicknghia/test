/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/reporting/JFreeChartScriptlet.java,v 1.1 2006/06/21 11:20:25 dkumar Exp $
 * 
 *  Modification History:
 *  $Log: JFreeChartScriptlet.java,v $
 *  Revision 1.1  2006/06/21 11:20:25  dkumar
 *  repackaging of ReportUtility to FDCommons
 *
 *  Revision 1.2  2006/04/06 20:01:00  ranand
 *  added javadoc comments
 *
 *  Revision 1.1  2004/09/15 13:36:28  asingh
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons.reporting;


import net.sf.jasperreports.engine.JRDefaultScriptlet;
import net.sf.jasperreports.engine.JRScriptletException;
import net.sf.jasperreports.engine.fill.JRFillField;
import net.sf.jasperreports.renderers.JCommonDrawableRenderer;

import org.apache.log4j.Logger;
import org.jfree.chart.ChartFactory;
import org.jfree.chart.JFreeChart;
import org.jfree.chart.plot.PiePlot3D;
import org.jfree.data.general.DefaultPieDataset;
import org.jfree.util.Rotation;


/**
 * 
 * This class is used to create a Chart for the Report.
 * @author Rajender Anand
 * 
 */
public class JFreeChartScriptlet extends JRDefaultScriptlet
{

    DefaultPieDataset dataset = new DefaultPieDataset();
    Logger logger = Logger.getLogger(getClass());
    
    
    /**
     * This method is called after execution of every detais section in the Report.
     */
    public void afterDetailEval() throws JRScriptletException
    {
        logger.debug("Field Map is :: "+fieldsMap);
        
        String key = (String)((JRFillField)fieldsMap.get("KEY")).getValue();
        String value = (String)((JRFillField)fieldsMap.get("VALUE")).getValue();
        dataset.setValue(key, Integer.parseInt(value));
        
        JFreeChart chart = 
            ChartFactory.createPieChart3D(
                "Pie Chart 3D Demo 1",
                dataset,
                true,
                true,
                false
                );

        PiePlot3D plot = (PiePlot3D) chart.getPlot();
        plot.setStartAngle(290);
        plot.setDirection(Rotation.CLOCKWISE);
        plot.setForegroundAlpha(0.5f);
        plot.setNoDataMessage("No data to display");

        /*   */
        this.setVariableValue("Chart", new JCommonDrawableRenderer(chart));
    }


}
