/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/StackManager.java,v 1.1 2006/03/29 22:05:35 ranand Exp $
 * 
 *  Modification History:
 *  $Log: StackManager.java,v $
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.2  2004/11/09 11:29:43  asaxena
 *  Only formatting changes
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdcommons;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.Stack;

import org.apache.log4j.Logger;

public class StackManager
{
    Stack actionStack;
	public Logger logger = Logger.getLogger (getClass());

    public StackManager()
    {
        actionStack = null;
        actionStack = new Stack();
        logger.debug(" constructor called " + actionStack);
    }

    public Object closeEvent()
    {
        return actionStack.pop();
    }

    public void createEvent(Object newOperationInfo)    
    {
        if(!actionStack.isEmpty()) {
        	OperationInfo operationInfoAtTop = (OperationInfo)currentEvent();
	        if(operationInfoAtTop.equals(newOperationInfo))
                return;
        }
    	logger.debug(" OperationInfo At Top and new OperationInfo are not same ");    	    
        actionStack.push(newOperationInfo);
    }

    public Object currentEvent()
    {
        return actionStack.peek();
    }

    public boolean isEmpty()
    {
        return actionStack.empty();
    }

    public String toString()
    {
        if (actionStack == null)
            return "";
        else
            return actionStack.toString();
    }
    
    /**
     * Retrieves all header keys from available operation(s) in action Stack.
     * These header keys are being used to show the navigation level on the Jsp page
     * using application resource file as mapping for keys.   
     * 
     * @return NavigationHeaderKeyList
     */
    public List getNavigationHeaderKeyList()
    {
    	List operationLevelList = new ArrayList();
    	if(actionStack != null)
    	{
    		int counter = 0;
    		Iterator itr = actionStack.iterator();
    		while(itr.hasNext())
    		{
    			OperationInfo operationInfo = (OperationInfo)itr.next();
    			if (counter > 0)
    			{   //Skipping root level operation, as most of the times it is home page of some domain.
					operationLevelList.add(operationInfo.getNavigationHeaderKey());
    			}
    			counter++;
    		}
    	}
    	//return 
    	return operationLevelList;
    }
}
