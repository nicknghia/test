/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 */

package com.freightdesk.fdcommons;

import java.sql.Timestamp;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.GregorianCalendar;
import java.util.HashMap;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

/**
 * A utility class to format and parse date and timestamp info.
 *
 * @author Biju Joseph
 * @author Amrinder Arora
 */
public class FormatDate
{
    /** A logger */
    protected static Logger logger = Logger.getLogger("com.freightdesk.fdcommons.FormatDate");

    /** A map of various date formats - used to avoid creating date format objects repeatedly */
    private static Map dateFormatsMap = new HashMap();

    /**
     * Gets the date format from the String provided. 
     * Looks up the map to see if an instance was already created for the 
     * given format.
     */
    private static DateFormat getDateFormat(String formatString)
    {
        if (dateFormatsMap.containsKey(formatString)) {
            return ((DateFormat) (dateFormatsMap.get(formatString)));
        }
        DateFormat dateFormat = new SimpleDateFormat(formatString);
        dateFormatsMap.put (formatString, dateFormat);
        return dateFormat;
    }

    /** Formats the given timestamp using the default to string. */
    public static String format(Timestamp timestamp)
    {
        return timestamp.toString();
    }

    /**
     * Formats the given date using the given format string.
     *
     * @param timestamp The timestamp to format
     * @param formatString The format string which should be used to format
     */
    public static String format(Timestamp timestamp, String formatString)
    {
        if (timestamp == null)
            return "";
        if (formatString == null)
            return timestamp.toString();
        DateFormat dateFormat = getDateFormat(formatString);
        return dateFormat.format(timestamp);
    }

    /**
     * Formats the given date using the given format string.
     *
     * @param timestamp The timestamp to format
     * @param formatString The format string which should be used to format
     */
    public static String format(Date timestamp, String formatString)
    {
        if (timestamp == null)
            return "";
        if (formatString == null)
            return timestamp.toString();
        DateFormat dateFormat = getDateFormat(formatString);
        return dateFormat.format(timestamp);
    }
    
    public static String[] formatDateTime(Timestamp timeStamp, String dateFormat)
    {
        String stringDateNTime[] = new String[2];
        GregorianCalendar gc = null;
        try {
            gc = new GregorianCalendar();
            gc.setTime(new Date(timeStamp.getTime()));
            stringDateNTime[0] = format(timeStamp, dateFormat);
            if (gc.get(11) < 10)
                stringDateNTime[1] = "0" + gc.get(11) + ":";
            else
                stringDateNTime[1] = gc.get(11) + ":";
            if (gc.get(12) < 10)
                stringDateNTime[1] += "0" + gc.get(12) + ":";
            else
                stringDateNTime[1] += gc.get(12) + ":";
            if (gc.get(13) < 10)
                stringDateNTime[1] += "0" + gc.get(13);
            else
                stringDateNTime[1] += gc.get(13);
        } catch (Exception _ex) {
            stringDateNTime[0] = "";
            stringDateNTime[1] = "";
        }
        return stringDateNTime;
    }
    
    public static Timestamp parse (String stringDate, String dateFormat)
    {
        Timestamp timeStamp = null;
        String tmp_dateFormat = dateFormat.toLowerCase();
        int firstIndex = tmp_dateFormat.indexOf("y");
        int lastIndex = tmp_dateFormat.lastIndexOf("y");
        StringBuffer sb = new StringBuffer(dateFormat);
        sb.replace(firstIndex, lastIndex + 1, "yy");
        try {
            DateFormat simpleDateFormat = getDateFormat(sb.toString());
            simpleDateFormat.setLenient(false);
            if (stringDate != null) {
                logger.debug("sb " + sb + " " + simpleDateFormat.parse(stringDate));
                timeStamp = new Timestamp(simpleDateFormat.parse(stringDate).getTime());
            }
        } catch (Exception _ex) {
        }
        return timeStamp;
    }

    public static Timestamp doParseDateTime(String stringDate, String stringTime, String dateFormat)
    {
        Timestamp timeStamp = null;
        StringBuffer sb = new StringBuffer(dateFormat);
        dateFormat = dateFormat.toLowerCase();
        dateFormat = dateFormat.replaceAll("m", "M");
        //sb.replace(firstIndex, lastIndex + 1, "yy");
        //String s = 
        try {
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(sb.toString());
            simpleDateFormat.setLenient(false);

            if (stringDate != null) {
                timeStamp = new Timestamp(simpleDateFormat.parse(stringDate).getTime());
                long time = parseTime(stringTime);
                timeStamp = new Timestamp(timeStamp.getTime() + time);
            }
        } catch (Exception _ex) {
            logger.debug("Exception: " + _ex);
        }
        return timeStamp;
    }


    /**
     * Parses the given time using the format 'HH:mm:ss'.
     *
     * @param time The time to parse
     * @return The parsed time in milliseconds
     */
    public static long parseTime(String time)
    {
        //required format -
        StringTokenizer tokenizer = new StringTokenizer(time, ":");
        String hourS = tokenizer.nextToken();
        String minS = tokenizer.nextToken();
        String secS = tokenizer.nextToken();
        long hours = Long.parseLong(hourS);
        long mins = Long.parseLong(minS);
        long secs = Long.parseLong(secS);

        long timeInSeconds = (hours * 60 * 60) + (mins * 60) + secs;
        long timeInMilliSeconds = timeInSeconds * 1000;

        return timeInMilliSeconds;
    }
}
