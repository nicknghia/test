package com.freightdesk.fdcommons;

import java.sql.Timestamp;

public class ErrorLogModel {
private long errorLogID;
private long errorCode;
private String errorMessage;
private String userId;
private String ipAddress;
private String userAgent;
private String status;
private Timestamp createTimeStamp;
private String lastUpdateUserId;
private Timestamp lastUpdateTimeStamp;
private String domainName;
private String priority;
public Timestamp getCreateTimeStamp() {
	return createTimeStamp;
}
public void setCreateTimeStamp(Timestamp createTimeStamp) {
	this.createTimeStamp = createTimeStamp;
}
public String getDomainName() {
	return domainName;
}
public void setDomainName(String domainName) {
	this.domainName = domainName;
}
public long getErrorCode() {
	return errorCode;
}
public void setErrorCode(long errorCode) {
	this.errorCode = errorCode;
}
public long getErrorLogID() {
	return errorLogID;
}
public void setErrorLogID(long errorLogID) {
	this.errorLogID = errorLogID;
}
public String getErrorMessage() {
	return errorMessage;
}
public void setErrorMessage(String errorMessage) {
	this.errorMessage = errorMessage;
}
public String getIpAddress() {
	return ipAddress;
}
public void setIpAddress(String ipAddress) {
	this.ipAddress = ipAddress;
}
public Timestamp getLastUpdateTimeStamp() {
	return lastUpdateTimeStamp;
}
public void setLastUpdateTimeStamp(Timestamp lastUpdateTimeStamp) {
	this.lastUpdateTimeStamp = lastUpdateTimeStamp;
}
public String getLastUpdateUserId() {
	return lastUpdateUserId;
}
public void setLastUpdateUserId(String lastUpdateUserId) {
	this.lastUpdateUserId = lastUpdateUserId;
}
public String getStatus() {
	return status;
}
public void setStatus(String status) {
	this.status = status;
}
public String getUserAgent() {
	return userAgent;
}
public void setUserAgent(String userAgent) {
	this.userAgent = userAgent;
}
public String getUserId() {
	return userId;
}
public void setUserId(String userId) {
	this.userId = userId;
}
public String getPriority() {
	return priority;
}
public void setPriority(String priority) {
	this.priority = priority;
}
}
