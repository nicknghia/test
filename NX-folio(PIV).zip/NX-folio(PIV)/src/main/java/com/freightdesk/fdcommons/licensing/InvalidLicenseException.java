/** 
* Copyright (c) 2000-2002 NTELX 
*  All rights reserved. 
* 
* This software is the confidential and proprietary information of NTELX 
* ("Confidential Information").  You shall not disclose such Confidential Information 
* and shall use it only in accordance with the terms of the license agreement you entered 
* into with NTELX. 
* 
* 
*  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/licensing/InvalidLicenseException.java,v 1.1.4.1 2007/05/18 18:51:04 mechevarria Exp $ 
* 
*  Modification History:
*  $Log: InvalidLicenseException.java,v $
*  Revision 1.1.4.1  2007/05/18 18:51:04  mechevarria
*  add new licensing
*
*  Revision 1.1  2007/04/12 16:31:14  dkumar
*  base version
*
*/
package com.freightdesk.fdcommons.licensing;

public class InvalidLicenseException extends Exception {

    /**
     *
     */
    public InvalidLicenseException() {
        super();
    }

    /**
     * @param message
     */
    public InvalidLicenseException(String message) {
        super(message);
    }

    /**
     * @param message
     * @param cause
     */
    public InvalidLicenseException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * @param cause
     */
    public InvalidLicenseException(Throwable cause) {
        super(cause);
    }

}
