/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/LcpApplicationException.java,v 1.1 2006/03/29 22:05:35 ranand Exp $
 * 
 *  Modification History:
 *  $Log: LcpApplicationException.java,v $
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.4  2004/12/17 00:08:20  amrinder
 *  Added comments
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 */


package com.freightdesk.fdcommons;

/**
 * Root Exception class for all application (business) exceptions.
 *
 * @author Biju Joseph
 */
public class LcpApplicationException 
    extends Exception 
{
    /**
     * Creates an instance of LcpApplicationException.
     */
    public LcpApplicationException() {
        super();
    }

    /**
     * Creates an instance of LcpApplicationException.
     * @param message
     */
    public LcpApplicationException(String message) {
        super(message);
    }

    /**
     * Creates an instance of LcpApplicationException.
     *
     * @param message
     * @param cause
     */
    public LcpApplicationException(String message, Throwable cause) {
        super(message, cause);
    }

    /**
     * Creates an instance of LcpApplicationException.
     *
     * @param cause
     */
    public LcpApplicationException(Throwable cause) {
        super(cause);
    }
}
