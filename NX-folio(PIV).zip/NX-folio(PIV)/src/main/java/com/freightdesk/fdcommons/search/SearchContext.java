/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/search/SearchContext.java,v 1.2 2007/07/13 19:54:13 ranand Exp $
 * 
 *  Modification History:
 *  $Log: SearchContext.java,v $
 *  Revision 1.2  2007/07/13 19:54:13  ranand
 *  added new property BaseForm
 *
 *  Revision 1.1  2007/06/21 02:37:56  ranand
 *  moved from ViewContext
 *
 *  Revision 1.3  2007/06/19 16:43:49  ranand
 *  fixed Exception
 *
 *  Revision 1.2  2007/06/18 19:43:22  ranand
 *  added getMessage
 *
 *  Revision 1.1  2007/06/06 20:52:01  ranand
 *  new files for serach Framework
 *
 *  
 */
package com.freightdesk.fdcommons.search;

import java.io.Serializable;
import java.util.List;

import com.freightdesk.fdcommons.BaseForm;

/**
 * 
 * Encapsulates SearchContext Properties
 * 
 * @author Rajender Anand
 *
 */
public class SearchContext implements Serializable
{

	private List propertyMatchList;

    private boolean isAdvance;

    private String searchStr;
	
	private String searchLabel;
    
    private BaseForm baseForm;

    /**
     *  Default Constructor.
     *
     */
    public SearchContext() {}
    
    /**
     * Initialize with PropertyMatchList
     * 
     * @param propertyMatchList
     */
    public SearchContext(List propertyMatchList){
        
        this.propertyMatchList = propertyMatchList;
    }
    
    
    public boolean isAdvance()
    {
        return isAdvance;
    }

    public void setAdvance(boolean isAdvance)
    {
        this.isAdvance = isAdvance;
    }


    public List getPropertyMatchList()
    {
        return propertyMatchList;
    }

    public void setPropertyMatchList(List propertyMatchList)
    {
        this.propertyMatchList = propertyMatchList;
    }

    public String getSearchStr()
    {
        return searchStr;
    }

    public void setSearchStr(String searchStr)
    {
        this.searchStr = searchStr;
    }
	
	public String getSearchLabel()
    {
        return searchLabel;
    }

    public void setSearchLabel(String searchLabel)
    {
        this.searchLabel = searchLabel;
    }

    /**
     * 
     * 
     * @return
     */
    public String getMessage()
    {
        if (isAdvance) {
            return " advanced search results.";
        }
        if (searchStr == null) {
            return "";
        }
        return " search result for \""+searchStr+"\"";
    }
    
    /**
     * 
     * 
     * @return BaseAdvanceSearchForm
     */
    public BaseForm getBaseForm()
    {
        return baseForm;
    }
    
    /**
     * set BaseAdvanceSearchForm
     * 
     * @param baseAdvanceSearchForm
     */
    public void setBaseForm(BaseForm baseForm)
    {
        this.baseForm = baseForm;
    }
}
