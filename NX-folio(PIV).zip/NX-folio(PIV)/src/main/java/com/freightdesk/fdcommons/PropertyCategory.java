/** 
* Copyright (c) 2000-2002 NTELX 
*  All rights reserved. 
* 
* This software is the confidential and proprietary information of NTELX 
* ("Confidential Information").  You shall not disclose such Confidential Information 
* and shall use it only in accordance with the terms of the license agreement you entered 
* into with NTELX. 
* 
* 
*  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/PropertyCategory.java,v 1.1 2006/10/27 10:05:15 ranand Exp $ 
* 
*  Modification History:
*  $Log: PropertyCategory.java,v $
*  Revision 1.1  2006/10/27 10:05:15  ranand
*  Added to read XML properties file
*
*/

package com.freightdesk.fdcommons;

import java.util.List;

/**
 * 
 * This class contains the info related to categories used 
 * to group the properties. 
 * 
 * @author Rajender Anand
 *
 */
public class PropertyCategory
{
    /**  Sequence for the category */
    private String sequence;
    
    /**  Name of Category */
    private String categoryName;
    
    /** List of Properties */
    private List propertyList;
    
    
    public String getCategoryName()
    {
        return categoryName;
    }
    public void setCategoryName(String categoryName)
    {
        this.categoryName = categoryName;
    }
    public String getSequence()
    {
        return sequence;
    }
    public void setSequence(String sequence)
    {
        this.sequence = sequence;
    }
    /**
     * @return Returns the propertyList.
     */
    public List getPropertyList()
    {
        return propertyList;
    }
    /**
     * @param propertyList The propertyList to set.
     */
    public void setPropertyList(List propertyList)
    {
        this.propertyList = propertyList;
    }
    
}
