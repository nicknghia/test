/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/ServiceLocatorException.java,v 1.1 2006/03/29 22:05:35 ranand Exp $
 * 
 *  Modification History:
 *  $Log: ServiceLocatorException.java,v $
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons;

import org.apache.log4j.Logger;

/**
 * This class implements an exception which can wrapped a lower-level exception.
 *
 */
public class ServiceLocatorException extends Exception {
  protected Logger logger = Logger.getLogger(getClass());
  private Exception exception;

  /**
   * Creates a new ServiceLocatorException wrapping another exception, and with a detail message.
   * @param message the detail message.
   * @param exception the wrapped exception.
   */
  public ServiceLocatorException(String message, Exception exception) {
    
    super(message);
      logger.debug("ServiceLocatorException   111");
    this.exception = exception;
    return;
  }

  /**
   * Creates a ServiceLocatorException with the specified detail message.
   * @param message the detail message.
   */
  public ServiceLocatorException(String message) {
      
    this(message, null);
      logger.debug("ServiceLocatorException   222");
    return;
  }

  /**
   * Creates a new ServiceLocatorException wrapping another exception, and with no detail message.
   * @param exception the wrapped exception.
   */
  public ServiceLocatorException(Exception exception) {
    this(null, exception);
      logger.debug("ServiceLocatorException   333");
    return;
  }

  /**
   * Gets the wrapped exception.
   *
   * @return the wrapped exception.
   */
  public Exception getException() {
        logger.debug("ServiceLocatorException   444");
    return exception;
  }

  /**
   * Retrieves (recursively) the root cause exception.
   *
   * @return the root cause exception.
   */
  public Exception getRootCause() {
        logger.debug("ServiceLocatorException   555");
    if (exception instanceof ServiceLocatorException) {
      return ((ServiceLocatorException) exception).getRootCause();
    }
    return exception == null ? this : exception;
  }

  public String toString() {
        logger.debug("ServiceLocatorException   66");
    if (exception instanceof ServiceLocatorException) {
      return ((ServiceLocatorException) exception).toString();
    }
    return exception == null ? super.toString() : exception.toString();
  }
}

