/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/UserPreferenceModel.java,v 1.1 2006/03/29 22:05:35 ranand Exp $
 * 
 *  Modification History:
 *  $Log: UserPreferenceModel.java,v $
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:27:37  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.3  2006/03/28 21:23:07  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.2  2005/08/01 09:41:08  pjain
 *  refactored UserModel to BaseModel
 *
 *  Revision 1.1  2004/09/15 13:07:11  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdcommons;

import java.io.Serializable;
import java.sql.Timestamp;


/**
 * Models the persistable UserPreference object.
 *
 * @author Nitin Gupta
 * @author Amrinder Arora 
 */
public class UserPreferenceModel extends BaseModel
    implements Serializable
{
	private long userPreferenceId;
	private long systemUserId;   
	private String preferenceCode; 
	private String prefValue;
	
     public UserPreferenceModel()
     {
    
     }

	public UserPreferenceModel(long userPreferenceId,long systemUserId,String preferenceCode,String prefValue,String status,
	                           String createUserId,Timestamp createTimestamp, String lastUpdateUserId,	Timestamp lastUpdateTimestamp, String domainName)
	{
		this.userPreferenceId = userPreferenceId;
        this.systemUserId = systemUserId;
        this.preferenceCode = preferenceCode;
        this.prefValue = prefValue;
        this.status = status;
		this.createUserId = createUserId;
		this.createTimestamp = createTimestamp;
		this.lastUpdateUserId = lastUpdateUserId;
		this.lastUpdateTimestamp = lastUpdateTimestamp;
		this.domainName = domainName;
	 }
        
	

	/**
	 * Implements the abstract method defined by BaseModel.
	 * @return primaryKey  the unique id key for this model object.
	 */
	public long getPrimaryKey(){
		return this.userPreferenceId;
	}  
      
	/**
	 * @return preferenceCode
	 */
	public String getPreferenceCode() {
		return this.preferenceCode;
	}

	/**
	 * @return prefValue
	 */
	public String getPrefValue() {
		return this.prefValue;
	}

	/**
	 * @return systemUserId
	 */
	public long getSystemUserId() {
		return this.systemUserId;
	}

	/**
	 * @param preferenceCode
	 */
	public void setPreferenceCode(String preferenceCode) {
		this.preferenceCode = preferenceCode;
	}

	/**
	 * @param prefValue
	 */
	public void setPrefValue(String prefValue) {
		this.prefValue = prefValue;
	}

	/**
	 * @param systemUserId
	 */
	public void setSystemUserId(long systemUserId) {
		this.systemUserId = systemUserId;
	}

	/**
	 * @return userPreferenceId
	 */
	public long getUserPreferenceId() {
		return userPreferenceId;
	}

	/**
	 * @param userPreferenceId
	 */
	public void setUserPreferenceId(long userPreferenceId) {
		this.userPreferenceId = userPreferenceId;
	}

}

