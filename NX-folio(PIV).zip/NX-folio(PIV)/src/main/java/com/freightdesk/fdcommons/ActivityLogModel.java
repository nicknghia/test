package com.freightdesk.fdcommons;

import java.sql.Timestamp;

/**
 * model corresponding to activitylog table.
 * @author Amit Tripathi
 *
 */
public class ActivityLogModel extends BaseModel
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long activityLogId;

    private String activityType;

    private Timestamp dateTime;

    private String userId;

    private String doneBy;

    private String result;

    private String ipAddress;

    public String getActivityType()
    {
        return activityType;
    }

    /**
     * Implements the abstract method defined by BaseModel.
     *
     * @return The primaryKey for this model object
     */
    public long getPrimaryKey()
    {
        return this.activityLogId;
    }

    public void setActivityType(String activityType)
    {
        this.activityType = activityType;
    }

    public Timestamp getDateTime()
    {
        return dateTime;
    }

    public void setDateTime(Timestamp dateTime)
    {
        this.dateTime = dateTime;
    }

    public String getDoneBy()
    {
        return doneBy;
    }

    public void setDoneBy(String doneBy)
    {
        this.doneBy = doneBy;
    }

    public String getResult()
    {
        return result;
    }

    public void setResult(String result)
    {
        this.result = result;
    }

    public String getUserId()
    {
        return userId;
    }

    public void setUserId(String userId)
    {
        this.userId = userId;
    }

    public String getIpAddress()
    {
        return ipAddress;
    }

    public void setIpAddress(String ipAddress)
    {
        this.ipAddress = ipAddress;
    }
}
