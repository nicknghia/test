package com.freightdesk.fdcommons.taglib;

import java.io.IOException;

import javax.servlet.jsp.JspException;
import javax.servlet.jsp.JspWriter;
import javax.servlet.jsp.tagext.Tag;
import javax.servlet.jsp.tagext.TagSupport;

import org.apache.log4j.Logger;

public class SortedTag extends TagSupport implements Tag {
	/**
	 * a log4j Logger
	 */
	protected Logger logger = Logger.getLogger(getClass());

	/**
	 * Private variable to <%@ attribute name="colName" required="true" %> %@
	 * attribute name="sortColAttr" %> <%@ attribute name="sortOrderAttr" %>
	 * hold whether or not the user in session has the specified permission.
	 */

	protected String colName;

	protected String sortColAttr;

	protected String sortOrderAttr;

	/**
	 * Processes the start of the tag.
	 */
	public int doStartTag() throws JspException {
		try {

			JspWriter out = pageContext.getOut();
			out.println("<START TAG>");

			String orderAttr = "up";
			orderAttr = "up".equals(sortOrderAttr) ? "down" : "up";

			// "<a class=\"a1\" href=\"\" onClick=\"return
			// sortbyColumn('<%=orderAttr%>','<%=colName%>');\">"
			out
					.println("<a class=\"a1\" href=\"\" onClick=\"return sortbyColumn('"
							+ orderAttr + "','" + colName + "');\">");

		} catch (Exception ioe) {
			logger.error("Exception while writing to client", ioe);
			throw new JspException("IOException while writing to client"
					+ ioe.getMessage());
		}
		return EVAL_BODY_INCLUDE;
	}

	public int doEndTag() {
		JspWriter out = pageContext.getOut();

		String orderAttr = "up";
		String sortImage = "<img src='/resources/images/up_arrow.gif'/>";
		orderAttr = "up".equals(sortOrderAttr) ? "down" : "up";

		if ("down".equals(orderAttr))
			sortImage = "<img src='/resources/images/down_arrow.gif'/>";

		try {

			out.println("</a>");

			if (colName != null && colName.equals(sortColAttr))
				out.println(sortImage);

		} catch (IOException e) {
			//e.printStackTrace();
			logger.error("Exception : " + e.getMessage());
		}
		return EVAL_PAGE;
	}

	public void setColName(String colName) {
		this.colName = colName;
	}

	public void setSortColAttr(String sortColAttr) {
		this.sortColAttr = sortColAttr;
	}

	public void setSortOrderAttr(String sortOrderAttr) {
		this.sortOrderAttr = sortOrderAttr;
	}
}
