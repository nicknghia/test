/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/DuplicateRecordFoundException.java,v 1.1 2006/03/29 22:05:35 ranand Exp $
 * 
 *  Modification History:
 *  $Log: DuplicateRecordFoundException.java,v $
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons;


/**
 * @author nitin.gupta
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */

public class DuplicateRecordFoundException extends LcpApplicationException {

	/**
	 *
	 */
	public DuplicateRecordFoundException() {
		super();
	}

	/**
	 * @param message
	 */
	public DuplicateRecordFoundException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public DuplicateRecordFoundException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public DuplicateRecordFoundException(Throwable cause) {
		super(cause);
	}

}
