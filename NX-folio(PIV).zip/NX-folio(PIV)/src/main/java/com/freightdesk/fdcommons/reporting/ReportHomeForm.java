/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/reporting/ReportHomeForm.java,v 1.1 2006/06/21 11:20:25 dkumar Exp $
 * 
 *  Modification History:
 *  $Log: ReportHomeForm.java,v $
 *  Revision 1.1  2006/06/21 11:20:25  dkumar
 *  repackaging of ReportUtility to FDCommons
 *
 *  Revision 1.5  2006/02/24 21:31:49  ranand
 *  Code Merged from Nafith branch
 *
 *  Revision 1.4.2.2  2006/02/10 20:48:12  ranand
 *  Report support different formats
 *
 *  Revision 1.4.2.1  2005/11/28 13:00:05  ranand
 *  added new parameter
 *
 *  Revision 1.4  2005/07/07 09:32:03  ranand
 *  property header and footer added
 *
 *  Revision 1.3  2005/07/06 05:56:51  ranand
 *  added  functionality for "Company Report" drop down in the home page
 *
 *  Revision 1.2  2004/12/16 16:06:58  asaxena
 *  fixed  bug 1166
 *
 *  Revision 1.1  2004/09/15 13:36:28  asingh
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons.reporting;

import java.util.List;
import java.util.Map;


public class ReportHomeForm {
        
    private Map reportsMap;
    private String domainName;
    private String configFile;
    private String beginDate;
    private String endDate;
    private String generateReport;
    private String count;
    private String fileName;
    private String[] name;
    private String[] type;
    private String[] label;
    private String[] value;
    private String reportName;
    private List inputFieldsList;   
    	

	/**
	 * Returns the reportsMap.
	 * @return Map
	 */
	public Map getReportsMap() {
		return reportsMap;
	}


	/**
	 * Sets the reportsMap.
	 * @param reportsMap The reportsMap to set
	 */
	public void setReportsMap(Map reportsMap) {
		this.reportsMap = reportsMap;
	}


	/**
	 * Returns the configFile.
	 * @return String
	 */
	public String getConfigFile() {
		return configFile;
	}
	
	
	/**
	 * Sets the configFile.
	 * @param configFile The configFile to set
	 */
	public void setConfigFile(String configFile) {
		this.configFile = configFile;
	}
	
	/**
	 * Returns the fileName.
	 * @return String
	 */
	public String getFileName() {
		return fileName;
	}
	
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

    /**
     * Returns the beginDate.
     * @return String
     */
    public String getBeginDate() {
        return beginDate;
    }

    /**
     * Returns the endDate.
     * @return String
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * Returns the submit.
     * @return String
     */
    public String getGenerateReport() {
        return generateReport;
    }

    /**
     * Sets the beginDate.
     * @param beginDate The beginDate to set
     */
    public void setBeginDate(String beginDate) {
        this.beginDate = beginDate;
    }

    /**
     * Sets the endDate.
     * @param endDate The endDate to set
     */
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    /**
     * Sets the submit.
     * @param submit The submit to set
     */
    public void setGenerateReport(String argGenerateReport) {
        this.generateReport = argGenerateReport;
    }
    

	/**
	 * Returns the label.
	 * @return String[]
	 */
	public String[] getLabel() {
		return label;
	}

	/**
	 * Returns the name.
	 * @return String[]
	 */
	public String[] getName() {
		return name;
	}

	/**
	 * Returns the type.
	 * @return String[]
	 */
	public String[] getType() {
		return type;
	}

	/**
	 * Sets the label.
	 * @param label The label to set
	 */
	public void setLabel(String[] label) {
		this.label = label;
	}

	/**
	 * Sets the name.
	 * @param name The name to set
	 */
	public void setName(String[] name) {
		this.name = name;
	}

	/**
	 * Sets the type.
	 * @param type The type to set
	 */
	public void setType(String[] type) {
		this.type = type;
	}

	/**
	 * Returns the count.
	 * @return String
	 */
	public String getCount() {
		return count;
	}

	/**
	 * Sets the count.
	 * @param count The count to set
	 */
	public void setCount(String count) {
		this.count = count;
	}

	/**
	 * Returns the parameterList.
	 * @return List
	 */
	public List getInputFieldsList() {
		return inputFieldsList;
	}

	/**
	 * Sets the parameterList.
	 * @param parameterList The parameterList to set
	 */
	public void setInputFieldsList(List parameterList) {
		inputFieldsList = parameterList;
	}

	/**
	 * Returns the reportName.
	 * @return String
	 */
	public String getReportName() {
		return reportName;
	}

	/**
	 * Sets the reportName.
	 * @param reportName The reportName to set
	 */
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	/**
	 * Returns the domainName.
	 * @return String
	 */
	public String getDomainName() {
		return domainName;
	}

	/**
	 * Sets the domainName.
	 * @param domainName The domainName to set
	 */
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	/**
	 * @return Returns the value.
	 */
	public String[] getValue() {
		return value;
	}
	/**
	 * @param value The value to set.
	 */
	public void setValue(String[] value) {
		this.value = value;
	}
	
}

