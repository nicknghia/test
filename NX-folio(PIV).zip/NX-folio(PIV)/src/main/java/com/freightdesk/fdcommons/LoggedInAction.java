/**
 * Copyright (c) 2000-2002 NTELX All rights reserved.
 * 
 * This software is the confidential and proprietary information of FreightDesk
 * Technologies, LLC ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with NTELX.
 */

package com.freightdesk.fdcommons;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Timestamp;
import java.util.Iterator;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;
import org.apache.log4j.NDC;
//import org.apache.struts.action.Action;
//import org.apache.struts.action.ActionErrors;
//import org.apache.struts.action.ActionForm;
//import org.apache.struts.action.ActionForward;
//import org.apache.struts.action.ActionMapping;
//import org.apache.struts.action.ActionMessage;
//import org.apache.struts.action.ActionMessages;
//import org.apache.struts.util.MessageResources;
import com.freightdesk.fdcommons.ActionErrors;
import com.freightdesk.fdcommons.ActionMessage;
import com.freightdesk.fdcommons.ActionMessages;

import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;
import com.freightdesk.fdcommons.search.ViewContext;


/**
 * The base Struts Action class for freightDesk applications, which ensures that
 * the user is logged in before performing any further action.
 * 
 * All concrete subclasses must implement execute method.
 * 
 * @author Amrinder Arora
 * @author Amit Tripathi
 * @author Rajender Anand
 */
//public abstract class LoggedInAction extends Action
public abstract class LoggedInAction
{
    /** A logger */
    protected Logger logger = Logger.getLogger("com.freightdesk.fdcommons.LoggedInAction");

    /** Manager for logging Asynchronous request for time consuming Framework */
    protected static AsyncProcessManager asyncRequestManager = new AsyncProcessManager();


    /** The execute method which every concrete sub class should implement */
//    public abstract ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response, Credentials credentials)
//        throws java.lang.Exception;

    /**
     * checks permission for the requested operation
     * 
     * @param request
     * @param response
     * @param credentials
     * @param mapping
     * @return
     */

//    public final boolean checkPermission(HttpServletRequest request, HttpServletResponse response, Credentials credentials, ActionMapping mapping)
//    {
//        String permission = getSystemFunctionCode(request);
//        HttpSession session = request.getSession();
//        SessionStore sessionStore = SessionStore.getInstance(session);
//        Map accessMap = (Map) (sessionStore.get(SessionKey.ACCESS_CONTROL_LIST));
//        boolean hasPermission = false;
//        
//        hasPermission = checkSecurityPermission(permission, accessMap, credentials);
//        if (hasPermission == false) {
//            try {
//                response.sendRedirect("/noPermissions.jsp?");
//            } catch (IOException ioe) {
//                logger.error("Exception in redirecting response to noPermissions.jsp:" + ioe);
//            }
//        } 
//        return hasPermission;
//    }

    /** The execute method. Declared final. */
//    public final ActionForward execute(ActionMapping mapping, ActionForm form, HttpServletRequest request, HttpServletResponse response)
//        throws java.lang.Exception
//    {
//        HttpSession session = request.getSession(false);
//        if (session == null) {
//            logger.info("request is not in any known session - webserver does not know this browser instance");
//            return handleInvalidSession(request, response);
//        }
//        SessionStore store = SessionStore.getInstance(session);
//
//        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
//
//        boolean isInvalidSession = isSessionInvalidated(mapping, request);
//
//        logger.debug("isInvalidSession: " + isInvalidSession);
//
//        if (isInvalidSession) {
//            return handleInvalidSession(request, response);
//        }
//        boolean hasPermission = checkPermission(request, response, credentials, mapping);
//        if (!hasPermission) {
//            return null;
//        }


        // calls the real "execute", redirecting to error page if an exception
        // was raised
//        try {
//            
//            String contextPath = request.getContextPath();
//            logger.debug("contextPath: "+contextPath);
//
//            NDC.setMaxDepth(1);
//            NDC.push(credentials.getUserId());
//            return this.execute(mapping, form, request, response, credentials);
//        } catch (SystemUnavailableException sue) {
//            logger.info("Logging this user out, as the system is marked for safe exit");
//            session.removeAttribute(SessionKey.SESSION_STORE.getKey());
//            String message = sue.getMessage();
//            if ("SE".equalsIgnoreCase(message)) {
//                response.sendRedirect(response.encodeRedirectURL("/logon.do?action=LOGOUT&reason=SE"));
//                return null;
//            } else if ("SU".equalsIgnoreCase(message)) {
//                response.sendRedirect(response.encodeRedirectURL("/logon.do?action=LOGOUT&reason=SU"));
//                return null;
//            } else if ("NW".equalsIgnoreCase(message)) {
//                response.sendRedirect(response.encodeRedirectURL("/logon.do?reason=NW&rnd=" + Math.random()));
//                return null;
//            }
//            response.sendRedirect(response.encodeRedirectURL("/logon.do?action=LOGOUT&reason=SE"));
//            return null;
//        } catch (Throwable e) {
//            logger.error("Exception raised in execute, redirecting to home page", e);
//
//            // Lets the application error handler handle the top level exception
//            ApplicationErrorHandler.handleApplicationError(e, credentials);
//
//            // Gets the tab key in which the problem *probably* occured
//            Integer currentTab = (Integer) (store.get(SessionKey.CURRENT_TAB));
//            String tabKey = ApplicationTabs.getTabKey(currentTab);
//
//
//			// As ActionMessage will take both String and Array of Objects
//			String[] messageKeyObject = new String[2];
//			messageKeyObject[0] = "error.module";
//			messageKeyObject[1] = tabKey.substring(10);
//			setActionMessage(request, messageKeyObject);
//			session.setAttribute("LAST_UNEXPECTED_EXCEPTION", e);
//
//            // Added to avoid self looping
//            logger.debug("Exception was invoked from :" + store.get(SessionKey.CURRENT_TAB));
//            response.sendRedirect("/ErrorPage.jsp?");
//            return null;
//        } finally {
//            NDC.clear();
//            NDC.remove();
//        }
//    }

    /**
     * Handles an invalid session.
     * 
     * @param request
     * @param response
     * @return The ActionForward
     * @throws IOException
     */
//    private ActionForward handleInvalidSession(HttpServletRequest request, HttpServletResponse response)
//        throws IOException
//    {
//        if (isAsynchronousRequest(request)) {
//            // For AJAX Request write to the response stream.
//            PrintWriter writer = response.getWriter();
//            writer.write("Your session has expired.");
//            writer.flush();
//            writer.close();
//            return null;
//        } else {
//            response.sendRedirect("/expire.jsp?");
//            return null;
//        }
//    }

    /**
     * 
     * Invalidates the session if there is no Credentials in SessionStore or
     * user is Logged in from another Location.
     * 
     * @param mapping
     * @param request
     * @return boolean
     */
//    private boolean isSessionInvalidated(ActionMapping mapping, HttpServletRequest request)
//    {
//        HttpSession session = request.getSession(false);
//        SessionStore store = SessionStore.getInstance(session);
//
//        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
//        if (credentials == null) {
//            logger.debug("User is not logged in, redirecting to login page");
//            ActionErrors errors = new ActionErrors();
//            errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("error.sessionExpired"));
//            this.saveErrors(request, errors);
//            store.invalidateSessions(request);
//            return true;
//        }
//
//        //checks that user is already login then forward to login page
//        if (session != null && session.getAttribute("logout.reason.loggedInFromAnotherLoc") != null) {
//            logger.debug("User has logged in from another page, logging out from here, and redirecting to login page");
//            ActionErrors errors = new ActionErrors();
//            errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("error.sessionExpired.loggedInFromAnotherLoc"));
//            this.saveErrors(request, errors);
//            store.invalidateSessions(request);
//            return true;
//        }
//
//        return false;
//    }

    /**
     * The public method to check the security permissions to see if the user is
     * allowed to certain action
     */
    public boolean checkSecurityPermission(String permission, Map accessMap, Credentials credentials)
    {
    	boolean hasPermission = false;
    	if (permission == null || accessMap.containsKey(permission)) {
    		hasPermission = true;
    	} else {
    		logger.debug(credentials.getRole() + " does not have permission " + permission);
    	}
        return hasPermission;
    }

    /**
     * A convenience method to popcom.freightdesk.fdfolio.utiluses
     * {@link com.ntelx.nxcommons.StackManager#closeEvent()}for the
     * StackManager object stored in the session.
     */
    public void popStack(HttpServletRequest request)
    {
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        StackManager stackManager = (StackManager) sessionStore.get(SessionKey.STACK);
        if (stackManager != null) {
            stackManager.closeEvent();
        }
    }

    /**
     * A convenience method to create a new event on the stack
     */
    public void pushStack(String newAction, String newMgr, String newOprType, HttpServletRequest request)
    {
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        StackManager stackManager = (StackManager) (sessionStore.get(SessionKey.STACK));
        if (stackManager == null) {
            stackManager = new StackManager();
            sessionStore.put(SessionKey.STACK, stackManager);
        }

        if (newAction != null && !newAction.trim().equals("")) {
            stackManager.createEvent(new OperationInfo(newMgr, newOprType, newAction, "", "", ""));
        }
    }

    /**
     * returns action forward for the return path.
     * 
     * @param mapping
     * @param request
     * @param pathToAppend
     * @return
     */
//    public ActionForward getReturnPath(ActionMapping mapping, HttpServletRequest request, String pathToAppend)
//    {
//        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
//        String invokedFrom = (String) sessionStore.get(SessionKey.INVOKED_FROM);
//        return getReturnPath(mapping, invokedFrom, pathToAppend);
//    }

    /**
     * returns action forward, generated from forwardName and pathToAppend
     * 
     * @param mapping
     * @param forwardName
     * @param pathToAppend
     * @return
     */
//    private ActionForward getReturnPath(ActionMapping mapping, String forwardName, String pathToAppend)
//    {
//        logger.info("getReturnPath(): begin");
//        ActionForward actionForward = new ActionForward();
//        if (forwardName != null) {
//            String path = mapping.findForward(forwardName).getPath() + pathToAppend;
//            logger.debug("path: " + path);
//            actionForward.setPath(path);
//            logger.info("getReturnPath(): end");
//            return actionForward;
//        } else {
//            return mapping.findForward("home");
//        }
//    }

    /**
     * 
     * append offset value to the URL.
     * 
     * @param mapping
     * @param forwardName
     * @param viewContext
     * @return ActionForward
     */
//    protected ActionForward getReturnPathforViewContext(ActionMapping mapping, String forwardName, ViewContext viewContext)
//    {
//        logger.info("getReturnPath(): begin");
//        String pathToAppend = "?pager.offset=" + viewContext.getViewOffsetIndex();
//        logger.debug("pathToAppend: " + pathToAppend);
//        logger.info("getReturnPath(): end");
//        return getReturnPath(mapping, forwardName, pathToAppend);
//    }

    public void obtainLock(ObjectKey objectKey, long userId)
        throws ObjectLockedException
    {
        try {
            ObjectLock.getInstance().obtainLock(objectKey, userId);
        } catch (ObjectLockedException e) {
            logger.error("Object already locked by another user", e);
            throw e;
        }
    }

    public void releaseLock(ObjectKey objectKey, long userId)
    {
        ObjectLock.getInstance().releaseLock(objectKey, userId);
    }

    /** Puts an object into session store. */
    public void putIntoSessionStore(HttpServletRequest request, SessionKey sessionKey, Object obj)
    {
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        sessionStore.put(sessionKey, obj);
    }

    /** Gets an object from session store. */
    public Object getFromSessionStore(HttpServletRequest request, SessionKey sessionKey)
    {
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        return sessionStore.get(sessionKey);
    }

    /**
     * sets message to request.
     * 
     * @param request
     * @param messageKeyObject
     * 
     * @Deprecated - replaced by setActionMessage(request, messageKeyObject,
     *             isMessageForHomePage, isHomePageMainMessage)
     */
//    public void setActionMessage(HttpServletRequest request, String[] messageKeyObject)
//    {
//        setActionMessage(ActionMessages.GLOBAL_MESSAGE, request, messageKeyObject, new ActionMessages());
//    }

    /**
     * 
     * sets message to request.
     * 
     * @param request
     * @param messageKeyObject 
     * @param isMessageForHomePage -  true if message to be displayed on Home page
     */
//    public void setActionMessage(HttpServletRequest request, String[] messageKeyObject, boolean isMessageForHomePage)
//    {
//        ActionMessages newActionMessages = new ActionMessages();
//        setActionMessage(ActionMessages.GLOBAL_MESSAGE, request, messageKeyObject, newActionMessages);
//        
//    }

    /**
     * sets message to request.
     * 
     * @param key
     * @param request
     * @param messageKeyObject
     * @param messages
     */
//    public void setActionMessage(String key, HttpServletRequest request, String[] messageKeyObject, ActionMessages messages)
//    {
//        ActionMessage actionMessage = getActionMessage(messageKeyObject);
//        messages.add(key, actionMessage);
//        this.saveMessages(request, messages);
//        logger.debug("message has been set on request");
//    }

    /**
     * 
     * creates the ActionMessage Object from the given array.
     * 
     * 
     * @param messageKeyObject
     * @return
     */
    public ActionMessage getActionMessage(String[] messageKeyObject)
    {

        int length = messageKeyObject.length;
        logger.debug("messageKeyObject.length = " + length);
        ActionMessage actionMessage = null;
        switch (length) {
            case 2:
                logger.debug("messagekeyvalues" + messageKeyObject[0]);
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1]);
                break;
            case 3:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2]);
                break;
            case 4:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3]);
                break;
            case 5:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3], messageKeyObject[4]);
                break;
            default:
                actionMessage = new ActionMessage(messageKeyObject[0]);
        }

        return actionMessage;
    }


    /**
     * checks whether the request is Asynchronous AJAX request ( based on
     * Header: isAnsynchronous=true)
     * 
     * @param httpRequest
     * @return boolean
     */
    protected boolean isAsynchronousRequest(HttpServletRequest httpRequest)
    {
        String isAnsynchronous = httpRequest.getHeader("isAnsynchronous");
        if ("true".equalsIgnoreCase(isAnsynchronous)) {
            return true;
        }
        return false;
    }

    /**
     * 
     * Returns an instance of AsyncProcessingLogModel
     * 
     * @return
     */
    protected AsyncProcessingLogModel getAsyncProcessingModel(HttpServletRequest request, HttpServletResponse response, Credentials credentials)
    {
        String moduleName = request.getHeader("moduleName");
        String description = request.getHeader("description");
        String guid = request.getHeader("guid");

        /** Prepare the response Headers * */
        response.setContentType(LcpConstants.ContentType.TEXT_XML);
        //response.setHeader("Cache-Control", "private");

        /** Create the Log Record * */
        AsyncProcessingLogModel asyncLog = new AsyncProcessingLogModel();
        asyncLog.setCreateUserId(credentials.getUserId());
        Timestamp currTimestamp = new Timestamp(System.currentTimeMillis());
        asyncLog.setCreateTimestamp(currTimestamp);
        asyncLog.setLastUpdateUserId(credentials.getUserId());
        asyncLog.setLastUpdateTimestamp(currTimestamp);
        asyncLog.setDomainName(credentials.getDomainName());
        asyncLog.setStatus(AsyncProcessingLogModel.STATUS_INPROCESS);
        asyncLog.setModuleName(moduleName);
        asyncLog.setDescription(description);
        asyncLog.setGUID(guid);

        return asyncLog;

    }

    /**
     * Formats the Message text from ActionMessage object
     * 
     * @param request
     * @param responseMsg
     * @param messages
     */
//    protected void getMessageText(HttpServletRequest request, StringBuffer responseMsg, ActionMessages messages)
//    {
//        Iterator it = messages.get();
//        while (it.hasNext()) {
//            ActionMessage message = (ActionMessage) it.next();
//            responseMsg.append(getMessageText(request, message.getKey(), message.getValues()));
//            responseMsg.append(" ");
//        }
//    }

    /**
     * 
     * Formats the Message text for given resource key and values.
     * 
     * @param request
     * @param key
     * @param values
     */
//    protected String getMessageText(HttpServletRequest request, String key, Object[] values)
//    {
//        MessageResources resource = this.getResources(request);
//        return resource.getMessage(getLocale(request), key, values);
//    }

    /**
     * Method for processing Asynchronous AJAX requests. One need to Override
     * this Method. In Overriden version, one should process the request, update
     * the asyncProcessLog Model for its Status/LastUpdateTimeStamp/FeedBack.
     * Call "asyncRequestManager.updateAsyncProcessLogModel(asyncProcessLog)"
     * method to update DB record. Create response and flush the Response.
     * 
     * @param form
     * @param request
     * @param response
     * @param credentials
     * @param asyncProcessLog
     * @throws Exception
     */
//    protected void processAsynchronousRequest(ActionForm form, HttpServletRequest request, HttpServletResponse response, Credentials credentials,
//            AsyncProcessingLogModel asyncProcessLog)
//        throws Exception
//    {
//        logger.debug("processAsynchronousRequest(): begin");
//        throw new IllegalArgumentException("processAsynchronousRequest() method not Overrided in Action Class");
//    }

    /**
     * gets String repesentation of passed request object. This is default
     * representation, subclass can override.
     * 
     * @param request
     * @return
     */
//    protected String getRequestString(HttpServletRequest request, ActionForm form)
//    {
//        String requestedURI = request.getRequestURI();
//        String queryString = request.getQueryString();
//        String requestString = "requestedURI:" + requestedURI + " queryString:" + queryString;
//        return requestString;
//    }

    /**
     * returns permission code
     * 
     * @return
     */
    protected String getSystemFunctionCode(HttpServletRequest request)
    {
        String URI = request.getRequestURI();
        String action = request.getParameter("action");
        String process = request.getParameter("process");
        String forward = request.getParameter("forward");
        
        // User homepage
        if (URI.indexOf("userHome.do") >= 0)
          return "NAV3";

        // Address tab/Entity management
        if (URI.indexOf("addressHome.do") >= 0) {
            if ("addOrg".equalsIgnoreCase(forward))
                return "A13";
            else if ("addLoc".equalsIgnoreCase(forward))
            	return "A9";
            else if ("addCon".equalsIgnoreCase(forward))
            	return "A16";
            else
            	return "NAV4";
        }

        // Setup tab and links from setup home
        if (URI.indexOf("setupHome.do") >= 0) {
            if ("reload".equalsIgnoreCase(action))
                return "ADM31";
        }
        
        if (URI.indexOf("systemMessage.do") >= 0)
        	return "ADM15";
        
        if (URI.indexOf("listUsers.do") >= 0)
        	if ("userAdd".equalsIgnoreCase(process))
        		return "ADM10";
        	else if("delete".equalsIgnoreCase(process))
        		return "ADM11";
        	else
        		return "ADM1";
        
        if (URI.indexOf("editData.do") >= 0)
            return "ADM3";
        
        if (URI.indexOf("assignRole.do") >= 0) 
            return "ADM7";
        
        if (URI.indexOf("editProperties.do") >= 0)
            return "ADM6";
        
        if (URI.indexOf("onlineUsers.do") >= 0)
            return "ADM9";
        
        if (URI.indexOf("assignRole.do") >= 0)
        	return "ADM7";
        // end setup pages
        
        // For core FAS tabs
        if (URI.indexOf("awbHome.do") >= 0) 
        	return "ADM1";

        if (URI.indexOf("awbDetails.do") >= 0) 
        	return "ADM1";

        return null;
    }
}
