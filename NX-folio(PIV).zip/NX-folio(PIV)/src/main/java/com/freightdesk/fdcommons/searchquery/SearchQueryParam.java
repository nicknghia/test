/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: 
 * 
 *  Modification History:
 *  $Log: 
 *
 */

package com.freightdesk.fdcommons.searchquery;

import com.freightdesk.fdcommons.BaseModel;

/**
 * @author Rajender Anand
 *
 */
public class SearchQueryParam  extends BaseModel
{
    private long   searchQueryParamId; 
    private String paramValue; 
    private int   sequence; 
    private long searchQueryId;
    
    /**
     *  Gets the Primary Key
     */
    public long getPrimaryKey() {
        return searchQueryParamId;
    }

    /**
     * @return the paramValue
     */
    public String getParamValue()
    {
        return paramValue;
    }

    /**
     * @param paramValue the paramValue to set
     */
    public void setParamValue(String paramValue)
    {
        this.paramValue = paramValue;
    }

    /**
     * @return the searchQueryParamId
     */
    public long getSearchQueryParamId()
    {
        return searchQueryParamId;
    }

    /**
     * @param searchQueryParamId the searchQueryParamId to set
     */
    public void setSearchQueryParamId(long searchQueryParamId)
    {
        this.searchQueryParamId = searchQueryParamId;
    }

    /**
     * @return the sequence
     */
    public int getSequence()
    {
        return sequence;
    }

    /**
     * @param sequence the sequence to set
     */
    public void setSequence(int sequence)
    {
        this.sequence = sequence;
    }

    /**
     * @return the searchQueryId
     */
    public long getSearchQueryId()
    {
        return searchQueryId;
    }

    /**
     * @param searchQueryId the searchQueryId to set
     */
    public void setSearchQueryId(long searchQueryId)
    {
        this.searchQueryId = searchQueryId;
    }

}
