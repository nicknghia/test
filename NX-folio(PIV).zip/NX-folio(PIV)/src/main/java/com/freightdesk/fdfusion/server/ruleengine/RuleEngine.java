package com.freightdesk.fdfusion.server.ruleengine;

//import crt.com.freightdesk.fdfolio.event.VarianceComparator;
//import crt.com.freightdesk.fdfolio.event.FasEventUtil;
import org.apache.log4j.Logger;

import com.freightdesk.fdfolio.event.model.EventModel;
import com.freightdesk.fdcommons.Credentials;
import crt.com.ntelx.nxcommons.FasConstants;

public class RuleEngine {
	protected final Logger logger = Logger.getLogger(RuleEngine.class);

//	public EventModel applyFlags(EventModel model, Credentials credentials) {
//		logger.debug("Applying flags to model");
//
//		if (FasEventUtil.isPastEditDate(model.getEventDateTime()) && (!model.getFlagUnlock().equalsIgnoreCase("Y"))) {
//			logger.debug("marking submission late");
//			model.setFlagLate("Y");
//		}
//		
//		// unlocking is for one time edit.  we are about to save so take off the unlock flag
//		if (model.getFlagUnlock()!= null && model.getFlagUnlock().equalsIgnoreCase("Y"))
//			model.setFlagUnlock(null);
//
//		// apply not 100% screen flag to Air Carrier submissions (CAR and INB)
//		String category = model.getEventCategoryCode();
//		if (category.equalsIgnoreCase(FasConstants.carCategory)) {
//			logger.debug("Performing Screening check on Air waybills");
//			double weightScreenPercent = 0;
//			double awbScreenPercent = 0;
//			
//			weightScreenPercent = FasEventUtil.calcWeightPercentScreened(model);
//			awbScreenPercent = FasEventUtil.calcAwbPercentScreened(model); 
//			
//			if ( (weightScreenPercent < 0.99) || (awbScreenPercent < 1))
//				model.setFlagScreen("Y");
//			else
//				model.setFlagScreen(null);
//		}
//
//		// variance check on total field for all submissions
//		if (!model.getFlagVarW().equalsIgnoreCase("N") || !model.getFlagVarA().equalsIgnoreCase("N")) {
//
//			VarianceComparator varComp = new VarianceComparator();
//			
//			if (category.equalsIgnoreCase(FasConstants.carCategory) || category.equalsIgnoreCase(FasConstants.inbCategory)) {
//				varComp.setCarrierComparator(model.getCarrierOrgId(), model.getAirportOrgId());
//			} else if (category.equalsIgnoreCase(FasConstants.iacCategory) || category.equalsIgnoreCase(FasConstants.shipCategory) || category.equalsIgnoreCase(FasConstants.icsfCategory)) {
//				varComp.setCcsfComparator(model.getCertNum(), model.getAirportOrgId());
//			} else {
//				logger.debug("No variance comparator defined for eventCategory "+category);
//			}
//			
//			double weightPerDay = FasEventUtil.getWeightPerDay(model);
//			int awbPerDay = FasEventUtil.getWaybillPerDay(model);
//			
//			if (!model.getFlagVarW().equalsIgnoreCase("N")) {
//			  if(varComp.weightVaries(weightPerDay))
//				model.setFlagVarW("Y");
//			  else
//				model.setFlagVarW(null);
//			}
//			
//			if (!model.getFlagVarA().equalsIgnoreCase("N")) {
//			  if(varComp.awbVaries(awbPerDay))
//				model.setFlagVarA("Y");
//			  else
//				model.setFlagVarA(null);
//			}
//
//		} else {
//			logger.debug("Variance acknowledged by user.  Setting to null for future checks");
//			model.setFlagVarW(null);
//			model.setFlagVarA(null);
//		}
//
//		return model;
//	}

}
