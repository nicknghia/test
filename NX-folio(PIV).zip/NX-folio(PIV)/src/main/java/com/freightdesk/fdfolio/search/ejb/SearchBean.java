/**
 * Copyright (c) NTELX All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the license
 * agreement you entered into with NTELX.
 *
 *
 * $Header:
 * /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/search/ejb/SearchBean.java,v
 * 1.21.2.15 2010/10/01 19:57:27 mechevarria Exp $
 *
 * Modification History: $Log: SearchBean.java,v $ Revision 1.21.2.15 2010/10/01
 * 19:57:27 mechevarria jboss6 upgrade
 *
 * Revision 1.21.2.14 2010/09/23 19:35:24 mechevarria remove ejb layer for
 * instantiating objects. direct calls to bean class now made
 *
 * Revision 1.21.2.13 2010/09/16 15:13:46 mechevarria make search with like % on
 * both sides
 *
 * Revision 1.21.2.12 2010/08/22 23:08:33 mechevarria update with company name
 * in copyright
 *
 * Revision 1.21.2.11 2010/04/28 22:39:09 mechevarria fix up jdbc
 *
 * Revision 1.21.2.10 2010/04/28 20:45:26 mechevarria prevent null point
 * exception on zero results
 *
 * Revision 1.21.2.9 2010/04/22 14:10:26 mechevarria put close statement in
 * right spot
 *
 * Revision 1.21.2.8 2010/04/21 20:27:39 mechevarria fix open jdbc statements
 *
 * Revision 1.21.2.7 2010/04/20 23:42:53 mechevarria close open resultsets
 *
 * Revision 1.21.2.6 2010/02/03 20:31:38 mechevarria update addresshome load
 * query getorghierarchies to use bind variables
 *
 * Revision 1.21.2.5 2009/12/11 21:47:56 mechevarria comment out useless jdbc
 * clearing statements
 *
 * Revision 1.21.2.4 2009/10/07 15:52:21 mechevarria pickup the contact email
 * instead of timezoneid
 *
 * Revision 1.21.2.3 2009/09/18 22:00:14 mechevarria change equals to 'in'
 * clauses
 *
 * Revision 1.21.2.2 2008/07/01 18:07:36 mechevarria update query to be more
 * efficient
 *
 * Revision 1.21.2.1 2008/02/15 20:04:00 mechevarria fix queries for bind
 * variables
 *
 * Revision 1.21 2006/10/19 11:55:37 dkumar added getAddressHomeForOrgOrLoc for
 * child navigation
 *
 * Revision 1.20 2006/10/06 08:01:09 dkumar changed getAddressHomeForUserAccess
 * query for counting num of records
 *
 * Revision 1.19 2006/05/11 16:55:28 aarora Many changes as the SessionKey class
 * has been added to com.freightdesk.fdfolio.commons
 *
 * Revision 1.18 2006/04/10 22:55:15 aarora Minor logging change
 *
 * Revision 1.17 2006/04/05 07:49:56 dkumar minor changes(removed last changes
 * for bug 1619)
 *
 * Revision 1.16 2006/04/04 16:26:16 dkumar added null check in getorgHeirchy
 * for argRole and orgType
 *
 * Revision 1.15 2006/03/29 22:53:14 aarora Due to repackaging of FormatDate
 *
 * Revision 1.14 2006/03/28 21:23:06 aarora Repackaging of fdcommons
 *
 * Revision 1.13 2005/09/15 11:13:29 pjain impact of removing getOrgName
 *
 * Revision 1.12 2005/09/01 18:53:04 amrinder Cleaning up code that is not used
 * - arguments to constructors etc
 *
 * Revision 1.11 2005/08/30 02:14:52 amrinder Trying to clean the code for
 * handling links on address tab
 *
 * Revision 1.10 2005/08/09 21:57:12 amrinder Removed redundant code
 *
 * Revision 1.9 2005/07/06 04:26:49 nsehra removed isMyAddressbook argument from
 * getOrgHierchy method . MyAddressBook functinality implemented using argument
 * addressType
 *
 * Revision 1.8 2005/07/02 10:11:04 nsehra changed method getOrgHierarchies to
 * aacept one more parameter for my addressbook
 *
 * Revision 1.7 2005/05/12 20:48:04 amrinder Removed an unused method And now
 * throwing EJBException instead of SQLException
 *
 * Revision 1.6 2005/04/26 05:34:50 dkhoker added latitude/longitude to the
 * search query
 *
 * Revision 1.5 2005/04/07 08:04:03 nsehra Paging enhancement
 *
 * Revision 1.4 2005/02/15 10:53:04 ranand Item enhancement
 *
 * Revision 1.3 2005/02/15 10:41:21 ranand Item enhancement
 *
 * Revision 1.2 2004/09/16 07:25:20 ranand package name changed from
 * organization to orghierarchy in fdfolio
 *
 * Revision 1.1 2004/09/15 13:21:11 ranand 2.6 Baseline
 */
package com.freightdesk.fdfolio.search.ejb;

import org.apache.log4j.Logger;
import java.math.BigInteger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.StringTokenizer;

import javax.ejb.CreateException;
import javax.ejb.EJBException;

import crt.com.freightdesk.fdfolio.addressbook.util.OrgSearchResult;
import com.freightdesk.fdfolio.common.LcpReferenceData;
import com.freightdesk.fdfolio.orghierarchy.ejb.OrganizationSLSBean;
import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;
//import com.freightdesk.fdfolioweb.addressbook.form.AddressHomeForm;
import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.BaseSLSBean;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.LcpConstants;
import com.freightdesk.fdcommons.ServiceLocator;

/**
 * @author Various
 */
public class SearchBean extends BaseSLSBean {

    /**
     *
     */
    private Logger logger = Logger.getLogger("SearchBean");
	
	private static final long serialVersionUID = 1L;
    /**
     * An instance of OrganizationSLS
     */
    protected OrganizationSLSBean organizationSLS;

    public OrgSearchResult getAddressHome(String startStr, String domainName, List<String> typeCodes, long startIndex, long endIndex) {
        ArrayList<OrghierarchyModel> orgList = new ArrayList<OrghierarchyModel>();
        HashMap<Integer, Object> params = new HashMap<Integer, Object>();
        int paramIndex = 0;

        String orgQuery = "SELECT * FROM ( ";
        orgQuery = orgQuery + "SELECT ORGID ,ORGNAME, COUNTRYCODE, PARENTORGID, ORGHIERARCHYTYPECODE,LASTUPDATETIMESTAMP, ROWNUM myrow ";
        orgQuery = orgQuery + "FROM ORGHIERARCHY ";
        orgQuery = orgQuery + "WHERE DOMAINNAME in (?,?) ";
        paramIndex++;
        params.put(paramIndex, "PUBLIC");
        paramIndex++;
        params.put(paramIndex, domainName);

        // dynamically fill in the like query
        if (typeCodes.size() > 0) {
            orgQuery = orgQuery + "AND ORGHIERARCHYTYPECODE in (";
            for (String typeCode : typeCodes) {
                orgQuery = orgQuery + "?,";
                paramIndex++;
                params.put(paramIndex, typeCode);
            }
            // remove the last comma
            orgQuery = orgQuery.substring(0, orgQuery.length() - 1);
            orgQuery = orgQuery + ") ";
        }

        orgQuery = orgQuery + "AND UPPER(ORGNAME) LIKE (?) ORDER BY ORGNAME DESC ";
        paramIndex++;
        params.put(paramIndex, "%" + startStr.toUpperCase() + "%");

        orgQuery = orgQuery + ") WHERE myrow between ? AND ?";
        paramIndex++;
        params.put(paramIndex, startIndex);
        paramIndex++;
        params.put(paramIndex, endIndex);

        LcpReferenceData lcpReferenceData = LcpReferenceData.getInstance(domainName);
        Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        int recordCount = 0;

        try {
            connection = getConnection();
            stmt = connection.prepareStatement(orgQuery);
            stmt = new BaseDao().bindParams(stmt, params);

            OrghierarchyModel orgModel;
            for (rs = stmt.executeQuery(); rs.next(); orgList.add(orgModel)) {
                recordCount++;
                orgModel = new OrghierarchyModel();
                orgModel.setOrgId(rs.getLong(1));
                orgModel.setOrgName(rs.getString(2));

//                AddressModel addrModel = orgModel.getAddressModel();
                String countryCode = rs.getString(3);

                orgModel.setCountryCode(countryCode);
                orgModel.setCountryName(lcpReferenceData.getCountryName(countryCode));

                long parentOrgId = rs.getLong(4);
                orgModel.setParentOrgName(getOrgName(connection, parentOrgId));
                orgModel.setOrgHierarchyTypeCode(rs.getString(5));
                orgModel.setLastUpdateTimestamp(rs.getTimestamp(6));

                // set references
//                addrModel.setOrghierarchy(orgModel);
//                orgModel.setAddressModel(addrModel);
            }
            fillAddressInfo(orgList, connection);
            logger.debug("Search returned " + recordCount + " records.");
            OrgSearchResult addressSearchResult = new OrgSearchResult(orgList, recordCount);

            rs.close();
            stmt.close();
            connection.close();

            return addressSearchResult;
        } catch (Exception ex) {
            logger.error(orgQuery);
            throw new EJBException(ex);
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
    }

    public OrgSearchResult getAddressHomeForOrgOrLoc(long parentorgId, String domainName, String hierarchyTypeCode, long startIndex, long endIndex) {
        ArrayList addressList = new ArrayList();
        String orgQuery = "SELECT * FROM (SELECT ORGID ,ORGNAME, COUNTRYCODE, PARENTORGID, ORGHIERARCHYTYPECODE,LASTUPDATETIMESTAMP, ROWNUM myrow FROM ORGHIERARCHY WHERE DOMAINNAME in ('PUBLIC', '" + domainName + "') AND ORGHIERARCHYTYPECODE ='" + hierarchyTypeCode + "' AND PARENTORGID = " + parentorgId + " ORDER BY LASTUPDATETIMESTAMP DESC) WHERE myrow between " + startIndex + " AND " + endIndex;
        logger.debug("getAddressHome: " + orgQuery);
        LcpReferenceData lcpReferenceData = LcpReferenceData.getInstance(domainName);

        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            logger.debug("getAddressHome(): organization query " + orgQuery);

            connection = getConnection();
            stmt = connection.createStatement();
//            AddressModel addressModel;
            OrghierarchyModel orgModel;
            for (rs = stmt.executeQuery(orgQuery); rs.next(); addressList.add(orgModel)) {
//                addressModel = new AddressModel();
                //addressModel.setOrgId(rs.getLong(1));
                orgModel = new OrghierarchyModel();
                //addressModel.setOrgName(rs.getString(2));
                String countryCode = rs.getString(3);
                orgModel.setCountryName(lcpReferenceData.getCountryName(countryCode));
                long parentOrgId = rs.getLong(4);
                orgModel.setParentOrgName(getOrgName(connection, parentOrgId));
                orgModel.setHierarchyTypeCode(rs.getString(5));
                orgModel.setLastUpdateTimestamp(rs.getTimestamp(6));
            }
            //get the total count of the records 
            String countQuery = "SELECT COUNT(*) FROM ORGHIERARCHY WHERE DOMAINNAME in ('PUBLIC', '" + domainName + "') AND ORGHIERARCHYTYPECODE ='" + hierarchyTypeCode + "'  AND PARENTORGID = " + parentorgId;
            long count = executeQuery_long(countQuery);
            logger.debug(" After getting the count of the records " + count);
            fillAddressInfo(addressList, connection);
            OrgSearchResult addressSearchResult = new OrgSearchResult(addressList, count);

            rs.close();
            stmt.close();
            connection.close();

            return addressSearchResult;
        } catch (SQLException sqEx) {
            logger.error("getAddressHome(startStr, domainName, hierarchyTypeCode)", sqEx);
            throw new EJBException(sqEx);
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
    }

    public OrgSearchResult getAddressHomeForCarrier(String startStr, String domainName, long startIndex, long endIndex) {
        ArrayList addressList = new ArrayList();
        OrgSearchResult addressSearchResult = null;
        LcpReferenceData lcpReferenceData = LcpReferenceData.getInstance(domainName);
        String orgQuery = "SELECT * FROM (SELECT ORGID ,ORGNAME, COUNTRYCODE, PARENTORGID, ORGHIERARCHYTYPECODE,LASTUPDATETIMESTAMP, ROWNUM myrow FROM ORGHIERARCHY WHERE DOMAINNAME='" + domainName + "' AND ORGHIERARCHYTYPECODE ='ORG' AND ORGROLECODE='CAR' AND UPPER(ORGNAME) LIKE UPPER('" + startStr + "%') ORDER BY LASTUPDATETIMESTAMP DESC) WHERE myrow BETWEEN " + startIndex + " AND " + endIndex;

        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            logger.debug("getAddressHomeForCarrier : organization query " + orgQuery);

            connection = getConnection();
            stmt = connection.createStatement();
//            AddressModel addressModel;
            OrghierarchyModel orgModel;
            for (rs = stmt.executeQuery(orgQuery); rs.next(); addressList.add(orgModel)) {
//                addressModel = new AddressModel();
                orgModel = new OrghierarchyModel();
                //addressModel.setOrgId(rs.getLong(1));
//                addressModel.setOrgName(rs.getString(2));
                String countryCode = rs.getString(3);
                orgModel.setCountryName(lcpReferenceData.getCountryName(countryCode));
                long parentOrgId = rs.getLong(4);
                orgModel.setParentOrgName(getOrgName(connection, parentOrgId));
                orgModel.setHierarchyTypeCode(rs.getString(5));
                orgModel.setLastUpdateTimestamp(rs.getTimestamp(6));
            }
            String countQuery = "SELECT  COUNT(*) FROM ORGHIERARCHY WHERE DOMAINNAME='"
                    + domainName + "' AND ORGHIERARCHYTYPECODE ='ORG' AND ORGROLECODE='CAR' AND UPPER(ORGNAME) LIKE UPPER('"
                    + startStr + "%')";
            long count = executeQuery_long(countQuery);
            logger.debug(" After getting the count of the records " + count);
            fillAddressInfo(addressList, connection);
            addressSearchResult = new OrgSearchResult(addressList, count);
        } catch (SQLException sqEx) {
            logger.error("getAddressHome(startStr, domainName, hierarchyTypeCode)", sqEx);
            throw new EJBException(sqEx);
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
        return addressSearchResult;
    }

    public OrgSearchResult getAddressHomeForLookUp(String startStr, String domainName, String involvedPartyQualifier, long startIndex, long endIndex) {
        ArrayList addressList = new ArrayList();
        StringTokenizer strTokenizer = new StringTokenizer(startStr, ",");
        StringBuffer strBuffer = new StringBuffer(" ( ");
        String queryString = " UPPER(ORGNAME) LIKE UPPER('" + startStr + "%')";

        String token = null;
        while (strTokenizer.hasMoreTokens()) {
            token = strTokenizer.nextToken();
            logger.debug("getAddressHomeForLookUp: token " + token);
            if (strTokenizer.hasMoreTokens()) {
                strBuffer.append(" UPPER(ORGNAME) LIKE UPPER('" + token + "%') OR ");
            } else {
                strBuffer.append(" UPPER(ORGNAME) LIKE UPPER('" + token + "%') ) ");
            }
        }

        if (token != null) {
            queryString = strBuffer.toString();
        }

        String orgQuery = "SELECT * FROM (SELECT ORGID ,ORGNAME, COUNTRYCODE, PARENTORGID, ORGHIERARCHYTYPECODE,LASTUPDATETIMESTAMP,CONTACTLASTNAME, ROWNUM myrow FROM ORGHIERARCHY WHERE DOMAINNAME IN ('" + domainName + "', 'PUBLIC') AND " + queryString;

        if (LcpConstants.InvolvedPartyTypeCode.AMS_FILER.equalsIgnoreCase(involvedPartyQualifier)) {
            orgQuery += " AND SCACCODE IS NOT NULL ";
        }
        


        orgQuery += " ORDER BY ORGNAME) WHERE myrow BETWEEN " + startIndex + " AND " + endIndex;

        LcpReferenceData lcpReferenceData = LcpReferenceData.getInstance(domainName);

        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            connection = getConnection();
            stmt = connection.createStatement();
//            AddressModel addressModel;
            OrghierarchyModel orgModel;
            logger.debug("getAddressHomeForLookUp: " + orgQuery);
            for (rs = stmt.executeQuery(orgQuery); rs.next(); addressList.add(orgModel)) {
//                addressModel = new AddressModel();
                orgModel = new OrghierarchyModel();
                //addressModel.setOrgId(rs.getLong(1));
                String countryCode = rs.getString(3);
                orgModel.setCountryName(lcpReferenceData.getCountryName(countryCode));
                long orgId = rs.getLong(4);
                orgModel.setParentOrgName(getOrgName(connection, orgId));
                String orgHierarchyTypeCode = rs.getString(5);
                if (orgHierarchyTypeCode.equalsIgnoreCase("CON")) {
                    orgModel.setOrgName(rs.getString(7));
                } else {
                    orgModel.setOrgName(rs.getString(2));
                }
                orgModel.setHierarchyTypeCode(orgHierarchyTypeCode);
                orgModel.setLastUpdateTimestamp(rs.getTimestamp(6));
            }

            // make the query to count the total no. of records for this lookup
            String countQuery = "SELECT COUNT(*) FROM ORGHIERARCHY WHERE DOMAINNAME IN ('" + domainName + "', 'PUBLIC') AND " + queryString;
            if (LcpConstants.InvolvedPartyTypeCode.AMS_FILER.equalsIgnoreCase(involvedPartyQualifier)) {
                orgQuery += " AND SCACCODE IS NOT NULL ";
            }

            long count = executeQuery_long(countQuery);

            fillAddressInfo(addressList, connection);
            OrgSearchResult addressSearchResult = new OrgSearchResult(addressList, count);
            return addressSearchResult;
        } catch (SQLException sqEx) {
            logger.error("getAddressHomeForLookUp(startStr, domainName)", sqEx);
            throw new EJBException(sqEx);
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
    }

    public OrgSearchResult lookupContact(String startStr, String domainName, long startIndex, long endIndex) {
        List<OrghierarchyModel> orgList = new ArrayList<OrghierarchyModel>();
        HashMap<Integer, Object> params = new HashMap<Integer, Object>();
        int paramIndex = 0;
        OrgSearchResult addressSearchResult = null;

        String orgQuery = "SELECT * FROM (";
        orgQuery = orgQuery + "SELECT O.ORGID,O.COUNTRYCODE,O.ORGNAME,O.PARENTORGID,O.ORGHIERARCHYTYPECODE,O.LASTUPDATETIMESTAMP,ROWNUM myrow ";
        orgQuery = orgQuery + "FROM ORGHIERARCHY O ";
        orgQuery = orgQuery + "WHERE O.STATUS='ACTIVE' AND O.DOMAINNAME IN(?,?) ";


        paramIndex++;
        params.put(paramIndex, "PUBLIC");
        paramIndex++;
        params.put(paramIndex, domainName);

        orgQuery = orgQuery + "AND UPPER(O.CONTACTLASTNAME) LIKE (?) ";
        paramIndex++;
        params.put(paramIndex, "%" + startStr.toUpperCase() + "%");

        orgQuery = orgQuery + "ORDER BY O.ORGNAME) WHERE myrow BETWEEN ? AND ?";
        paramIndex++;
        params.put(paramIndex, startIndex);
        paramIndex++;
        params.put(paramIndex, endIndex);

        LcpReferenceData lcpReferenceData = LcpReferenceData.getInstance(domainName);

        Connection connection = null;
        PreparedStatement stmt = null;
        ResultSet rs = null;
        int recordCount = 0;

        try {
            connection = getConnection();
            stmt = connection.prepareStatement(orgQuery);
            stmt = new BaseDao().bindParams(stmt, params);

            OrghierarchyModel orgModel;
            for (rs = stmt.executeQuery(); rs.next(); orgList.add(orgModel)) {
                recordCount++;
                orgModel = new OrghierarchyModel();
                orgModel.setOrgId(rs.getLong("ORGID"));
                orgModel.setOrgName(rs.getString("ORGNAME"));
                String countryCode = rs.getString("COUNTRYCODE");

//                AddressModel addrModel = orgModel.getAddressModel();
                orgModel.setCountryCode(countryCode);
                orgModel.setCountryName(lcpReferenceData.getCountryName(countryCode));

                long parentOrgId = rs.getLong("PARENTORGID");
                orgModel.setParentOrgName(getOrgName(connection, parentOrgId));
                orgModel.setOrgHierarchyTypeCode(rs.getString("ORGHIERARCHYTYPECODE"));
                orgModel.setLastUpdateTimestamp(rs.getTimestamp("LASTUPDATETIMESTAMP"));

                // set references in objects
//                addrModel.setOrghierarchy(orgModel);
//                orgModel.setAddressModel(addrModel);
            }

            fillAddressInfo(orgList, connection);

            logger.debug("number of results returned is " + recordCount);
            addressSearchResult = new OrgSearchResult(orgList, recordCount);

        } catch (SQLException sqEx) {
            logger.error(orgQuery);
            throw new EJBException(sqEx);
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
        return addressSearchResult;
    }

    public ArrayList getAdvanceOrgSearch(String sql, String domainName) {
        ArrayList addressList = new ArrayList();
        LcpReferenceData lcpReferenceData = LcpReferenceData.getInstance(domainName);
        Connection connection = null;
        ResultSet rs = null;
        Statement stmt = null;
        try {
            connection = getConnection();
            stmt = connection.createStatement();
//            AddressModel addressModel;
            OrghierarchyModel orgModel;
            logger.debug("getAdvanceOrgSearch: " + sql);
            for (rs = stmt.executeQuery(sql); rs.next(); addressList.add(orgModel)) {
//                addressModel = new AddressModel();
                orgModel = new OrghierarchyModel();
                //addressModel.setOrgId(rs.getLong(1));
                orgModel.setOrgName(rs.getString(2));
                String countryCode = rs.getString(3);
                logger.debug(" Country Code is :::  " + countryCode);
                orgModel.setCountryName(lcpReferenceData.getCountryName(countryCode));
                long orgId = rs.getLong(4);
                orgModel.setParentOrgName(getOrgName(connection, orgId));
                orgModel.setHierarchyTypeCode(rs.getString(5));
                orgModel.setLastUpdateTimestamp(rs.getTimestamp(6));
                orgModel.setCity(rs.getString(7));
                orgModel.setStateProvince(rs.getString(8));
                orgModel.setCountryCode(countryCode);
                orgModel.setAddressLine1(rs.getString(9));
                orgModel.setStateProvinceCode(rs.getString(10));
            }

        } catch (SQLException sqEx) {
            logger.error("getAdvanceOrgSearch(sql, domainName)] -> ", sqEx);
            throw new EJBException(sqEx);
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
        return addressList;
    }

    private String getOrgName(Connection connection, long orgId) {
        String orgQuery = "SELECT ORGNAME FROM ORGHIERARCHY WHERE ORGID = ?";
        String orgName = "";
        PreparedStatement stmt = null;
        ResultSet rs = null;
        try {
            stmt = connection.prepareStatement(orgQuery);
            stmt.setLong(1, orgId);

            rs = stmt.executeQuery();

            if (rs.next()) {
                orgName = rs.getString("ORGNAME");
            }
        } catch (Exception ex) {
            //ex.printStackTrace();
			logger.error("Exception : " + ex.getMessage());
        } finally {
            ConnectionUtil.closeResources(null, stmt, rs);
        }
        return orgName;
    }

    /*
     public ArrayList getEventSearchResults(String query, String domainName)
     {
     Connection connection = null;
     Statement stmt = null;
     ArrayList searchResult = new ArrayList();
     ArrayList shipmentIdList = new ArrayList();
     ResultSet rs = null;
     try
     {
     connection = getConnection();
     stmt = connection.createStatement();
     long shipmentId;
     logger.debug ("getEventSearchResults : Query: " + query);
     for (rs = stmt.executeQuery(query); rs.next(); shipmentIdList.add(new Long(shipmentId)))
     shipmentId = rs.getLong(1);

     searchResult = getSearchResult(shipmentIdList, domainName);
     }
     catch (SQLException sqEx)
     {
     logger.error("ShipmentSLSBean[getEventSearchResults(referenceList)] -> ", sqEx);
     throw new EJBException(sqEx.toString());
     }
     finally
     {
     ConnectionUtil.closeResources(connection, stmt, rs);
     }
     return searchResult;
     }
     */
    /**
     * This method takes classification code and classification value to find
     * out the corresponding item id.
     *
     * @param classificationCode java.lang.String
     * @param classificationValue java.lang.String
     * @return java.util.ArrayList (list of matched ids)
     */
    public ArrayList getItemIdFromClassification(String classificationCode, String classificationValue) {
        Connection con = null;
        String itemIdQuery = "SELECT ITEMID FROM ITEMCLASSIFICATION WHERE ITEMCLASSIFICATIONTYPECODE =? AND VALUE =?";
        PreparedStatement pStmt = null;
        ResultSet rSet = null;
        ArrayList itemIds = new ArrayList();
        try {
            logger.debug("getItemIdFromClassification : Query: is " + itemIdQuery);
            con = getConnection();
            pStmt = con.prepareStatement(itemIdQuery);
            pStmt.setString(1, classificationCode);
            pStmt.setString(2, classificationValue);
            logger.debug("Query: " + itemIdQuery);
            rSet = pStmt.executeQuery();
            while (rSet.next()) {
                itemIds.add(new Long(rSet.getLong(1)));
            }
        } catch (SQLException sqEx) {
            logger.error("getItemIdFromClassification(classificationCode,classificationValue)", sqEx);
            throw new EJBException(sqEx);
        } finally {
            ConnectionUtil.closeResources(con, pStmt, rSet);
        }

        return itemIds;
    }

    public ArrayList getQuickAddressHome(String startStr, String domainName) {
        ArrayList addressList = new ArrayList();
        LcpReferenceData lcpReferenceData = LcpReferenceData.getInstance(domainName);
        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;

        String orgQuery = "SELECT ORGID ,ORGNAME, COUNTRYCODE, PARENTORGID, ORGHIERARCHYTYPECODE,LASTUPDATETIMESTAMP,CONTACTLASTNAME FROM ORGHIERARCHY WHERE DOMAINNAME='" + domainName + "' AND UPPER(ORGNAME) LIKE UPPER('%" + startStr + "%') OR UPPER(CONTACTLASTNAME) LIKE UPPER('%" + startStr + "%')  ORDER BY LASTUPDATETIMESTAMP DESC";

        try {
            connection = getConnection();
            stmt = connection.createStatement();
//            AddressModel addressModel;
            OrghierarchyModel orgModel;
            logger.debug("getQuickAddressHome : orgQuery is  " + orgQuery);
            for (rs = stmt.executeQuery(orgQuery); rs.next(); addressList.add(orgModel)) {
//                addressModel = new AddressModel();
                orgModel = new OrghierarchyModel();
                //addressModel.setOrgId(rs.getLong(1));
                String orgHierarchyTypeCode = rs.getString(5);
                if (orgHierarchyTypeCode.equalsIgnoreCase("CON")) {
                    orgModel.setOrgName(rs.getString(7));
                } else {
                    orgModel.setOrgName(rs.getString(2));
                }
                String countryCode = rs.getString(3);
                orgModel.setCountryName(lcpReferenceData.getCountryName(countryCode));
                long parentOrgId = rs.getLong(4);
                orgModel.setParentOrgName(getOrgName(connection, parentOrgId));
                orgModel.setHierarchyTypeCode(orgHierarchyTypeCode);
                orgModel.setLastUpdateTimestamp(rs.getTimestamp(6));
            }

            fillAddressInfo(addressList, connection);

        } catch (SQLException sqEx) {
            logger.error("getQuickAddressHome(startStr, domainName)] -> ", sqEx);
            throw new EJBException(sqEx);
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
        return addressList;
    }

    /**
     * Returns all addresses which start with the startStr
     */
    public OrgSearchResult getOrgHierarchies(String searchStr, String refType, String refTxt, Credentials credentials, String orgType, String orgRole, long startIndex, long endIndex) {
        logger.debug("Getting orghierarchies for addressHome");
        List<OrghierarchyModel> orgList = new ArrayList<OrghierarchyModel>();
        int resultCount = 0;
        OrgSearchResult addressSearch = new OrgSearchResult(orgList, resultCount);

        Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        // used for binding variables
        HashMap<Integer, Object> params = new HashMap<Integer, Object>();
        int paramIndex = 0;

        String query;

        if ("OGS".equalsIgnoreCase(credentials.getRole())) {
            // filter out domestic air carriers.
            query = getOgsAddressQuery();
        } else {
            query = "select * from ( select a.*, rownum rnum from (" + // This line is to allow paging of results ****
                    "select o.orgid AS ORGID, o.orghierarchytypecode AS ORGHIERARCHYTYPECODE, o.orgname AS ORGNAME, p.orgname as PARENTORGNAME, "
                    + "o.city AS CITY,o.stateprovincecode AS STATECODE, o.countrycode AS COUNTRYCODE,c.countryname AS COUNTRYNAME, "
                    + "o.phone AS PHONE, o.email as EMAIL "
                    + "from orghierarchy o, orghierarchy p, country c "
                    + "where "
                    + "o.parentorgid = p.orgid(+) and "
                    + "o.countrycode = c.countrycode and "
                    + "o.domainname in ('PUBLIC',?) ";
        }


        try {
            paramIndex++;
            params.put(paramIndex, credentials.getDomainName());

            // add optional variables to query where clause
            if (orgType != null && orgType.length() != 0) {
                query = query + " and o.orghierarchytypecode=? ";
                paramIndex++;
                params.put(paramIndex, orgType);
            }
            if (orgRole != null && orgRole.length() != 0) {
                query = query + " and o.orgrolecode=? ";
                paramIndex++;
                params.put(paramIndex, orgRole);
            }
            if (searchStr != null && searchStr.length() != 0) {
                query = query + " and o.orgname like ? ";
                paramIndex++;
                params.put(paramIndex, "%" + searchStr + "%");
            }

            if (refType != null && refType.length() != 0) {
                query = query + " and o.orgid in (select orgid from orgreference where orgreferencetypecode = ? and orgreferencevalue like ?)";
                paramIndex++;
                params.put(paramIndex, refType);
                paramIndex++;
                params.put(paramIndex, "%" + refTxt + "%");
            }

            // **** ADD THE FINAL LINE FOR PAGING THE RESULTS
            query = query + ") a )where rnum between ? and ?";

            paramIndex++;
            params.put(paramIndex, startIndex);
            paramIndex++;
            params.put(paramIndex, endIndex);

            // prepare the statement
            connection = getConnection();
            logger.debug("Combined query: " + query);
            pStmt = connection.prepareStatement(query);

            // bind the params in map to statement
            pStmt = new BaseDao().bindParams(pStmt, params);

            // populate addressList from result set
            rs = pStmt.executeQuery();

            OrghierarchyModel orgModel;
            while (rs.next()) {
                resultCount++;
                orgModel = new OrghierarchyModel();
                orgModel.setOrgId(rs.getLong("ORGID"));
                orgModel.setOrgHierarchyTypeCode(rs.getString("ORGHIERARCHYTYPECODE"));
                orgModel.setOrgName(rs.getString("ORGNAME"));
                orgModel.setParentOrgName(rs.getString("PARENTORGNAME"));
                orgModel.setEmail(rs.getString("EMAIL"));
                orgModel.setPhone(rs.getString("PHONE"));

//				AddressModel addrModel = orgModel.getAddressModel();

//				addrModel.setAddressId(rs.getLong("ADDRESSID"));
                orgModel.setCity(rs.getString("CITY"));
                orgModel.setStateProvinceCode(rs.getString("STATECODE"));
                orgModel.setCountryCode(rs.getString("COUNTRYCODE"));
                orgModel.setCountryName(rs.getString("COUNTRYNAME"));

                // set references
//				addrModel.setOrghierarchy(orgModel);
//				orgModel.setAddressModel(addrModel);

                orgList.add(orgModel);
            }

            // set the final values in the search result
            addressSearch.setOrgList(orgList);
            addressSearch.setCount(resultCount);
        } catch (SQLException sqEx) {
            logger.error("getOrgHierarchies (" + searchStr + ", " + credentials.getDomainName() + ")", sqEx);
            throw new EJBException(sqEx);
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }

        return addressSearch;
    }

    /*
     private ArrayList getSearchResult(ArrayList shipmentIdList, String domainName)
     {
     String addressQuery = "SELECT TM.TRANSPORTMODENAME, SH.ORIGINADDRESSID, SH.DESTINATIONADDRESSID, TM.LASTUPDATETIMESTAMP FROM SHIPMENT SH, TRANSPORTMODE TM WHERE SH.SHIPMENTID=? AND SH.DOMAINNAME='" + domainName + "' AND SH.MODECODE=TM.TRANSPORTMODECODE AND TM.DOMAINNAME=SH.DOMAINNAME";
     String referenceQuery = "SELECT SHIPMENTREFERENCEID, SHIPMENTREFERENCETYPECODE, SHIPMENTREFERENCEVALUE FROM SHIPMENTREFERENCE WHERE SHIPMENTID=? AND DOMAINNAME ='" + domainName + "'";
     ArrayList searchList = new ArrayList();
     ArrayList shipmentRefList = new ArrayList();
     Connection connection = null;
     PreparedStatement pStmt = null;
     ResultSet rs = null;
     try
     {
     logger.debug ("getSearchResult : addressQuery is  " + addressQuery);
     logger.debug ("getSearchResult : referenceQuery is  " + referenceQuery);
     connection = getConnection();
     pStmt = connection.prepareStatement(addressQuery);
     for (int i = 0; i < shipmentIdList.size(); i++)
     {
     long shipmentId = ((Long)shipmentIdList.get(i)).longValue(); 
     pStmt.setLong(1, shipmentId);
     String modeName;
     java.sql.Timestamp lastUpdateTimestamp;
     String originLocationName;
     String destinationLocationName;

     for (rs = pStmt.executeQuery(); rs.next(); shipmentRefList.add(new ShipmentDetails(shipmentId, "", modeName, originLocationName, destinationLocationName, lastUpdateTimestamp)))
     {
     modeName = rs.getString(1);
     long originAddressId = rs.getLong(2);
     long destinationAddressId = rs.getLong(3);
     lastUpdateTimestamp = rs.getTimestamp(4);
     originLocationName = organizationSLS.getOrgNameFromAddressId (originAddressId);
     destinationLocationName = organizationSLS.getOrgNameFromAddressId (destinationAddressId);
     }
     ConnectionUtil.closeResources(null, null, rs);
     }

     for (int i = 0; i < shipmentRefList.size(); i++)
     {
     ShipmentDetails shipmentDetails = (ShipmentDetails)shipmentRefList.get(i);
     pStmt = connection.prepareStatement(referenceQuery);
     pStmt.setLong(1, shipmentDetails.getShipmentId());
     rs = pStmt.executeQuery();
     List shipmentReferences = new ArrayList();
     while(rs.next())
     {
     String shipmentReferenceTypeCode = rs.getString(2);
     String shipmentReferenceValue = rs.getString(3);
     ShipmentReferenceModel shipmentReferenceModel = new ShipmentReferenceModel();
     shipmentReferenceModel.setShipmentReferenceTypeCode(shipmentReferenceTypeCode);
     shipmentReferenceModel.setShipmentReferenceValue(shipmentReferenceValue);
     shipmentReferences.add(shipmentReferenceModel);
     }
     shipmentDetails.setShipmentReferences(shipmentReferences);
     searchList.add(shipmentDetails);
     ConnectionUtil.closeResources(null, null, rs);
     }
     }
     catch (Exception sqEx)
     {
     logger.error("Exception in getSearchResult(domain)", sqEx);
     throw new EJBException (sqEx);
     }
     finally
     {
     ConnectionUtil.closeResources(connection, pStmt, rs);
     }
     return searchList;
     }

     private ArrayList getShipmentDetails(long shipmentId, String domain)
     {
     String referenceQuery = "SELECT SHIPMENTREFERENCEID, SHIPMENTREFERENCETYPECODE, SHIPMENTREFERENCEVALUE FROM SHIPMENTREFERENCE WHERE SHIPMENTID=? AND DOMAINNAME ='" + domain + "' AND SHIPMENTREFERENCETYPECODE IN ('AW','HA','BL','HO','OB', 'SR', 'MAWB')";
     String ipQuery = "SELECT INVOLVEDPARTYNAME  FROM INVOLVEDPARTY  WHERE  SHIPMENTID = ? AND INVOLVEDPARTYTYPECODE ='SHIP'";
     ArrayList shipments = new ArrayList();
     Connection connection = null;
     Statement stmt = null;
     PreparedStatement pStmt = null;
     ResultSet rs = null;
     try
     {
     connection = getConnection();
     String shipmentQuery = "SELECT SH.SHIPMENTID, TM.TRANSPORTMODENAME, SH.SHIPPERORGID, SH.LASTUPDATETIMESTAMP, SS.SHIPMENTSTATUSNAME FROM SHIPMENT SH, TRANSPORTMODE TM, SHIPMENTSTATUS SS WHERE SH.SHIPMENTID=" + shipmentId + " AND SH.DOMAINNAME='" + domain + "' AND SH.MODECODE=TM.TRANSPORTMODECODE AND TM.DOMAINNAME=SH.DOMAINNAME AND SS.SHIPMENTSTATUSCODE = SH.STATUS ORDER BY LASTUPDATETIMESTAMP DESC";
     stmt = connection.createStatement();
     logger.debug ("getShipmentDetails(): shipmentQuery is " + shipmentQuery);
     rs = stmt.executeQuery(shipmentQuery);
     ShipmentDetails shipmentDetails = new ShipmentDetails();
     String mode = "";
     while(rs.next())
     {
     shipmentId = rs.getLong(1);
     mode = rs.getString(2);
     String shipperName = rs.getString(3);
     java.sql.Timestamp lastUpdated = rs.getTimestamp(4);
     String status = rs.getString(5);
     shipmentDetails = new ShipmentDetails(shipmentId, status, mode, shipperName, lastUpdated);
     }
     pStmt = connection.prepareStatement(referenceQuery);
     pStmt.setLong(1, shipmentId);
     logger.debug ("getShipmentDetails : referenceQuery for shipmentId: " +shipmentId + ": "
     + referenceQuery);

     List shipmentReferences = new ArrayList();
     for (rs = pStmt.executeQuery(); rs.next();)
     {
     String shipmentReferenceTypeCode = rs.getString(2);
     String shipmentReferenceValue = rs.getString(3);
     ShipmentReferenceModel shipmentReferenceModel = new ShipmentReferenceModel();
     shipmentReferenceModel.setShipmentReferenceTypeCode(shipmentReferenceTypeCode);
     shipmentReferenceModel.setShipmentReferenceValue(shipmentReferenceValue);
     shipmentReferences.add(shipmentReferenceModel);
     }
     shipmentDetails.setShipmentReferences(shipmentReferences);
     logger.debug ("getShipmentDetails(): InvolvedParty for shipmentid:" +shipmentId + ": " + ipQuery);
     pStmt = connection.prepareStatement(ipQuery);
     pStmt.setLong(1, shipmentId);
     rs = pStmt.executeQuery();
     shipmentDetails.setShipperName("--");
     for (; rs.next(); shipmentDetails.setShipperName(rs.getString(1)));
     shipments.add(shipmentDetails);
     }
     catch (SQLException sqEx)
     {
     logger.error("ShipmentSLSBean[getShipmentDetails(shipmentId, domain)] -> ", sqEx);
     throw new EJBException (sqEx);
     }
     finally
     {
     ConnectionUtil.closeResources(null, pStmt, null);
     ConnectionUtil.closeResources(connection, stmt, rs);
     }
     return shipments;
     }

     */
    private ArrayList getShipmentIds(String userName, String domainName) {
        long orgId = 0L;
        ArrayList shipmentIds = new ArrayList();
        String query = "SELECT ORGID FROM SYSTEMUSER WHERE USERID='" + userName + "' AND DOMAINNAME='" + domainName + "'";
        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;
        try {
            connection = getConnection();
            stmt = connection.createStatement();
            logger.debug("getShipmentIds : Query is " + query);
            for (rs = stmt.executeQuery(query); rs.next();) {
                orgId = rs.getLong(1);
            }
            rs.close();
            List orgIdList = organizationSLS.getOrgIdList(orgId);

            String str = "";
            for (int i = 0; i < orgIdList.size(); i++) {
                if (i != orgIdList.size() - 1) {
                    str = str + ((Long) orgIdList.get(i)).longValue() + ",";
                } else {
                    str = str + ((Long) orgIdList.get(i)).longValue();
                }
            }

            rs = null;
            String shipQuery = "SELECT DISTINCT SHIPMENTID FROM INVOLVEDPARTY WHERE ORGID IN(" + str + ")";
            logger.debug("getShipmentIds : shipQuery is " + shipQuery);
            for (rs = stmt.executeQuery(shipQuery); rs.next(); shipmentIds.add(new Long(rs.getLong(1))));
        } catch (SQLException sqEx) {
            logger.error("getShipmentIds(userName, domainName)] -> ", sqEx);
            throw new EJBException(sqEx);
        } catch (Exception e) {
            logger.error("getShipmentIds(userName, domainName)] -> ", e);
            throw new EJBException(e);
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
        return shipmentIds;
    }

    public ArrayList getOrgIdFromOrgReference(String orgReferenceTypecode, String loationReferenceValue, String domainName) {
        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;
        ArrayList orgIdList = new ArrayList();

        String orgQuery = "SELECT ORGID FROM ORGREFERENCE WHERE ORGREFERENCETYPECODE = '" + orgReferenceTypecode + "' and ORGREFERENCEVALUE = '" + loationReferenceValue + "' and (DOMAINNAME = '" + domainName + "' or DOMAINNAME = 'PUBLIC')";
        try {
            connection = this.getConnection();
            stmt = connection.createStatement();
            logger.debug("getOrgIdFromOrgReference : orgQuery is " + orgQuery);
            rs = stmt.executeQuery(orgQuery);
            while (rs.next()) {
                orgIdList.add(new Long(rs.getLong(1)));
            }
        } catch (SQLException sqEx) {
            logger.error("Could not get org id from org reference");
            throw new EJBException(sqEx);
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
        return orgIdList;
    }

    public boolean validateAddressId(long addressId, String domainName) {
        Connection connection = null;
        Statement stmt = null;
        ResultSet rs = null;
        String addressIdQuery = "SELECT ADDRESSID FROM ORGHIERARCHY WHERE  ADDRESSID =" + addressId + " and (DOMAINNAME = '" + domainName + "' or DOMAINNAME = 'PUBLIC')";
        try {
            connection = this.getConnection();
            stmt = connection.createStatement();
            logger.debug("validateAddressId : addressIdQuery is " + addressIdQuery);
            rs = stmt.executeQuery(addressIdQuery);
            if (rs.next()) {
                return true;
            } else {
                return false;
            }

        } catch (SQLException sqEx) {
            throw new EJBException(sqEx);
        } finally {
            ConnectionUtil.closeResources(connection, stmt, rs);
        }
    }

    /**
     * Fills addressInfo.
     */
    protected void fillAddressInfo(List<OrghierarchyModel> orgList, Connection connection) {
        String addressQuery = "SELECT CITY, STATEPROVINCE, COUNTRYCODE, ADDRESSLINE1, ADDRESSLINE2, STATEPROVINCECODE, LATITUDE, LONGITUDE  FROM ORGHIERARCHY WHERE  ORGID= ?";
        logger.debug("fillAddressInfo : " + addressQuery);

        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try {
            pStmt = connection.prepareStatement(addressQuery);
            for (OrghierarchyModel orgModel : orgList) {
                //pStmt.clearParameters();
                pStmt.setLong(1, orgModel.getOrgId());
                rs = pStmt.executeQuery();
                if (rs.next()) {
                    if (rs.getString(1) != null) {
                        orgModel.setCity(rs.getString(1));
                    } else {
                        orgModel.setCity("--");
                    }
                    if (rs.getString(2) != null) {
                        orgModel.setStateProvince(rs.getString(2));
                    } else {
                        orgModel.setStateProvince("--");
                    }
                    if (rs.getString(3) != null) {
                        orgModel.setCountryCode(rs.getString(3));
                    } else {
                        orgModel.setCountryCode("--");
                    }
                    //orgModel.setAddressId(rs.getLong(4));

                    orgModel.setAddressLine1(rs.getString(5));
                    orgModel.setAddressLine2(rs.getString(6));

                    if (rs.getString(7) != null) {
                        orgModel.setStateProvinceCode(rs.getString(7));
                    } else {
                        orgModel.setStateProvinceCode("--");
                    }

                    if (rs.getString("LATITUDE") != null) {
                        orgModel.setLatitude(rs.getString("LATITUDE"));
                    }

                    if (rs.getString("LONGITUDE") != null) {
                        orgModel.setLongitude(rs.getString("LONGITUDE"));
                    }

                } else {
                    orgModel.setCity("--");
                    orgModel.setStateProvince("--");
                    orgModel.setCountryCode("--");
                    orgModel.setAddressLine1("--");
                    orgModel.setAddressLine2("--");
                    orgModel.setStateProvinceCode("--");
                }
                rs.close();
            }

            if (pStmt != null) {
                pStmt.close();
            }
        } catch (SQLException sqEx) {
            logger.error("fillAddressInfo : ", sqEx);
            throw new EJBException(sqEx);
        } finally {
            ConnectionUtil.closeResources(null, pStmt, rs);
        }
    }

    public void ejbCreate()
            throws CreateException {
        try {
            ServiceLocator serviceLocator = ServiceLocator.getInstance();
            organizationSLS = new OrganizationSLSBean();
        } catch (Exception e) {
            logger.error("ejbCreate() failed because an instance of OrganizationSLS could not be created");
            throw new CreateException("ejbCreate() failed because an instance of OrganizationSLS could not be created");
        }
    }

    private String getOgsAddressQuery() {
        return "select * from ( select a.*, rownum rnum from (" + // This line is to allow paging of results ****
                "select o.orgid AS ORGID, o.orghierarchytypecode AS ORGHIERARCHYTYPECODE, o.orgname AS ORGNAME, p.orgname as PARENTORGNAME, "
                + "o.city AS CITY,o.stateprovincecode AS STATECODE, o.countrycode AS COUNTRYCODE,c.countryname AS COUNTRYNAME, "
                + "o.phone AS PHONE, o.email as EMAIL "
                + "from orghierarchy o, orghierarchy p, country c "
                + "where "
                + "o.parentorgid = p.orgid(+) and "
                + "o.countrycode = c.countrycode and "
                + "o.domainname in ('PUBLIC',?) and "
                + "((o.orghierarchytypecode = 'ORG' AND o.countrycode <> 'US' AND o.orgrolecode = 'CAR') OR" 
                + "(p.orghierarchytypecode = 'ORG' AND p.countrycode <> 'US' AND p.orgrolecode = 'CAR')) ";

    }
}
