/**
 * Copyright (c) NTELX All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information"). You shall not disclose such Confidential
 * Information and shall use it only in accordance with the terms of the license
 * agreement you entered into with NTELX.
 *
 */
package com.freightdesk.fdfolio.dao;

import org.apache.log4j.Logger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Order;
import org.hibernate.criterion.Projections;
import org.hibernate.criterion.Restrictions;

import com.freightdesk.fdfolio.common.LcpReferenceData;
import com.freightdesk.fdfolio.common.SessionFactoryUtil;
import crt.com.freightdesk.fdfolio.event.FasEventUtil;
import crt.com.freightdesk.fdfolio.event.model.EventHomeModel;
import crt.com.freightdesk.fdfolio.event.model.EventHomeSearchBean;
import com.freightdesk.fdfolio.event.model.EventModel;
import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdcommons.Credentials;
import crt.com.ntelx.nxcommons.FasConstants;
import com.freightdesk.fdcommons.OptionBean;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;
import crt.com.ntelx.nxcommons.reporting.OptionCollectionManager;

/**
 * The Data Access Object to insert/update/delete Event Model objects. Also
 * contains functionality to insert/update/delete some sub objects.
 *
 * @author Mike Echevarria
 */
public class EventDAO extends BaseDao {

    protected static Logger logger = Logger.getLogger("EventDAO");
	private OrghierarchyDAO orgDAO = new OrghierarchyDAO();

    // Used in FAS
    /**
     * Creates a DB record corresponding to the given model.
     */
    public EventModel persist(EventModel shipmentEventModel) throws SQLException {
        Session session = null;
        try {
            session = SessionFactoryUtil.getSession();
            session.beginTransaction();

            session.saveOrUpdate(shipmentEventModel);
        } catch (Exception e) {
		    if (session != null) {
              session.getTransaction().rollback(); 
            }			  
			logger.error("Exception: " + e.getMessage());
            throw (SQLException) new SQLException().initCause(e);
        } finally {
            if (session != null) {
			   session.getTransaction().commit();
               session.close();
			}
        }
        return shipmentEventModel;
    }

    /**
     * create
     *
     * @param eventList
     * @throws SQLException
     */
    public boolean persist(List<EventModel> eventList) {
        logger.debug("Persisting " + eventList.size() + " events to the database");
        Session session = null;
        boolean saved = false;
        try {
            session = SessionFactoryUtil.getSession();
            session.beginTransaction();

            for (EventModel model : eventList) {
                session.saveOrUpdate(model);
            }
            saved = true;
        } catch (Exception ex) {
		    if (session != null) {
               session.getTransaction().rollback();
			}
            logger.error("Failed to persist list of events.  Rolling back transaction.", ex);
        } finally {
            if (session != null) {
			  session.getTransaction().commit();
              session.close();
			}
        }
        return saved;
    }

    // used in FAS
    public void delete(Long eventId, Credentials credentials) throws SQLException {
        Session session = null;
        AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
        AsyncProcessManager asyncRequestManager = new AsyncProcessManager();
        try {
            session = SessionFactoryUtil.getSession();
            session.beginTransaction();
            EventModel eventModel = (EventModel) session.get(EventModel.class, new Long(eventId));

            // log user deletions of data.
            asyncLogModel.init(credentials.getUserId(), credentials.getDomainName(), "DELETE", "SECURITY", "Deleting EVENT " + eventModel.getEventId(), credentials.getIpAddress());
            asyncLogModel = asyncRequestManager.createAsyncProcessLog(asyncLogModel);

            // if this user is trying to delete data not in his/her domain and
            // is not a system admin, log an error
            if (eventModel.getDomainName().equalsIgnoreCase(credentials.getDomainName()) == false && (credentials.getRole().equalsIgnoreCase("SYS") == false)) {
                logger.error("User " + credentials.getDomainName() + "." + credentials.getUserId() + " does not have permission to delete data in domain of " + eventModel.getDomainName());
                asyncRequestManager.logResult(asyncLogModel, false, "Failed to delete event.  User is deleting data outside of domain and is not a administrator", "deleteEventAndLog");
                throw new java.lang.Exception();
            }

            session.delete(eventModel);

            // log success
            asyncRequestManager.logResult(asyncLogModel, true, "Successfully deleted event " + eventModel.getEventId(), "deleteEventAndLog");
        } catch (Exception e) {
		    if (session != null) {
                session.getTransaction().rollback();
			}	
            logger.error("Exception in deleteEventAndLog for " + eventId);            
            throw (SQLException) new SQLException().initCause(e);
        } finally {
		     if (session != null) {
               session.getTransaction().commit();
               session.close();
			 }
        }
    }

    public EventModel retrieve(long eventId, Credentials credentials, boolean loadAll) throws SQLException {
        Session session = null;
        try {
            session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(EventModel.class);
            criteria.add(Restrictions.eq("eventId", eventId));

            List<String> subList = getSubsidiaryDomains(credentials.getOrgId());

            // Permission E7 loads all events in the system, otherwise retrict by domain for security
            if (!subList.isEmpty())
            {
                subList.add(credentials.getDomainName());
                criteria.add(Restrictions.in("domainName", subList));
            }
            else if (!loadAll) {
                criteria.add(Restrictions.eq("domainName", credentials.getDomainName()));
            }

            EventModel eventModel = (EventModel) criteria.uniqueResult();

            // Set the company name for viewing purposes only
            if (eventModel.getCertNum() != null) {
                eventModel.setCompanyName(orgDAO.getOrgNameFromReference(eventModel.getCertNum(), "CRTNM"));
            }

            // get the airportname from either the complete foreign and domestic list
            OptionCollectionManager optionManager = OptionCollectionManager.getInstance();
            List<OptionBean> allAirports = new ArrayList<OptionBean>();
            allAirports.addAll(optionManager.getCollection("intAirportsOrgs"));
            allAirports.addAll(optionManager.getCollection("domAirportsOrgs"));

            eventModel.setAirportName(FasEventUtil.getNameFromOptionsBeanList(allAirports, eventModel.getAirportOrgId()));

            if (eventModel.getCarrierOrgId() != null) {
                eventModel.setCarrierName(FasEventUtil.getNameFromOptionsBeanList(optionManager.getCollection("carrierOrgs"), eventModel.getCarrierOrgId()));
            }

            return eventModel;
        } catch (Exception e) {
            logger.error("Exception in retrieveByEventIdDomain" + e);
            throw (SQLException) new SQLException().initCause(e);
        } finally {
            if (session != null) {
			  session.close();
			}
        }
    }

    public boolean isAirportUsed(Long airportOrgId) {
        logger.debug("Determining if " + airportOrgId + " is used in event table.");
        boolean isAirportUsed = false;
        long[] airportArray = new long[1];
        
        String query = "select 1 from dual where exists (select * from event where airport = ?)";

        Arrays.fill(airportArray, airportOrgId);
        
        try
        {
            executeQuery_String(query, airportArray);
            isAirportUsed = true;
        }
        catch (Exception e)
        {
        	// Do nothing. No records found.
        }

        return isAirportUsed;
    }

    
    // used in FAS
    @SuppressWarnings("unchecked")
    public EventHomeSearchBean retrieveForEventHome(Credentials credentials, boolean loadAll, int offset, Timestamp startDate, Timestamp endDate, String searchText, String searchCert) {

        EventHomeSearchBean ehsb = new EventHomeSearchBean();
        Session session = null;
        int pagingAmount = Integer.valueOf(ApplicationProperties.getProperty("requestTracker.paging"));

        List<EventHomeModel> eventList = new ArrayList<EventHomeModel>();

        try {
            session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(EventHomeModel.class);

            filterEventsForOgsRole(credentials, criteria);

            // Permission E7 loads all events in the system, regardless of type, domain.  loadAll set in EventHomeAction
            //
            List<String> subList = getSubsidiaryDomains(credentials.getOrgId());
            
            if (!subList.isEmpty())
            {
                subList.add(credentials.getDomainName());
                criteria.add(Restrictions.in("domainName", subList));
            }
            else if (!loadAll) {
                criteria.add(Restrictions.eq("domainName", credentials.getDomainName()));

                // no locId means parent is only org, so corporate user that has visibility to entire domain
                if (credentials.getParentLocId() > 0L) {
                    logger.debug("Not corporate level user, restricting by createUserIds at same hierarchy level");
                    // not a corporate user, so restrict by creation
                    if (credentials.getRelatedUserIds() == null || credentials.getRelatedUserIds().size() < 1) {
                        criteria.add(Restrictions.eq("createUserId", credentials.getUserId()));
                    } else {
                        criteria.add(Restrictions.in("createUserId", credentials.getRelatedUserIds()));
                    }
                }
            }

            //search name
            if (searchText != null && searchText.length() > 1) {
                // if loading all events search on company name
                if (loadAll) {
                    criteria.add(Restrictions.like("companyName", searchText.toUpperCase() + "%"));
                } else {
                    criteria.add(Restrictions.like("airportName", searchText.toUpperCase() + "%"));
                }
            }

            //search cert.  Restricted to the E7, view all events permission
            logger.debug("SearchCert " + searchCert);
            if (searchCert != null && searchCert.length() > 1) {
                if (loadAll) {
                    logger.debug("Adding filter eventHome.certnum like  %" + searchCert.toUpperCase() + "%");
                    criteria.add(Restrictions.like("certNum", "%" + searchCert.toUpperCase() + "%"));
                } else {
                    logger.debug("User does not have permission to search by certfication number");
                }
            } else {
                logger.debug("Not adding filter on certnum");
            }

            criteria.add(Restrictions.between("eventDateTime", startDate, endDate));

            // Add two Order criteria to remove ambiguity when multiple records
            //   have the same timestamp.  This happens during batch input of data
            //    
            criteria.addOrder(Order.desc("lastUpdateTimestamp"));
            criteria.addOrder(Order.asc("airportName"));
            criteria.addOrder(Order.asc("eventDateTime"));

            criteria.setProjection(Projections.rowCount());
            Long count = (Long) criteria.uniqueResult();
            int totalCount = count.intValue();
            ehsb.setTotalEventCount(totalCount);

            ehsb.setTotalPages((totalCount / pagingAmount) + 1);
            ehsb.setCurrentPage((offset / pagingAmount) + 1);
            ehsb.setStartDate(startDate);
            ehsb.setEndDate(endDate);

            criteria.setProjection(null);
            criteria.setResultTransformer(Criteria.ROOT_ENTITY);

            criteria.setFirstResult(offset);
            criteria.setMaxResults(pagingAmount);

            eventList = criteria.list();

            logger.info("Returning " + eventList.size() + " events for user " + credentials.getDomainName() + "." + credentials.getUserId());

            ehsb.setEventList(eventList);

        } catch (Exception e) {            
			logger.error("Exception: " + e.getMessage());
            ehsb.setEventList(eventList);
        } finally {
		    if (session != null) {
               session.close();
			}
        }

        return ehsb;
    }

    public boolean updateEventFlag(Long eventId, String flagLate, String flagUnlock) {
        logger.debug("updating event " + eventId + " flag to " + flagLate + ", unlock flag to " + flagUnlock);

        String query = "update event set flaglate=?, flagunlock=? where eventid=?";

        HashMap<Integer, Object> params = new HashMap<Integer, Object>();
        params.put(1, flagLate);
        params.put(2, flagUnlock);
        params.put(3, eventId);

        int numUpdate = executeUpdate(query, params);

        if (numUpdate > 0) {
            return true;
        } else {
            return false;
        }
    }

    public long getIdFromOptionBeanList(List<OptionBean> list, String label) {
        for (OptionBean ob : list) {
            if (ob.getLabel().equalsIgnoreCase(label)) {
                return Long.parseLong(ob.getValue());
            }
        }
        return 0;
    }

    public void fillLcpReferenceData(LcpReferenceData lcpReferenceData, String domainName) throws SQLException {
        logger.debug("loading Event Reference DATA:");

        String eventTypeCodeQuery = "SELECT EVENTTYPECODE,EVENTTYPENAME FROM EVENTTYPE WHERE DOMAINNAME IN(?,'PUBLIC')";
        String eventCategoryTypeQuery = "SELECT EVENTCATEGORYCODE,EVENTCATEGORYNAME FROM EVENTCATEGORY WHERE DOMAINNAME IN(?,'PUBLIC')";

        lcpReferenceData.setEventCategoryCodes(this.retrieveReferenceTypeCodesList(domainName, eventTypeCodeQuery));
        lcpReferenceData.setEventTypeCodes(this.retrieveReferenceTypeCodesList(domainName, eventCategoryTypeQuery));

    }

    public List<OptionBean> retrieveReferenceTypeCodesList(String domainName, String query) throws SQLException {

        Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        List<OptionBean> referenceTypeCodesList = new ArrayList<OptionBean>();
        try {
            connection = getConnection();
            pStmt = connection.prepareStatement(query);
            pStmt.setString(1, domainName);
            logger.debug("query is " + query);
            OptionBean codename;
            for (rs = pStmt.executeQuery(); rs.next(); referenceTypeCodesList.add(codename)) {
                codename = new OptionBean(rs.getString(2), rs.getString(1));
            }
        } catch (SQLException sqEx) {
            logger.debug("ERROR in query:" + query);
            logger.error("getretrieveReferenceTypeCodesList()", sqEx);
            throw sqEx;
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return referenceTypeCodesList;
    }

    /*
     * Find an event that has an overlapping date range, same airport and same
     * carrier or certnumber
     */
    public EventModel findSameDateRange(EventModel model) {
        Connection connection = null;
        PreparedStatement pStmt = null;
        EventModel similarModel = null;
        ResultSet rs = null;
		

        try {
            connection = getConnection();
            String query = "select eventdatetime, eventenddatetime from event where airport=? AND ?<=eventenddatetime and eventdatetime<=? and eventcategorycode=? and eventid <> ?";

            // For Air Carriers lookup the carrier
            if (model.getEventCategoryCode().equals(FasConstants.carCategory) || model.getEventCategoryCode().equals(FasConstants.inbCategory)) {
                query = query + " AND carrier=?";
            } // For all other CCSFs lookup by certnum
            else {
                query = query + " AND certnum=?";
            }

            pStmt = connection.prepareStatement(query);

            pStmt.setLong(1, model.getAirportOrgId().longValue());
            pStmt.setTimestamp(2, model.getEventDateTime());
            pStmt.setTimestamp(3, model.getEventEndDateTime());
            pStmt.setString(4, model.getEventCategoryCode());
            pStmt.setLong(5, model.getEventId());


            if (model.getEventCategoryCode().equals(FasConstants.carCategory) || model.getEventCategoryCode().equals(FasConstants.inbCategory)) {
                pStmt.setLong(6, model.getCarrierOrgId().longValue());
            } else {
                pStmt.setString(6, model.getCertNum());
            }

            rs = pStmt.executeQuery();

            // just get the first result if any
            if (rs.next()) {
                logger.debug("Found a similar event");
                similarModel = new EventModel();
                similarModel.setEventDateTime(rs.getTimestamp(1));
                similarModel.setEventEndDateTime(rs.getTimestamp(2));
            } else {
                logger.debug("passed duplicate date range lookup.");
            }
            
			rs.close();
            pStmt.close();
            connection.close();
        } catch (Exception ex) {
            logger.error("An exception occurred with finding a similar event.", ex);
        } finally {
		    ConnectionUtil.closeResources(connection, pStmt, rs);			                       
        }	
        return similarModel;
    }

    /**
     * If the user role is "OGS" apply special filtering... 
     * --NOT Domestic carriers (carrier neq "US")
     * --NOT Locations in the US (location neq "US")
     * this hibernate criteria is equivalent to the SQL:
     *
     * select * from v_eventhome where not (airportcc = 'US' and carriercc =
     * 'US')
     *
     * @param credentials
     * @param criteria
     */
    private void filterEventsForOgsRole(Credentials credentials, Criteria criteria) {

        //eventCategoryCode filter out ICSF

        if ("OGS".equalsIgnoreCase(credentials.getRole())) {
            logger.debug("OGS role detected, filtering events accordingly...");
            criteria.add(
                    Restrictions.not(
                    Restrictions.disjunction()
                        .add(Restrictions.and(
                        Restrictions.eq("airportcc", "US"),
                        Restrictions.eq("carriercc", "US")
                          )
                        ) // end not
                    ));            
            // also add filter on ICSF category code.
            criteria.add(Restrictions.ne("eventCategoryCode", "ICSF"));
            // also add filter on SHIP category code.
            criteria.add(Restrictions.ne("eventCategoryCode", "SHIP"));
            // also add filter on IAC category code.
            criteria.add(Restrictions.ne("eventCategoryCode", "IAC"));
        }
    }

    public List<String> getSubsidiaryDomains(Long orgId) throws SQLException {
        
        Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        List<String> subList = new ArrayList<String>();
        String query = "select distinct su.domainname from systemuser su, orghierarchy oh "
                + "where su.orgid = oh.orgid and oh.parentorgid in ( "
                + "select orgid from orghierarchy where parentorgid = " 
                + "(select parentorgid from orghierarchy where orgid = ? and orghierarchytypecode = 'CON')" 
                + "and orghierarchytypecode = 'ORG')";

        try {
            connection = getConnection();
            pStmt = connection.prepareStatement(query);
            pStmt.setLong(1, orgId);
            logger.debug("query is " + query);
            String domain;
            for (rs = pStmt.executeQuery(); rs.next(); subList.add(domain)) {
                domain = rs.getString(1);
            }
        } catch (SQLException sqEx) {
            logger.debug("ERROR in query:" + query);
            logger.error("getSubsidiaryDomains()", sqEx);
            throw sqEx;
        } finally {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        logger.info("Sublist count: " + subList.size());
        return subList;
    }
}
