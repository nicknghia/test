/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/util/UnitConversion.java,v 1.1.10.1 2010/08/22 23:08:34 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: UnitConversion.java,v $
 *  Revision 1.1.10.1  2010/08/22 23:08:34  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdfolio.util;

import java.util.Hashtable;
import java.util.Map;

import org.apache.log4j.Logger;

/**
 * A utility class to help with units conversion
 *
 * @author Sangeeta Taneja
 */
public final class UnitConversion
{
    private static Map conversionTable = new Hashtable();

    static {
        // Length units
        conversionTable.put ("MI::::KM", new Double (1.609344));
        conversionTable.put ("MI::::MTR", new Double (1609.344 ));
        conversionTable.put ("MI::::YD", new Double (1760));
        conversionTable.put ("MI::::FT", new Double (5280));
        conversionTable.put ("MI::::IN", new Double (63360));
        conversionTable.put ("MI::::CM", new Double (160934.4));

        conversionTable.put ("KM::::MTR", new Double (1000));
        conversionTable.put ("KM::::YD", new Double (1093.6132983));
        conversionTable.put ("KM::::FT", new Double (3280.839895));
        conversionTable.put ("KM::::IN", new Double (39370.0787402 ));
        conversionTable.put ("KM::::CM", new Double (100000));

        conversionTable.put ("MTR::::YD", new Double (1.0936133));
        conversionTable.put ("MTR::::FT", new Double (3.2808399));
        conversionTable.put ("MTR::::IN", new Double (39.3700787));
        conversionTable.put ("MTR::::CM", new Double (100));

        conversionTable.put ("YD::::FT", new Double (3));
        conversionTable.put ("YD::::IN", new Double (36));
        conversionTable.put ("YD::::CM", new Double (91.44));

        conversionTable.put ("FT::::IN", new Double (12));
        conversionTable.put ("FT::::CM", new Double (30.48));

        conversionTable.put ("IN::::CM", new Double (2.54));

        // Volume units
        conversionTable.put ("CMTR::::CCFT", new Double (35.3146666));
        conversionTable.put ("CMTR::::CUIN", new Double (61023.7438368));
        conversionTable.put ("CMTR::::CC", new Double (1000000));

        conversionTable.put ("CCFT::::CUIN", new Double (1728));
        conversionTable.put ("CCFT::::CC", new Double (28316.8467117));

        conversionTable.put ("CUIN::::CC", new Double (16.3870641));

        // Weight units
        conversionTable.put ("MTON::::STON", new Double (1.1023113));
        conversionTable.put ("MTON::::KG", new Double (1000));
        conversionTable.put ("MTON::::POUND", new Double (2204.6226218 ));
        conversionTable.put ("MTON::::OUNCE", new Double (35273.9619496));
        conversionTable.put ("MTON::::GRAM", new Double (1000000));

        conversionTable.put ("STON::::KG", new Double (907.18474));
        conversionTable.put ("STON::::POUND", new Double (2000));
        conversionTable.put ("STON::::OUNCE", new Double (32000));
        conversionTable.put ("STON::::GRAM", new Double (907184.74));

        conversionTable.put ("KG::::POUND", new Double (2.2046226218 ));
        conversionTable.put ("KG::::OUNCE", new Double (35.2739619496));
        conversionTable.put ("KG::::GRAM", new Double (1000));

        conversionTable.put ("POUND::::OUNCE", new Double (16));
        conversionTable.put ("POUND::::GRAM", new Double (453.59237));

        conversionTable.put ("OUNCE::::GRAM", new Double (28.3495231));

        // time units
        conversionTable.put ("DAY::::SEC", new Double (86400));
        conversionTable.put ("HOUR::::SEC", new Double (3600));
        conversionTable.put ("MIN::::SEC", new Double (60));
    }

    protected static Logger logger = Logger.getLogger ("com.freightdesk.fdfolio.util.UnitConversion");

    /**
     * UnitConversion is a static class.  No public constructors please.
     * Why do you need an instance anyway?
     */
    private UnitConversion()
    {
    }

    /**
     * Converts a value from one unit of measure to another.
     * If one of the units of measure is not recognized, an exception is thrown.
     *
     * <P> This method can be used as follows:
     * <code>
     * double lengthInMeters = UnitConversion.convertToUOM ("CM", "MTR", 100); <BR>
     * // After this call, lengthInMeters = 1.
     * </code>
     *
     * @param fromUom The unit of measure that the value is currently in
     * @param toUom The target unit of measure that we want the value to translate to
     * @param value The value (in <code>fromUom</code> that has to be translated
     *
     * @exception IllegalArgumentException If fromUom or toUom is null, empty or not recognized
     */
    public static double convertToUOM(String fromUomCode, String toUomCode, double value)
    {
        Double conversionFactor = null;

        if ((fromUomCode == null) || ("".equals (fromUomCode)))
            throw new IllegalArgumentException ("No From UOM code specified, cant convert it to anything");

        if ((toUomCode == null) || ("".equals (toUomCode)))
            throw new IllegalArgumentException ("No Target UOM code specified");

        // Gets the conversion factor from the table, if needed
        if  (fromUomCode.equals (toUomCode)) {
            conversionFactor = new Double (1.0);
        } else {
            fromUomCode = fromUomCode.toUpperCase();
            toUomCode = toUomCode.toUpperCase();

            conversionFactor = (Double) (conversionTable.get(fromUomCode + "::::" + toUomCode));
            // if the conversion factor is still null, try the inverse
            if (conversionFactor == null) {
                Double inverseFactor = (Double) (conversionTable.get(toUomCode + "::::" + fromUomCode));
                if (inverseFactor != null)
                    conversionFactor = new Double(1.0 / inverseFactor.doubleValue());
            }
        }

        // applies the conversion factor if it is not null
        if (conversionFactor != null)
        {
            logger.debug ("Applying conversion factor: " + conversionFactor.doubleValue());
            return conversionFactor.doubleValue() * value;
        }

        // conversion factor not recognized, throw exception
        logger.warn ("No conversion factor exists for " + fromUomCode + " to " + toUomCode);
        throw new IllegalArgumentException ("No conversion factor exists  for " +
                fromUomCode + " to " + toUomCode);
    }
}


