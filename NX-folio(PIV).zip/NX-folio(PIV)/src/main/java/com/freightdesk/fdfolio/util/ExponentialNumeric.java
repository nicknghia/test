/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/util/ExponentialNumeric.java,v 1.2.4.1 2010/08/22 23:08:34 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: ExponentialNumeric.java,v $
 *  Revision 1.2.4.1  2010/08/22 23:08:34  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.2  2006/05/23 22:13:56  aarora
 *  Formatted as per style file
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 */


package com.freightdesk.fdfolio.util;

public class ExponentialNumeric
{
    public static String convertExponentialToNumeric(String strGrossWeightValue)
    {
        char[] charArray = strGrossWeightValue.toCharArray();
        char c = '\0';
        String modifiedString = "";
        for (int i = 0; charArray != null && i < charArray.length; i++) {
            if (charArray[i] == 'E') {
                try {
                    c = charArray[i];

                    String expPart = strGrossWeightValue.substring(i + 1);
                    int expPartInt = Integer.parseInt(expPart);

                    String headPart = strGrossWeightValue.substring(0, i);

                    String[] splitString = new String[2];
                    java.util.StringTokenizer st = new java.util.StringTokenizer(headPart, ".");
                    int count = 0;
                    while (st.hasMoreTokens()) {
                        splitString[count++] = st.nextToken();
                    }

                    String headerLeftToDecimal = splitString[0];

                    String headerRightToDecimal = "";
                    int lengthOfDecimal = 0;

                    headerRightToDecimal = splitString[1];

                    if (headerRightToDecimal != null) {
                        lengthOfDecimal = headerRightToDecimal.length();
                    }

                    if (lengthOfDecimal == 0) {
                        for (int j = 0; j < expPartInt; j++) {
                            headPart = headPart + "0";
                        }
                        modifiedString = headPart;
                        break;
                    } else {
                        if (lengthOfDecimal == expPartInt) {
                            modifiedString = headerLeftToDecimal + headerRightToDecimal;
                            break;
                        } else if (expPartInt > lengthOfDecimal) {
                            int numberOfZeroTobeInserted = expPartInt - lengthOfDecimal;
                            modifiedString = headerLeftToDecimal + headerRightToDecimal;
                            for (int j = 0; j < numberOfZeroTobeInserted; j++) {
                                modifiedString = modifiedString + "0";
                            }
                            break;
                        } else if (expPartInt < lengthOfDecimal) {
                            modifiedString = headerLeftToDecimal + headerRightToDecimal;
                            StringBuffer sb = new StringBuffer(modifiedString);
                            sb.insert(expPartInt + 1, ".");
                            modifiedString = sb.toString();
                            break;
                        }
                    }

                } catch (Exception e) {

                }
            }
        }
        if (c == '\0') {
            return strGrossWeightValue;
        }

        return modifiedString;
    }
}
