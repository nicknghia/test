/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/event/model/EventDocumentModel.java,v 1.3.4.4 2010/08/22 23:08:38 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: EventDocumentModel.java,v $
 *  Revision 1.3.4.4  2010/08/22 23:08:38  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.3.4.3  2009/09/23 18:04:14  mechevarria
 *  import cleanup via eclipse
 *
 *  Revision 1.3.4.2  2008/07/10 19:15:46  mechevarria
 *  added isnew field
 *
 *  Revision 1.3.4.1  2008/06/03 12:39:04  mechevarria
 *  gov_solutions merge updates
 *
 *  Revision 1.6  2007/05/24 10:52:47  atripathi
 *  rolled back to oracle 9i dialect class
 *
 *  Revision 1.5  2007/05/23 11:59:31  nsehra
 *  fixed documentbinary data issue
 *
 *  Revision 1.4  2007/04/12 09:32:54  nsehra
 *  added method applyPartitionTimeStamp for Data Partitioning
 *
 *  Revision 1.3  2006/03/28 21:23:02  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.2  2005/08/01 09:41:08  pjain
 *  refactored UserModel to BaseModel
 *
 *  Revision 1.1  2004/09/15 13:12:45  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdfolio.event.model;


import java.sql.Timestamp;

import com.freightdesk.fdcommons.BaseModel;

/**
 * EventModel associated with EventDao and ShipmentEventAction. This class is a
 * Value Object to transfer the data from presentation layer to the Database.
 * 
 * 
 * @author Biju Joseph
 */

public class EventDocumentModel extends BaseModel

{

    private long eventId;

    private long eventDocumentId;

    private String eventDocumentPath;

    private String eventDocumentDescription;

    private String documentTypeCode;

    private String documentDataText;

    private byte[] documentDataBinary;

    //not persisted
    private String eventDocumentName;
    private boolean isNew;

    public EventDocumentModel() {
    }

    public EventDocumentModel(long eventDocumentId, long eventId,
            String eventDocumentPath, String eventDocumentDescription,
            String createUserId, Timestamp createTimestamp,
            String lastUpdateUserId, Timestamp lastUpdateTimestamp,
            String domainName) {
        super(createUserId, createTimestamp, lastUpdateUserId,
                lastUpdateTimestamp, domainName);
        this.eventDocumentId = eventDocumentId;
        this.eventId = eventId;
        this.eventDocumentPath = eventDocumentPath;
        this.eventDocumentDescription = eventDocumentDescription;
    }

    /**
     * Implements the abstract method defined by BaseModel.
     * 
     * @return primaryKey the unique id key for this model object.
     */
    public long getPrimaryKey() {
        return this.eventDocumentId;
    }

    /**
     * Returns the documentName.
     * 
     * @return String
     */
    public String getEventDocumentName() {
        return eventDocumentName;
    }

    /**
     * Returns the documentPath.
     * 
     * @return String
     */
    public String getEventDocumentPath() {
        return eventDocumentPath;
    }

    /**
     * Returns the eventDocumentId.
     * 
     * @return long
     */
    public long getEventDocumentId() {
        return eventDocumentId;
    }

    /**
     * Returns the eventId.
     * 
     * @return long
     */
    public long getEventId() {
        return eventId;
    }

    /**
     * Sets the documentName.
     * 
     * @param documentName
     *            The documentName to set
     */
    public void setEventDocumentName(String eventDocumentName) {
        this.eventDocumentName = eventDocumentName;
    }

    /**
     * Sets the documentPath.
     * 
     * @param documentPath
     *            The documentPath to set
     */
    public void setEventDocumentPath(String eventDocumentPath) {
        this.eventDocumentPath = eventDocumentPath;
    }

    /**
     * Sets the eventDocumentId.
     * 
     * @param eventDocumentId
     *            The eventDocumentId to set
     */
    public void setEventDocumentId(long eventDocumentId) {
        this.eventDocumentId = eventDocumentId;
    }

    /**
     * Sets the eventId.
     * 
     * @param eventId
     *            The eventId to set
     */
    public void setEventId(long eventId) {
        this.eventId = eventId;
    }

    /**
     * Returns the eventDocumentDescription.
     * 
     * @return String
     */
    public String getEventDocumentDescription() {
        return eventDocumentDescription;
    }

    /**
     * Sets the eventDocumentDescription.
     * 
     * @param eventDocumentDescription
     *            The eventDocumentDescription to set
     */
    public void setEventDocumentDescription(String eventDocumentDescription) {
        this.eventDocumentDescription = eventDocumentDescription;
    }

    /**
     * @return documentTypeCode
     */
    public String getDocumentTypeCode() {
        return this.documentTypeCode;
    }

    /**
     * @param documentTypeCode
     */
    public void setDocumentTypeCode(String documentTypeCode) {
        this.documentTypeCode = documentTypeCode;
    }

    /**
     * @return
     */
    public byte[] getDocumentDataBinary() {
        return documentDataBinary;
    }

    /**
     * @return
     */
    public String getDocumentDataText() {
        return documentDataText;
    }

    /**
     * @param string
     */
    public void setDocumentDataBinary(byte[] b) {
        documentDataBinary = b;
    }

    /**
     * @param string
     */
    public void setDocumentDataText(String string) {
        documentDataText = string;
    }


    /**
     * @return the isNew
     */
    public boolean isNew()
    {
        return isNew;
    }

    /**
     * @param isNew the isNew to set
     */
    public void setNew(boolean isNew)
    {
        this.isNew = isNew;
    }
}

