/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/dao/FinancialAccountingDAO.java,v 1.2.6.2 2010/08/22 23:08:29 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: FinancialAccountingDAO.java,v $
 *  Revision 1.2.6.2  2010/08/22 23:08:29  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.2.6.1  2010/03/15 14:45:11  mechevarria
 *  fix jdbc methods to use bind vars
 *
 *  Revision 1.2  2006/03/28 21:22:58  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.1  2005/08/20 12:30:16  pjain
 *  centralized DAO package
 *
 *  Revision 1.4  2005/06/15 11:24:26  ranand
 *  delete method calls to Base DAO delete method
 *
 *  Revision 1.3  2005/06/14 11:57:19  ranand
 *  delete method calls to Base DAO delete method
 *
 *  Revision 1.2  2004/11/22 08:48:07  ranand
 *  Settlement enhancement removed Naming Exception in throws clause
 *
 *  Revision 1.1  2004/09/23 13:41:20  ranand
 *  package changed from settlement to invoice
 *
 *  Revision 1.1  2004/09/15 13:20:00  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdfolio.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import javax.naming.NamingException;

import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdfolio.invoice.model.FinancialAccountingModel;

/** 
 * Defines the methods for performing insert, update, delete, Read operations on INVOICE table.
 *
 * @author Sangeeta Taneja
 * @author Amrinder Arora
 */

public class FinancialAccountingDAO extends BaseDao {


    public void create(FinancialAccountingModel financialAccountingModel)
        throws SQLException
    {
        PreparedStatement pStmt = null;
        Connection connection = null;
        try
        {
            String query = "INSERT INTO FINANCIALACCOUNTING ( FINANCIALACCOUNTINGID, INVOICECHARGEID, SHIPMENTCHARGETYPECODE, FINANCIALINFORMATION, BREAKDOWNSTRUCTURE, BREAKDOWNSTRUCTUREORGID, PERCENTAGE, RATE, AMOUNT, CURRENCYCODE, STATUS, CREATEUSERID, CREATETIMESTAMP, LASTUPDATEUSERID, LASTUPDATETIMESTAMP, DOMAINNAME )"+
                           " VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
     
            logger.info("FinancialAccountingDAO Create ::: begin::  "+query);

            connection = getConnection();
            pStmt = connection.prepareStatement(query);
            if (financialAccountingModel.getFinancialAccountingId()==0)
            {
                financialAccountingModel.setFinancialAccountingId(getNextID("FINANCIALACCOUNTINGID"));    
            }
           
            pStmt.setLong(1,financialAccountingModel.getFinancialAccountingId());
            
            if (financialAccountingModel.getInvoiceChargeId() != 0L)
                pStmt.setLong(2, financialAccountingModel.getInvoiceChargeId());
            else
                pStmt.setNull(2, Types.NUMERIC);
            
            if(financialAccountingModel.getShipmentChargeTypeCode() != null)
                pStmt.setString(3, financialAccountingModel.getShipmentChargeTypeCode());
            else
                pStmt.setNull(3,Types.VARCHAR);

            if(financialAccountingModel.getFinancialInformation() != null)
                pStmt.setString(4, financialAccountingModel.getFinancialInformation());
            else
                pStmt.setNull(4,Types.VARCHAR);

            if(financialAccountingModel.getBreakDownStructure() != null)
                pStmt.setString(5, financialAccountingModel.getBreakDownStructure());
            else
                pStmt.setNull(5,Types.VARCHAR);

            logger.debug("  ORG ID IS  ::::  "+financialAccountingModel.getOrgId());
            if(financialAccountingModel.getOrgId() != 0)
                pStmt.setLong(6, financialAccountingModel.getOrgId());
            else
                pStmt.setNull(6,Types.NUMERIC);

            if(financialAccountingModel.getPercentage() != 0.0)
                pStmt.setDouble(7, financialAccountingModel.getPercentage());
            else
                pStmt.setNull(7,Types.NUMERIC);

            if(financialAccountingModel.getRate() != 0.0)
                pStmt.setDouble(8, financialAccountingModel.getRate());
            else
                pStmt.setNull(8,Types.NUMERIC);
                
                
            if(financialAccountingModel.getAmount() != 0.0)
                pStmt.setDouble(9, financialAccountingModel.getAmount());
            else
                pStmt.setNull(9,Types.NUMERIC);

            if(financialAccountingModel.getCurrencycode() != null)
                pStmt.setString(10, financialAccountingModel.getCurrencycode());
            else
                pStmt.setNull(10,Types.NUMERIC);

            pStmt.setString(11, financialAccountingModel.getStatus());
            pStmt.setString(12, financialAccountingModel.getCreateUserId());
            pStmt.setTimestamp(13, financialAccountingModel.getLastUpdateTimestamp());
            pStmt.setString(14, financialAccountingModel.getLastUpdateUserId());
            pStmt.setTimestamp(15, financialAccountingModel.getLastUpdateTimestamp());
            pStmt.setString(16, financialAccountingModel.getDomainName());
            pStmt.executeUpdate();
        }
        catch(SQLException e)
        {
            logger.error("create(): Exception while creating the FinancialAccounting ", e);
            throw e;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }

    public void update(FinancialAccountingModel financialAccountingModel)
        throws SQLException
    {
        StringBuffer query = new StringBuffer("UPDATE  FINANCIALACCOUNTING SET  INVOICECHARGEID=?, SHIPMENTCHARGETYPECODE=?, FINANCIALINFORMATION=?,");
                             query.append("BREAKDOWNSTRUCTURE = ?, BREAKDOWNSTRUCTUREORGID = ?, PERCENTAGE = ?, RATE = ?, AMOUNT = ?, CURRENCYCODE = ?,");
                             query.append("STATUS = ?, CREATEUSERID = ?, CREATETIMESTAMP = ?, LASTUPDATEUSERID = ?, LASTUPDATETIMESTAMP = ?, DOMAINNAME = ?");
                              query.append(" WHERE FINANCIALACCOUNTINGID = ? "); 
        
        PreparedStatement pStmt = null;
        Connection connection = null;
        try
        {
            connection = getConnection();
            pStmt = connection.prepareStatement(query.toString());
            
            if (financialAccountingModel.getInvoiceChargeId() != 0L)
                pStmt.setLong(1, financialAccountingModel.getInvoiceChargeId());
            else
                pStmt.setNull(1, Types.NUMERIC);
            
            if(financialAccountingModel.getShipmentChargeTypeCode() != null)
                pStmt.setString(2, financialAccountingModel.getShipmentChargeTypeCode());
            else
                pStmt.setNull(2,Types.VARCHAR);

            if(financialAccountingModel.getFinancialInformation() != null)
                pStmt.setString(3, financialAccountingModel.getFinancialInformation());
            else
                pStmt.setNull(3,Types.VARCHAR);

            if(financialAccountingModel.getBreakDownStructure() != null)
                pStmt.setString(4, financialAccountingModel.getBreakDownStructure());
            else
                pStmt.setNull(4,Types.VARCHAR);


            if(financialAccountingModel.getOrgId() != 0)
                pStmt.setLong(5, financialAccountingModel.getOrgId());
            else
                pStmt.setNull(5,Types.NUMERIC);

            if(financialAccountingModel.getPercentage() != 0.0)
                pStmt.setDouble(6, financialAccountingModel.getPercentage());
            else
                pStmt.setNull(6,Types.NUMERIC);

            if(financialAccountingModel.getRate() != 0.0)
                pStmt.setDouble(7, financialAccountingModel.getRate());
            else
                pStmt.setNull(7,Types.NUMERIC);
                
                
            if(financialAccountingModel.getAmount() != 0.0)
                pStmt.setDouble(8, financialAccountingModel.getAmount());
            else
                pStmt.setNull(8,Types.NUMERIC);

            if(financialAccountingModel.getCurrencycode() != null)
                pStmt.setString(9, financialAccountingModel.getCurrencycode());
            else
                pStmt.setNull(9,Types.VARCHAR);

            pStmt.setString(10, financialAccountingModel.getStatus());
            pStmt.setString(11, financialAccountingModel.getCreateUserId());
            pStmt.setTimestamp(12, financialAccountingModel.getLastUpdateTimestamp());
            pStmt.setString(13, financialAccountingModel.getLastUpdateUserId());
            pStmt.setTimestamp(14, financialAccountingModel.getLastUpdateTimestamp());
            pStmt.setString(15, financialAccountingModel.getDomainName());
            pStmt.setLong(16, financialAccountingModel.getFinancialAccountingId());
            pStmt.executeUpdate();

      }
        catch(SQLException e)
        {
            logger.error("Exception in InvoiceChargeDAO::update() ", e);
            throw e;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }

    public FinancialAccountingModel retrieve(long financialAccountingId)  throws SQLException
    {
        logger.info("retrieve(invoiceChargeId: " + financialAccountingId + "): begin");

        PreparedStatement pStmt = null;
        ResultSet rs = null;
        Connection connection = null;
        FinancialAccountingModel financialAccountingModel = null;

        try
        {
           String query = " SELECT  INVOICECHARGEID, SHIPMENTCHARGETYPECODE, FINANCIALINFORMATION, BREAKDOWNSTRUCTURE, BREAKDOWNSTRUCTUREORGID, PERCENTAGE, RATE, AMOUNT, CURRENCYCODE, STATUS, CREATEUSERID, CREATETIMESTAMP, LASTUPDATEUSERID, LASTUPDATETIMESTAMP, DOMAINNAME  FROM FINANCIALACCOUNTING WHERE FINANCIALACCOUNTINGID=?";
           
           connection = getConnection();
           pStmt = connection.prepareStatement(query);
           pStmt.setLong(1, financialAccountingId);
           rs = pStmt.executeQuery();

            if(rs.next())
            {
                financialAccountingModel = new FinancialAccountingModel();
                financialAccountingModel.setInvoiceChargeId(rs.getLong("INVOICECHARGEID"));
                financialAccountingModel.setShipmentChargeTypeCode(rs.getString("SHIPMENTCHARGETYPECODE"));
                financialAccountingModel.setFinancialInformation(rs.getString("FINANCIALINFORMATION"));
                financialAccountingModel.setBreakDownStructure(rs.getString("BREAKDOWNSTRUCTURE"));
                financialAccountingModel.setOrgId(rs.getLong("BREAKDOWNSTRUCTUREORGID"));
                financialAccountingModel.setPercentage(rs.getDouble("PERCENTAGE"));
                financialAccountingModel.setRate(rs.getDouble("RATE"));
                financialAccountingModel.setAmount(rs.getDouble("AMOUNT"));
                financialAccountingModel.setCurrencycode(rs.getString("CURRENCYCODE"));
                financialAccountingModel.setStatus(rs.getString("STATUS"));
                financialAccountingModel.setCreateUserId(rs.getString("CREATEUSERID"));
                financialAccountingModel.setCreateTimestamp(rs.getTimestamp("CREATETIMESTAMP"));
                financialAccountingModel.setLastUpdateUserId(rs.getString("LASTUPDATEUSERID"));
                financialAccountingModel.setLastUpdateTimestamp(rs.getTimestamp("LASTUPDATETIMESTAMP"));
                financialAccountingModel.setDomainName(rs.getString("DOMAINNAME"));
                
            }
        }
        catch(SQLException e)
        {
            logger.error(" Exception in InvoiceChargeDAO::retrieve(): ", e);
            throw e;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return financialAccountingModel;
    }

    public List retrieveAllByInvoiceChargeId(long invoiceChargeId)  
        throws SQLException
    {
            logger.info("retrieve(invoiceChargeId: " + invoiceChargeId + "): begin");

            PreparedStatement pStmt = null;
            ResultSet rs = null;
            Connection connection = null;
            List accountingList  = new ArrayList();

            try
            {
                String query = " SELECT FINANCIALACCOUNTINGID,  SHIPMENTCHARGETYPECODE, FINANCIALINFORMATION, BREAKDOWNSTRUCTURE, BREAKDOWNSTRUCTUREORGID, PERCENTAGE, RATE, AMOUNT, CURRENCYCODE, STATUS, CREATEUSERID, CREATETIMESTAMP, LASTUPDATEUSERID, LASTUPDATETIMESTAMP, DOMAINNAME  FROM FINANCIALACCOUNTING WHERE INVOICECHARGEID=?";
           
               connection = getConnection();
               pStmt = connection.prepareStatement(query);
               pStmt.setLong(1, invoiceChargeId);
               rs = pStmt.executeQuery();

                while (rs.next())
                {
                    FinancialAccountingModel financialAccountingModel = new FinancialAccountingModel();
                    financialAccountingModel.setFinancialAccountingId(rs.getLong("FINANCIALACCOUNTINGID"));
                    financialAccountingModel.setShipmentChargeTypeCode(rs.getString("SHIPMENTCHARGETYPECODE"));
                    financialAccountingModel.setFinancialInformation(rs.getString("FINANCIALINFORMATION"));
                    financialAccountingModel.setBreakDownStructure(rs.getString("BREAKDOWNSTRUCTURE"));
                    financialAccountingModel.setOrgId(rs.getLong("BREAKDOWNSTRUCTUREORGID"));
                    financialAccountingModel.setPercentage(rs.getDouble("PERCENTAGE"));
                    financialAccountingModel.setRate(rs.getDouble("RATE"));
                    financialAccountingModel.setAmount(rs.getDouble("AMOUNT"));
                    financialAccountingModel.setCurrencycode(rs.getString("CURRENCYCODE"));
                    financialAccountingModel.setStatus(rs.getString("STATUS"));
                    financialAccountingModel.setCreateUserId(rs.getString("CREATEUSERID"));
                    financialAccountingModel.setCreateTimestamp(rs.getTimestamp("CREATETIMESTAMP"));
                    financialAccountingModel.setLastUpdateUserId(rs.getString("LASTUPDATEUSERID"));
                    financialAccountingModel.setLastUpdateTimestamp(rs.getTimestamp("LASTUPDATETIMESTAMP"));
                    financialAccountingModel.setDomainName(rs.getString("DOMAINNAME"));
                    
                    accountingList.add(financialAccountingModel);                        
                }
            }
            catch (SQLException e)
            {
                logger.error("Exception in retrieveAllByInvoiceLineId()", e);
                throw e;
            }
            finally
            {
                ConnectionUtil.closeResources(connection, pStmt, rs);
            }
            return accountingList;
        }


    
    public void delete(FinancialAccountingModel financialAccountingModel)  throws SQLException,NamingException
    {
        delete(financialAccountingModel.getFinancialAccountingId());
    }


    public void delete(long accountingId)  throws SQLException,NamingException
    {
        String query = "DELETE FINANCIALACCOUNTING WHERE FINANCIALACCOUNTINGID = ?";
        deleteRecord (query,accountingId);
    }
    
    public void deleteAllByInvoiceChargeId(long invoiceChargeId)  throws SQLException
    {
        String query = "DELETE FINANCIALACCOUNTING WHERE INVOICECHARGEID = ?";
        HashMap<Integer, Object> paramMap = new HashMap<Integer, Object>();
        paramMap.put(1, invoiceChargeId);
        
        executeUpdate(query,paramMap);
        }
        
} 
