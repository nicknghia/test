/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/analyzer/util/ShipmentSecurityMap.java,v 1.4.4.1 2010/08/22 23:08:45 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: ShipmentSecurityMap.java,v $
 *  Revision 1.4.4.1  2010/08/22 23:08:45  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.4  2006/05/07 22:11:57  aarora
 *  Removed unused fields
 *
 *  Revision 1.3  2004/09/15 13:03:03  ranand
 *  2.6 Baseline
 *
 * 
 */


package com.freightdesk.fdfolio.analyzer.util;

import java.util.List;

/**
 * @author biju.joseph
 *
 * To change the template for this generated type comment go to
 * Window>Preferences>Java>Code Generation>Code and Comments
 */
public class ShipmentSecurityMap {
	
	private List shipmentLegSecurityMaps;
	//this map will be used later
	private String isShipperIPSecure;	
	private String isConsigneeIPSecure;
	private String isOriginLocSecure;
	private String isDestLocSecure;
	private double transitTime;
	private double dwellTime;
	private double requiredSecurityScore;
	private double actualSecurityScore;

	/**
	 * @return dwellTime
	 */
	public double getDwellTime() {
		return dwellTime;
	}

	/**
	 * @return transitTime
	 */
	public double getTransitTime() {
		return transitTime;
	}

	/**
	 * @param transitTime
	 */
	public void setTransitTime(double transitTime) {
		this.transitTime = transitTime;
	}
	
	/**
	 * @param dwellTime
	 */
	public void setDwellTime(double dwellTime) {
		this.dwellTime = dwellTime;
	}

	/**
	 * @return shipmentLegSecurityMaps
	 */
	public List getShipmentLegSecurityMaps() {
		return shipmentLegSecurityMaps;
	}

	/**
	 * @param shipmentLegSecurityMaps
	 */
	public void setShipmentLegSecurityMaps(List shipmentLegSecurityMaps) {
		this.shipmentLegSecurityMaps = shipmentLegSecurityMaps;
	}

	/**
	 * @return isConsigneeIPSecure
	 */
	public String getIsConsigneeIPSecure() {
		return isConsigneeIPSecure;
	}

	/**
	 * @return isDestLocSecure
	 */
	public String getIsDestLocSecure() {
		return isDestLocSecure;
	}

	/**
	 * @return isOriginLocSecure
	 */
	public String getIsOriginLocSecure() {
		return isOriginLocSecure;
	}

	/**
	 * @return isShipperIPSecure
	 */
	public String getIsShipperIPSecure() {
		return isShipperIPSecure;
	}

	/**
	 * @param isConsigneeIPSecure
	 */
	public void setIsConsigneeIPSecure(String isConsigneeIPSecure) {
		this.isConsigneeIPSecure = isConsigneeIPSecure;
	}

	/**
	 * @param isDestLocSecure
	 */
	public void setIsDestLocSecure(String isDestLocSecure) {
		this.isDestLocSecure = isDestLocSecure;
	}

	/**
	 * @param isOriginLocSecure
	 */
	public void setIsOriginLocSecure(String isOriginLocSecure) {
		this.isOriginLocSecure = isOriginLocSecure;
	}

	/**
	 * @param isShipperIPSecure
	 */
	public void setIsShipperIPSecure(String isShipperIPSecure) {
		this.isShipperIPSecure = isShipperIPSecure;
	}

	/**
	 * @return actualSecurityScore
	 */
	public double getActualSecurityScore() {
		return actualSecurityScore;
	}

	/**
	 * @return requiredSecurityScore
	 */
	public double getRequiredSecurityScore() {
		return requiredSecurityScore;
	}

	/**
	 * @param actualSecurityScore
	 */
	public void setActualSecurityScore(double actualSecurityScore) {
		this.actualSecurityScore = actualSecurityScore;
	}

	/**
	 * @param requiredSecurityScore
	 */
	public void setRequiredSecurityScore(double requiredSecurityScore) {
		this.requiredSecurityScore = requiredSecurityScore;
	}
    
	public String getSecurityDisplayVal(String val) {
		if("Y".equalsIgnoreCase(val)) {
			return "Secure";
		}
		else if("N".equalsIgnoreCase(val)) {
			return "Unsecure";
		}
		return "";
	}

	public String getSecurityDisplayValForIP(String val) {
		if("Y".equalsIgnoreCase(val)) {
			return "M trusted";
		}
		else if("N".equalsIgnoreCase(val)) {
			return "N total";
		}
		return "";
	}
}
