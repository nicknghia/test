 /** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/common/LocatableObject.java,v 1.3.8.1 2010/08/22 23:08:26 mechevarria Exp $ 
 * 
 *  Modification History:
 *  $Log: LocatableObject.java,v $
 *  Revision 1.3.8.1  2010/08/22 23:08:26  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.3  2005/04/26 22:45:42  amrinder
 *  Removed the identifier, just using description
 *
 *  Revision 1.2  2005/04/25 22:36:23  amrinder
 *  Added toString
 *
 *  Revision 1.1  2005/04/16 14:15:45  dkhoker
 *  Implementation of Locatable interface
 *
 */
 package com.freightdesk.fdfolio.common;

import java.io.Serializable;

/**
 * Models a locatable object.
 *
 * @see com.freightdesk.fdfolio.common.Locatable 
 * @author Devendra Khoker
 */
public class LocatableObject
    implements Serializable, Locatable
{
    private double longitude;
    private double latitude;
    private String description;

	public LocatableObject() {
		super();
	}

	public LocatableObject(double latitudeArg, double longitudeArg, String descriptionArg)
	{
		this.latitude = latitudeArg;
		this.longitude = longitudeArg;
		this.description = descriptionArg;
	}

    /** Gets a String version of the locatable object. */
    public String toString()
    {
        return "Desc: " + description + ", lat: " + latitude + ", long: " + longitude;
    }

	/** gets latitude for the organization
	 */
	public double getLatitude() {
		return latitude;
	}

	/** returns the longitude for the organization
	 */
	public double getLongitude() {
		return longitude;
	}

	/**
	 * Sets the latitude for the organization
	 * @param double
	 */
	public void setLatitude(double latitude)
	{
		this.latitude = latitude;
	}

	/**
	 * Sets the longitude for the organization
	 * @param double
	 */
	public void setLongitude(double longitude)
	{
		this.longitude = longitude;
	}

	
	/**
	 * Gets the description for the locatable object. 
	 * @return description
	 * @see com.freightdesk.fdfolio.common.Locatable#getDescription()
	 */
	public String getDescription() {
		return description;
	}

	/**
	 * Sets the description.
	 * @param descriptionArg The description to set
	 */
	public void setDescription (String descriptionArg) {
		this.description = descriptionArg;
	}
}
