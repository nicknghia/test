/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/dao/CommunicationMethodDAO.java,v 1.6.4.6 2010/11/15 21:11:21 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: CommunicationMethodDAO.java,v $
 *  Revision 1.6.4.6  2010/11/15 21:11:21  mechevarria
 *  remove oraclepreparestatement
 *
 *  Revision 1.6.4.5  2010/08/22 23:08:29  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.6.4.4  2010/04/28 20:44:50  mechevarria
 *  clean up sql to use not oraclepreparedconnection
 *
 *  Revision 1.6.4.3  2010/04/20 23:42:52  mechevarria
 *  close open resultsets
 *
 *  Revision 1.6.4.2  2010/03/01 14:25:58  mechevarria
 *  use non-sql injection delet
 *
 *  Revision 1.6.4.1  2009/10/05 20:09:13  mechevarria
 *  fix to make email required
 *
 *  Revision 1.6  2006/04/20 11:12:52  uvasundhara
 *  Statement is replaced by PreparedStatement
 *
 *  Revision 1.5  2006/03/28 21:22:58  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.4  2005/09/15 19:39:40  amrinder
 *  Some Javadoc changes
 *
 *  Revision 1.3  2005/09/15 10:34:08  pjain
 *  added: create(list) method
 *
 *  Revision 1.2  2005/08/31 13:19:19  nsehra
 *  removed i18n of basic fields
 *
 *  Revision 1.1  2005/08/20 12:30:16  pjain
 *  centralized DAO package
 *
 *  Revision 1.10  2005/08/18 13:49:48  nsehra
 *  changes for internationalization
 *
 *  Revision 1.9  2005/06/22 23:12:16  amrinder
 *  Added a deleteByInvolvedPartyID method, removed dead code and formatted
 *
 *  Revision 1.8  2005/06/14 11:57:19  ranand
 *  delete method calls to Base DAO delete method
 *
 *  Revision 1.7  2005/03/11 17:22:14  agarg
 *  changed setDouble for Ids to setLong
 *
 *  Revision 1.6  2005/03/10 19:18:46  agarg
 *  Changed return type of Create method from void to CommunicationModel
 *
 *  Revision 1.5  2005/02/16 21:51:27  amrinder
 *  Removed unnecessary imports
 *
 *  Revision 1.4  2004/11/29 12:46:53  biju
 *  DAO/EJB changes for UM
 *
 *  Revision 1.3  2004/09/15 13:06:03  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdfolio.dao;

import org.apache.log4j.Logger;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.criterion.Restrictions;

import com.freightdesk.fdfolio.common.SessionFactoryUtil;
import com.freightdesk.fdfolio.communication.model.CommunicationModel;
import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.ConnectionUtil;

public class CommunicationMethodDAO extends BaseDao {

	protected static Logger logger = Logger.getLogger("CommunicationMethodDAO");
	
	public void persist(List<CommunicationModel> modelList) {
		logger.debug("Persisting " + modelList.size() + " CommunicationMethod models to the database");
		boolean saved = false;
		
		for (CommunicationModel model : modelList) {
			saved = persist(model);
			
			if(!saved)
				logger.error("Failed to persist CommunicationModel.  ID is " + model.getCommunicationMethodId());
		}

	}

	public boolean persist(CommunicationModel model) {
		logger.debug("Attempting to persist CommunicationModel");
		Session session = null;
		boolean saved = false;
		try {
			session = SessionFactoryUtil.getSession();
			session.beginTransaction();

			session.saveOrUpdate(model);
			saved = true;
		} catch (Exception e) {
			session.getTransaction().rollback();
			saved = false;
			//e.printStackTrace();
			logger.error("Exception: " + e.getMessage());
		} finally {
			session.getTransaction().commit();
			session.close();
		}
		return saved;
	}
	
	@SuppressWarnings("unchecked")
	public List<CommunicationModel> retrieve(long orgId) {
		logger.debug("Getting CommunicationMethod models for ORG "+orgId);
		Session session = null;
		List<CommunicationModel> modelList = new ArrayList<CommunicationModel>();
		
		try {
			session = SessionFactoryUtil.getSession();
			Criteria criteria = session.createCriteria(CommunicationModel.class);
			criteria.add(Restrictions.eq("orgId", orgId));
			
			modelList = criteria.list();
		} catch (Exception ex) {
			//ex.printStackTrace();
			logger.error("Exception: " + ex.getMessage());
		} finally {
			session.close();
		}
		logger.debug("Return list of "+modelList.size()+ " CommunicationModels");
		return modelList;
	}

	public boolean delete(long comId) {
		logger.debug("Deleting CommunciationMethod " + comId);
		boolean deleted = false;

		Session session = null;
		try {
			session = SessionFactoryUtil.getSession();
			session.beginTransaction();
			CommunicationModel model = (CommunicationModel) session.get(CommunicationModel.class, new Long(comId));
			session.delete(model);
		} catch (Exception ex) {
			session.getTransaction().rollback();
			//ex.printStackTrace();
			logger.error("Exception: " + ex.getMessage());
		} finally {
			session.close();
		}
		return deleted;
	}

	/*
	 * checks for duplicate communication type, value pairs
	 */
	public boolean checkForDuplicate(String type, String value, long orgID) {
		boolean duplicate = true;
		PreparedStatement pStmt = null;
		Connection connection = null;
		ResultSet rs = null;
		String query = "SELECT COUNT(*) FROM COMMUNICATIONMETHOD WHERE COMMUNICATIONMETHODTYPECODE=? AND VALUE=? AND ORGID <> ?";
		try {
			connection = getConnection();
			pStmt = connection.prepareStatement(query);
			pStmt.setString(1, type);
			pStmt.setString(2, value);
			pStmt.setLong(3, orgID);

			rs = pStmt.executeQuery();
			rs.next();
			int count = rs.getInt(1);
			logger.debug("Found " + count + " existing type/values in COMMUNICATIONMETHOD.");
			if (count < 1)
				duplicate = false;

			rs.close();
			pStmt.close();
			connection.close();
		} catch (Exception ex) {
			//logger.error(ex.getMessage());
			//ex.printStackTrace();
			logger.error("Exception: " + ex.getMessage());
		} finally {
			ConnectionUtil.closeResources(connection, pStmt, rs);
		}

		return duplicate;
	}
}
