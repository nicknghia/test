package com.freightdesk.fdfolio.orghierarchy;

import crt.com.freightdesk.fdfolio.orghierarchy.OrgOrgAssocValidator;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.sf.json.JSONArray;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.ActionErrors;
import com.freightdesk.fdcommons.ActionMessage;

import com.freightdesk.fdfolio.addressbook.model.OrganizationChartModel;
import com.freightdesk.fdfolio.dao.OrghierarchyDAO;
import crt.com.freightdesk.fdfolio.event.FasEventUtil;

import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;

import crt.com.freightdesk.fdfolioweb.orghierarchy.form.OrgAssocForm;
import crt.com.freightdesk.fdfolioweb.orghierarchy.form.OrgReferenceForm;
import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.Credentials;
import crt.com.ntelx.nxcommons.NxUtils;
import com.freightdesk.fdcommons.OptionBean;
import crt.com.ntelx.nxcommons.email.EmailUtil;
import crt.com.ntelx.nxcommons.reporting.OptionCollectionManager;
import com.freightdesk.fdfolioweb.orghierarchy.action.OrghierarchyAction.OrgFormFieldBean;

public class OrghierarchyManager {

    private Logger logger = Logger.getLogger(OrghierarchyManager.class);
    OrghierarchyDAO orgDAO = new OrghierarchyDAO();
    OptionCollectionManager optionManager = OptionCollectionManager.getInstance();

    public OrganizationChartModel getChartModel(long orgId, String parentOrgStr) {
        OrganizationChartModel model = null;
        long parentOrgId = 0L;

        try {
            parentOrgId = Long.parseLong(parentOrgStr);
        } catch (Exception ex) {
        }

        long orgIdToLookup = 0L;

        // the orgId will be zero if its a new org.  If so, then show the tree for the parent Org.
        if (orgId > 0) {
            orgIdToLookup = orgId;
        } else if (parentOrgId > 0) {
            orgIdToLookup = parentOrgId;
        }

        try {
            model = orgDAO.getOrganizationChart(orgIdToLookup);
        } catch (Exception ex) {
            
			logger.error("Exception - Failed to get chart model for Returning null: " + ex.getMessage());
        }
        return model;
    }

    public OrghierarchyModel prepareNewModel(String type, Credentials credentials) {
        logger.debug("Preparing NEW " + type + " model");
        
        OrghierarchyModel model = new OrghierarchyModel();

        model.setOrgHierarchyTypeCode(type);

        // no division by DomainName in FAS
        
        model.setDomainName(com.freightdesk.fdcommons.GlobalConstants.FAS_DOMAIN);
        model.setCreateUserId(credentials.getUserId());
        model.setLastUpdateUserId(credentials.getUserId());
        logger.info("prepareNewModel credentials.getUserId() " + credentials.getUserId());
        logger.info("prepareNewModel setLastUpdateUserId credentials.getUserId() " + credentials.getUserId());

        Timestamp now = new Timestamp(System.currentTimeMillis());
        model.setCreateTimestamp(now);
        model.setLastUpdateTimestamp(now);
        logger.info("prepareNewModel createTimestamp " + now);
        logger.info("prepareNewModel lastUpdateTimestamp " + now);

        return model;
    }

    public void setOptionLists(OrgFormFieldBean form) {
        form.setRoleList(optionManager.getCollection("orgRoleList"));
        form.setCountryList(optionManager.getCollection("countryList"));
        form.setRefTypeList(optionManager.getCollection("refTypeList"));
        form.setTitleList(optionManager.getCollection("titleList"));
        form.setRegionList(optionManager.getCollection("regionList"));
        form.setEventTypeList(optionManager.getCollection("orgEventList"));
        form.setOrgAssocTypeList(optionManager.getCollection("orgAssocTypeList"));
        form.setOrgApAcAssocTypeList(optionManager.getCollection("orgOrgApAcAssocTypeList"));


        List<OptionBean> parentOrgList = orgDAO.getParentOrgOptions(form.getOrgHierarchyTypeCode(), form.getOrgId());
        JSONArray jsonArray = JSONArray.fromObject(parentOrgList);

        form.setParentJsArray(jsonArray.toString());

        // set association list.  For profiles its a list of locations.  For organizations its a list of other organizations
        List<OptionBean> assocOptions = new ArrayList<OptionBean>();

        if (form.getOrgHierarchyTypeCode().equalsIgnoreCase("CON")) {
            assocOptions = orgDAO.retrieveAddFacilityList(form.getParentOrgId(), form.getOrgRoleCode());
        }

        if (form.getOrgHierarchyTypeCode().equalsIgnoreCase("ORG")) {
            assocOptions = orgDAO.retrievePossiblePartners(form.getOrgRoleCode(), form.getOrgHierarchyTypeCode(), form.getOrgId());
        }
        
        if (form.getOrgRoleCode().equalsIgnoreCase("CAR") && form.getOrgHierarchyTypeCode().equalsIgnoreCase("ORG")) {
            assocOptions = optionManager.getCollection("orgOrgApAcAssocOrgList");
        }

        jsonArray = JSONArray.fromObject(assocOptions);

        form.setAssocJsArray(jsonArray.toString());

    }

    public ActionErrors validate(OrgFormFieldBean form) {
        ActionErrors errors = new ActionErrors();
        String typeCode = form.getOrgHierarchyTypeCode();
        
        logger.debug("validate executing ");

        if (typeCode.equalsIgnoreCase("CON")) {
            logger.debug("validate CON executing ");
            errors = validateContact(form);
        } else if (typeCode.equalsIgnoreCase("LOC")) {
            logger.debug("validate LOC executing ");
            errors = validateLocation(form);
        } else if (typeCode.equalsIgnoreCase("ORG")) {
            logger.debug("validate ORG executing ");
            errors = validateOrganization(form);
        } else if (typeCode.equalsIgnoreCase("AIRPT")) {
            logger.debug("validate AIRPT executing ");
            errors = validateAirport(form);
        } else {
            logger.debug("Did not validate form");
            logger.warn("Did not validate form");
        }


        
        logger.debug("Caught " + errors.size() + " validation errors");
        return errors;
    }

    public ActionErrors validateContact(OrgFormFieldBean form) {
        logger.debug("Validating contact form");
        
        ActionErrors errors = new ActionErrors();

        // make sure last name is entered
        if (NxUtils.isEmptyOrBlank(form.getContactLastName())) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Last name is required."));
        }

        // make sure first name is entered
        if (NxUtils.isEmptyOrBlank(form.getContactFirstName())) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "First name is required."));
        }

        // parentorg
        HashMap<Integer, Object> param = new HashMap<Integer, Object>();
        param.put(1, form.getParentOrgId());
        long orgId = new BaseDao().executeQuery_long("select orgid from fd.orghierarchy where orgid=?", param);
        if (orgId < 0) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Parent entity must be selected."));
        }

        // validate that the email is entered and unique
        OrghierarchyDAO orgDAO = new OrghierarchyDAO();
        String email = form.getEmail().toUpperCase();
        if (email.trim().equalsIgnoreCase("")) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Email is required."));
        } else {
            // regex check on email
            boolean valid = EmailUtil.isValidEmail(email);

            if (valid) {
                boolean isDuplicate = orgDAO.checkForDuplicateEmail(email, form.getOrgId());
                if (isDuplicate) {
                    errors.add("error.filecontent", new ActionMessage("error.file.content", "A profile with an email of " + email + " already exists."));
                }
            } else {
                errors.add("error.filecontent", new ActionMessage("error.file.content", email + " is not a valid email address.  Please check the spelling."));
            }
        }

        // make sure phone number was entered
        if (NxUtils.isEmptyOrBlank(form.getPhone())) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "A profile phone number is required."));
        } else if (!isValidPhone(form.getPhone())) {
        	errors.add("error.filecontent", new ActionMessage("error.file.content", "A Profile phone number format is invalid."
                    + "  (Only numerical values, +, -,and space are allowed. 15 character maximum.)"));
        }

        // orgrolecode
        if (NxUtils.isEmptyOrBlank(form.getOrgRoleCode())) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Please select a profile role."));
        }

        // is there an exact duplicate already in the database?
        if (errors.size() == 0) {
            if (orgDAO.checkDuplicateOrgHierarchy(form.getOrgId(), "CON", form.getOrgRoleCode(), form.getOrgName(), form.getContactFirstName(), form.getContactLastName())) {
                errors.add("error.filecontent", new ActionMessage("error.file.content", "A entity with this name and type already exists in the system."));
            }
        }
        errors.add(validateReferences(form.getOrgRefs(), form.getOrgHierarchyTypeCode()));

        

        return errors;
    }

    public ActionErrors validateLocation(OrgFormFieldBean form) {
        logger.debug("Validating location form");
        
        ActionErrors errors = new ActionErrors();

        // orgname
        if (NxUtils.isEmptyOrBlank(form.getOrgName())) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Location name is required."));
        }

        // parentorg
        HashMap<Integer, Object> param = new HashMap<Integer, Object>();
        param.put(1, form.getParentOrgId());
        long orgId = new BaseDao().executeQuery_long("select orgid from orghierarchy where orgid=?", param);
        if (orgId < 0) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Parent entity must be selected."));
        }

        // orgrolecode
        if (NxUtils.isEmptyOrBlank(form.getOrgRoleCode())) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Please select a location role."));
        }

        // countrycode
        if (NxUtils.isEmptyOrBlank(form.getCountryCode())) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Country must be selected."));
        }

        // is there an exact duplicate already in the database?
        if (errors.size() == 0) {
            if (orgDAO.checkDuplicateOrgHierarchy(form.getOrgId(), "LOC", form.getOrgRoleCode(), form.getOrgName(), "", "")) {
                errors.add("error.filecontent", new ActionMessage("error.file.content", "A entity with this name and type already exists in the system."));
            }
        }

        // validate orgReferences
        errors.add(validateReferences(form.getOrgRefs(), form.getOrgHierarchyTypeCode()));

        
        
        return errors;
    }

    private ActionErrors validateOrganization(OrgFormFieldBean form) {
        logger.debug("Validating Organization form");
        
        ActionErrors errors = new ActionErrors();

        // orgname
        if (NxUtils.isEmptyOrBlank(form.getOrgName())) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Organization name is required."));
        }

        // orgrolecode
        if (NxUtils.isEmptyOrBlank(form.getOrgRoleCode())) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Please select an organization role."));
        }

        // countrycode
        if (NxUtils.isEmptyOrBlank(form.getCountryCode())) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Country must be selected."));
        }

        if (errors.size() == 0) {
            // is there an exact duplicate already in the database?
            if (orgDAO.checkDuplicateOrgHierarchy(form.getOrgId(), "ORG", form.getOrgRoleCode(), form.getOrgName(), "", "")) {
                errors.add("error.filecontent", new ActionMessage("error.file.content", "A entity with this name and type already exists in the system."));
            }
        }

        // validate references
        errors.add(validateReferences(form.getOrgRefs(), form.getOrgHierarchyTypeCode()));

        
        
        return errors;
    }

    public ActionErrors validateAirport(OrgFormFieldBean form) {
        logger.debug("Validating airport form");
        
        
        ActionErrors errors = new ActionErrors();

        // orgname
        if (NxUtils.isEmptyOrBlank(form.getOrgName())) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Airport name is required."));
        }

        // port code
        if (NxUtils.isEmptyOrBlank(form.getPortCode())) {
            errors.add("error.filecontent", new ActionMessage("error.file.content", "Port Code is required."));
        }

        // is there an exact duplicate already in the database?
        if (errors.size() == 0) {
            if (orgDAO.checkDuplicateOrgHierarchy(form.getOrgId(), "AIRPT", form.getOrgRoleCode(), form.getOrgName(), form.getContactFirstName(), form.getContactLastName())) {
                errors.add("error.filecontent", new ActionMessage("error.file.content", "A entity with this name and type already exists in the system."));
            }
            
            
            logger.info("form.getContext()" + form.getContext());
            if ((form.getContext() != null) && (!(form.getContext().equalsIgnoreCase("EDIT")))) {
                    
                if (orgDAO.checkDuplicatePortCode(form.getPortCode())) {
                    errors.add("error.filecontent", new ActionMessage("error.file.content", "A entity with this port code already exists in the system."));
                }
            }
        }

        errors.add(validateReferences(form.getOrgRefs(), form.getOrgHierarchyTypeCode()));

        return errors;
    }


    private ActionErrors validateAssociations(List<OrgAssocForm> assocList, long orgId) {
        logger.debug("Valdating associations");
        ActionErrors errors = new ActionErrors();

        int row = 1;
        for (OrgAssocForm assocForm : assocList) {
            String type = assocForm.getRelationShipType();

            if (NxUtils.isEmptyOrBlank(type)) {
                errors.add("error.filecontent", new ActionMessage("error.file.content", "Associations must have a relationship type selected. (" + row + ")"));
            }

            if (NxUtils.isEmptyOrBlank(assocForm.getDestOrgId())) {
                errors.add("error.filecontent", new ActionMessage("error.file.content", "Associations must have another entity/organization name selected. (" + row + ")"));
            }

            row++;
        }
        return errors;
    }

    private ActionErrors validateReferences(List<OrgReferenceForm> orgRefs, String orgHierarchyTypeCode) {
        logger.debug("Validating references");
        ActionErrors errors = new ActionErrors();
        boolean isDuplicate;
        boolean isWrongFormat;

        int row = 1;
        for (OrgReferenceForm refForm : orgRefs) {
            String refValue = refForm.getRefValue();
            String refType = refForm.getRefType();
            String refId = refForm.getRefId();

            if (NxUtils.isEmptyOrBlank(refValue)) {
                errors.add("error.filecontent", new ActionMessage("error.file.content", "References must have a value. (" + row + ")"));
            }

            if (refType.equalsIgnoreCase("CRTNM") && !orgHierarchyTypeCode.equalsIgnoreCase("LOC")) {
                errors.add("error.filecontent", new ActionMessage("error.file.content", "Only entities are allowed to have a certification number reference. (" + row + ")"));
            }

            if (refType.equalsIgnoreCase("CRTNM")) {
                // Is the cert num in the correct format?
                isWrongFormat = FasEventUtil.isWrongFormat(refValue);
                if (isWrongFormat) {
                    errors.add("error.filecontent", new ActionMessage("error.file.content", "Certfication number " + refValue
                            + " is not in the correct format.  Correct example: DCA.S.02.15.2010.123 (" + row + ")"));
                }

                // only do this lookup if there are no previous errors. Save
                // hits on the database
                if (errors.size() == 0) {
                    long refIdToCheck = 0L;
                    try {
                        refIdToCheck = Long.parseLong(refId);
                    } catch (Exception ex) {
                    }

                    isDuplicate = orgDAO.checkDuplicateReference(refType, refValue, refIdToCheck);
                    if (isDuplicate) {
                        errors.add("error.filecontent", new ActionMessage("error.file.content", "Another entity already has a certification number of " + refValue + " (" + row + ")"));
                    }
                }
            }
            row++;
        }

        return errors;
    }
   
    private static boolean isValidPhone(String phone) {

        
        if (phone == null || phone.trim().isEmpty() ) {
           return false;
}

        //valid format: 111-222-3333, 111 222 3333, 1112223333       
        String phoneRegex = "^([\\+\\-\\ 0-9]){1,15}$";
        Pattern phonePattern = Pattern.compile(phoneRegex);
        Matcher phoneMatcher = phonePattern.matcher(phone.trim());
        return phoneMatcher.matches();
    } 
}
