/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/invoice/model/DateTimestampReferenceModel.java,v 1.3.4.2 2010/08/22 23:08:31 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: DateTimestampReferenceModel.java,v $
 *  Revision 1.3.4.2  2010/08/22 23:08:31  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.3.4.1  2008/06/03 12:39:04  mechevarria
 *  gov_solutions merge updates
 *
 *  Revision 1.5  2007/04/12 05:31:03  dkumar
 *  method applyPartitionTimestamp added.
 *
 *  Revision 1.4  2007/04/11 11:59:27  nsehra
 *  added method applyPartitionTimeStamp for Data Partitioning
 *
 *  Revision 1.3  2006/03/28 21:23:01  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.2  2005/08/01 09:41:08  pjain
 *  refactored UserModel to BaseModel
 *
 *  Revision 1.1  2004/09/23 13:41:20  ranand
 *  package changed from settlement to invoice
 *
 *  Revision 1.1  2004/09/15 13:20:00  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdfolio.invoice.model;

import java.sql.Timestamp;

import com.freightdesk.fdcommons.BaseModel;

/**
 * @author biju.joseph
 *
 * To change this generated comment edit the template variable "typecomment":
 * Window>Preferences>Java>Templates.
 * To enable and disable the creation of type comments go to
 * Window>Preferences>Java>Code Generation.
 */
public class DateTimestampReferenceModel extends BaseModel {


	private long dateTimestampReferenceId;
    private String domainObjectCode;
    private long domainObjectId;
    private long invoiceId;
    private long eventId;
    private long legId;
    private long legContainerId;
    private long orderId;
    private long orderReleaseId;
    private long packageId;
    private long shipmentId;
    private long invoiceDetailId;
    private long invoiceLineItemId;
    private String dateTimestampReferenceTypeCode;
    private String dateTimestampReferenceQualifier;
    private Timestamp dateTimestampReferenceValue;


	/**
	 * Constructor for DateTimestampReferenceModel.
	 */
	public DateTimestampReferenceModel(

		long dateTimestampReferenceId,
	    String domainObjectCode,
		long domainObjectId,
		long invoiceId,
		long eventId,
		long legId,
		long legContainerId,
		long orderId,
		long orderReleaseId,
		long packageId,
		long shipmentId,
		String dateTimestampReferenceTypeCode,
		Timestamp dateTimestampReferenceValue,
	    String dateTimestampReferenceQualifer,
	    String status,
		String createUserId,
		Timestamp createTimestamp,
		String lastUpdateUserId,
		Timestamp lastUpdateTimestamp,
		String domainName) {

		super(
			createUserId,
			createTimestamp,
			lastUpdateUserId,
			lastUpdateTimestamp,
			domainName);

		this.dateTimestampReferenceId = dateTimestampReferenceId;
		this.domainObjectId = domainObjectId;
		this.invoiceId = invoiceId;
		this.eventId = eventId;
		this.legId = legId;
		this.legContainerId = legContainerId;
		this.orderId = orderId;
		this.orderReleaseId = orderReleaseId;
		this.packageId = packageId;
		this.shipmentId = shipmentId;
		this.domainObjectCode = domainObjectCode;
		this.dateTimestampReferenceTypeCode = dateTimestampReferenceTypeCode;
		this.dateTimestampReferenceQualifier = dateTimestampReferenceQualifer;
		this.dateTimestampReferenceValue = dateTimestampReferenceValue;
		this.status = status;
	}

	/**
	 * Constructor for DateTimestampReference.
	 */
	public DateTimestampReferenceModel() {
		super();
	}

	/**
	com.freightdesk.fdfolio.utilesk.fdfolio.util.UserModel#getPrimaryKey()
	 */
	public long getPrimaryKey() {
		return dateTimestampReferenceId;
	}

	/**
	 * Returns the dateTimestampReferenceValue.
	 * @return Timestamp
	 */
	public Timestamp getDateTimestampReferenceValue() {
		return dateTimestampReferenceValue;
	}

	/**
	 * Returns the dateTimestampReferenceId.
	 * @return long
	 */
	public long getDateTimestampReferenceId() {
		return dateTimestampReferenceId;
	}

	/**
	 * Returns the dateTimestampReferenceQualifier.
	 * @return String
	 */
	public String getDateTimestampReferenceQualifier() {
		return dateTimestampReferenceQualifier;
	}

	/**
	 * Returns the dateTimestampReferenceTypeCode.
	 * @return String
	 */
	public String getDateTimestampReferenceTypeCode() {
		return dateTimestampReferenceTypeCode;
	}

	/**
	 * Returns the domainObjectCode.
	 * @return String
	 */
	public String getDomainObjectCode() {
		return domainObjectCode;
	}

	/**
	 * Returns the domainObjectId.
	 * @return long
	 */
	public long getDomainObjectId() {
		return domainObjectId;
	}

	/**
	 * Returns the eventId.
	 * @return long
	 */
	public long getEventId() {
		return eventId;
	}

	/**
	 * Returns the invoiceId.
	 * @return long
	 */
	public long getInvoiceId() {
		return invoiceId;
	}

	/**
	 * Returns the legContainerId.
	 * @return long
	 */
	public long getLegContainerId() {
		return legContainerId;
	}

	/**
	 * Returns the legId.
	 * @return long
	 */
	public long getLegId() {
		return legId;
	}

	/**
	 * Returns the orderId.
	 * @return long
	 */
	public long getOrderId() {
		return orderId;
	}

	/**
	 * Returns the orderReleaseId.
	 * @return long
	 */
	public long getOrderReleaseId() {
		return orderReleaseId;
	}

	/**
	 * Returns the packageId.
	 * @return long
	 */
	public long getPackageId() {
		return packageId;
	}

	/**
	 * Returns the shipmentId.
	 * @return long
	 */
	public long getShipmentId() {
		return shipmentId;
	}

	/**
	 * Sets the dateTimestampReferenceValue.
	 * @param dateTimestampReferenceValue The dateTimestampReferenceValue to set
	 */
	public void setDateTimestampReferenceValue(Timestamp dateTimestampReferenceValue) {
		this.dateTimestampReferenceValue = dateTimestampReferenceValue;
	}

	/**
	 * Sets the dateTimestampReferenceId.
	 * @param dateTimestampReferenceId The dateTimestampReferenceId to set
	 */
	public void setDateTimestampReferenceId(long dateTimestampReferenceId) {
		this.dateTimestampReferenceId = dateTimestampReferenceId;
	}

	/**
	 * Sets the dateTimestampReferenceQualifer.
	 * @param dateTimestampReferenceQualifer The dateTimestampReferenceQualifer to set
	 */
	public void setDateTimestampReferenceQualifier(String dateTimestampReferenceQualifier) {
		this.dateTimestampReferenceQualifier = dateTimestampReferenceQualifier;
	}

	/**
	 * Sets the dateTimestampReferenceTypeCode.
	 * @param dateTimestampReferenceTypeCode The dateTimestampReferenceTypeCode to set
	 */
	public void setDateTimestampReferenceTypeCode(String dateTimestampReferenceTypeCode) {
		this.dateTimestampReferenceTypeCode = dateTimestampReferenceTypeCode;
	}

	/**
	 * Sets the domainObjectCode.
	 * @param domainObjectCode The domainObjectCode to set
	 */
	public void setDomainObjectCode(String domainObjectCode) {
		this.domainObjectCode = domainObjectCode;
	}

	/**
	 * Sets the domainObjectId.
	 * @param domainObjectId The domainObjectId to set
	 */
	public void setDomainObjectId(long domainObjectId) {
		this.domainObjectId = domainObjectId;
	}

	/**
	 * Sets the eventId.
	 * @param eventId The eventId to set
	 */
	public void setEventId(long eventId) {
		this.eventId = eventId;
	}

	/**
	 * Sets the invoiceId.
	 * @param invoiceId The invoiceId to set
	 */
	public void setInvoiceId(long invoiceId) {
		this.invoiceId = invoiceId;
	}

	/**
	 * Sets the legContainerId.
	 * @param legContainerId The legContainerId to set
	 */
	public void setLegContainerId(long legContainerId) {
		this.legContainerId = legContainerId;
	}

	/**
	 * Sets the legId.
	 * @param legId The legId to set
	 */
	public void setLegId(long legId) {
		this.legId = legId;
	}

	/**
	 * Sets the orderId.
	 * @param orderId The orderId to set
	 */
	public void setOrderId(long orderId) {
		this.orderId = orderId;
	}

	/**
	 * Sets the orderReleaseId.
	 * @param orderReleaseId The orderReleaseId to set
	 */
	public void setOrderReleaseId(long orderReleaseId) {
		this.orderReleaseId = orderReleaseId;
	}

	/**
	 * Sets the packageId.
	 * @param packageId The packageId to set
	 */
	public void setPackageId(long packageId) {
		this.packageId = packageId;
	}

	/**
	 * Sets the shipmentId.
	 * @param shipmentId The shipmentId to set
	 */
	public void setShipmentId(long shipmentId) {
		this.shipmentId = shipmentId;
	}

    /**
     * @return invoiceDetailId
     */
    public long getInvoiceDetailId() {
        return this.invoiceDetailId;
    }

    /**
     * @param invoiceDetailId
     */
    public void setInvoiceDetailId(long invoiceDetailId) {
        this.invoiceDetailId = invoiceDetailId;
    }

	/**
	 * Returns the invoiceLineItemId.
	 * @return long
	 */
	public long getInvoiceLineItemId() {
		return invoiceLineItemId;
	}

	/**
	 * Sets the invoiceLineItemId.
	 * @param invoiceLineItemId The invoiceLineItemId to set
	 */
	public void setInvoiceLineItemId(long invoiceLineItemId) {
		this.invoiceLineItemId = invoiceLineItemId;
	}
	
}
