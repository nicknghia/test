/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/shipmentinspection/mappings/ImageReportObjectMapping.java,v 1.2.10.1 2010/08/22 23:08:24 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: ImageReportObjectMapping.java,v $
 *  Revision 1.2.10.1  2010/08/22 23:08:24  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.2  2004/09/21 08:44:31  ranand
 *  package of Manager classes  changed from folioweb to folio
 *
 *  Revision 1.1  2004/09/15 13:13:41  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdfolio.shipmentinspection.mappings;
/**
 * CommercialInvoiceXMLItem provides model object for items in commercial invoice document.
 * 
 * @author Sangeeta Taneja
 */

import java.util.ArrayList;
import java.util.List;

/*
	 <class name="com.freightdesk.fdfolio.legcontainer.mappings.ImageReportRootObject">
		<map-to xml="IMAGEREPORT"/>
		 <field name="childObject" type="com.freightdesk.fdfolio.legcontainer.mappings.ImageObject" collection="collection">
			<bind-xml name="IMAGE" node="element"/>
		</field>
		<field name="inspectionReportId">
		    	<bind-xml name="INSPECTIONREPORTID" node="element"/>
		    </field>
	</class> 
*/
    
public class ImageReportObjectMapping  {
   
    private List childObject;
    private String inspectionReportId;
    /**
     * @return
     */

     public ImageReportObjectMapping()
     {
         this.childObject = new ArrayList();
     }

    public List getChildObject() {
        return childObject;
    }

    /**
     * @return inspectionReportId
     */
    public String getInspectionReportId() {
        return this.inspectionReportId;
    }

    /**
     * @param childObject
     */
    public void setChildObject(List childObject) {
        this.childObject = childObject;
    }

    /**
     * @param inspectionReportId
     */
    public void setInspectionReportId(String inspectionReportId) {
        this.inspectionReportId = inspectionReportId;
    }
}
   
