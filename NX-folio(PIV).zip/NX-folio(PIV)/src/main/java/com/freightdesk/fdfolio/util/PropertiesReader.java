/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/util/PropertiesReader.java,v 1.1.10.1 2010/08/22 23:08:34 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: PropertiesReader.java,v $
 *  Revision 1.1.10.1  2010/08/22 23:08:34  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdfolio.util;

import java.util.Locale;
import java.util.ResourceBundle;

/**
 * PropertiesReader is used to read properties from a property file. It uses ResourceBundle.
*/
public class PropertiesReader
{
    private Locale locale;
    private String propertiesFile;
    private ResourceBundle resourceBundle;

    public PropertiesReader(String propertiesFile, Locale locale)
    {
        this.setLocale(locale);
        this.setPropertiesFile(propertiesFile);
        this.setResourceBundle(
            ResourceBundle.getBundle(this.getPropertiesFile(), this.getLocale()));
    }

    public PropertiesReader(String propertiesFile)
    {
        this(propertiesFile, Locale.getDefault());
    }

    public PropertiesReader()
    {
    }

    public void setLocale(Locale locale)
    {
        this.locale = locale;
    }

    public Locale getLocale()
    {
        return this.locale;
    }

    public void setPropertiesFile(String propertiesFile)
    {
        this.propertiesFile = propertiesFile;
    }

    public String getPropertiesFile()
    {
        return this.propertiesFile;
    }

    public void setResourceBundle(ResourceBundle resourceBundle)
    {
        this.resourceBundle = resourceBundle;
    }

    public ResourceBundle getResourceBundle()
    {
        return this.resourceBundle;
    }

    public String getProperty(String propertyName)
    {
        String propertyValue = this.getResourceBundle().getString(propertyName);
        return propertyValue;
    }
}
