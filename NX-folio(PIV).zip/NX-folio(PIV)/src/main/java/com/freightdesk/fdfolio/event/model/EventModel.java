/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/event/model/EventModel.java,v 1.8.4.19 2010/08/22 23:08:38 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: EventModel.java,v $
 *  Revision 1.8.4.19  2010/08/22 23:08:38  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.8.4.18  2010/04/14 19:44:25  jhansford
 *  Made adjustments for 75% level, and alt category for IACs
 *
 *  Revision 1.8.4.17  2009/10/22 20:10:52  mechevarria
 *  add create and edit user
 *
 *  Revision 1.8.4.16  2009/09/14 21:17:42  jhansford
 *  no message
 *
 *  Revision 1.8.4.15  2009/09/02 19:34:48  jhansford
 *  Changes for UAT on 9/3/2009
 *
 *  Revision 1.8.4.14  2009/08/28 18:18:12  mechevarria
 *  additional validation and tracking updates
 *
 *  Revision 1.8.4.13  2009/08/27 15:11:45  mechevarria
 *  todo cleanup
 *
 *  Revision 1.8.4.12  2009/04/21 13:49:12  mechevarria
 *  updates from GS to be compatible with latest version of FDfusion
 *
 *  Revision 1.8.4.11  2009/04/14 18:33:59  jhansford
 *  Added False Alarm field to web form and file upload
 *
 *  Revision 1.8.4.10  2009/03/10 13:21:33  mechevarria
 *  remove comprate
 *
 *  Revision 1.8.4.9  2009/03/05 16:56:06  mechevarria
 *  added iacsp attributes
 *
 *  Revision 1.8.4.8  2009/03/05 16:07:12  jhansford
 *  CompRate added
 *
 *  Revision 1.8.4.7  2009/02/10 21:51:58  mechevarria
 *  dev update
 *
 *  Revision 1.8.4.6  2009/02/09 19:49:04  mechevarria
 *  development update
 *
 *  Revision 1.8.4.5  2009/02/09 18:45:41  mechevarria
 *  proper names for carrier and airport id
 *
 *  Revision 1.8.4.4  2009/01/30 15:34:57  mechevarria
 *  additional field for eventcategoryname
 *
 *  Revision 1.8.4.3  2008/12/18 20:29:51  mechevarria
 *  additional updates for the eventhomepage and industry reporting modifications
 *
 *  Revision 1.8.4.2  2008/06/18 13:44:33  mechevarria
 *  updates from HEAD to fix security devices and complete new event types of SCR and COC
 *
 */

package com.freightdesk.fdfolio.event.model;

import java.io.Serializable;
import java.math.BigInteger;
import java.sql.Timestamp;
import java.text.DecimalFormat;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.persistence.Transient;

import org.hibernate.annotations.Type;

import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;
import com.freightdesk.fdcommons.BaseModel;
import com.freightdesk.fdcommons.FormatDate;

/**
 * EventModel associated with EventDao and ShipmentEventAction. This class is a
 * Value Object to transfer the data from presentation layer to the Database.
 * 
 * @author Mike Echevarria
 */

@Entity
@Table(name="FD.EVENT")
public class EventModel extends BaseModel implements Serializable {

	private static final long serialVersionUID = 1L;
	private static String defaultFormat = "MM/dd/yyyy";
	
	@Id @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="EVENTID")
	@SequenceGenerator(name="EVENTID", sequenceName = "EVENTID")
	private long eventId;

	@Column(nullable=false)
	private String eventTypeCode;
	private String version;
	private String remarks;

	@Column(nullable=false)
	private String eventCategoryCode;

	/* Event Date,Time */
	private Timestamp eventDateTime;
	private Timestamp eventEndDateTime;
	private String eventDateTimeZone;

	private String flagLate;
	private String flagUnlock;
	private String flagScreen;
	private String flagVarW;
	private String flagVarA;
	
	private Double totalWgt = 0.0;
	private Integer totalAwb = 0;
	private Double screenWgt = 0.0;
	private Integer screenAwb = 0;
	private Double altWgt = 0.0;
	private Integer altAwb = 0;
	private Double recvdWgt = 0.0;
	private Double partScreenWgt = 0.0;
	private Integer partScreenAwb = 0;
	
	@Column(name="airport") @Type(type="java.math.BigInteger")
	private BigInteger airportOrgId;
	
	@ManyToOne @JoinColumn(name="location")
	private OrghierarchyModel orghierarchy;
	
	@Transient
	private String airportName;
	
	@Column(name="carrier") @Type(type="java.math.BigInteger")
	private BigInteger carrierOrgId;
	
	@Transient
	private String carrierName;
	
	@Transient
	private String eventTypeName;
	
	@Transient
	private String eventCategoryName;
	private String certNum;
	
	@Transient
	private String companyName;
	
	public EventModel() {
		domainName = "";
		lastUpdateUserId = "";
		createUserId = "";
	}

	public double getTotalWgt() {
		if(totalWgt == null)
		  return 0.0;
		else
		  return Double.valueOf(new DecimalFormat("#.##").format(totalWgt));
	}

	public void setTotalWgt(double totalWgt) {
		this.totalWgt = totalWgt;
	}

	public int getTotalAwb() {
		if(totalAwb == null)
		  return 0;
		else
		  return totalAwb;
	}

	public void setTotalAwb(int totalAwb) {
		this.totalAwb = totalAwb;
	}

	public double getScreenWeight() {
		if(screenWgt == null)
		  return 0.0;
		else
		  return Double.valueOf(new DecimalFormat("#.##").format(screenWgt));
	}

	public void setScreenWeight(double screenWgt) {
		this.screenWgt = screenWgt;
	}

	public int getScreenAwb() {
		if(screenAwb == null)
			return 0;
		else
		  return screenAwb;
	}

	public void setScreenAwb(int screenAwb) {
		this.screenAwb = screenAwb;
	}

	public double getAltWgt() {
		if(altWgt == null)
		  return 0.0;
		else
		  return Double.valueOf(new DecimalFormat("#.##").format(altWgt));
	}

	public void setAltWgt(double altWgt) {
		this.altWgt = altWgt;
	}

	public int getAltAwb() {
		if(altAwb == null)
		  return 0;
		else
		  return altAwb;
	}

	public void setAltAwb(int altAwb) {
		this.altAwb = altAwb;
	}

	public double getRecvdWgt() {
		if(recvdWgt == null)
		  return 0.0;
		else
		  return Double.valueOf(new DecimalFormat("#.##").format(recvdWgt));
	}

	public void setRecvdWgt(double recvdWgt) {
		this.recvdWgt = recvdWgt;
	}

	public double getPartScreenWgt() {
		if(partScreenWgt == null)
		  return 0.0;
		else
		  return Double.valueOf(new DecimalFormat("#.##").format(partScreenWgt));
	}

	public void setPartScreenWgt(double partScreenWgt) {
		this.partScreenWgt = partScreenWgt;
	}

	public int getPartScreenAwb() {
		if(partScreenAwb == null)
		  return 0;
		else
		  return partScreenAwb;
	}

	public void setPartScreenAwb(int partScreenAwb) {
		this.partScreenAwb = partScreenAwb;
	}

	public String getFlagVarW() {
		if(flagVarW == null)
			return "";
		else
			return flagVarW;
	}

	public void setFlagVarW(String flagVarW) {
		this.flagVarW = flagVarW;
	}

	public String getFlagVarA() {
		if(flagVarA == null)
			return "";
		else
			return flagVarA;
	}

	public void setFlagVarA(String flagVarA) {
		this.flagVarA = flagVarA;
	}

	public String getFlagUnlock() {
		if(flagUnlock == null)
			return "";
		else
			return flagUnlock;
	}

	public void setFlagUnlock(String flagUnlock) {
		this.flagUnlock = flagUnlock;
	}

	public String getFlagScreen() {
		return flagScreen;
	}

	public void setFlagScreen(String flagScreen) {
		this.flagScreen = flagScreen;
	}

	public OrghierarchyModel getOrghierarchy() {
		return orghierarchy;
	}

	public void setOrghierarchy(OrghierarchyModel orghierarchy) {
		this.orghierarchy = orghierarchy;
	}

	public String getEventCategoryCode() {
		return eventCategoryCode;
	}

	public void setEventCategoryCode(String eventCategoryCode) {
		this.eventCategoryCode = eventCategoryCode;
	}

	public Timestamp getEventDateTime() {
		return eventDateTime;
	}

	public void setEventDateTime(Timestamp eventDateTime) {
		this.eventDateTime = eventDateTime;
	}

	public Timestamp getEventEndDateTime() {
		return eventEndDateTime;
	}

	public void setEventEndDateTime(Timestamp eventEndDateTime) {
		this.eventEndDateTime = eventEndDateTime;
	}

	public String getCompanyName() {
		return companyName;
	}

	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	public String getCertNum() {
		return certNum;
	}

	public void setCertNum(String certnum) {
		this.certNum = certnum;
	}

	public String getFormatEventDateTime() {
		String inFormat = FormatDate.format(eventDateTime, defaultFormat);
		return inFormat;
	}

	public String getFormatEventEndDateTime() {
		String inFormat = FormatDate.format(eventEndDateTime, defaultFormat);
		return inFormat;
	}

	public String getEventCategoryName() {
		return eventCategoryName;
	}

	public void setEventCategoryName(String eventCategoryName) {
		this.eventCategoryName = eventCategoryName;
	}

	public String getEventTypeName() {
		return eventTypeName;
	}

	public void setEventTypeName(String eventTypeName) {
		this.eventTypeName = eventTypeName;
	}

	public String getAirportName() {
		return airportName;
	}

	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}

	public String getCarrierName() {
		return carrierName;
	}

	public void setCarrierName(String carrierName) {
		this.carrierName = carrierName;
	}

	/**
	 * Implements the abstract method defined by BaseModel.
	 * 
	 * @return primaryKey the unique id key for this model object.
	 */
	public long getPrimaryKey() {
		return this.eventId;
	}

	// Get/Set Method added for new variables
	public void setVersion(String version) {
		this.version = version;
	}

	public String getVersion() {
		if(version == null)
			return "";
		return version;
	}

	public String getFlagLate() {
		if (flagLate == null)
			flagLate = "";
		return flagLate;
	}

	public String getEventTypeCode() // TBR later
	{
		if (eventTypeCode == null)
			eventTypeCode = "";
		return eventTypeCode;
	}

	public String getRemarks() {
		if (remarks == null)
			remarks = "";
		return remarks;
	}

	public long getShipmentEventId() // TBR later
	{
		return eventId;
	}

	public long getEventId() {
		return eventId;
	}

	public void setFlagLate(String flagLate) {
		this.flagLate = flagLate;
	}

	public void setEventTypeCode(String eventTypeCode) {
		this.eventTypeCode = eventTypeCode;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public void setShipmentEventId(long eventId) {
		this.eventId = eventId;
	}

	public void setEventId(long eventId) {
		this.eventId = eventId;
	}

	/**
	 * @return eventDateTimeZone
	 */
	public String getEventDateTimeZone() {
		return eventDateTimeZone;
	}

	/**
	 * @param argEventDateTimeZone
	 */
	public void setEventDateTimeZone(String argEventDateTimeZone) {
		eventDateTimeZone = argEventDateTimeZone;
	}

	public BigInteger getAirportOrgId() {
		return airportOrgId;
	}

	public void setAirportOrgId(BigInteger airportOrgId) {
		this.airportOrgId = airportOrgId;
	}

	public BigInteger getCarrierOrgId() {
		return carrierOrgId;
	}

	public void setCarrierOrgId(BigInteger carrierOrgId) {
		this.carrierOrgId = carrierOrgId;
	}

}
