/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/communication/model/CommunicationModel.java,v 1.5.4.3 2010/08/22 23:08:40 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: CommunicationModel.java,v $
 *  Revision 1.5.4.3  2010/08/22 23:08:40  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.5.4.2  2009/10/05 20:09:13  mechevarria
 *  fix to make email required
 *
 *  Revision 1.5.4.1  2008/06/03 12:39:05  mechevarria
 *  gov_solutions merge updates
 *
 *  Revision 1.6  2007/04/12 05:30:34  dkumar
 *  method applyPartitionTimestamp added.
 *
 *  Revision 1.5  2006/03/28 21:23:01  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.4  2005/08/01 09:41:08  pjain
 *  refactored UserModel to BaseModel
 *
 *  Revision 1.3  2004/09/15 13:06:03  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdfolio.communication.model;

import java.io.Serializable;
import java.sql.Timestamp;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;
import com.freightdesk.fdcommons.BaseModel;

@Entity
@Table(name = "COMMUNICATIONMETHOD")
public class CommunicationModel extends BaseModel implements Serializable {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id @GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "COMMUNICATIONMETHODID")
	@SequenceGenerator(name = "COMMUNICATIONMETHODID", sequenceName = "COMMUNICATIONMETHODID")
	private long communicationMethodId;
	
	private String communicationMethodTypeCode;
	private String value;
	private String notes;
	
	@ManyToOne @JoinColumn(name="orgId")
	private OrghierarchyModel orghierarchy;

	public CommunicationModel() {
	}

	/**
	 * Implements the abstract method defined by BaseModel.
	 * 
	 * @return primaryKey the unique id key for this model object.
	 */
	public long getPrimaryKey() {
		return this.communicationMethodId;
	}

	// new one - without notifyrank
	public CommunicationModel(long communicationMethodId, String communicationMethodTypeCode, String value, String notes, String createUserId,
			Timestamp createTimestamp, String lastUpdateUserId, Timestamp lastUpdateTimestamp, String domainName) {
		this.communicationMethodId = communicationMethodId;
		this.communicationMethodTypeCode = communicationMethodTypeCode;
		this.value = value;
		// this.notifyRank = notifyRank; //TBR
		this.notes = notes;
		super.createUserId = createUserId;
		super.createTimestamp = createTimestamp;
		super.lastUpdateUserId = lastUpdateUserId;
		super.lastUpdateTimestamp = lastUpdateTimestamp;
		super.domainName = domainName;
	}

	public long getCommunicationMethodId() {
		return communicationMethodId;
	}

	public String getCommunicationMethodTypeCode() {
		if (communicationMethodTypeCode == null)
			communicationMethodTypeCode = "";
		return communicationMethodTypeCode;
	}

	public String getNotes() {
		if (notes == null)
			notes = "";
		return notes;
	}

	public String getValue() {
		if (value == null)
			value = "";
		return value.toUpperCase();
	}

	public void setCommunicationMethodId(long communicationMethodId) {
		this.communicationMethodId = communicationMethodId;
	}

	public void setCommunicationMethodTypeCode(String communicationMethodTypeCode) {
		this.communicationMethodTypeCode = communicationMethodTypeCode;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public void setValue(String value) {
		this.value = value.toUpperCase();
	}

	public OrghierarchyModel getOrghierarchy() {
		return orghierarchy;
	}

	public void setOrghierarchy(OrghierarchyModel orghierarchy) {
		this.orghierarchy = orghierarchy;
	}
}
