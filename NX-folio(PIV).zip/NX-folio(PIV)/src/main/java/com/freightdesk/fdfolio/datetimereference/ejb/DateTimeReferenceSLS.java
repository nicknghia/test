/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/datetimereference/ejb/DateTimeReferenceSLS.java,v 1.2.10.1 2010/08/22 23:08:40 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: 
 * 
 */



package com.freightdesk.fdfolio.datetimereference.ejb;

import java.rmi.RemoteException;
import java.sql.SQLException;

import javax.ejb.EJBObject;

import com.freightdesk.fdfolio.invoice.model.DateTimestampReferenceModel;


public interface DateTimeReferenceSLS  extends EJBObject
{

    /**
     * create a DateTimeStampReference.
     *
     *
     * @param dateTimestampReferenceModel The dateTimestampReference model to be saved
     * @return The DateTimestampReferenceModel that was saved
     * @throws SQLException If there is a problem accessing the DB
     */
    public abstract DateTimestampReferenceModel createDateTimeReference(DateTimestampReferenceModel dateTimestampReferenceModel)
        throws RemoteException, SQLException;


    /**
     * Update a DateTimeStampReference.
     *
     *
     * @param dateTimestampReferenceModel The dateTimestampReference model to be saved
     * @return The DateTimestampReferenceModel that was saved
     * @throws SQLException If there is a problem accessing the DB
     */
    public abstract DateTimestampReferenceModel updateDateTimeReference (DateTimestampReferenceModel dateTimestampReferenceModel)
        throws RemoteException, SQLException;


}

