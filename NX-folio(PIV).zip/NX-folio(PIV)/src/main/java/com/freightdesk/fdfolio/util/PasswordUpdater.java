/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/util/PasswordUpdater.java,v 1.3.4.2 2010/08/22 23:08:34 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: PasswordUpdater.java,v $
 *  Revision 1.3.4.2  2010/08/22 23:08:34  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.3.4.1  2008/12/11 13:56:11  mechevarria
 *  passwordhasher reference now in commons
 *
 *  Revision 1.3  2006/05/23 22:21:55  aarora
 *  Formatted the code
 *  Organized imports
 *  Removed unused variables
 *  [Trying to get to no Eclipse warnings]
 *
 *  Revision 1.2  2006/05/11 16:55:27  aarora
 *  Many changes as the SessionKey class has been added to com.freightdesk.fdfolio.commons
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdfolio.util;


import org.apache.log4j.Logger;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.freightdesk.fdcommons.PasswordHasher;


/**
 * @author nitin.gupta
 *
 * To change the template for this generated type comment go to
 * Window&gt;Preferences&gt;Java&gt;Code Generation&gt;Code and Comments
 */
public class PasswordUpdater {
                                                                                                                                   
	                                                                                                               
//	   using java.sql.{Statement, DriverManager, Connection, ResultSet,SQLEx.}                                                         
                                                                                                                                   
	/**                                                                                                                                
	 * Updates the passwords in the DB with their hashes.                                                                              
	 *                                                                                                                                 
	 * @author Amrinder Arora                                                                                                          
	 */                                                                                                                                
                                                                                           
                                                                                                                                   
		protected static Logger logger = Logger.getLogger(PasswordUpdater.class);
		
		/** Target database driver */                                                                                                  
		public static  String DBDriver = "oracle.jdbc.driver.OracleDriver";                                                       
		/** Target database IP */                                                                                                      
		public static  String IP = "192.168.20.10";                                                                               
		/** Target database port */                                                                                                    
		public static String port = "1521";                                                                                      
		/** Target database SID */                                                                                                     
		public static  String SID = "LCPDB";                                                                                      
		/** Target database userid */                                                                                                  
		public static  String user = "scott";                                                                                     
		/** Target database password */                                                                                                
		public static  String pass = "tiger";                                                                                     
                                                                                                                                   
		                                                                                                                           
		public static void main (String args[])
		{                                                                                                                              
			try {                            
				if (args.length < 5)
				{                                                                                 
				 System.out.println("USAGE IS: Java PasswordUpdater IPAddress Port SID Userid CurrentPassword");
				 //System.exit(0);
				}
				
				IP = args[0];                                                                               
						/** Target database port */                                                                                                    
				port = args[1];                                                                                      
						/** Target database SID */                                                                                                     
				SID = args[2];                                                                                      
						/** Target database userid */                                                                                                  
				user = args[3];                                                                                     
						/** Target database password */                                                                                                
				pass = args[4];                                                                                     
        		 
				 
				// load the Oracle driver by referencing it                                                                            
				 Class.forName("oracle.jdbc.OracleDriver");                                                                          
				 Class.forName(DBDriver);                                                                                               
				//System.out.println ("Ok classes loaded");                                                                              
				Connection con =  DriverManager.getConnection("jdbc:oracle:thin:@" + IP + ":" + port + ":" + SID,user,pass);
				
				PasswordHasher passwordHasher = new PasswordHasher();                         
				Statement stmt = con.createStatement();                                                                                
				ResultSet rs = stmt.executeQuery("SELECT SYSTEMUSERID, USERID, PASSWORD, PASSPHRASEHASH FROM SYSTEMUSER");                
				while (rs.next())
                {
					String systemuserid = rs.getString(1);
					String userid = rs.getString(2);
					String password = rs.getString(3);

					System.out.println ("SystemUserID: " + systemuserid + ", userID: " + userid + ", pasword " + password);

                    if ( password != null && !password.equals(""))
                    {
						String passwordHash = passwordHasher.hashPassword(password);
						Statement stmt2 = con.createStatement();
						// Create an update statement here
						 String updateSql = "UPDATE SYSTEMUSER SET PASSPHRASEHASH = '" + passwordHash + "' WHERE SYSTEMUSERID = " + systemuserid;
						// Run the update statement
						stmt2.executeUpdate (updateSql);
					}                                                                                                               
				} 
			} 
			catch (SQLException sqle) {                                                                                              
				//System.out.println ("sqle: " + sqle);                                                                                  
				//sqle.printStackTrace(); 
                logger.error("Exception : " + sqle.getMessage());			
			} catch (ClassNotFoundException cnfe) {                                                                                    
				System.out.println("Failed to load JDBC/ODBC driver.");                                                                
			} catch (Exception e) {                                                                                                    
				//e.printStackTrace(); 
                logger.error("Exception : " + e.getMessage());				
			}                                                                                                                          
		}                                                                                                                              
}                                                                                                                                  


