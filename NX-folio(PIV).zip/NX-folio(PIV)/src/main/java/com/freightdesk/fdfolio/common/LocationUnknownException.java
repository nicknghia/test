 /** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/common/LocationUnknownException.java,v 1.1.8.1 2010/08/22 23:08:26 mechevarria Exp $ 
 * 
 *  Modification History:
 *  $Log: LocationUnknownException.java,v $
 *  Revision 1.1.8.1  2010/08/22 23:08:26  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.1  2005/04/14 12:40:50  dkhoker
 *  used by Locatable Objects
 *
 */
 package com.freightdesk.fdfolio.common;

 /**
 * @author Devendra Khoker
 *
 */
public class LocationUnknownException extends RuntimeException {

	/**
	 * 
	 */
	public LocationUnknownException() {
		super();
	}

	/**
	 * @param message
	 */
	public LocationUnknownException(String message) {
		super(message);
	}

	/**
	 * @param message
	 * @param cause
	 */
	public LocationUnknownException(String message, Throwable cause) {
		super(message, cause);
	}

	/**
	 * @param cause
	 */
	public LocationUnknownException(Throwable cause) {
		super(cause);
	}
}
