/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/common/BaseManager.java,v 1.6.4.1 2010/08/22 23:08:26 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: BaseManager.java,v $
 *  Revision 1.6.4.1  2010/08/22 23:08:26  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.6  2006/03/28 21:23:00  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.5  2005/09/09 00:06:12  amrinder
 *  Added instance variable of ServiceLocator
 *
 *  Revision 1.4  2005/01/20 23:36:24  amrinder
 *  Added javadoc
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdfolio.common;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.ServiceLocator;

/**
 * An abstract base class for business logic managers.
 *
 * @author Amrinder Arora
 */
public abstract class BaseManager
{
    /** A logger */
    protected Logger logger = Logger.getLogger (getClass());

    /** An instance of service locator */
    protected ServiceLocator serviceLocator = null;

    /** Creates an instance */
    public BaseManager ()
    {
        try {
            serviceLocator = ServiceLocator.getInstance();
        } catch (Exception e) {
            logger.error("Exception creating an insance of ServiceLocator", e);
        }
    }

}

