/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/setup/model/DataSetupModel.java,v 1.4.2.1 2010/08/22 23:08:48 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: DataSetupModel.java,v $
 *  Revision 1.4.2.1  2010/08/22 23:08:48  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.4  2006/10/11 12:31:38  ranand
 *  removed dependency on SYSTEMNAVIGATIONTYPE
 *
 *  Revision 1.3  2006/03/28 21:23:01  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.2  2005/08/01 09:41:08  pjain
 *  refactored UserModel to BaseModel
 *
 *  Revision 1.1  2004/09/15 13:18:20  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdfolio.setup.model;

import java.io.Serializable;
import java.sql.Timestamp;

import com.freightdesk.fdcommons.BaseModel;

public class DataSetupModel extends BaseModel
    implements Serializable
{

    private String typeCode;
    private String typeName;
    private String dataSetupStatus;
    private String operationMode;
    private boolean isModified;

    public DataSetupModel()
    {
    }

	/**
	 * Implements the abstract method defined by BaseModel.
	 * @throws RunTimeException because no unique id key for this model object exist.
	 */
	public long getPrimaryKey(){
		throw new RuntimeException("Why do you want the primary key of a DataSetupModel?");
	}  
	
    public DataSetupModel(String typeCode, String typeName, String dataSetupStatus, String createUserId, Timestamp createTimestamp, String lastUpdateUserId, 
            Timestamp lastUpdateTimestamp, String domainName)
    {
        this.typeCode = typeCode;
        this.typeName = typeName;
        this.dataSetupStatus = dataSetupStatus;
        super.createUserId = createUserId;
        super.createTimestamp = createTimestamp;
        super.lastUpdateUserId = lastUpdateUserId;
        super.lastUpdateTimestamp = lastUpdateTimestamp;
        super.domainName = domainName;
    }

    public DataSetupModel(String typeCode, String typeName, String dataSetupStatus, String createUserId, Timestamp createTimestamp, String lastUpdateUserId, 
            Timestamp lastUpdateTimestamp, String domainName, String operationMode)
    {
        this.typeCode = typeCode;
        this.typeName = typeName;
        this.dataSetupStatus = dataSetupStatus;
        super.createUserId = createUserId;
        super.createTimestamp = createTimestamp;
        super.lastUpdateUserId = lastUpdateUserId;
        super.lastUpdateTimestamp = lastUpdateTimestamp;
        super.domainName = domainName;
        this.operationMode = operationMode;
    }


    public boolean getIsModified()
    {
        return isModified;
    }

    public String getOperationMode()
    {
        if(operationMode == null)
            operationMode = "";
        return operationMode;
    }

    public String getDataSetupStatus()
    {
        if(dataSetupStatus == null)
            dataSetupStatus = "";
        return dataSetupStatus;
    }


    public String getTypeCode()
    {
        if(typeCode == null)
            typeCode = "";
        return typeCode;
    }

    public String getTypeName()
    {
        if(typeName == null)
            typeName = "";
        return typeName;
    }

    public void setIsModified(boolean isModified)
    {
        this.isModified = isModified;
    }

    public void setOperationMode(String operationMode)
    {
        this.operationMode = operationMode;
    }

    public void setDataSetupStatus(String dataSetupStatus)
    {
        this.dataSetupStatus = dataSetupStatus;
    }

    public void setTypeCode(String typeCode)
    {
        this.typeCode = typeCode;
    }

    public void setTypeName(String typeName)
    {
        this.typeName = typeName;
    }
}

