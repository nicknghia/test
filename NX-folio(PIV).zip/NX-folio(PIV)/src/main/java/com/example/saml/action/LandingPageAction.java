package com.example.saml.action;

import com.opensymphony.xwork2.ActionSupport;

import org.springframework.security.core.context.SecurityContextHolder;

public class LandingPageAction  extends ActionSupport {
  
    private static final long serialVersionUID = 1L;
 
    @Override
    public java.lang.String execute() {
    	
	System.out.println("LANDING PAGE ACTION");
    	// 
		System.out.println("NAME:" + SecurityContextHolder.getContext().getAuthentication().getName());
		System.out.println("toString:" + SecurityContextHolder.getContext().getAuthentication().toString());
		System.out.println("Credentials:" + SecurityContextHolder.getContext().getAuthentication().getCredentials().toString());
         
        return "success";
    }
     
}


