/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Kevin.Tsou
 */
public class IacModel implements Serializable{
    private static final long serialVersionUID = -8767337899673261248L;

    private String iacId;
    private String iacName;
    private String iacStatus;
    private String iacType;
    private String iacExpiredDate;
    

    public IacModel() {
    }
        
    public IacModel(String iacName, String iacType, String iacId, String iacStatus) {
        this.iacName = iacName;
        this.iacType = iacType;
        this.iacId = iacId;
        this.iacStatus = iacStatus;
    }
    
        public void setIacId (String iacId) {
		this.iacId = iacId; 
	}

	public void setIacName (String iacName) {
		this.iacName = iacName; 
	}
	
	public void setIacStatus (String iacStatus) {
		this.iacStatus = iacStatus; 
	}
        
        public void setIacType (String iacType) {
		this.iacType = iacType; 
	}
        
	public String getIacId () {
		return (this.iacId); 
	}

	public String getIacName () {
		return (this.iacName); 
	}

	public String getIacStatus () {
//            if (iacStatus == null){
//                this.iacStatus = "";
//            }
            return (this.iacStatus); 
	}
        
        public String getIacType () {
		return (this.iacType); 
	}

	public String toString () {

		String sep = System.getProperty("line.separator");

		StringBuffer buffer = new StringBuffer();
		buffer.append(sep);		
		buffer.append("iacName = ");
		buffer.append(iacName);
		buffer.append(sep);
		buffer.append("iacType = ");
		buffer.append(iacType);
		buffer.append(sep);
		buffer.append("iacId = ");
		buffer.append(iacId);
		buffer.append(sep);
		buffer.append("iacStatus = ");
		buffer.append(iacStatus);
		buffer.append(sep);       
		buffer.append("iacExpiredDate = ");
		buffer.append(iacExpiredDate);
		buffer.append(sep);       
		
		return buffer.toString();
	}

	
	public void setIacExpiredDate (String iacExpiredDate) {
		this.iacExpiredDate = iacExpiredDate; 
	}

	public String getIacExpiredDate () {
		return (this.iacExpiredDate); 
	}

	
}
