/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Binh.Nguyen
 */
public class SubjectIndividualIacModel implements Serializable{
    private static final long serialVersionUID = -8767337899673261248L;
    private String subjectIndividualIacNumber;
	private String subjectIndividualIacName;
	private String subjectIndividualIacCity;
	private String subjectIndividualIacState;
	private String subjectIndividualIacStartDate;
	private String subjectIndividualIacEndDate;
		
    public SubjectIndividualIacModel() {
    }
        
    public SubjectIndividualIacModel(String subjectIndividualIacNumber, 
	    String subjectIndividualIacName, String subjectIndividualIacCity, 
		String subjectIndividualIacState, String subjectIndividualIacStartDate,
		String subjectIndividualIacEndDate) {		
		this.subjectIndividualIacNumber = subjectIndividualIacNumber;
        this.subjectIndividualIacName = subjectIndividualIacName;
		this.subjectIndividualIacCity = subjectIndividualIacCity;       
		this.subjectIndividualIacState = subjectIndividualIacState;
		this.subjectIndividualIacStartDate = subjectIndividualIacStartDate;
		this.subjectIndividualIacEndDate = subjectIndividualIacEndDate;		
    }
    
    public String getSubjectIndividualIacNumber() {        	
	return subjectIndividualIacNumber;
    }
    
    public void setSubjectIndividualIacNumber(String subjectIndividualIacNumber) {
	this.subjectIndividualIacNumber = subjectIndividualIacNumber;
    }
	
	public String getSubjectIndividualIacName() {        	
	return subjectIndividualIacName;
    }
    
    public void setSubjectIndividualIacName(String subjectIndividualIacName) {
	this.subjectIndividualIacName = subjectIndividualIacName;
    }
	
	public String getSubjectIndividualIacCity() {        	
	return subjectIndividualIacCity;
    }
    
    public void setSubjectIndividualIacCity(String subjectIndividualIacCity) {
	this.subjectIndividualIacCity = subjectIndividualIacCity;
    }
	
	public String getSubjectIndividualIacState() {        	
	return subjectIndividualIacState;
    }
    
    public void setSubjectIndividualIacState(String subjectIndividualIacState) {
	this.subjectIndividualIacState = subjectIndividualIacState;
    }
	
	public String getSubjectIndividualIacStartDate() {        	
	return subjectIndividualIacStartDate;
    }
    
    public void setSubjectIndividualIacStartDate(String subjectIndividualIacStartDate) {
	this.subjectIndividualIacStartDate = subjectIndividualIacStartDate;
    }
	
	public String getSubjectIndividualIacEndDate() {        	
	return subjectIndividualIacEndDate;
    }
    
    public void setSubjectIndividualIacEndDate(String subjectIndividualIacEndDate) {
	this.subjectIndividualIacEndDate = subjectIndividualIacEndDate;
    }
	
    public String toString () {

	String sep = System.getProperty("line.separator");

	StringBuffer buffer = new StringBuffer();
	buffer.append(sep);			
    buffer.append("subjectIndividualIacNumber= ");
	buffer.append(subjectIndividualIacNumber);
	buffer.append(sep);
	buffer.append("subjectIndividualIacName= ");
	buffer.append(subjectIndividualIacName);
	buffer.append(sep);
	buffer.append("subjectIndividualIacCity= ");
	buffer.append(subjectIndividualIacCity);
	buffer.append(sep);		
	buffer.append("subjectIndividualIacState= ");
	buffer.append(subjectIndividualIacState);
	buffer.append(sep);
	buffer.append("subjectIndividualIacStartDate= ");
	buffer.append(subjectIndividualIacStartDate);
	buffer.append(sep);		
	buffer.append("subjectIndividualIacEndDate= ");
	buffer.append(subjectIndividualIacEndDate);
	buffer.append(sep);		
	
	return buffer.toString();
    }
}
