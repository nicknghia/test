/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ctu.tsa.fas.requesttracker.ejb;

import com.ctu.tsa.fas.requesttracker.data.RequestTrackerData;
import java.rmi.RemoteException;
import java.util.Map;


public interface RequestTrackerRemote {
   public void saveRequestTracker(RequestTrackerData requestTrackerData) throws RemoteException;
   public Map<String, String > getSubjectRegionList() throws RemoteException; 
   public Map<String, String > getOgaReferralList() throws RemoteException;
   public Map<String, String > getJointOperationsList() throws RemoteException;
   public Map<String, String > getFieldCallStaRequestList() throws RemoteException;
   public Map<String, String > getCargoIncidentList() throws RemoteException;
   public Map<String, String > getCCSFApprovalList() throws RemoteException;

   public Map<String, String > getTargeterList() throws RemoteException;
   public Map<String, String > getRequestTypeList() throws RemoteException;
   
}
