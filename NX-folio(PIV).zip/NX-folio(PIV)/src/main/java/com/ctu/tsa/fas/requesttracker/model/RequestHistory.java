/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.requesttracker.model;

import java.io.Serializable;
import java.sql.Timestamp;

/**
 *
 * @author STCI
 */
public class RequestHistory implements Serializable {

    private static final long serialVersionUID = -8767337899673261247L;

    private Timestamp timestamp; 
    private String action;

    public Timestamp getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    public String getAction() {
        return action;
    }

    public void setAction(String action) {
        this.action = action;
    }

    public String toJsonString() {
        return "{timestamp:" + timestamp + ", action:" + action + '}';
    }

    @Override
    public String toString() {
        return "RequestHistory{" + "timestamp=" + timestamp + "~action=" + action + '}';
    }

    public String toAjaxString() {
        return "timestamp~" + timestamp + "~action~" + action;
    }
 
}
