/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.requesttracker.data;

import com.ctu.tsa.fas.delegation.RequestTrackerDelegation;
import java.util.LinkedHashMap;
import java.util.Map;
import org.apache.log4j.Logger;

/**
 * This class is used to obtain static data for drop down lists. Anytime a list is updated, the Delegate object should be
 * called and call an appropriate set method defined in this class.
 * @author Nick.Hoang
 */
public class RequestReferenceData {

    private Map<String, String> targeterLinkedMap = new LinkedHashMap<String, String>();
    private Map<String, String> airportNamesLinkedMap = new LinkedHashMap<String, String>();
    private Map<String, String> requestTypeLinkedMap = new LinkedHashMap<String, String>();
    private Map<String, String> ccsfApprovalLinkedMap = new LinkedHashMap<String, String>();
    private Map<String, String> requesterLinkedMap = new LinkedHashMap<String, String>();
    private Map<String, String> subjectRegionLinkedMap = new LinkedHashMap<String, String>();
    private Map<String, String> ogaReferralLinkedMap = new LinkedHashMap<String, String>();
    private Map<String, String> jointOperationsLinkedMap = new LinkedHashMap<String, String>();
    private Map<String, String> fieldCallStaRequestLinkedMap = new LinkedHashMap<String, String>();
    private Map<String, String> staInLieuOfLinkedMap = new LinkedHashMap<String, String>();
    private Map<String, String> cargoIncidentLinkedMap = new LinkedHashMap<String, String>();

    private static RequestReferenceData instance = null;
    protected Logger logger = Logger.getLogger(getClass());

    private RequestReferenceData() {
        logger.debug(" ---------RequestReferenceData constructor");
        RequestTrackerDelegation delegate = new RequestTrackerDelegation();
        try {
            targeterLinkedMap = delegate.getTargeterList();
            airportNamesLinkedMap = delegate.getAirportList();
            ccsfApprovalLinkedMap = delegate.getCCSFApprovalList();
            ogaReferralLinkedMap = delegate.getOgaReferralList();
            subjectRegionLinkedMap = delegate.getSubjectRegionList();
            requestTypeLinkedMap = delegate.getRequestTypeList();
            jointOperationsLinkedMap = delegate.getJointOperationsList();
            fieldCallStaRequestLinkedMap = delegate.getFieldCallStaRequestList();
            staInLieuOfLinkedMap = delegate.getStaInLieuOfList();
            cargoIncidentLinkedMap = delegate.getCargoIncidentList();

        } catch (Exception e) {
            logger.debug("*** EXCEPTION 2::  "+e.getMessage());

        }
    }

    public static RequestReferenceData getInstance() {
        if (instance == null) {
            instance = new RequestReferenceData();
        }
        return instance;
    }

    public Map<String, String> getOgaReferralLinkedMap() {
        return ogaReferralLinkedMap;
    }

    public void setOgaReferralLinkedMap(Map<String, String> ogaReferralLinkedMap) {
        this.ogaReferralLinkedMap = ogaReferralLinkedMap;
    }

    public Map<String, String> getJointOperationsLinkedMap() {
        return jointOperationsLinkedMap;
    }

    public void setJointOperationsLinkedMap(Map<String, String> jointOperationsLinkedMap) {
        this.jointOperationsLinkedMap = jointOperationsLinkedMap;
    }

    public Map<String, String> getFieldCallStaRequestLinkedMap() {
        return fieldCallStaRequestLinkedMap;
    }

    public void setFieldCallStaRequestLinkedMap(Map<String, String> fieldCallStaRequestLinkedMap) {
        this.fieldCallStaRequestLinkedMap = fieldCallStaRequestLinkedMap;
    }

    public Map<String, String> getCargoIncidentLinkedMap() {
        return cargoIncidentLinkedMap;
    }

    public void setCargoIncidentLinkedMap(Map<String, String> cargoIncidentLinkedMap) {
        this.cargoIncidentLinkedMap = cargoIncidentLinkedMap;
    }

    public Map<String, String> getAirportNamesLinkedMap() {
        return airportNamesLinkedMap;
    }

    public void setAirportNamesLinkedMap(Map<String, String> airportNamesLinkedMap) {
        this.airportNamesLinkedMap = airportNamesLinkedMap;
    }

    public Map<String, String> getTargeterLinkedMap() {
        return targeterLinkedMap;
    }

    public void setTargeterLinkedMap(Map<String, String> targeterLinkedMap) {
        this.targeterLinkedMap = targeterLinkedMap;
    }

    public Map<String, String> getRequestTypeLinkedMap() {
        return requestTypeLinkedMap;
    }

    public void setRequestTypeLinkedMap(Map<String, String> requestTypeLinkedMap) {
        this.requestTypeLinkedMap = requestTypeLinkedMap;
    }

    public Map<String, String> getCcsfApprovalLinkedMap() {
        return ccsfApprovalLinkedMap;
    }

    public void setCcsfApprovalLinkedMap(Map<String, String> ccsfApprovalLinkedMap) {
        this.ccsfApprovalLinkedMap = ccsfApprovalLinkedMap;
    }

    public Map<String, String> getRequesterLinkedMap() {
        return requesterLinkedMap;
    }

    public void setRequesterLinkedMap(Map<String, String> requesterLinkedMap) {
        this.requesterLinkedMap = requesterLinkedMap;
    }

    public Map<String, String> getSubjectRegionLinkedMap() {
        return subjectRegionLinkedMap;
    }

    public void setSubjectRegionLinkedMap(Map<String, String> subjectRegionLinkedMap) {
        this.subjectRegionLinkedMap = subjectRegionLinkedMap;
    }

    public Map<String, String> getStaInLieuOfLinkedMap() {
        return staInLieuOfLinkedMap;
    }

    public void setStaInLieuOfLinkedMap(Map<String, String> staInLieuOfLinkedMap) {
        this.staInLieuOfLinkedMap = staInLieuOfLinkedMap;
    }

}
