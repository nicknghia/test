/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.requesttracker.action;

import com.ctu.tsa.fas.requesttracker.dao.RequestTrackerDAO;
import com.opensymphony.xwork2.Action;
import org.apache.log4j.Logger;

public class RequestTrackerAjaxEditAction implements Action {

    private String message = "";
    private String requestNumberValue;
    private String userNameValue;
	protected Logger logger = Logger.getLogger(getClass());

    public RequestTrackerAjaxEditAction() {        
    }

    public String execute() {        
        RequestTrackerDAO dao = new RequestTrackerDAO();

        String anotherUser = "";
        try {

            if (requestNumberValue.isEmpty()) { // cancel edit             
                dao.cancelEditRequest(userNameValue);
            } else {               
               anotherUser = dao.processEditRequest(requestNumberValue, userNameValue);

                message = "";    // reset
                if (null != anotherUser && !anotherUser.isEmpty()) {
                     message = anotherUser;
                }
            }
        } catch (Exception e) {
            logger.debug("*** EXCEPTION in RequestTrackerAjaxEditAction:  "+e.getMessage());			
        }

        return SUCCESS;
    }

    public String getRequestNumberValue() {
        return requestNumberValue;
    }

    public void setRequestNumberValue(String requestNumberValue) {
        this.requestNumberValue = requestNumberValue;
    }

    public String getUserNameValue() {
        return userNameValue;
    }

    public void setUserNameValue(String userNameValue) {
        this.userNameValue = userNameValue;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

}
