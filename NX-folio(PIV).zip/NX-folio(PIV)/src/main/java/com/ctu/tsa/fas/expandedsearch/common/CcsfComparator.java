/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.common;
import java.io.Serializable;
import java.util.Comparator;

import org.apache.log4j.Logger;
import com.ctu.tsa.fas.expandedsearch.model.CcsfModel;

/**
 *
 * @author Kevin.Tsou
 */
public class CcsfComparator implements Comparator<CcsfModel>, Serializable{
    private static final long serialVersionUID = 1L;

    private Logger logger = Logger.getLogger(CcsfComparator.class);
    private boolean ascending;
    private String colName;
    
    public CcsfComparator(String colName, boolean ascending) {
	this.ascending = ascending;
	this.colName = colName;
    }
    
    @SuppressWarnings("unchecked")
    public int compare(CcsfModel o1, CcsfModel o2) {
        int result = 0;
        
        try {
            Object value1 = null;
            Object value2 = null;
            
            if (colName.equalsIgnoreCase("facilityName")) {
		       value1 = o1.getFacilityName();
		       value2 = o2.getFacilityName();
            } else if (colName.equalsIgnoreCase("type")) {
		       value1 = o1.getType();
               value2 = o2.getType();
            } else if (colName.equalsIgnoreCase("iacNumber")) {
		       value1 = o1.getIacNumber();
		       value2 = o2.getIacNumber();
            } else if (colName.equalsIgnoreCase("ccsfStatus")) {
		       value1 = o1.getCcsfStatus();
		       value2 = o2.getCcsfStatus();
            } else if (colName.equalsIgnoreCase("certificationNumber")) {
		       value1 = o1.getCertificationNumber();
		       value2 = o2.getCertificationNumber();
            } else {
		       logger.warn("Could not map " + colName + " to class attribute");
            }
            
            // Null is lesser than anything else.
            if ((value1 == null) && (value2 == null)) {
		      result = 0;
            } else if ((value1 == null) && (value2 != null)) {
		      result = -1;
            } else if ((value1 != null) && (value2 == null)) {
		      result = 1;
			} else if ((value1 != null) && (value2 != null) && (value1 == value2)) {
			   if (result == 0) {			      
		          result = 1; 
			   }
            } else if (value1 instanceof Comparable) {
		// the attribute values are Comparable, we have hit the JackPot.  We have absolutely nothing intelligent to do
		@SuppressWarnings("rawtypes")
		Comparable comp1 = (Comparable) value1;
		@SuppressWarnings("rawtypes")
		Comparable comp2 = (Comparable) value2;
		result = comp1.compareTo(comp2);
            } else {
		       logger.warn("Dont know how to sort by " + colName);
            }          

            if (!ascending) {
		       result = 0 - result;
            }
        }
        catch (Exception ex) {
            //ex.printStackTrace();
            logger.error("Exception : " + ex.getMessage());
	}
        
        return result;
    }
}
