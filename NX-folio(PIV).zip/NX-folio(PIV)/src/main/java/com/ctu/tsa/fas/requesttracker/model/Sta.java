package com.ctu.tsa.fas.requesttracker.model;


public class Sta {
    	private String subject;
    	private String status;
    	private String inlieuof;
    	private String credential;

	
	public void setSubject (String subject) {
		this.subject = subject; 
	}

	public void setStatus (String status) {
		this.status = status; 
	}

	public void setInlieuof (String inlieuof) {
		this.inlieuof = inlieuof; 
	}

	public void setCredential (String credential) {
		this.credential = credential; 
	}

	public String getSubject () {
		return (this.subject); 
	}

	public String getStatus () {
		return (this.status); 
	}

	public String getInlieuof () {
		return (this.inlieuof); 
	}

	public String getCredential () {
		return (this.credential); 
	}
	
	public String compare (Sta another) {
		if (another == null) {
			return null;
		}
		else if (another.getSubject ().equalsIgnoreCase(this.subject) &&
			another.getStatus ().equals(this.status) &&
			another.getInlieuof ().equals(this.inlieuof) &&
			another.getCredential ().equalsIgnoreCase(this.credential) ) {			
			return ("SAME");
		} 
		else if (another.getSubject ().equalsIgnoreCase(this.subject)) {
			return ("SAME_SUBJECT");			
		}
		else {
			return ("DIFF");			
		}
	}
	
    @Override
    public String toString() {
        return "{" + subject + ", " + status + ", " + inlieuof + ", " + credential + '}';
    }


}
