/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;

/**
 *
 * @author Binh.Nguyen
 */
public class SubjectIndividualDetails implements Serializable{
    private static final long serialVersionUID = -8767337899673261247L;

    private String subjectIndividualStaId = "";
	private String subjectIndividualLastName = "";
	private String subjectIndividualFirstName = "";
	private String subjectIndividualMiddleName = "";
	private String subjectIndividualSuffix = "";
	private String subjectIndividualCreationDate = "";
	private String subjectIndividualIssuedDate = "";
	private String subjectIndividualExpirationDate = "";
	private String subjectIndividualRecordStatus = "";
	private String subjectIndividualStaStatus = "";
	private String subjectIndividualAlias1 = "";
	private String subjectIndividualAlias2 = "";
	private String subjectIndividualAlias3 = "";
	private String subjectIndividualAddress1 = "";
    private String subjectIndividualAddress2 = "";
	private String subjectIndividualCity = "";	            
    private String subjectIndividualState = "";     
    private String subjectIndividualZipPostalCode = "";
    private String subjectIndividualCountry = "";	
	
	private String subjectIndividualResidentialPhysicalAddress = "";
	private String subjectIndividualResidentialPhysicalCity = "";
	private String subjectIndividualResidentialPhysicalState = "";	
	private String subjectIndividualResidentialPhysicalZipPostalCode = "";
	private String subjectIndividualResidentialPhysicalCountry = "";
	private String subjectIndividualResidentialPhysicalStartDate = "";
	private String subjectIndividualResidentialPhysicalEndDate = "";
	
	private String subjectIndividualGender = "";
	private String subjectIndividualSsn = "";
	private String subjectIndividualDateOfBirth = "";
	private String subjectIndividualBirthCity = "";
	private String subjectIndividualBirthState = "";
	private String subjectIndividualBirthCountry = "";
	
	private String subjectIndividualCountryOfCitizenship = "";
	private String subjectIndividualAlienNumber = "";
	private String subjectIndividualNaturalizationDate = "";
	private String subjectIndividualNaturalizationNumber = "";
	private String subjectIndividualUsPassportNumber = "";
	private String subjectIndividualBirthAbroadCertificationNumber = "";
	
	private String subjectIndividualIacNumber = "";
	private String subjectIndividualIacName = "";
	private String subjectIndividualIacCity = "";
	private String subjectIndividualIacState = "";
	private String subjectIndividualIacStartDate = "";
	private String subjectIndividualIacEndDate = "";
	
	private String subjectIndividualAgentName = "";
	private String subjectIndividualAgentId = "";
	private String subjectIndividualAgentCity = "";
	private String subjectIndividualAgentState = "";
	private String subjectIndividualAgentAssociatedIac = "";
	private String subjectIndividualAgentStartDate = "";
	private String subjectIndividualAgentEndDate = "";
	
	private String subjectIndividualAcName = "";
	private String subjectIndividualAcCity = "";
	private String subjectIndividualAcState = "";
	private String subjectIndividualAcStartDate = "";
	private String subjectIndividualAcEndtDate = "";
	
	public String getSubjectIndividualAcName() {        	
	return subjectIndividualAcName;
    }
    
    public void setSubjectIndividualAcName(String subjectIndividualAcName) {
	this.subjectIndividualAcName = subjectIndividualAcName;
    }
	
	public String getSubjectIndividualAcCity() {        	
	return subjectIndividualAcCity;
    }
    
    public void setSubjectIndividualAcCity(String subjectIndividualAcCity) {
	this.subjectIndividualAcCity = subjectIndividualAcCity;
    }
	
	public String getSubjectIndividualAcState() {        	
	return subjectIndividualAcState;
    }
    
    public void setSubjectIndividualAcState(String subjectIndividualAcState) {
	this.subjectIndividualAcState = subjectIndividualAcState;
    }
	
	public String getSubjectIndividualAcStartDate() {        	
	return subjectIndividualAcStartDate;
    }
    
    public void setSubjectIndividualAcStartDate(String subjectIndividualAcStartDate) {
	this.subjectIndividualAcStartDate = subjectIndividualAcStartDate;
    }
	
	public String getSubjectIndividualAcEndtDate() {        	
	return subjectIndividualAcEndtDate;
    }
    
    public void setSubjectIndividualAcEndtDate(String subjectIndividualAcEndtDate) {
	this.subjectIndividualAcEndtDate = subjectIndividualAcEndtDate;
    }
	
	public String getSubjectIndividualAgentName() {        	
	return subjectIndividualAgentName;
    }
    
    public void setSubjectIndividualAgentName(String subjectIndividualAgentName) {
	this.subjectIndividualAgentName = subjectIndividualAgentName;
    }
	
	public String getSubjectIndividualAgentId() {        	
	return subjectIndividualAgentId;
    }
    
    public void setSubjectIndividualAgentId(String subjectIndividualAgentId) {
	this.subjectIndividualAgentId = subjectIndividualAgentId;
    }
	
	public String getSubjectIndividualAgentCity() {        	
	return subjectIndividualAgentCity;
    }
    
    public void setSubjectIndividualAgentCity(String subjectIndividualAgentCity) {
	this.subjectIndividualAgentCity = subjectIndividualAgentCity;
    }
	
	public String getSubjectIndividualAgentState() {        	
	return subjectIndividualAgentState;
    }
    
    public void setSubjectIndividualAgentState(String subjectIndividualAgentState) {
	this.subjectIndividualAgentState = subjectIndividualAgentState;
    }
	
	public String getSubjectIndividualAgentAssociatedIac() {        	
	return subjectIndividualAgentAssociatedIac;
    }
    
    public void setSubjectIndividualAgentAssociatedIac(String subjectIndividualAgentAssociatedIac) {
	this.subjectIndividualAgentAssociatedIac = subjectIndividualAgentAssociatedIac;
    }
	
	public String getSubjectIndividualAgentStartDate() {        	
	return subjectIndividualAgentStartDate;
    }
    
    public void setSubjectIndividualAgentStartDate(String subjectIndividualAgentStartDate) {
	this.subjectIndividualAgentStartDate = subjectIndividualAgentStartDate;
    }
	
	public String getSubjectIndividualAgentEndDate() {        	
	return subjectIndividualAgentEndDate;
    }
    
    public void setSubjectIndividualAgentEndDate(String subjectIndividualAgentEndDate) {
	this.subjectIndividualAgentEndDate = subjectIndividualAgentEndDate;
    }
		
	public String getSubjectIndividualIacNumber() {        	
	return subjectIndividualIacNumber;
    }
    
    public void setSubjectIndividualIacNumber(String subjectIndividualIacNumber) {
	this.subjectIndividualIacNumber = subjectIndividualIacNumber;
    }
	
	public String getSubjectIndividualIacName() {        	
	return subjectIndividualIacName;
    }
    
    public void setSubjectIndividualIacName(String subjectIndividualIacName) {
	this.subjectIndividualIacName = subjectIndividualIacName;
    }
	
	public String getSubjectIndividualIacCity() {        	
	return subjectIndividualIacCity;
    }
    
    public void setSubjectIndividualIacCity(String subjectIndividualIacCity) {
	this.subjectIndividualIacCity = subjectIndividualIacCity;
    }
	
	public String getSubjectIndividualIacState() {        	
	return subjectIndividualIacState;
    }
    
    public void setSubjectIndividualIacState(String subjectIndividualIacState) {
	this.subjectIndividualIacState = subjectIndividualIacState;
    }
	
	public String getSubjectIndividualIacStartDate() {        	
	return subjectIndividualIacStartDate;
    }
    
    public void setSubjectIndividualIacStartDate(String subjectIndividualIacStartDate) {
	this.subjectIndividualIacStartDate = subjectIndividualIacStartDate;
    }
	
	public String getSubjectIndividualIacEndDate() {        	
	return subjectIndividualIacEndDate;
    }
    
    public void setSubjectIndividualIacEndDate(String subjectIndividualIacEndDate) {
	this.subjectIndividualIacEndDate = subjectIndividualIacEndDate;
    }
	
	public String getSubjectIndividualCountryOfCitizenship() {        	
	return subjectIndividualCountryOfCitizenship;
    }
    
    public void setSubjectIndividualCountryOfCitizenship(String subjectIndividualCountryOfCitizenship) {
	this.subjectIndividualCountryOfCitizenship = subjectIndividualCountryOfCitizenship;
    }
	
	public String getSubjectIndividualAlienNumber() {        	
	return subjectIndividualAlienNumber;
    }
    
    public void setSubjectIndividualAlienNumber(String subjectIndividualAlienNumber) {
	this.subjectIndividualAlienNumber = subjectIndividualAlienNumber;
    }
	
	public String getSubjectIndividualNaturalizationDate() {        	
	return subjectIndividualNaturalizationDate;
    }
    
    public void setSubjectIndividualNaturalizationDate(String subjectIndividualNaturalizationDate) {
	this.subjectIndividualNaturalizationDate = subjectIndividualNaturalizationDate;
    }
	
	public String getSubjectIndividualNaturalizationNumber() {        	
	return subjectIndividualNaturalizationNumber;
    }
    
    public void setSubjectIndividualNaturalizationNumber(String subjectIndividualNaturalizationNumber) {
	this.subjectIndividualNaturalizationNumber = subjectIndividualNaturalizationNumber;
    }
	
	public String getSubjectIndividualUsPassportNumber() {        	
	return subjectIndividualUsPassportNumber;
    }
    
    public void setSubjectIndividualUsPassportNumber(String subjectIndividualUsPassportNumber) {
	this.subjectIndividualUsPassportNumber = subjectIndividualUsPassportNumber;
    }
	
	public String getSubjectIndividualBirthAbroadCertificationNumber() {        	
	return subjectIndividualBirthAbroadCertificationNumber;
    }
    
    public void setSubjectIndividualBirthAbroadCertificationNumberr(String subjectIndividualBirthAbroadCertificationNumber) {
	this.subjectIndividualBirthAbroadCertificationNumber = subjectIndividualBirthAbroadCertificationNumber;
    }
	
	public String getSubjectIndividualGender() {        	
	return subjectIndividualGender;
    }
    
    public void setSubjectIndividualGender(String subjectIndividualGender) {
	this.subjectIndividualGender = subjectIndividualGender;
    } 
	
	public String getSubjectIndividualSsn() {        	
	return subjectIndividualSsn;
    }
    
    public void setSubjectIndividualSsn(String subjectIndividualSsn) {
	this.subjectIndividualSsn = subjectIndividualSsn;
    } 
	
	public String getSubjectIndividualDateOfBirth() {        	
	return subjectIndividualDateOfBirth;
    }
    
    public void setSubjectIndividualDateOfBirth(String subjectIndividualDateOfBirth) {
	this.subjectIndividualDateOfBirth = subjectIndividualDateOfBirth;
    } 
	
	public String getSubjectIndividualBirthCity() {        	
	return subjectIndividualBirthCity;
    }
    
    public void setSubjectIndividualBirthCity(String subjectIndividualBirthCity) {
	this.subjectIndividualBirthCity = subjectIndividualBirthCity;
    } 
	
	public String getSubjectIndividualBirthState() {        	
	return subjectIndividualBirthState;
    }
    
    public void setSubjectIndividualBirthState(String subjectIndividualBirthState) {
	this.subjectIndividualBirthState = subjectIndividualBirthState;
    } 
	
	public String getSubjectIndividualBirthCountry() {        	
	return subjectIndividualBirthCountry;
    }
    
    public void setSubjectIndividualBirthCountry(String subjectIndividualBirthCountry) {
	this.subjectIndividualBirthCountry = subjectIndividualBirthCountry;
    } 
	
	public String getSubjectIndividualResidentialPhysicalEndDate() {        	
	return subjectIndividualResidentialPhysicalEndDate;
    }
    
    public void setSubjectIndividualResidentialPhysicalEndDate(String subjectIndividualResidentialPhysicalEndDate) {
	this.subjectIndividualResidentialPhysicalEndDate = subjectIndividualResidentialPhysicalEndDate;
    }  
		
	public String getSubjectIndividualResidentialPhysicalZipPostalCode() {        
	return subjectIndividualResidentialPhysicalZipPostalCode;
    }
    
    public void setSubjectIndividualResidentialPhysicalZipPostalCode(String subjectIndividualResidentialPhysicalZipPostalCode) {
	this.subjectIndividualResidentialPhysicalZipPostalCode = subjectIndividualResidentialPhysicalZipPostalCode;
    }
	
	public String getSubjectIndividualResidentialPhysicalCountry() {       
	return subjectIndividualResidentialPhysicalCountry;
    }
    
    public void setSubjectIndividualResidentialPhysicalCountry(String subjectIndividualResidentialPhysicalCountry) {
	this.subjectIndividualResidentialPhysicalCountry = subjectIndividualResidentialPhysicalCountry;
    }
	
	public String getSubjectIndividualExpirationDate() {       	
	return subjectIndividualExpirationDate;
    }
    
    public void setSubjectIndividualExpirationDate(String subjectIndividualExpirationDate) {
	this.subjectIndividualExpirationDate = subjectIndividualExpirationDate;
    }
	
	public String getSubjectIndividualResidentialPhysicalStartDate() {        	
	return subjectIndividualResidentialPhysicalStartDate;
    }
    
    public void setSubjectIndividualResidentialPhysicalStartDate(String subjectIndividualResidentialPhysicalStartDate) {
	this.subjectIndividualResidentialPhysicalStartDate = subjectIndividualResidentialPhysicalStartDate;
    }
		
	public String getSubjectIndividualResidentialPhysicalCity() {	
    return subjectIndividualResidentialPhysicalCity;
    }

    public void setSubjectIndividualResidentialPhysicalCity(String subjectIndividualResidentialPhysicalCity) {
        this.subjectIndividualResidentialPhysicalCity = subjectIndividualResidentialPhysicalCity;
    }
	
	public String getSubjectIndividualResidentialPhysicalState() {	
    return subjectIndividualResidentialPhysicalState;
    }

    public void setSubjectIndividualResidentialPhysicalState(String subjectIndividualResidentialPhysicalState) {
        this.subjectIndividualResidentialPhysicalState = subjectIndividualResidentialPhysicalState;
    }
	
    public String getSubjectIndividualCreationDate() {	
    return subjectIndividualCreationDate;
    }

    public void setSubjectIndividualCreationDate(String subjectIndividualCreationDate) {
        this.subjectIndividualCreationDate = subjectIndividualCreationDate;
    }
	
	public String getSubjectIndividualAlias1() {	    
    return subjectIndividualAlias1;
    }

    public void setSubjectIndividualAlias1(String subjectIndividualAlias1) {
        this.subjectIndividualAlias1 = subjectIndividualAlias1;
    } 
	
	public String getSubjectIndividualAlias2() {	    
    return subjectIndividualAlias2;
    }

    public void setSubjectIndividualAlias2(String subjectIndividualAlias2) {
        this.subjectIndividualAlias2 = subjectIndividualAlias2;
    } 

	public String getSubjectIndividualAlias3() {	    
    return subjectIndividualAlias3;
    }

    public void setSubjectIndividualAlias3(String subjectIndividualAlias3) {
        this.subjectIndividualAlias3 = subjectIndividualAlias3;
    }
	
	public String getSubjectIndividualFirstName() {	    
    return subjectIndividualFirstName;
    }

    public void setSubjectIndividualFirstName(String subjectIndividualFirstName) {
        this.subjectIndividualFirstName = subjectIndividualFirstName;
    }
	
	public String getSubjectIndividualLastName() {	    
    return subjectIndividualLastName;
    }

    public void setSubjectIndividualLastName(String subjectIndividualLastName) {
        this.subjectIndividualLastName = subjectIndividualLastName;
    }
	
	public String getSubjectIndividualResidentialPhysicalAddress() {	    
    return subjectIndividualResidentialPhysicalAddress;
    }

    public void setSubjectIndividualResidentialPhysicalAddress(String subjectIndividualResidentialPhysicalAddress) {
        this.subjectIndividualResidentialPhysicalAddress = subjectIndividualResidentialPhysicalAddress;
    }
	
	public void setSubjectIndividualRecordStatus (String subjectIndividualRecordStatus) {
        this.subjectIndividualRecordStatus = subjectIndividualRecordStatus; 
     }

	 public void setSubjectIndividualStaStatus (String subjectIndividualStaStatus) {
        this.subjectIndividualStaStatus = subjectIndividualStaStatus; 
     }
	 
	 public void setSubjectIndividualIssuedDate (String subjectIndividualIssuedDate) {
        this.subjectIndividualIssuedDate = subjectIndividualIssuedDate; 
     }
	 	 
    public void setSubjectIndividualStaId (String subjectIndividualStaId) {
        this.subjectIndividualStaId = subjectIndividualStaId; 
     }   
	 
    public void setSubjectIndividualState (String subjectIndividualState) {
	this.subjectIndividualState = subjectIndividualState; 
     }
	    
    public void setSubjectIndividualMiddleName (String subjectIndividualMiddleName) {
	this.subjectIndividualMiddleName = subjectIndividualMiddleName; 
    }

    public String getSubjectIndividualRecordStatus () {
	return (this.subjectIndividualRecordStatus); 
    }
	
	public String getSubjectIndividualStaStatus () {
	return (this.subjectIndividualStaStatus); 
    }
	
	public String getSubjectIndividualIssuedDate () {
	return (this.subjectIndividualIssuedDate); 
    }	
	
    public String getSubjectIndividualStaId () {
	return (this.subjectIndividualStaId); 
    }
   
    public String getSubjectIndividualState () {
	return (this.subjectIndividualState); 
    }
    
    public String getSubjectIndividualMiddleName () {
	return (this.subjectIndividualMiddleName); 
    }

    public String getSubjectIndividualSuffix() {
        return subjectIndividualSuffix;
    }

    public void setSubjectIndividualSuffix(String subjectIndividualSuffix) {
        this.subjectIndividualSuffix = subjectIndividualSuffix;
    }
            
    public String getSubjectIndividualAddress1() {
        return subjectIndividualAddress1;
    }

    public void setSubjectIndividualAddress1(String subjectIndividualAddress1) {
        this.subjectIndividualAddress1 = subjectIndividualAddress1;
    }        
        
    public String getSubjectIndividualAddress2() {
        return subjectIndividualAddress2;
    }

    public void setSubjectIndividualAddress2(String subjectIndividualAddress2) {
        this.subjectIndividualAddress2 = subjectIndividualAddress2;
    }    
    
    public String getsubjectIndividualCity() {
        return subjectIndividualCity;
    }

    public void setSubjectIndividualCity(String subjectIndividualCity) {
        this.subjectIndividualCity = subjectIndividualCity;
    }
        
    public String getSubjectIndividualZipPostalCode() {
        return subjectIndividualZipPostalCode;
    }

    public void setSubjectIndividualZipPostalCode(String subjectIndividualZipPostalCode) {
        this.subjectIndividualZipPostalCode = subjectIndividualZipPostalCode;
    }
    
    public String getSubjectIndividualCountry() {
        return subjectIndividualCountry;
    }

    public void setSubjectIndividualCountry(String subjectIndividualCountry) {
        this.subjectIndividualCountry = subjectIndividualCountry;
    }
    
	public String toString () {

		String sep = System.getProperty("line.separator");

		StringBuffer buffer = new StringBuffer();
		buffer.append(sep);       
		buffer.append("subjectIndividualLastName = ");
		buffer.append(subjectIndividualLastName);
		buffer.append(sep);
		buffer.append("subjectIndividualFirstName = ");
		buffer.append(subjectIndividualFirstName);
		buffer.append(sep);
		buffer.append("subjectIndividualMiddleName = ");
		buffer.append(subjectIndividualMiddleName);
		buffer.append(sep);
		buffer.append("subjectIndividualStaId = ");
		buffer.append(subjectIndividualStaId);
		buffer.append(sep);
		buffer.append("subjectIndividualRecordStatus = "); 
		buffer.append(subjectIndividualRecordStatus);
		buffer.append(sep);
		buffer.append("subjectIndividualStaStatus = "); 
		buffer.append(subjectIndividualStaStatus);
		buffer.append(sep);
		buffer.append("subjectIndividualIssuedDate = "); 
		buffer.append(subjectIndividualIssuedDate);
		buffer.append(sep);		
        buffer.append("subjectIndividualState = ");
		buffer.append(subjectIndividualState);
		buffer.append(sep);				
		buffer.append("subjectIndividualAddress1 = ");
		buffer.append(subjectIndividualAddress1);
		buffer.append(sep);
		buffer.append("subjectIndividualAddress2 = ");
		buffer.append(subjectIndividualAddress2);
		buffer.append(sep);
		buffer.append("subjectIndividualCity = ");
		buffer.append(subjectIndividualCity);
		buffer.append(sep);
		buffer.append("subjectIndividualZipPostalCode = ");
		buffer.append(subjectIndividualZipPostalCode);
		buffer.append(sep);
		buffer.append("subjectIndividualCountry = ");
		buffer.append(subjectIndividualCountry);
		buffer.append(sep);
		buffer.append("subjectIndividualSuffix = ");
		buffer.append(subjectIndividualSuffix);
		buffer.append(sep);	
        buffer.append("subjectIndividualCreationDate = ");
		buffer.append(subjectIndividualCreationDate);
		buffer.append(sep);	
		buffer.append("subjectIndividualAlias1= ");
		buffer.append(subjectIndividualAlias1);
		buffer.append(sep);
		buffer.append("subjectIndividualAlias2= ");
		buffer.append(subjectIndividualAlias2);
		buffer.append(sep);
		buffer.append("subjectIndividualAlias3= ");
		buffer.append(subjectIndividualAlias3);
		buffer.append(sep);		
		buffer.append("subjectIndividualResidentialPhysicalAddress= ");
		buffer.append(subjectIndividualResidentialPhysicalAddress);
		buffer.append(sep);
		buffer.append("subjectIndividualResidentialPhysicalCity= ");
		buffer.append(subjectIndividualResidentialPhysicalCity);
		buffer.append(sep);
		buffer.append("subjectIndividualResidentialPhysicalState= ");
		buffer.append(subjectIndividualResidentialPhysicalState);
		buffer.append(sep);		
		buffer.append("subjectIndividualResidentialPhysicalZipPostalCode= ");
		buffer.append(subjectIndividualResidentialPhysicalZipPostalCode);
		buffer.append(sep);
		buffer.append("subjectIndividualResidentialPhysicalCountry= ");
		buffer.append(subjectIndividualResidentialPhysicalCountry);
		buffer.append(sep);
		buffer.append("subjectIndividualExpirationDate= ");
		buffer.append(subjectIndividualExpirationDate);
		buffer.append(sep);
		buffer.append("subjectIndividualResidentialPhysicalStartDate= ");
		buffer.append(subjectIndividualResidentialPhysicalStartDate);
		buffer.append(sep);
		buffer.append("subjectIndividualResidentialPhysicalEndDate= ");
		buffer.append(subjectIndividualResidentialPhysicalEndDate);
		buffer.append(sep);
		buffer.append("subjectIndividualGender= ");
		buffer.append(subjectIndividualGender);
		buffer.append(sep);
		buffer.append("subjectIndividualSsn= ");
		buffer.append(subjectIndividualSsn);
		buffer.append(sep);
		buffer.append("subjectIndividualDateOfBirth= ");
		buffer.append(subjectIndividualDateOfBirth);
		buffer.append(sep);
		buffer.append("subjectIndividualBirthCity= ");
		buffer.append(subjectIndividualBirthCity);
		buffer.append(sep);
		buffer.append("subjectIndividualBirthState= ");
		buffer.append(subjectIndividualBirthState);
		buffer.append(sep);
		buffer.append("subjectIndividualBirthCountry= ");
		buffer.append(subjectIndividualBirthCountry);
		buffer.append(sep);
		buffer.append("subjectIndividualCountryOfCitizenship= ");
		buffer.append(subjectIndividualCountryOfCitizenship);
		buffer.append(sep);
		buffer.append("subjectIndividualAlienNumber= ");
		buffer.append(subjectIndividualAlienNumber);
		buffer.append(sep);
		buffer.append("subjectIndividualNaturalizationDate= ");
		buffer.append(subjectIndividualNaturalizationDate);
		buffer.append(sep);
		buffer.append("subjectIndividualNaturalizationNumber= ");
		buffer.append(subjectIndividualNaturalizationNumber);
		buffer.append(sep);
		buffer.append("subjectIndividualUsPassportNumber= ");
		buffer.append(subjectIndividualUsPassportNumber);
		buffer.append(sep);
		buffer.append("subjectIndividualBirthAbroadCertificationNumber= ");
		buffer.append(subjectIndividualBirthAbroadCertificationNumber);
		buffer.append(sep);
		buffer.append("subjectIndividualIacNumber= ");
		buffer.append(subjectIndividualIacNumber);
		buffer.append(sep);
		buffer.append("subjectIndividualIacName= ");
		buffer.append(subjectIndividualIacName);
		buffer.append(sep);
		buffer.append("subjectIndividualIacCity= ");
		buffer.append(subjectIndividualIacCity);
		buffer.append(sep);
		buffer.append("subjectIndividualIacState= ");
		buffer.append(subjectIndividualIacState);
		buffer.append(sep);
		buffer.append("subjectIndividualIacStartDate= ");
		buffer.append(subjectIndividualIacStartDate);
		buffer.append(sep);
		buffer.append("subjectIndividualIacEndDate= ");
		buffer.append(subjectIndividualIacEndDate);
		buffer.append(sep);
		buffer.append("subjectIndividualAgentName= ");
		buffer.append(subjectIndividualAgentName);
		buffer.append(sep);
		buffer.append("subjectIndividualAgentId= ");
		buffer.append(subjectIndividualAgentId);
		buffer.append(sep);
		buffer.append("subjectIndividualAgentCity= ");
		buffer.append(subjectIndividualAgentCity);
		buffer.append(sep);
		buffer.append("subjectIndividualAgentState= ");
		buffer.append(subjectIndividualAgentState);
		buffer.append(sep);
		buffer.append("subjectIndividualAgentAssociatedIac= ");
		buffer.append(subjectIndividualAgentAssociatedIac);
		buffer.append(sep);
		buffer.append("subjectIndividualAgentStartDate= ");
		buffer.append(subjectIndividualAgentStartDate);
		buffer.append(sep);
		buffer.append("subjectIndividualAgentEndDate= ");
		buffer.append(subjectIndividualAgentEndDate);
		buffer.append(sep);
		buffer.append("subjectIndividualAcName= ");
		buffer.append(subjectIndividualAcName);
		buffer.append(sep);
        buffer.append("subjectIndividualAcCity= ");
		buffer.append(subjectIndividualAcCity);
		buffer.append(sep);
        buffer.append("subjectIndividualAcState= ");
		buffer.append(subjectIndividualAcState);
		buffer.append(sep);
        buffer.append("subjectIndividualAcStartDate= ");
		buffer.append(subjectIndividualAcStartDate);
		buffer.append(sep);
        buffer.append("subjectIndividualAcEndtDate= ");
		buffer.append(subjectIndividualAcEndtDate);
		buffer.append(sep);

		return buffer.toString();
	}
}
