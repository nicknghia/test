/**
 * Copyright (c) 2000-2002 NTELX
 *  All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with NTELX.
 *
 *
 *  $Header: /usr2/cvs/fdt/core/src/FDSuite/src/com/freightdesk/fdsuite/action/LogonAction.java,v 1.12.2.3.2.1.2.2.2.31 2010/10/04 15:52:33 mechevarria Exp $
 *
 *  Modification History:
 *  $Log: LogonAction.java,v $
 *  Revision 1.12.2.3.2.1.2.2.2.31  2010/10/04 15:52:33  mechevarria
 *  url encode the cookie to prevent non character stripping
 *
 *  Revision 1.12.2.3.2.1.2.2.2.30  2010/04/30 22:32:48  mechevarria
 *  remove bad button type
 *
 *  Revision 1.12.2.3.2.1.2.2.2.29  2010/04/08 22:07:42  mechevarria
 *  removed commented out code
 *
 *  Revision 1.12.2.3.2.1.2.2.2.28  2010/04/05 20:29:19  mechevarria
 *  updates
 *
 *  Revision 1.12.2.3.2.1.2.2.2.27  2010/03/22 20:12:45  mechevarria
 *  add additional loggin
 *
 *  Revision 1.12.2.3.2.1.2.2.2.26  2010/03/15 14:44:06  mechevarria
 *  add ip address to credentials
 *
 *  Revision 1.12.2.3.2.1.2.2.2.25  2010/03/15 13:46:12  mechevarria
 *  remove proprietary messages and add ip address to logging
 *
 *  Revision 1.12.2.3.2.1.2.2.2.24  2010/02/11 22:13:24  mechevarria
 *  add help page
 *
 *  Revision 1.12.2.3.2.1.2.2.2.23  2009/10/12 20:44:37  mechevarria
 *  fix for expirationdate
 *
 *  Revision 1.12.2.3.2.1.2.2.2.22  2009/10/02 19:49:14  mechevarria
 *  fix up english on exception logging
 *
 *  Revision 1.12.2.3.2.1.2.2.2.21  2009/05/08 20:33:32  mechevarria
 *  change logging of failed logins and removing some stack traces
 *
 *  Revision 1.12.2.3.2.1.2.2.2.20  2009/04/28 15:04:37  mechevarria
 *  remove unused axis1 called function
 *
 *  Revision 1.12.2.3.2.1.2.2.2.19  2009/03/18 20:18:56  jhansford
 *  Allowed users to see all events connect to their parent org id
 *
 *  Revision 1.12.2.3.2.1.2.2.2.18  2009/03/18 15:30:34  mechevarria
 *  checked in bad code..oops
 *
 *  Revision 1.12.2.3.2.1.2.2.2.17  2009/03/18 13:33:35  mechevarria
 *  add fas specific getCredentials
 *
 *  Revision 1.12.2.3.2.1.2.2.2.16  2009/03/16 16:59:41  mechevarria
 *  use methods in FDCommons instead of action
 *
 *  Revision 1.12.2.3.2.1.2.2.2.15  2009/03/12 18:29:28  mechevarria
 *  import optimization
 *
 *  Revision 1.12.2.3.2.1.2.2.2.14  2009/03/11 14:37:29  mechevarria
 *  removed encryption of userid parameter
 *
 *  Revision 1.12.2.3.2.1.2.2.2.13  2009/03/10 19:39:20  mechevarria
 *  add support for id passing in the url for cookie reading errors
 *
 *  Revision 1.12.2.3.2.1.2.2.2.12  2009/02/19 19:23:39  mechevarria
 *  use generic login error messages
 *
 *  Revision 1.12.2.3.2.1.2.2.2.11  2009/01/23 15:11:12  mechevarria
 *  updated code to be compatible with struts 1.3.10
 *
 *  Revision 1.12.2.3.2.1.2.2.2.10  2008/07/28 16:53:07  mechevarria
 *  fix bug where parentorgid were not loaded
 *
 *  Revision 1.12.2.3.2.1.2.2.2.9  2008/07/18 15:01:07  mechevarria
 *  additional session key for monitor if upgraded
 *
 *  Revision 1.12.2.3.2.1.2.2.2.8  2008/07/03 14:16:34  mechevarria
 *  added SSL and HTTPOnly options to cookies for FAS poam mitigation
 *
 *  Revision 1.12.2.3.2.1.2.2.2.7  2008/06/05 16:23:50  mechevarria
 *  fix logout error with corrupted credentials
 *
 *  Revision 1.12.2.3.2.1.2.2.2.6  2007/12/12 13:02:03  mechevarria
 *  import optimization
 *
 *  Revision 1.12.2.3.2.1.2.2.2.5  2007/12/11 20:19:55  mechevarria
 *  changed getParents() method to use bind variables in SQL statements
 *
 *  Revision 1.12.2.3.2.1.2.2.2.4  2007/12/07 20:45:44  mechevarria
 *  added rule to truncate usernames greater than 8 characters.  Changed login and logout messages to info level since login information is now recorded in the aync process log tables
 *
 *  Revision 1.12.2.3.2.1.2.2.2.3  2007/08/15 19:29:19  mechevarria
 *  added async logging on session logout
 *
 *  Revision 1.12.2.3.2.1.2.2.2.2  2007/08/13 19:19:14  mechevarria
 *  added more verbose async logging messages
 *
 *  Revision 1.12.2.3.2.1.2.2.2.1  2007/08/10 19:12:13  mechevarria
 *  added asyncprocesslog calls
 *
 *  Revision 1.12.2.3.2.1.2.2  2007/06/25 13:17:50  mechevarria
 *  warning supression and logon limit dictated in app.props
 *
 *  Revision 1.12.2.3.2.1.2.1  2007/06/12 15:20:37  mechevarria
 *  add calculation of number of days until password expiration
 *
 *  Revision 1.12.2.3.2.1  2007/06/07 12:52:15  mechevarria
 *  add tracking of numfailedlogin
 *
 *  Revision 1.12.2.3  2007/05/18 14:54:07  mechevarria
 *  implement new licensing code
 *
 *  Revision 1.12.2.2  2007/03/23 14:38:35  mechevarria
 *  change logon messages to warn level and consistent template
 *
 *  Revision 1.12.2.1  2007/03/19 13:19:13  mechevarria
 *  Added login blocking on 3 failed attempts.  Added separate error messages for invalid usernames and passwords.
 *
 *  Revision 1.12  2007/02/07 13:20:30  atripathi
 *  Message.jsp issue resolved ActionMessage used instead of ActionErrors
 *
 *  Revision 1.11  2007/02/05 14:00:20  atripathi
 *  Message.jsp genMsg issue resolved
 *
 *  Revision 1.10  2007/02/05 12:14:04  atripathi
 *  Message.jsp genMsg issue resolved.
 *
 *  Revision 1.9  2007/01/13 00:16:02  aarora
 *  Removed product specific code
 *
 *  Revision 1.8  2006/12/11 20:05:00  ranand
 *  Handle the case where user change the password when first time logged in
 *
 *  Revision 1.7  2006/10/11 12:30:42  ranand
 *  removed dependency on SYSTEMNAVIGATIONTYPE
 *
 *  Revision 1.6  2006/10/11 07:50:48  ranand
 *  removed dependency on USERSYSTEMROLE table
 *
 *  Revision 1.5  2006/10/11 07:32:39  nsehra
 *  changed FDMonitor to vActiveMonitor
 *
 *  Revision 1.4  2006/10/09 12:18:08  dkumar
 *  created seperate FDSuite properties
 *
 *  Revision 1.3  2006/09/07 16:36:07  dkumar
 *  changes DISABLE_AUTOLOGOUT to KEEP_ME_LOGGED_IN
 *
 *  Revision 1.2  2006/09/07 11:49:39  dkumar
 *  set Disable_AutoLogOut key when the user log in using  FDSuite cookie
 *  /clicks check box
 *
 *  Revision 1.1  2006/08/11 20:51:41  dkumar
 *  chages for making fdsuite struts based application
 *
 *  Revision 1.26  2006/07/18 20:16:53  aarora
 *  Corrected some comment and log
 *
 *  Revision 1.25  2006/06/12 23:00:55  aarora
 *  Removed unused vars
 *
 *  Revision 1.24  2006/06/09 09:59:38  dkumar
 *  new method setUserDashBoardTilesMap for setting dashboard tiles map in user credentials
 *
 *  Revision 1.23  2006/05/25 12:46:04  nsehra
 *  multiple login check
 *
 *  Revision 1.22  2006/05/11 22:19:15  aarora
 *  Moving to FDSuite
 *
 *  Revision 1.21  2006/05/11 16:55:27  aarora
 *  Many changes as the SessionKey class has been added to com.ntelx.fdfolio.commons
 *
 *  Revision 1.20  2006/05/07 22:04:52  aarora
 *  Added the concept of defaultProduct
 *
 *  Revision 1.19  2006/04/26 22:38:56  ranand
 *  removed the logging of the password and passpharse
 *
 *  Revision 1.18  2006/04/12 04:57:10  aarora
 *  organized imports
 *
 *  Revision 1.17  2006/03/28 21:23:00  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.16  2005/08/20 12:35:36  pjain
 *  DAO movement impact
 *
 *  Revision 1.15  2005/07/27 09:31:30  ranand
 *  Class name changed from LcpProperties to ApplicationProperties
 *
 *  Revision 1.14  2005/07/15 22:53:11  amrinder
 *  Removed the already logged in message, it does not add anything
 *
 *  Revision 1.13  2005/06/27 22:35:40  amrinder
 *  Now setting the locale while displaying page
 *
 *  Revision 1.12  2005/06/23 22:44:50  amrinder
 *  i18n related changes
 *
 *  Revision 1.11  2005/06/23 18:56:46  amrinder
 *  Better support for locales and sublocales
 *
 *  Revision 1.10  2005/04/25 05:24:53  pjain
 *  added condition for default product
 *
 *  Revision 1.9  2005/04/15 14:21:11  pjain
 *  forward to selected product
 *
 *  Revision 1.8  2005/02/25 22:12:31  amrinder
 *  Changed the logging for business exceptions to debug + e.  Consolidated different system exceptions into one heading
 *
 *  Revision 1.7  2005/02/10 20:26:41  amrinder
 *  Changed the logging to debug for business exceptions
 *
 *  Revision 1.6  2004/12/17 00:21:01  amrinder
 *  Minor change in log messages
 *
 *  Revision 1.5  2004/11/23 07:13:35  biju
 *  added last login timestamp update call
 *
 *  Revision 1.4  2004/10/20 04:03:19  amrinder
 *  Corrected the method name in logs
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 *  Revision 2.0  2015/04/30 13:51:45  bnguyen
 *  Upgrade from struts1 to struts2
 */

package com.ctu.tsa.fas.login.action;

import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.InvalidUserException;
import com.freightdesk.fdcommons.LicenseProperties;
import com.freightdesk.fdcommons.PasswordExpiredException;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.UserNotActiveException;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;
import com.opensymphony.xwork2.ActionSupport;

import crt.com.ntelx.fdsuite.common.RequestDetails;
import crt.com.ntelx.nxcommons.AuthenticationUtils;
import ctu.com.tsa.fas.ctu.Ctuuser;

import java.util.HashMap;

import javax.security.auth.login.AccountExpiredException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.ActionErrors;
import com.freightdesk.fdcommons.ActionMessage;
import com.freightdesk.fdcommons.ActionMessages;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.ServletActionContext;

import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import crt.com.freightdesk.fdfolio.setup.SystemMessageManager;

import org.apache.commons.lang.StringEscapeUtils;


public class LogonAction extends ActionSupport implements ServletRequestAware {

    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();
    
    private String username;
    private String password;
    Ctuuser ctuuser = new Ctuuser();
    private String domainName;
    private String myAction;
    private String messageText;
    private String faqTxt;
    private String loginTimeRoleMsg;
    private String btnLogin;
    private String plugins="";

    public String execute() throws Exception {
        request = ServletActionContext.getRequest();        		
        if (!hasValidLicense()) {
            logger.debug("License for NXsuite is not valid or expired, redirecting to login page");
            ActionErrors errors = new ActionErrors();
            errors.add(ActionMessages.GLOBAL_MESSAGE, new ActionMessage("error.licenseExpired"));
            return "licenseExpired";
        }
        
        // check if browser version is supported
	RequestDetails requestDetails = new RequestDetails(request);
	if (requestDetails.browserNotSupported()) {
            logger.debug(requestDetails);
            // forward to not supported page
            return "help";
        }
        
    	// invalidating any active sessions before display
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        
        // POAM HttpOnly Secure
        HttpServletResponse response = (HttpServletResponse)ServletActionContext.getResponse();
        String secure = "";
        if (request.isSecure()) {
          secure = "; Secure";
        }
        
        
        response.setHeader("SET-COOKIE", "JSESSIONID=" + request.getSession().getId()
                         + "; Path=" + request.getContextPath() + "; HttpOnly" + secure);      
        
        String action = request.getParameter("myAction");

		// plugins are handled separately.  do not invalidate the session.
        if ((action != null) && (action.equalsIgnoreCase("plugins"))) {
		    logger.info("preparing to display plugins page");
		    setBtnLogin(null);
			setPlugins(plugins);
		    return "display";
		}

        if ((action != null) && (action.equalsIgnoreCase("logout"))) {
            // Variables for ASYNCPROCESSINGLOG
            AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
            AsyncProcessManager asyncManager = new AsyncProcessManager();
            Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
            
            try {
		// Log session logouts in the ASYNCPROCESSINGLOG table
		asyncLogModel.init(credentials.getUserId(), credentials.getDomainName(), "LOGOUT", "SECURITY", "In process logout", request.getRemoteAddr());
		asyncLogModel = asyncManager.createAsyncProcessLog(asyncLogModel);
		// invalidates the session
		store.invalidateSessions(request);
		// record success in the ASYNCPROCESSINGLOG table
		asyncManager.logResult(asyncLogModel, true, "Successful logout of user " + "." + credentials.getUserId(), "respondBtnLogout");
            } catch (Exception ex) {
		asyncManager.logResult(asyncLogModel, false, "Failed logout of user, unable to read credentials", "Exception");		
            }
            // sends the user back to the login page
            
            return "input";
        }
        
        domainName = com.freightdesk.fdcommons.GlobalConstants.FAS_DOMAIN;
        String cred = username.trim() + "," + password.trim();
        if (session != null) {
            logger.debug("!! invalidating active session");
            store = SessionStore.getInstance(session);
            store.invalidateSessions(request);
        }
        
        ///starting the implementation for the forward page
        AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
        AsyncProcessManager asyncManager = new AsyncProcessManager();
        /**
         * The following try catch blocks are sequenced so that different error
         * conditions can be handled differently.
         */
        try {

            username = StringEscapeUtils.escapeHtml(getUsername().replaceAll("&lt;", "<").replaceAll("&quot;", "").replaceAll("&gt;", ">"));			
			password = StringEscapeUtils.escapeHtml(getPassword().replaceAll("&lt;", "<").replaceAll("&quot;", "").replaceAll("&gt;", ">"));
			
			// Record attempted logins in the ASYNCPROCESSINGLOG table
            asyncLogModel.init(username, domainName, "LOGIN",  "SECURITY", "In process login", request.getRemoteAddr());
            // add the browser details to the login
            requestDetails = new RequestDetails(request);
            asyncLogModel.setBrowser(requestDetails.getBrowser().toUpperCase());
            asyncLogModel.setBrowserVersion(requestDetails.getVersion());
            asyncLogModel = asyncManager.createAsyncProcessLog(asyncLogModel);           
            Credentials credentials = AuthenticationUtils.getCredentials(username, password, domainName, request.getRemoteAddr());
            session = request.getSession();

            // Record successful login in the ASYNCPROCESSINGLOG table
            asyncManager.logResult(asyncLogModel, true, "Successful login", "respondCredentials");
            // only for debugging purposes
            session.setAttribute("TimeUserLoggedIn", new java.util.Date());
            // Stores the credentials in the SessionStore
            if (credentials.getDateFormat() == null || credentials.getDateFormat().equals(""))
                credentials.setDateFormat("yyyy-MM-dd");

            store = SessionStore.getInstance(session);
            store.put(SessionKey.CREDENTIALS, credentials);
            // Stores the access list in the SessionStore
            HashMap<String, String> accessList = AuthenticationUtils.getNxRolePermissionList(credentials.getRole());
            store.put(SessionKey.ACCESS_CONTROL_LIST, accessList);
            
            loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);
            SystemMessageManager messageManager = SystemMessageManager.getInstance();
            messageText = messageManager.getMessageModel().getMessageText();
            faqTxt = messageManager.getMessageModel().getFaqTxt();
            
            if (credentials.getUserId() != null) {
			    username = credentials.getUserId();
                AuthenticationUtils.updateLastLoginTimestamp(credentials.getSystemUserId());
                
		        if (credentials.getLastLoginTime() == null) {
				   loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);
			       return "changePassword";
		        } else{
					return "success";
				}
				
            } else {
                return "error";
            }
        } // catches all exceptions and logs
        // all business exceptions are logged with logger.debug, system exceptions with logger.error
        catch (UserNotActiveException unaEx) {
            logger.info("UserAccess " + username + ". Login Error " + "User Not Active.");
            logger.error("respondBtnCredentials(): UserNotActiveException");
            asyncManager.logResult(asyncLogModel, false, "Failed login due to user not being active.", "UserNotActiveException");
			addActionError(getText("error.login.userNotActive"));
        } catch (PasswordExpiredException peEx) {
            logger.info("UserAccess " + username + ". Login Error " + "Password Expired.");
            logger.error("threw PasswordExpiredException");
            asyncManager.logResult(asyncLogModel, false, "Failed login due to password expiration.", "PasswordExpiredException");
			addActionError(getText("jsp.login.message"));
        } catch (InvalidUserException ivEx) {
            if (ivEx.getMessage().equals("-1")) {			    		        
                setUsername(StringEscapeUtils.escapeHtml(getUsername().replaceAll("&lt;", "").replaceAll("&quot;", "").replaceAll("&gt;", "")));	
				
				logger.info("UserAccess " + username + ". Login Error " + "username Does Not Exist.");
                asyncManager.logResult(asyncLogModel, false, "Failed login due to unknown user id.", "InvalidUserException");
				addActionError(getText("error.login.generic"));
            } else {
				username = getUsername();						        		        
                setPassword(StringEscapeUtils.escapeHtml(getPassword().replaceAll("&lt;", "").replaceAll("&quot;", "").replaceAll("&gt;", "")));
		        
                logger.debug("UserAccess " + username + ". Login Error " + "Invalid Password.");
                asyncManager.logResult(asyncLogModel, false, "Failed login due to invalid password.", "InvalidUserException");
				addActionError(getText("error.login.generic"));
            }
        } catch (AccountExpiredException auEx) {
            logger.error("UserAccess " + username + ". Login Error " + "Account Locked.");
            asyncManager.logResult(asyncLogModel, false, "Failed login due to excessive failed login attempts.", "AccountExpiredException");
			addActionError(getText("error.login.failedLoginExceeded"));
        } catch (RuntimeException ex) {
            logger.error("respondBtnCredentials(): ConnectionException", ex);
            asyncManager.logResult(asyncLogModel, false, "Failed login due to runtime exception.", "RuntimeException");
			addActionError(getText("error.login.connectionFailed"));
        } catch (Exception systemException) {		    		    
		    setUsername(StringEscapeUtils.escapeHtml(getUsername().replaceAll("&lt;", "").replaceAll("&quot;", "").replaceAll("&gt;", "")));			
			setPassword(StringEscapeUtils.escapeHtml(getPassword().replaceAll("&lt;", "").replaceAll("&quot;", "").replaceAll("&gt;", "")));

            logger.error("respondBtnCredentials(): SystemException", systemException);
            asyncManager.logResult(asyncLogModel, false, "Failed login due to system exception.", "systemException");
			addActionError(getText("error.login.generic"));
        }

		return "display";

    }
	
	public String getPlugins() {
        return plugins;
    }

    public void setPlugins(String plugins) {
        this.plugins = plugins;
    }
	
	public String getBtnLogin () {return btnLogin;}
    public void setBtnLogin (String btnLogin) {this.btnLogin = btnLogin;}

    public boolean hasValidLicense() {
        return LicenseProperties.isProductLicensed("FDSuite");
    }

    public void validate() {        
    }

    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }

    public Ctuuser getModel() {
        return ctuuser;
    }

    public Ctuuser getCtuuser() {
        return ctuuser;
    }

    public void setCtuuser(Ctuuser ctuuser) {
        this.ctuuser = ctuuser;
    }
        	
	public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }
    	
	public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public String getDomainName() {
        return domainName;
    }

    public void setDomainName(String domainName) {
        this.domainName = domainName;
    }
    
    public String getFaqTxt() {
        if (faqTxt == null)
	{
            this.faqTxt = "";
	}
		
	return faqTxt;
    }
    
    public void setFaqTxt(String faqTxt) {
	this.faqTxt = faqTxt;
    }
        
    public String getMessageText() {
	return messageText;
    }
        
    public void setMessageText(String messageText) {
	this.messageText = messageText; 
    }
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
    
    public String getMyAction() {
        return myAction;
    }

    public void setMyAction(String myAction) {
        this.myAction = myAction;
    }
    
    public void setActionMessage(HttpServletRequest request, String[] messageKeyObject) {
        int length = messageKeyObject.length;
        logger.debug("messageKeyObject.length = " + length);
        ActionMessage actionMessage = null;
        switch (length) {
            case 2:
                logger.debug("messagekeyvalues" + messageKeyObject[0]);
                actionMessage = new ActionMessage(messageKeyObject[0], (Object) messageKeyObject[1]);
                break;
            case 3:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2]);
                break;
            case 4:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3]);
                break;
            case 5:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3], messageKeyObject[4]);
                break;
            default:
                actionMessage = new ActionMessage(messageKeyObject[0]);
        }

        ActionMessages messages = new ActionMessages();
        messages.add(ActionMessages.GLOBAL_MESSAGE, actionMessage);

        logger.debug("message has been set on request");
    }
}
