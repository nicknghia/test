/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.common;
import java.io.Serializable;
import java.util.Comparator;

import org.apache.log4j.Logger;
import com.ctu.tsa.fas.expandedsearch.model.ShipperModel;

/**
 *
 * @author Kevin.Tsou
 */
public class ShipperComparator implements Comparator<ShipperModel>, Serializable{
    private static final long serialVersionUID = 1L;

    private Logger logger = Logger.getLogger(ShipperComparator.class);
    private boolean ascending;
    private String colName;
    
    public ShipperComparator(String colName, boolean ascending) {
	this.ascending = ascending;	
	this.colName = colName;
    }
    
    @SuppressWarnings("unchecked")
    public int compare(ShipperModel o1, ShipperModel o2) {
        int result = 0;
        		
        try {
            Object value1 = null;
            Object value2 = null;
            
            if (colName.equalsIgnoreCase("shipperName")) {
		      value1 = o1.getShipperName();
		      value2 = o2.getShipperName();			  
            } else if (colName.equalsIgnoreCase("shipperType")) {
		      value1 = o1.getShipperType();
              value2 = o2.getShipperType();			  
            } else if (colName.equalsIgnoreCase("shipperId")) {
		      value1 = o1.getShipperId();
              value2 = o2.getShipperId();		  
            } else if (colName.equalsIgnoreCase("shipperStatus")) {
		      value1 = o1.getShipperStatus();
		      value2 = o2.getShipperStatus();			  
            } else if (colName.equalsIgnoreCase("iacNumber")) {
		      value1 = o1.getIacNumber();
		      value2 = o2.getIacNumber();			  
            }else if (colName.equalsIgnoreCase("iacAcCompanyName")) {
		      value1 = o1.getIacAcCompanyName();
		      value2 = o2.getIacAcCompanyName();			  
            }
            else {
		      logger.warn("Could not map " + colName + " to class attribute");
            }
            
            // Null is lesser than anything else.
            if ((value1 == null) && (value2 == null)) {
		       result = 0;
            } else if ((value1 == null) && (value2 != null)) {
		       result = -1;
            } else if ((value1 != null) && (value2 == null)) {
		       result = 1;
            } else if (value1 instanceof Comparable) {
		    // the attribute values are Comparable, we have hit the JackPot.  We have absolutely nothing intelligent to do
		      @SuppressWarnings("rawtypes")
		      Comparable comp1 = (Comparable) value1;
		      @SuppressWarnings("rawtypes")
		      Comparable comp2 = (Comparable) value2;
		      result = comp1.compareTo(comp2);
            } else {
		       logger.warn("Dont know how to sort by " + colName);
            }
			
            if (!ascending) {
		       result = 0 - result;
            }			
        }    			
        catch (Exception ex) {
            logger.error("Exception : " + ex.getMessage());
	} 	
    return result;
	
    }
}
