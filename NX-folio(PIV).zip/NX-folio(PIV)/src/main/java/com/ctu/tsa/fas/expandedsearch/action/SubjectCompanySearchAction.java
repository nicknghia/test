/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.action;

import javax.servlet.http.HttpServletRequest;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import javax.servlet.http.HttpSession;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.log4j.Logger;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.ServletActionContext;
import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import java.util.List;
import java.util.ArrayList;
import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchSubjectCompanyDAO;
import com.ctu.tsa.fas.expandedsearch.model.SubjectCompanyDetails;
import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.LcpConstants;
import java.util.Map;
import java.util.HashMap;
import java.sql.*;
import java.util.Collections;
import java.util.Iterator;
import org.json.JSONArray;
import org.json.JSONObject;
import com.freightdesk.fdcommons.ApplicationTabs;
/**
 *
 * @author STCI
 */
public class SubjectCompanySearchAction extends ActionSupport implements ServletRequestAware {

    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();    
    private String loginTimeRoleMsg;
    private String expandedSearchType = "";
    private String basicBtnClicked = "";
    private List<String> searchTypeList = new ArrayList<>();
    private String subjectCompanyName = "";
    private String subjectCompanyId = "";
    private String partyId = "";
    
    private List<Map> subjectCompanyListMap;
    private List<Map> subjectCompanyList;
    private List<Map> iacList;
    private List<Map> acList;
    private List<Map> stationList;
    private List<Map> agentList;

    private long recordCount = 0;
    private String pagerOffset;
    private int noOfSubjectCompanyRecordsToLoad = 5000;
    private String noOfSubjectCompanyRecordsToLoadStr;   
       
    private int pageSize = 25;

    private HttpSession session = null;
    private SessionStore sessionStore = null;

    private long[] elapsedTime = new long[4];
    private Runtime runtime = Runtime.getRuntime();
	private String debugMsg = null;
    
    

    @Override
    public String execute() throws Exception {

        logger.info("SubjectCompanySearchAction-execute");
        elapsedTime[0] = System.currentTimeMillis();
        
        request = ServletActionContext.getRequest();
        
        session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        final ExpandedSearchSubjectCompanyDAO dao = new ExpandedSearchSubjectCompanyDAO();
        List<SubjectCompanyDetails> subjectCompanyDetails = new ArrayList<SubjectCompanyDetails>();
        ResultSet searchResultSet;
        

        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials) + "<br>" + IncludesUtil.getExpireMsg(credentials);       
        
        sessionStore = SessionStore.getInstance(request.getSession());
        sessionStore.put(SessionKey.CURRENT_TAB, ApplicationTabs.EXPANDEDSEARCH);
		
        try {            
            noOfSubjectCompanyRecordsToLoad = 100;
            noOfSubjectCompanyRecordsToLoadStr = Integer.toString(noOfSubjectCompanyRecordsToLoad);
        } catch (Exception ignored) {
            logger.debug("ADDRESSBOOK_MAXIMUM_RESULTS property is not set, defaulting to 100 " + ignored);
        }

        setNoOfSubjectCompanyRecordsToLoad(getNoOfSubjectCompanyRecordsToLoad());
       
        searchTypeList = initSearchTypeList(searchTypeList);
        
        
        if (getSubjectCompanyName().length() < 3){
            sessionStore.put(SessionKey.SubjectCompany_LIST, Collections.emptyList());
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(0) );
            addFieldError("userDetailsErrorsHeader", getText("errors.header"));
            addActionError("Minimum of 3 alphanumeric characters must be entered in the search field");
            return "displaySubjectCompany";
        } 
        
        setSubjectCompanyName(getSubjectCompanyName().toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt"));
        
        if (!getSubjectCompanyName().trim().equals("")) {
        	
            sessionStore.put(SessionKey.SubjectCompany_LIST, Collections.emptyList());

            logger.info("INITIAL ----SujectCompanySearchAction - getSubjectCompanyByName1234: " + getSubjectCompanyName());
            
	        Thread thread1 = new Thread() {
	            public void run() {
                        try {
                                ExpandedSearchSubjectCompanyDAO dao = ExpandedSearchSubjectCompanyDAO.getInstance();
            			elapsedTime[1] = System.currentTimeMillis();
                                iacList = dao.getSubjectCompanyByName1234(getSubjectCompanyName(), "EGOV_IAC.FAS_SUBJECT_COMPANY.SEL_REC_BY_NAME_SUMMARY_1");

                                logger.info("----getSubjectCompanyIac :" + (System.currentTimeMillis() - elapsedTime[1]));
	            	}
	                  catch (Exception e) {
	                	  logger.error("t1:" + e.getMessage());
	                  }
	            }
	        };
	        
	        Thread thread2;
            thread2 = new Thread() {
                public void run() {
                    try {
                        ExpandedSearchSubjectCompanyDAO dao = ExpandedSearchSubjectCompanyDAO.getInstance();
                        elapsedTime[2] = System.currentTimeMillis();
                        acList = dao.getSubjectCompanyByName1234(getSubjectCompanyName(), "EGOV_IAC.FAS_SUBJECT_COMPANY.SEL_REC_BY_NAME_SUMMARY_2");
                        
                        logger.info("----getSubjectCompanyAc :" + (System.currentTimeMillis() - elapsedTime[2]));
                    }
                    catch (Exception e) {
                        logger.error("t2:" + e.getMessage());
                    }
                }
            };
	        
	        Thread thread3 = new Thread() {
	            public void run() {
                        try {
                            ExpandedSearchSubjectCompanyDAO dao = ExpandedSearchSubjectCompanyDAO.getInstance();
                            elapsedTime[3] = System.currentTimeMillis();
	                    stationList = dao.getSubjectCompanyByName1234(getSubjectCompanyName(), "EGOV_IAC.FAS_SUBJECT_COMPANY.SEL_REC_BY_NAME_SUMMARY_3");

	                    logger.info("----getSubjectCompanyStation :" + (System.currentTimeMillis() - elapsedTime[3]));
	            	}
	                  catch (Exception e) {
	                	  logger.error("t3:" + e.getMessage());
	                  }
	            }
	        };
	        
	        Thread thread4 = new Thread() {
	            public void run() {
                        try {
                            ExpandedSearchSubjectCompanyDAO dao = ExpandedSearchSubjectCompanyDAO.getInstance();
                            elapsedTime[0] = System.currentTimeMillis();
	                    agentList = dao.getSubjectCompanyByName1234(getSubjectCompanyName(), "EGOV_IAC.FAS_SUBJECT_COMPANY.SEL_REC_BY_NAME_SUMMARY_4");

	                    logger.info("----getSubjectCompanyAgent :" + (System.currentTimeMillis() - elapsedTime[0]));
	            		}
	                  catch (Exception e) {
	                	  logger.error("t4:" + e.getMessage());
	                  }
	            }
	        };
	        
	        
            // Start the threads
            thread1.start();
            thread2.start();
            thread3.start();
            thread4.start();

            // Wait for them to finish
            try {
                thread1.join();
                thread2.join();
                thread3.join();
                thread4.join();
        	}
            catch (Exception e) {
          	  logger.error("threads join:" + e.getMessage());
            }
                        
            subjectCompanyList = iacList;
            logger.info("SujectCompanySearchAction - iacList: " + iacList.size());
            subjectCompanyList.addAll(acList);
            logger.info("SujectCompanySearchAction - acList: " + acList.size());
            subjectCompanyList.addAll(stationList);
            logger.info("SujectCompanySearchAction - stationList: " + stationList.size());
            subjectCompanyList.addAll(agentList);
            logger.info("SujectCompanySearchAction - agentList: " + agentList.size());
            
            
            subjectCompanyListMap = convertToSubjectCompanyListMap(subjectCompanyList);
            
            setRecordCount(subjectCompanyList.size());

            sessionStore.put(SessionKey.SubjectCompany_LIST, subjectCompanyList);
            sessionStore.put(SessionKey.TOTAL_COUNT, new Long(getRecordCount()));
            session.setAttribute("SUB_LIST", convertMapListToJsonString(subjectCompanyList));
        } 
        if (getSubjectCompanyName().trim().equals("")) {
            subjectCompanyList = new ArrayList<Map>();
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(getRecordCount()));
            sessionStore.put (SessionKey.SubjectCompany_LIST, subjectCompanyList); 
            session.setAttribute("SUB_LIST", convertMapListToJsonString(subjectCompanyList));
            addFieldError("userDetailsErrorsHeader", getText("errors.header"));
            addActionError("Company name cannot be blank.");
            return "displaySubjectCompany";
        } 
        
        return toDisplay(elapsedTime[0]);
    }

    
    private String toDisplay(long startTime) {
		debugMsg = "SUBJECT COMPANY **** Memory used: " + (runtime.totalMemory() - runtime.freeMemory())/1000 + " Elapsed Time :" + (System.currentTimeMillis() - startTime);
		logger.info(debugMsg);
	    session.setAttribute("DEBUG_MSG", debugMsg);        
        
        return "displaySubjectCompany";

    }
    
    public String respondBtnSearchTypeReturn() throws java.lang.Exception {

        logger.info("SubjectCompanySearchAction-respondBtnSearchTypeReturn");

        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials) + "<br>" + IncludesUtil.getExpireMsg(credentials);

        logger.debug("Starting respondBtnSearchTypeReturn ");
        logger.info("Starting respondBtnSearchTypeReturn ");
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());

        return "display";
    }

    public String getExpandedSearchType() {
        return expandedSearchType;
    }

    public void setExpandedSearchType(String expandedSearchType) {
        this.expandedSearchType = expandedSearchType;
    }

    public String getSubjectCompanyName() {
        return subjectCompanyName.toUpperCase();
    }

    public String getSubjectCompanyId() {
        return subjectCompanyId.toUpperCase();
    }

    public void setSubjectCompanyName(String subjectCompanyName) {
        this.subjectCompanyName = subjectCompanyName;
    }

    public void setSubjectCompanyId(String subjectCompanyId) {
        this.subjectCompanyId = subjectCompanyId;
    }

    public List<String> getSearchTypeList() {
        return searchTypeList;
    }

    public void setSearchTypeList(List<String> searchTypeList) {
        this.searchTypeList = searchTypeList;
    }

    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }

    @Override
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }

    public String getBasicBtnClicked() {
        return basicBtnClicked;
    }

    public void setBasicBtnClicked(String basicBtnClicked) {
        this.basicBtnClicked = basicBtnClicked;
    }

    public long getRecordCount() {
        return recordCount;
    }

    public void setRecordCount(long recordCount) {
        this.recordCount = recordCount;
    }

    private List<String> initSearchTypeList(List<String> inSearchTypeList) {
        inSearchTypeList = new ArrayList<>();
        inSearchTypeList.add("Subject Company");
        inSearchTypeList.add("CCSF");
        inSearchTypeList.add("IAC");
        inSearchTypeList.add("Shipper");
        inSearchTypeList.add("Subject Individual");

        return inSearchTypeList;
    }

    public List<Map> getSubjectCompanyListMap() {
        return subjectCompanyListMap;
    }

    public void setSubjectCompanytMap(List<Map> subjectCompanyListMap) {
        this.subjectCompanyListMap = subjectCompanyListMap;
    }

    public List<Map> getSubjectCompanyList() {
        return subjectCompanyList;
    }

    public void setSubjectCompanyList(List<Map> subjectCompanyList) {
        this.subjectCompanyList = subjectCompanyList;
    }

    public String getPagerOffset() {
        return pagerOffset;
    }

    public void setPagerOffset(String pagerOffset) {
        this.pagerOffset = pagerOffset;
    }

    private String convertMapListToJsonString(List<Map> list) {

		JSONArray ja = new JSONArray();
	    JSONObject jo = null;
		String dataStr = null;
	
	    try {
	        if (null != list && !list.isEmpty()) {
	
				for (Map<String, String> map : list) {
			      jo = new JSONObject();
			      for (Map.Entry<String, String> entry : map.entrySet()) {
			    	  jo.put(entry.getKey(), entry.getValue());
			      }
			      ja.put (jo);
	           }
				dataStr = ja.toString ();				
	        }
	    } catch(Exception e) {
	      logger.error ("Exception JSON conversion" + e);
	    }
	    return dataStr;
    
    }
    
    List<Map> convertToSubjectCompanyListMap(List<Map> theSubjectCompanyList) {

        int starting_idx = 0;
        List<Map> theSubjectCompanyListMap;

        if (request.getParameter("pager.offset") != null) {
            starting_idx = Integer.parseInt((String) request.getParameter("pager.offset"));
        }

    	logger.info(starting_idx + ":---convertToSubjectCompanyListMap--:" + pageSize);
    	
        // display current page
    	theSubjectCompanyListMap = theSubjectCompanyList.subList(starting_idx, Math.min(starting_idx + pageSize, theSubjectCompanyList.size()));
    	logger.info(":---theSubjectCompanyListMap size--:" + theSubjectCompanyListMap.size());

    return theSubjectCompanyListMap;
    }     

    public void setNoOfSubjectCompanyRecordsToLoad(int noOfSubjectCompanyRecordsToLoad) {
        this.noOfSubjectCompanyRecordsToLoad = noOfSubjectCompanyRecordsToLoad;
    }

    public int getNoOfSubjectCompanyRecordsToLoad() {
        return noOfSubjectCompanyRecordsToLoad;
    }       
   

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public String getPartyId() {
        return (this.partyId);
    }
    
}
