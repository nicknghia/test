/**
 * Copyright (c) NTELX
 *  All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with NTELX.
 *
 *
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/reports/action/ReportHomeAction.java,v 1.21.4.3 2010/12/01 21:57:01 mechevarria Exp $
 *
 *  Modification History:
 *  $Log: ReportHomeAction.java,v $
 */

package com.ctu.tsa.fas.dashboard.action;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Iterator;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.freightdesk.fdcommons.ApplicationTabs;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.OperationInfo;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.StackManager;
import com.ctu.tsa.fas.dashboard.common.DashboardReportProperties;
import com.freightdesk.fdcommons.reporting.ReportXML;
import com.freightdesk.fdcommons.reporting.ReportsUtil;
import com.freightdesk.fdcommons.reporting.ReportsXML;

import javax.servlet.http.HttpSession;

import crt.com.freightdesk.fdfolio.common.IncludesUtil;

import com.freightdesk.fdcommons.ObjectLock;
import com.freightdesk.fdcommons.FDSuiteProperties;
import com.freightdesk.fdcommons.SystemUnavailableException;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;

import com.opensymphony.xwork2.ActionSupport;


/**
 * Struts Action class which is used to handle all requests coming to/from
 * Report Home Page.  It is the struts Action class associated with
 * ReportHome.jsp and the ReportHomeForm.
 *
 * @author Mike Echevarria
 */
public class DashboardReportHomeAction extends ActionSupport implements ServletRequestAware {    
    private Map reportsMap;
    private String domainName;
    private String configFile;
    private String beginDate;
    private String endDate;
    private String generateReport;
    private String count;
    private String fileName;
    private String[] name;
    private String[] type;
    private String[] label;
    private String[] value;
    private String reportName;
    private List inputFieldsList;
    
    protected ReportsUtil reportsUtil = new ReportsUtil();

    private String loginTimeRoleMsg;
    HttpServletRequest request = ServletActionContext.getRequest();
    protected Logger logger = Logger.getLogger(getClass());
	
    public String execute() throws Exception {
        logger.debug("entering Dashboard report home");
             
        return initPage();
    }
    
    public String initPage() throws Exception {
        logger.debug("begin");
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession();
        SessionStore sessionStore = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) sessionStore.get(SessionKey.CREDENTIALS);
        
        // POAM HttpOnly Secure
        HttpServletResponse response = (HttpServletResponse)ServletActionContext.getResponse();
        String secure = "";
        if (request.isSecure())
        {
          secure = "; Secure";
        }
        response.setHeader("SET-COOKIE", "JSESSIONID=" + request.getSession().getId()
                         + "; Path=" + request.getContextPath() + "; HttpOnly" + secure);

        
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);
        // Clears the state
        clearState(request);

        DashboardReportProperties reportProps = DashboardReportProperties.getInstance();
        ReportsXML reportsXML = reportProps.getReportsXML();

        String roleCode = (String) credentials.getRole();
        List<ReportXML> reports = reportsXML.getReportXMLByRole(roleCode);

        Map<String, List<ReportXML>> categoryReports = reportsUtil.groupReportByCategory(reports);
        setReportsMap(categoryReports);
        
        sessionStore.put(SessionKey.REPORT_MAP, categoryReports);
        // Sets the tab to Reports
        sessionStore.put(SessionKey.CURRENT_TAB, ApplicationTabs.DASHBOARD);
        // creates a stack manager, and puts that in the session store
        StackManager stackManager = new StackManager();
        stackManager.createEvent(new OperationInfo("reportHome", "ReportHome", "display", "", "", "", ""));
        sessionStore.put(SessionKey.STACK, stackManager);
        
	return displayPage();
    }


    /**
     * The display method - called when ReportHome.jsp has to be displayed.
     *
     * @param mapping            The ActionMapping used to select this instance
     * @param reportHomeForm     ReportHomeForm
     * @param request            The HTTP request we are processing
     * @param response           The HTTP response we are creating
     * @param credentials        user information
     */
    public String displayPage() throws Exception {
        logger.info("displayPage(): begin");
        HttpSession session = request.getSession();
        SessionStore sessionStore = SessionStore.getInstance(session);      

        return "display";
    }
	
    protected final void clearState(HttpServletRequest request) {
        // clear any state info from request and session
        logger.info ("clearState(): begin");
        HttpSession session = request.getSession();
        SessionStore sessionStore = SessionStore.getInstance (session);
        Credentials credentials = (Credentials)sessionStore.get(SessionKey.CREDENTIALS);
        if (credentials != null)
        {
           ObjectLock objectLock = (ObjectLock)sessionStore.get(SessionKey.OBJECT_LOCK);
            if (objectLock != null)
            {   logger.info("Object lock is not null");
                objectLock.releaseAllLocksForUser(credentials.getSystemUserId());
            }
        }
        sessionStore.retainOnlyGeneralKeys();
        if ("SE".equals(FDSuiteProperties.getProperty("system.availability.status"))) {
            throw new SystemUnavailableException("SE");
        }
    }
	
	public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
	
	public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }        

	/**
	 * Returns the reportsMap.
	 * @return Map
	 */
	public Map getReportsMap() {
		return reportsMap;
	}


	/**
	 * Sets the reportsMap.
	 * @param reportsMap The reportsMap to set
	 */
	public void setReportsMap(Map reportsMap) {
		this.reportsMap = reportsMap;
	}


	/**
	 * Returns the configFile.
	 * @return String
	 */
	public String getConfigFile() {
		return configFile;
	}
	
	
	/**
	 * Sets the configFile.
	 * @param configFile The configFile to set
	 */
	public void setConfigFile(String configFile) {
		this.configFile = configFile;
	}
	
	/**
	 * Returns the fileName.
	 * @return String
	 */
	public String getFileName() {
		return fileName;
	}
	
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}

    /**
     * Returns the beginDate.
     * @return String
     */
    public String getBeginDate() {
        return beginDate;
    }

    /**
     * Returns the endDate.
     * @return String
     */
    public String getEndDate() {
        return endDate;
    }

    /**
     * Returns the submit.
     * @return String
     */
    public String getGenerateReport() {
        return generateReport;
    }

    /**
     * Sets the beginDate.
     * @param beginDate The beginDate to set
     */
    public void setBeginDate(String beginDate) {
        this.beginDate = beginDate;
    }

    /**
     * Sets the endDate.
     * @param endDate The endDate to set
     */
    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    /**
     * Sets the submit.
     * @param submit The submit to set
     */
    public void setGenerateReport(String argGenerateReport) {
        this.generateReport = argGenerateReport;
    }

    /** 
     * This method resets all bean properties to their default state. It is 
     * called before the properties are repopulated by the Action Class. 
     *
     * @param mapping        The ActionMapping used to select this instance
     * @param request        The HTTP request we are processing
     *
     */  
    public void reset(){                          
        reportsMap = null;
        configFile  = null;
        fileName=null;
        beginDate = null;
        endDate = null;
        generateReport = null;
        name = null;
        type = null;
        label = null;
        count = null;
        inputFieldsList = null;
    }

	/**
	 * Returns the label.
	 * @return String[]
	 */
	public String[] getLabel() {
		return label;
	}

	/**
	 * Returns the name.
	 * @return String[]
	 */
	public String[] getName() {
		return name;
	}

	/**
	 * Returns the type.
	 * @return String[]
	 */
	public String[] getType() {
		return type;
	}

	/**
	 * Sets the label.
	 * @param label The label to set
	 */
	public void setLabel(String[] label) {
		this.label = label;
	}

	/**
	 * Sets the name.
	 * @param name The name to set
	 */
	public void setName(String[] name) {
		this.name = name;
	}

	/**
	 * Sets the type.
	 * @param type The type to set
	 */
	public void setType(String[] type) {
		this.type = type;
	}

	/**
	 * Returns the count.
	 * @return String
	 */
	public String getCount() {
		return count;
	}

	/**
	 * Sets the count.
	 * @param count The count to set
	 */
	public void setCount(String count) {
		this.count = count;
	}

	/**
	 * Returns the parameterList.
	 * @return List
	 */
	public List getInputFieldsList() {
		return inputFieldsList;
	}

	/**
	 * Sets the parameterList.
	 * @param parameterList The parameterList to set
	 */
	public void setInputFieldsList(List parameterList) {
		inputFieldsList = parameterList;
	}

	/**
	 * Returns the reportName.
	 * @return String
	 */
	public String getReportName() {
		return reportName;
	}

	/**
	 * Sets the reportName.
	 * @param reportName The reportName to set
	 */
	public void setReportName(String reportName) {
		this.reportName = reportName;
	}

	/**
	 * Returns the domainName.
	 * @return String
	 */
	public String getDomainName() {
		return domainName;
	}

	/**
	 * Sets the domainName.
	 * @param domainName The domainName to set
	 */
	public void setDomainName(String domainName) {
		this.domainName = domainName;
	}

	/**
	 * @return Returns the value.
	 */
	public String[] getValue() {
		return value;
	}
	/**
	 * @param value The value to set.
	 */
	public void setValue(String[] value) {
		this.value = value;
	}
	   
        public void printReportsMap(Map rptMap) {
            String str;
            List<ReportXML> rptXmlList = new ArrayList<ReportXML>();
            Map<String, List<ReportXML>> myReports = rptMap;
            Iterator entries = rptMap.entrySet().iterator();
            while (entries.hasNext()) {
                Map.Entry entry = (Map.Entry) entries.next();
                str = (String) entry.getKey();
                rptXmlList = (List<ReportXML>)entry.getValue();
                
                {
                    ReportXML rptXml;
                    Iterator itrList = rptXmlList.iterator();
                    while (itrList.hasNext()){
                        rptXml = (ReportXML)itrList.next();
						logger.info(" CAT=" + rptXml.getCategory() + " confF=" + rptXml.getConfigFile() + " fName=" + rptXml.getFileName());
                        logger.info(" name=" + rptXml.getName() + " sFmt=" + rptXml.getSelectedFormat() + " fmt=" + rptXml.getFormats());
                        logger.info(" param" + rptXml.getParams() + " roles=" + rptXml.getRoles());												
                    }
                }
            }
            return;
	}
}

