/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.common;
import java.io.Serializable;
import java.util.Comparator;

import org.apache.log4j.Logger;
import com.ctu.tsa.fas.expandedsearch.model.SubjectIndividualAcModel;

/**
 *
 * @author Binh.Nguyen
 */
public class SubjectIndividualAcComparator implements Comparator<SubjectIndividualAcModel>, Serializable{
    private static final long serialVersionUID = 11L;

    private Logger logger = Logger.getLogger(SubjectIndividualAcComparator.class);
    private boolean ascendingAc;
    private String colName;
    
    public SubjectIndividualAcComparator(String colName, boolean ascendingAc) {
	this.ascendingAc = ascendingAc;
	this.colName = colName;
    }
    
    @SuppressWarnings("unchecked")
    public int compare(SubjectIndividualAcModel o1, SubjectIndividualAcModel o2) {
        int result = 0;
        
      try {
            Object value1 = null;
            Object value2 = null;
            
        if (colName.equalsIgnoreCase("subjectIndividualAcName")) {
		   value1 = o1.getSubjectIndividualAcName();
		   value2 = o2.getSubjectIndividualAcName();
        } else if (colName.equalsIgnoreCase("subjectIndividualAcCity")) {
		   value1 = o1.getSubjectIndividualAcCity();
		   value2 = o2.getSubjectIndividualAcCity();
        } else if (colName.equalsIgnoreCase("subjectIndividualAcState")) {
		   value1 = o1.getSubjectIndividualAcState();
		   value2 = o2.getSubjectIndividualAcState();
		} else if (colName.equalsIgnoreCase("subjectIndividualAcStartDate")) {
		   value1 = o1.getSubjectIndividualAcStartDate();
		   value2 = o2.getSubjectIndividualAcStartDate();
        } else if (colName.equalsIgnoreCase("subjectIndividualAcEndtDate")) {
		   value1 = o1.getSubjectIndividualAcEndtDate();
		   value2 = o2.getSubjectIndividualAcEndtDate();	
        } else {
		logger.warn("Could not map " + colName + " to class attribute");
        }
            
        // Null is lesser than anything else.
        if ((value1 == null) && (value2 == null)) {
		       result = 0;            
        } else if (value1 instanceof Comparable) {
		    // the attribute values are Comparable, we have hit the JackPot.  We have absolutely nothing intelligent to do
		      @SuppressWarnings("rawtypes")
		      Comparable comp1 = (Comparable) value1;
		      @SuppressWarnings("rawtypes")
		      Comparable comp2 = (Comparable) value2;
		      result = comp1.compareTo(comp2);
        } else {
		       logger.warn("Dont know how to sort by " + colName);
        }

        if (!ascendingAc) {
		result = 0 - result;
        }
      }
      catch (Exception ex) {
            //ex.printStackTrace();
            logger.error("Exception : " + ex.getMessage());
	 }
        return result;
    }
}
