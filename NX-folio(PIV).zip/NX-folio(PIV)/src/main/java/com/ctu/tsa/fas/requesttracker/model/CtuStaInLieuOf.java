
package com.ctu.tsa.fas.requesttracker.model;

import java.io.Serializable;
import java.sql.Timestamp;

public class CtuStaInLieuOf implements Serializable {

    private static final long serialVersionUID = -1106831298967580942L;

    private int staInLieuOfId;
    private String staInLieuOfType;
    private String description;
    private String createUserId;
    private Timestamp createtimestamp;
    private String lastUpdateuserId;
    private Timestamp lastUpdateTimestamp;

    public CtuStaInLieuOf() {

    }

    public CtuStaInLieuOf(int staInLieuOfId, String staInLieuOfType, String description, String createUserId, String lastUpdateuserId, Timestamp createtimestamp) {
        this.staInLieuOfId = staInLieuOfId;
        this.staInLieuOfType = staInLieuOfType;
        this.description = description;
        this.createUserId = createUserId;
        this.lastUpdateuserId = lastUpdateuserId;
        this.createtimestamp = createtimestamp;

    }

    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getStaInLieuOfId() {
        return staInLieuOfId;
    }

    public void setStaInLieuOfId(int staInLieuOfId) {
        this.staInLieuOfId = staInLieuOfId;
    }

    public String getStaInLieuOfType() {
        return staInLieuOfType;
    }

    public void setStaInLieuOfType(String staInLieuOfType) {
        this.staInLieuOfType = staInLieuOfType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreateUserId() {
        return createUserId;
    }

    public void setCreateUserId(String createUserId) {
        this.createUserId = createUserId;
    }

    public String getLastUpdateuserId() {
        return lastUpdateuserId;
    }

    public void setLastUpdateuserId(String lastUpdateuserId) {
        this.lastUpdateuserId = lastUpdateuserId;
    }

    public Timestamp getCreatetimestamp() {
        return createtimestamp;
    }

    public void setCreatetimestamp(Timestamp createtimestamp) {
        this.createtimestamp = createtimestamp;
    }

    public Timestamp getLastUpdateTimestamp() {
        return lastUpdateTimestamp;
    }

    public void setLastUpdateTimestamp(Timestamp lastUpdateTimestamp) {
        this.lastUpdateTimestamp = lastUpdateTimestamp;
    }

}
