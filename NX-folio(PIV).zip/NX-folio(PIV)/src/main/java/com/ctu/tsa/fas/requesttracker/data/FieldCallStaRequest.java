/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author STCI
 */

package com.ctu.tsa.fas.requesttracker.data;

import java.io.Serializable;
import java.util.Date;


public class FieldCallStaRequest implements Serializable {
 
private static final long serialVersionUID = -1106831298967580912L;

 
 private int requestStaID; 
 private String staType;
 private String description;
 private String creteUserId;
 private String lastUpdateuserId;
 private Date createtimestamp;
 private Date lastUpdateTimestamp;
 

    
 public FieldCallStaRequest() {

 
 }
public FieldCallStaRequest(int requestStaID, String staType, String description, String creteUserId, String lastUpdateuserId, Date createtimestamp) 
{
        this.requestStaID = requestStaID;
         this.staType = staType;
          this.description = description; 
          this.creteUserId = creteUserId; 
          this.lastUpdateuserId = lastUpdateuserId;
           this.createtimestamp = createtimestamp;
          
}
    public static long getSerialVersionUID() {
        return serialVersionUID;
    }

    public int getRequestStaID() {
        return requestStaID;
    }

    public String getStaType() {
        return staType;
    }

    public String getDescription() {
        return description;
    }

    public String getCreteUserId() {
        return creteUserId;
    }

    public String getLastUpdateuserId() {
        return lastUpdateuserId;
    }



    public void setRequestStaID(int requestStaID) {
        this.requestStaID = requestStaID;
    }
       public Date getCreatetimestamp() {
        return createtimestamp;
    }



    public void setCreatetimestamp(Date createtimestamp) {
        this.createtimestamp = createtimestamp;
    }

 
    public Date getLastUpdateTimestamp() {
        return lastUpdateTimestamp;
    }

    public void setLastUpdateTimestamp(Date lastUpdateTimestamp) {
        this.lastUpdateTimestamp = lastUpdateTimestamp;
    }

    public void setStaType(String staType) {
        this.staType = staType;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setCreteUserId(String creteUserId) {
        this.creteUserId = creteUserId;
    }

    public void setLastUpdateuserId(String lastUpdateuserId) {
        this.lastUpdateuserId = lastUpdateuserId;
    }



 
}

    

