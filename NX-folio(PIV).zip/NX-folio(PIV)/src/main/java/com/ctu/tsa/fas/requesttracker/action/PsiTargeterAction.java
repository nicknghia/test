/*

 */
package com.ctu.tsa.fas.requesttracker.action;

import com.ctu.tsa.fas.requesttracker.dao.RequestTrackerDAO;
import com.ctu.tsa.fas.requesttracker.data.RequestReferenceData;
import com.opensymphony.xwork2.Action;
import java.util.Map;
import java.util.Iterator;
import org.apache.log4j.Logger;

public class PsiTargeterAction implements Action {

    private Map<String, String> ccsfApprovalLinkedMap = null;
    private Map<String, String> targeterLinkedMap = null;
    protected Logger logger = Logger.getLogger(getClass());
	
    public String execute() {
        logger.info("execute----PsiTargeterAction------------------");		
        return SUCCESS;
    }	

    public String getActivePsiTargetters() {
    	
        logger.info("getActivePsiTargetters----------------------");		

        RequestTrackerDAO dao = RequestTrackerDAO.getInstance();
        try {

            ccsfApprovalLinkedMap = dao.getActiveCCSFApprovalList();           
            targeterLinkedMap = dao.getActiveTargeterList();
            
            RequestReferenceData requestReferenceData = RequestReferenceData.getInstance();
            requestReferenceData.setTargeterLinkedMap(dao.getActiveTargeterList());
            requestReferenceData.setCcsfApprovalLinkedMap(dao.getActiveCCSFApprovalList());
			
            ccsfApprovalLinkedMap.clear();
            ccsfApprovalLinkedMap.put("0", "Select PSI");
            ccsfApprovalLinkedMap.putAll(requestReferenceData.getCcsfApprovalLinkedMap());
			
            targeterLinkedMap.clear();
            targeterLinkedMap.put("0", "Select Targeter");
            targeterLinkedMap.putAll(requestReferenceData.getTargeterLinkedMap());	

        } catch (Exception e) {
            logger.error("getActivePsiTargetters EXCEPTION : = "+e.getMessage());
        }
        return SUCCESS;
	
    }
        

    public Map<String, String> getCcsfApprovalLinkedMap() {
        return ccsfApprovalLinkedMap;
    }

    public void setCcsfApprovalLinkedMap(Map<String, String> ccsfApprovalLinkedMap) {
        this.ccsfApprovalLinkedMap = ccsfApprovalLinkedMap;
    }


    public Map<String, String> getTargeterLinkedMap() {
        return targeterLinkedMap;
    }

    public void setTargeterLinkedMap(Map<String, String> targeterLinkedMap) {
        this.targeterLinkedMap = targeterLinkedMap;
    }

}
