/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.requesttracker.ejb;

import com.ctu.tsa.fas.requesttracker.dao.RequestTrackerDAO;
import com.ctu.tsa.fas.requesttracker.data.RequestTrackerData;
import java.rmi.RemoteException;
import java.util.LinkedHashMap;
import java.util.Map;
import javax.ejb.EJBException;
import javax.ejb.Stateless;

/**
 *
 * @author Eswara.Somu
 */
@Stateless
public class RequestTrackerSLSessionBean implements RequestTrackerRemote {

    // Add business logic below. (Right-click in editor and choose
    // "Insert Code > Add Business Method")
    public Map<String, String> getSubjectRegionList() throws RemoteException {
        Map<String, String> map = new LinkedHashMap<String, String>();
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            map = dao.getSubjectRegionList();
            return map;
        } catch (Exception ex) {

            throw new EJBException(ex);
        }
    }

    public Map<String, String> getOgaReferralList() throws RemoteException {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            Map<String, String> map = new LinkedHashMap<String, String>();
            map = dao.getOgaReferralList();
            return map;
        } catch (Exception ex) {

            throw new EJBException(ex);
        }
    }

    @Override
    public Map<String, String> getJointOperationsList() throws RemoteException {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            Map<String, String> map = new LinkedHashMap<String, String>();
            map = dao.getJointOperationsList();
            return map;
        } catch (Exception ex) {

            throw new EJBException(ex);
        }
    }

    @Override
    public Map<String, String> getFieldCallStaRequestList() throws RemoteException {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            Map<String, String> map = new LinkedHashMap<String, String>();
            map = dao.getFieldCallStaRequestList();
            return map;
        } catch (Exception ex) {

            throw new EJBException(ex);
        }
    }

    @Override
    public Map<String, String> getCargoIncidentList() throws RemoteException {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            Map<String, String> map = new LinkedHashMap<String, String>();
            map = dao.getCargoIncidentList();
            return map;
        } catch (Exception ex) {

            throw new EJBException(ex);
        }
    }

    @Override
    public Map<String, String> getCCSFApprovalList() throws RemoteException {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            Map<String, String> map = new LinkedHashMap<String, String>();
            map = dao.getCCSFApprovalList();
            return map;
        } catch (Exception ex) {

            throw new EJBException(ex);
        }
    }

    @Override
    public void saveRequestTracker(RequestTrackerData requestTrackerData) throws RemoteException {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            dao.saveRequestTracker(requestTrackerData);
        } catch (Exception ex) {

            throw new EJBException(ex);
        }
    }

    @Override
    public Map<String, String> getTargeterList() throws RemoteException {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            Map<String, String> map = new LinkedHashMap<String, String>();
            map = dao.getTargeterList();
            return map;
        } catch (Exception ex) {

            throw new EJBException(ex);
        }
    }

    @Override
    public Map<String, String> getRequestTypeList() throws RemoteException {
        RequestTrackerDAO dao = new RequestTrackerDAO();
        try {
            Map<String, String> map = new LinkedHashMap<String, String>();
            map = dao.getRequestTypeList();
            return map;
        } catch (Exception ex) {

            throw new EJBException(ex);
        }
    }
    
    
    
    
}
