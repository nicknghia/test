/*
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author STCI
 */
public class StaModel implements Serializable{
    private static final long serialVersionUID = -8767337899673261258L;

    private String staId;
    private String staFirstName;
    private String staLastName;
    private String staCreateDate;
    private String staIssueDate;
    private String staExpiredDate;
    private String staRecordStatus;
    private String staStatus;


	public StaModel (String staId, String staFirstName, String staLastName, 
				String staCreateDate, String staIssueDate, String staExpiredDate, 
				String staRecordStatus, String staStatus) {
		this.staId = staId;
		this.staFirstName = staFirstName;
		this.staLastName = staLastName;
		this.staCreateDate = staCreateDate;
		this.staIssueDate = staIssueDate;
		this.staExpiredDate = staExpiredDate;
		this.staRecordStatus = staRecordStatus;
		this.staStatus = staStatus;
	}

	public StaModel (StaModel other) {
		if (this != other) {
			this.staId = other.staId;
			this.staFirstName = other.staFirstName;
			this.staLastName = other.staLastName;
			this.staCreateDate = other.staCreateDate;
			this.staIssueDate = other.staIssueDate;
			this.staExpiredDate = other.staExpiredDate;
			this.staRecordStatus = other.staRecordStatus;
			this.staStatus = other.staStatus;
		}
	}
	
	public void setStaId (String staId) {
		this.staId = staId; 
	}

	public void setStaFirstName (String staFirstName) {
		this.staFirstName = staFirstName; 
	}

	public void setStaLastName (String staLastName) {
		this.staLastName = staLastName; 
	}

	public void setStaCreateDate (String staCreateDate) {
		this.staCreateDate = staCreateDate; 
	}

	public void setStaIssueDate (String staIssueDate) {
		this.staIssueDate = staIssueDate; 
	}

	public void setStaExpiredDate (String staExpiredDate) {
		this.staExpiredDate = staExpiredDate; 
	}

	public void setStaRecordStatus (String staRecordStatus) {
		this.staRecordStatus = staRecordStatus; 
	}

	public void setStaStatus (String staStatus) {
		this.staStatus = staStatus; 
	}

	public String getStaId () {
		return (this.staId); 
	}

	public String getStaFirstName () {
		return (this.staFirstName); 
	}

	public String getStaLastName () {
		return (this.staLastName); 
	}

	public String getStaCreateDate () {
		return (this.staCreateDate); 
	}

	public String getStaIssueDate () {
		return (this.staIssueDate); 
	}

	public String getStaExpiredDate () {
		return (this.staExpiredDate); 
	}

	public String getStaRecordStatus () {
		return (this.staRecordStatus); 
	}

	public String getStaStatus () {
		return (this.staStatus); 
	}

	public String toString () {

		String sep = System.getProperty("line.separator");

		StringBuffer buffer = new StringBuffer();
		buffer.append(sep);
		buffer.append("serialVersionUID = ");
		buffer.append(serialVersionUID);
		buffer.append(sep);
		buffer.append("staId = ");
		buffer.append(staId);
		buffer.append(sep);
		buffer.append("staFirstName = ");
		buffer.append(staFirstName);
		buffer.append(sep);
		buffer.append("staLastName = ");
		buffer.append(staLastName);
		buffer.append(sep);
		buffer.append("staCreateDate = ");
		buffer.append(staCreateDate);
		buffer.append(sep);
		buffer.append("staIssueDate = ");
		buffer.append(staIssueDate);
		buffer.append(sep);
		buffer.append("staExpiredDate = ");
		buffer.append(staExpiredDate);
		buffer.append(sep);
		buffer.append("staRecordStatus = ");
		buffer.append(staRecordStatus);
		buffer.append(sep);
		buffer.append("staStatus = ");
		buffer.append(staStatus);
		buffer.append(sep);
		
		return buffer.toString();
	}


}
