/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.action;

import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.opensymphony.xwork2.ActionSupport;
import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchSubjectCompanyDAO;
import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchIacDAO;
import com.ctu.tsa.fas.expandedsearch.model.SubjectCompanyDetails;

import crt.com.freightdesk.fdfolio.common.IncludesUtil;

import java.util.List;
import java.util.ArrayList;
import java.util.Map;
import java.util.HashMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.commons.lang3.StringEscapeUtils;
import org.apache.log4j.Logger;
import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;

/**
 *
 * @author STCI
 */
public class FasSubjectCompanyInfoAction extends ActionSupport implements ServletRequestAware {

    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();    
    private String loginTimeRoleMsg;
    private String subjectCompanyName;
    private String subjectCompanyType;
    private String subjectCompanyId = "";
    private String subjectCompanyState;
    private String subjectCompanyStatus;
    private String subjectCompanyAddress1;
    private String subjectCompanyAddress2;
    private String subjectCompanyCity;
    private String subjectCompanyZipPostalCode;
    private String subjectCompanySicCode;
    private String subjectCompanyPhone;
    private String subjectCompanyFax;
    private String subjectCompany24HourPhone;
    private String subjectCompanyCountry;
    private String subjectCompanyEinNumber;
    private String subjectCompanyKnownAs1;
    private String subjectCompanyKnownAs2;
    private String subjectCompanyKnownAs3;
    private String subjectCompanyFirstName;
    private String subjectCompanyLastName;
    private String subjectCompanyEmail;
    private String subjectCompanyDesignation;
    private String subjectCompanyTitle;
    private long subjectCompanyCredential = 0;
    private String subjectCompanyInitialApprovalDate;
    private String subjectCompanyLastApprovalDate;
    private String subjectCompanyExpirationDate;
    private String subjectCompanyApprovingAgent;
    private String subjectCompanyComments;
    private String partyId;
    private String iacName;
    private String iacNumber;
    private String airport;
    private List<Map> staList;
    List<Map> dirEmpMap = new ArrayList();
    List<Map> iacMapList = new ArrayList();
    private List<Map> subjectCompanyList;    
    List<Map> acStaMap = new ArrayList();
    List<Map> acSecContactMap = new ArrayList();
    List<Map> agContactMap = new ArrayList();
    List<Map> agAssoIacMap = new ArrayList();
    List<Map> agStaMap = new ArrayList();

    @Override
    public String execute() throws Exception {
        logger.info("--------------------------- FasSubjectCompanyInfoAction execute ------------------------- ");

        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        ExpandedSearchSubjectCompanyDAO dao = new ExpandedSearchSubjectCompanyDAO();
        ExpandedSearchIacDAO iacDao = new ExpandedSearchIacDAO();

        String type = getSubjectCompanyType();
        logger.info("FasSubjectCompanyInfoAction execute - getPartyId: " + getPartyId() + " getSubjectCompanyId:" + getSubjectCompanyId() + " getSubjectCompanyName:" + getSubjectCompanyName() + ", type:" + type);

        List<SubjectCompanyDetails> subjectCompanyDetails = new ArrayList<SubjectCompanyDetails>();
        int listSize = 0;

        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials) + "<br>" + IncludesUtil.getExpireMsg(credentials);       

        SessionStore sessionStore = SessionStore.getInstance(request.getSession());

        setSubjectCompanyList(dao.getSubjectCompanyByNameDetails(type, this.getPartyId()));

        if ((subjectCompanyList == null) || (subjectCompanyList.isEmpty())) {
            listSize = 0;
            logger.info("subjectCompanyList =" + listSize);
        } else {
            listSize = subjectCompanyList.size();

            if (type.equals("AC")) {
                logger.info("AC----" + listSize);
                if (subjectCompanyList.size() > 0) {
                    store.put(SessionKey.DETAIL_PAGE_SUB_COMP_LIST, subjectCompanyList);
                    setAcSubjectCompanyDetails();
                }

                logger.info("AC---getSecurityContacts for party id:" + getPartyId());

                if (listSize > 0) {
                    setAcSecContactMap(dao.getSecurityContacts(getPartyId()));

                    setAcStaMap(dao.getAcStaList(getPartyId()));

                }
                session.setAttribute("AC_SEC_CONT_LIST", IncludesUtil.convertMapListToJsonString(acSecContactMap));
                session.setAttribute("AC_STA_LIST", IncludesUtil.convertMapListToJsonString(acStaMap));
                
                return "displayAcDetails";
            } else {
                logger.info("Agent profile----" + listSize);
                if (subjectCompanyList.size() > 0) {
                    store.put(SessionKey.DETAIL_PAGE_SUB_COMP_AG_DETAIL_LIST, subjectCompanyList);
                    setAgentSubjectCompanyDetails();
                }

                if (listSize > 0) {
                    setAgContactMap(dao.getSecurityContacts(getPartyId()));
                    logger.info("displayAgentDetails setAgContactMap");

                    setAgAssoIacMap(dao.getIacList(getPartyId()));
                    logger.info("displayAgentDetails setAgAssoIacMap");

                    setAgStaMap(dao.getAgentStaList(getPartyId()));
                    logger.info("displayAgentDetails setAgStaMap");
                }
                session.setAttribute("AGT_CONTACT_LIST", IncludesUtil.convertMapListToJsonString(agContactMap));
                session.setAttribute("AGT_IAC_LIST", IncludesUtil.convertMapListToJsonString(agAssoIacMap));
                session.setAttribute("AGT_STA_LIST", IncludesUtil.convertMapListToJsonString(agStaMap));
                
                return "displayAgentDetails";
            }
        }
        return "success";
    }

    void setAcSubjectCompanyDetails() {

        logger.info("setAcSubjectCompanyDetails");
        Map theSubjectCompanyMap = new HashMap();

        if (null == subjectCompanyList || subjectCompanyList.size() == 0) {
            return;
        }

        theSubjectCompanyMap = subjectCompanyList.get(0);

        setSubjectCompanyId((String) theSubjectCompanyMap.get("subjectCompanyId"));

        setSubjectCompanyName((String) theSubjectCompanyMap.get("subjectCompanyName"));
        setSubjectCompanyState((String) theSubjectCompanyMap.get("subjectCompanyState"));
        setSubjectCompanyAddress1((String) theSubjectCompanyMap.get("subjectCompanyAddress1"));
        setSubjectCompanyAddress2((String) theSubjectCompanyMap.get("subjectCompanyAddress2"));
        setSubjectCompanyCity((String) theSubjectCompanyMap.get("subjectCompanyCity"));
        setSubjectCompanyZipPostalCode((String) theSubjectCompanyMap.get("subjectCompanyZipPostalCode"));
        setSubjectCompanyState((String) theSubjectCompanyMap.get("subjectCompanyState"));

        setSubjectCompanyDesignation((String) theSubjectCompanyMap.get("subjectCompanyDesignation"));

        if (theSubjectCompanyMap.get("subjectCompanyState") != null && theSubjectCompanyMap.get("subjectCompanyState") != "") {
            setSubjectCompanyCountry("UNITED STATES");
        }

    }

    void setAcSecurityContacts() {

        logger.info("setAcSecurityContacts");
        Map theSubjectCompanyMap = new HashMap();

        theSubjectCompanyMap = subjectCompanyList.get(0);

        setSubjectCompanyPhone((String) theSubjectCompanyMap.get("subjectCompanyPhone"));
        setSubjectCompanyFirstName((String) theSubjectCompanyMap.get("subjectCompanyFirstName"));
        setSubjectCompanyLastName((String) theSubjectCompanyMap.get("subjectCompanyLastName"));
        setSubjectCompanyEmail((String) theSubjectCompanyMap.get("subjectCompanyEmail"));
        setSubjectCompany24HourPhone((String) theSubjectCompanyMap.get("subjectCompany24HourPhone"));
        setSubjectCompanyFax((String) theSubjectCompanyMap.get("subjectCompanyFax"));

    }

    void setAgentContactList() {
        logger.info("setAgentContactList");
        Map theSubjectCompanyMap = new HashMap();

        theSubjectCompanyMap = subjectCompanyList.get(0);

        setSubjectCompanyFirstName((String) theSubjectCompanyMap.get("subjectCompanyFirstName"));
        setSubjectCompanyLastName((String) theSubjectCompanyMap.get("subjectCompanyLastName"));
        setSubjectCompanyEmail((String) theSubjectCompanyMap.get("subjectCompanyEmail"));
        setSubjectCompanyPhone((String) theSubjectCompanyMap.get("subjectCompanyPhone"));
    }

    void setAcStaList() {

        logger.info("setAcStaList");
        Map theSubjectCompanyMap = new HashMap();

        theSubjectCompanyMap = subjectCompanyList.get(0);

    }

    void setStationSubjectCompanyDetails() {

        logger.info("setStationSubjectCompanyDetails");
        Map theSubjectCompanyMap = new HashMap();

        theSubjectCompanyMap = subjectCompanyList.get(0);

        setSubjectCompanyName((String) theSubjectCompanyMap.get("subjectCompanyName"));
        setAirport((String) theSubjectCompanyMap.get("airport"));
        setIacName((String) theSubjectCompanyMap.get("iacName"));
        setIacNumber((String) theSubjectCompanyMap.get("iacNumber"));
        setSubjectCompanyState((String) theSubjectCompanyMap.get("subjectCompanyState"));
        setSubjectCompanyAddress1((String) theSubjectCompanyMap.get("subjectCompanyAddress1"));
        setSubjectCompanyAddress2((String) theSubjectCompanyMap.get("subjectCompanyAddress2"));
        setSubjectCompanyCity((String) theSubjectCompanyMap.get("subjectCompanyCity"));
        setSubjectCompanyPhone((String) theSubjectCompanyMap.get("subjectCompanyPhone"));
        setSubjectCompany24HourPhone((String) theSubjectCompanyMap.get("subjectCompany24HourPhone"));
        setSubjectCompanyFirstName((String) theSubjectCompanyMap.get("subjectCompanyFirstName"));
        setSubjectCompanyLastName((String) theSubjectCompanyMap.get("subjectCompanyLastName"));
        setSubjectCompanyEmail((String) theSubjectCompanyMap.get("subjectCompanyEmail"));
        setSubjectCompanyDesignation((String) theSubjectCompanyMap.get("subjectCompanyDesignation"));
        setSubjectCompanyExpirationDate((String) theSubjectCompanyMap.get("subjectCompanyExpirationDate"));
        setSubjectCompanyZipPostalCode((String) theSubjectCompanyMap.get("subjectCompanyZipPostalCode"));
        setSubjectCompanyState((String) theSubjectCompanyMap.get("subjectCompanyState"));
        setSubjectCompanyComments((String) theSubjectCompanyMap.get("subjectCompanyComments"));

        if (theSubjectCompanyMap.get("subjectCompanyState") != null && theSubjectCompanyMap.get("subjectCompanyState") != "") {
            setSubjectCompanyCountry("UNITED STATES");
        }

    }

    void setAgentSubjectCompanyDetails() {

        logger.info("setAgentSubjectCompanyDetails");
        Map theSubjectCompanyMap = new HashMap();

        theSubjectCompanyMap = subjectCompanyList.get(0);

        setSubjectCompanyName((String) theSubjectCompanyMap.get("subjectCompanyName"));
        setSubjectCompanyId((String) theSubjectCompanyMap.get("subjectCompanyId"));
        setSubjectCompanyStatus((String) theSubjectCompanyMap.get("subjectCompanyStatus"));
        setSubjectCompanyAddress1((String) theSubjectCompanyMap.get("subjectCompanyAddress1"));
        setSubjectCompanyAddress2((String) theSubjectCompanyMap.get("subjectCompanyAddress2"));
        setSubjectCompanyCity((String) theSubjectCompanyMap.get("subjectCompanyCity"));
        setSubjectCompanyZipPostalCode((String) theSubjectCompanyMap.get("subjectCompanyZipPostalCode"));
        setSubjectCompanyState((String) theSubjectCompanyMap.get("subjectCompanyState"));

        if (theSubjectCompanyMap.get("subjectCompanyState") != null && theSubjectCompanyMap.get("subjectCompanyState") != "") {
            setSubjectCompanyCountry("UNITED STATES");
        }
    }    

    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }

    @Override
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }

    public void setSubjectCompanyList(List subjectCompanyList) {
        this.subjectCompanyList = subjectCompanyList;
    }
   
    public String getSubjectCompanyType() {
        if (subjectCompanyType == null) {
            this.subjectCompanyType = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyType);
    }

    public void setSubjectCompanyType(String subjectCompanyType) {
        this.subjectCompanyType = subjectCompanyType;
    }

    public String getSubjectCompanyComments() {
        if (subjectCompanyComments == null) {
            this.subjectCompanyComments = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyComments);
    }

    public void setSubjectCompanyComments(String subjectCompanyComments) {
        this.subjectCompanyComments = subjectCompanyComments;
    }

    public String getSubjectCompanyInitialApprovalDate() {
        if (subjectCompanyInitialApprovalDate == null) {
            this.subjectCompanyInitialApprovalDate = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyInitialApprovalDate);
    }

    public void setSubjectCompanyInitialApprovalDate(String subjectCompanyInitialApprovalDate) {
        this.subjectCompanyInitialApprovalDate = subjectCompanyInitialApprovalDate;
    }

    public String getSubjectCompanyLastApprovalDate() {
        if (subjectCompanyLastApprovalDate == null) {
            this.subjectCompanyLastApprovalDate = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyLastApprovalDate);
    }

    public void setSubjectCompanyLastApprovalDate(String subjectCompanyLastApprovalDate) {
        this.subjectCompanyLastApprovalDate = subjectCompanyLastApprovalDate;
    }

    public String getSubjectCompanyExpirationDate() {
        if (subjectCompanyExpirationDate == null) {
            this.subjectCompanyExpirationDate = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyExpirationDate);
    }

    public void setSubjectCompanyExpirationDate(String subjectCompanyExpirationDate) {
        this.subjectCompanyExpirationDate = subjectCompanyExpirationDate;
    }

    public String getSubjectCompanyApprovingAgent() {
        if (subjectCompanyApprovingAgent == null) {
            this.subjectCompanyApprovingAgent = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyApprovingAgent);
    }

    public void setSubjectCompanyApprovingAgent(String subjectCompanyApprovingAgent) {
        this.subjectCompanyApprovingAgent = subjectCompanyApprovingAgent;
    }

    public String getSubjectCompanyId() {
        if (subjectCompanyId == null) {
            this.subjectCompanyId = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyId);

    }

    public void setSubjectCompanyId(String subjectCompanyId) {
        this.subjectCompanyId = subjectCompanyId;
    }

    public List<Map> getSubjectCompanyList() {
        return subjectCompanyList;
    }

    public String getSubjectCompanyName() {
        if (subjectCompanyName == null) {
            this.subjectCompanyName = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyName);
    }

    public void setSubjectCompanyName(String subjectCompanyName) {
        this.subjectCompanyName = subjectCompanyName;
    }

    public String getSubjectCompanyStatus() {
        if (subjectCompanyStatus == null) {
            this.subjectCompanyStatus = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyStatus);
    }

    public void setSubjectCompanyStatus(String subjectCompanyStatus) {
        this.subjectCompanyStatus = subjectCompanyStatus;
    }

    public long getSubjectCompanyCredential() {

        return subjectCompanyCredential;
    }

    public void setSubjectCompanyCredential(long subjectCompanyCredential) {
        this.subjectCompanyCredential = subjectCompanyCredential;
    }

    public String getSubjectCompanyFirstName() {
        if (subjectCompanyFirstName == null) {
            this.subjectCompanyFirstName = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyFirstName);
    }

    public void setSubjectCompanyFirstName(String subjectCompanyFirstName) {
        this.subjectCompanyFirstName = subjectCompanyFirstName;
    }

    public String getSubjectCompanyLastName() {
        if (subjectCompanyLastName == null) {
            this.subjectCompanyLastName = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyLastName);
    }

    public void setSubjectCompanyLastName(String subjectCompanyLastName) {
        this.subjectCompanyLastName = subjectCompanyLastName;
    }

    public String getSubjectCompanyEmail() {
        if (subjectCompanyEmail == null) {
            this.subjectCompanyEmail = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyEmail);
    }

    public void setSubjectCompanyEmail(String subjectCompanyEmail) {
        this.subjectCompanyEmail = subjectCompanyEmail;
    }

    public String getSubjectCompanyDesignation() {
        if (subjectCompanyDesignation == null) {
            this.subjectCompanyDesignation = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyDesignation);
    }

    public void setSubjectCompanyDesignation(String subjectCompanyDesignation) {
        this.subjectCompanyDesignation = subjectCompanyDesignation;
    }

    public String getSubjectCompanyTitle() {
        if (subjectCompanyTitle == null) {
            this.subjectCompanyTitle = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyTitle);
    }

    public void setSubjectCompanyTitle(String subjectCompanyTitle) {
        this.subjectCompanyTitle = subjectCompanyTitle;
    }

    public String getSubjectCompanySicCode() {
        if (subjectCompanySicCode == null) {
            this.subjectCompanySicCode = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanySicCode);
    }

    public void setSubjectCompanySicCode(String subjectCompanySicCode) {
        this.subjectCompanySicCode = subjectCompanySicCode;
    }

    public String getSubjectCompanyPhone() {
        if (subjectCompanyPhone == null) {
            this.subjectCompanyPhone = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyPhone);
    }

    public void setSubjectCompanyPhone(String subjectCompanyPhone) {
        this.subjectCompanyPhone = subjectCompanyPhone;
    }

    public String getSubjectCompanyAddress1() {
        if (subjectCompanyAddress1 == null) {
            this.subjectCompanyAddress1 = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyAddress1);
    }

    public void setSubjectCompanyAddress1(String subjectCompanyAddress1) {
        logger.info("subjectCompanyAddress1:" + subjectCompanyAddress1);
        this.subjectCompanyAddress1 = subjectCompanyAddress1;
    }

    public String getSubjectCompanyAddress2() {
        if (subjectCompanyAddress2 == null) {
            this.subjectCompanyAddress2 = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyAddress2);
    }

    public void setSubjectCompanyAddress2(String subjectCompanyAddress2) {
        this.subjectCompanyAddress2 = subjectCompanyAddress2;
    }

    public String getSubjectCompanyKnownAs1() {
        if (subjectCompanyKnownAs1 == null) {
            this.subjectCompanyKnownAs1 = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyKnownAs1);
    }

    public void setSubjectCompanyKnownAs1(String subjectCompanyKnownAs1) {
        this.subjectCompanyKnownAs1 = subjectCompanyKnownAs1;
    }

    public String getSubjectCompanyKnownAs2() {
        if (subjectCompanyKnownAs2 == null) {
            this.subjectCompanyKnownAs2 = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyKnownAs2);
    }

    public void setSubjectCompanyKnownAs2(String subjectCompanyKnownAs2) {
        this.subjectCompanyKnownAs2 = subjectCompanyKnownAs2;
    }

    public String getSubjectCompanyKnownAs3() {
        if (subjectCompanyKnownAs3 == null) {
            this.subjectCompanyKnownAs3 = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyKnownAs3);
    }

    public void setSubjectCompanyKnownAs3(String subjectCompanyKnownAs3) {
        this.subjectCompanyKnownAs3 = subjectCompanyKnownAs3;
    }

    public String getSubjectCompanyCity() {
        if (subjectCompanyCity == null) {
            this.subjectCompanyCity = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyCity);
    }

    public void setSubjectCompanyCity(String subjectCompanyCity) {
        this.subjectCompanyCity = subjectCompanyCity;
    }

    public String getSubjectCompanyState() {
        if (subjectCompanyState == null) {
            this.subjectCompanyState = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyState);
    }

    public void setSubjectCompanyState(String subjectCompanyState) {
        this.subjectCompanyState = subjectCompanyState;
    }

    public String getSubjectCompanyZipPostalCode() {
        if (subjectCompanyZipPostalCode == null) {
            this.subjectCompanyZipPostalCode = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyZipPostalCode);
    }

    public void setSubjectCompanyZipPostalCode(String subjectCompanyZipPostalCode) {
        this.subjectCompanyZipPostalCode = subjectCompanyZipPostalCode;
    }

    public String getSubjectCompanyEinNumber() {
        if (subjectCompanyEinNumber == null) {
            this.subjectCompanyEinNumber = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyEinNumber);
    }

    public void setSubjectCompanyEinNumber(String subjectCompanyEinNumber) {
        this.subjectCompanyEinNumber = subjectCompanyEinNumber;
    }

    public String getSubjectCompanyCountry() {
        if (subjectCompanyCountry == null) {
            this.subjectCompanyCountry = "";
        }

        return StringEscapeUtils.unescapeHtml4(subjectCompanyCountry);
    }

    public void setSubjectCompanyCountry(String subjectCompanyCountry) {
        this.subjectCompanyCountry = subjectCompanyCountry;
    }

    public void setAirport(String airport) {
        this.airport = airport;
    }

    public String getAirport() {
        return (this.airport);
    }

    public void setIacName(String iacName) {
        this.iacName = iacName;
    }

    public String getIacName() {
        return (this.iacName);
    }

    public void setIacNumber(String iacNumber) {
        this.iacNumber = iacNumber;
    }

    public String getIacNumber() {
        return (this.iacNumber);
    }

    public void setSubjectCompany24HourPhone(String subjectCompany24HourPhone) {
        this.subjectCompany24HourPhone = subjectCompany24HourPhone;
    }

    public String getSubjectCompany24HourPhone() {
        return (this.subjectCompany24HourPhone);
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }

    public String getPartyId() {
        return (this.partyId);
    }

    public void setDirEmpMap(List dirEmpMap) {
        this.dirEmpMap = dirEmpMap;
    }

    public List getDirEmpMap() {
        return (this.dirEmpMap);
    }

    public void setSubjectCompanyFax(String subjectCompanyFax) {
        this.subjectCompanyFax = subjectCompanyFax;
    }

    public String getSubjectCompanyFax() {
        return (this.subjectCompanyFax);
    }

    public void setIacMapList(List iacMapList) {
        this.iacMapList = iacMapList;
    }

    public List getIacMapList() {
        return (this.iacMapList);
    }

    public List<Map> getAcStaMap() {
        return acStaMap;
    }

    public void setAcStaMap(List<Map> acStaMap) {
        this.acStaMap = acStaMap;
    }

    public List<Map> getAcSecContactMap() {
        return acSecContactMap;
    }

    public void setAcSecContactMap(List<Map> acSecContactMap) {
        this.acSecContactMap = acSecContactMap;
    }

    public List<Map> getAgContactMap() {
        return agContactMap;
    }

    public void setAgContactMap(List<Map> agContactMap) {
        this.agContactMap = agContactMap;
    }

    public List<Map> getAgAssoIacMap() {
        return agAssoIacMap;
    }

    public void setAgAssoIacMap(List<Map> agAssoIacMap) {
        this.agAssoIacMap = agAssoIacMap;
    }

    public List<Map> getAgStaMap() {
        return agStaMap;
    }

    public void setAgStaMap(List<Map> agStaMap) {
        this.agStaMap = agStaMap;
    }

    public List<Map> getStaList() {
        return staList;
    }

    public void setStaList(List<Map> staList) {
        this.staList = staList;
    }
}
