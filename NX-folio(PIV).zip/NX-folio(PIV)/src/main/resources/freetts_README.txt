FreeTTS is an incredibly-old solution to implementing sound into JCAPTCHA.

As such, there were bugs that were never addressed because development stopped a long time ago.

As a result, the JAR file here is a mixture of the maven file as well as the recompiled (and modified) file Voice.java.

To install this jar so that the POM can read it properly is by using maven.  You must have installed maven to run this command
in the command prompt.  Change the file location as required to fit your scenario.

mvn install:install-file -Dfile=C:\Projects\CRT_Release_4.4_CLONE\src\NXfolio\src\main\resour
ces\freetts-1.0.jar -DgroupId=org.mobicents.external.freetts -DartifactId=freetts -Dversion=1.0 -Dpackaging=jar
