/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;

/**
 *
 * @author Binh.Nguyen
 */
public class ShipperDetails implements Serializable{
    private static final long serialVersionUID = -8767337899673261247L;

    private String shipperStatus = "";
    private long shipperId = 0;;
    private String shipperName = "";
    private String shipperNumber = "";
    private String shipperType = "";

    private String phone = "";
    private String address1 = "";
    private String address2 = "";
    private String city = "";
    private String state = "";
    private String zipPostalCode = "";
    private String country = "";
    private String notes = "";
	
    private String dispositionCode = "";
    private long organizationProfileId = 0;
    private String virtualShipper = "";
	
	public void setShipperStatus (String shipperStatus) {
		this.shipperStatus = shipperStatus; 
	}

	public void setShipperId (long shipperId) {
		this.shipperId = shipperId; 
	}

	public void setShipperName (String shipperName) {
		this.shipperName = shipperName; 
	}

	public void setShipperNumber (String shipperNumber) {
		this.shipperNumber = shipperNumber; 
	}
        
        public void setShipperType (String shipperType) {
		this.shipperType = shipperType; 
	}

	public String getShipperStatus () {
		return (this.shipperStatus); 
	}

	public long getShipperId () {
		return (this.shipperId); 
	}

	public String getShipperName () {
		return (this.shipperName); 
	}

	public String getShipperNumber () {
		return (this.shipperNumber); 
	}
        
    public String getShipperType () {
		return (this.shipperType); 
	}

	public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
            
    public String getAddress1() {
        return address1;
    }

    public void setAddress1(String address1) {
        this.address1 = address1;
    }        
        
    public String getAddress2() {
        return address2;
    }

    public void setAddress2(String address2) {
        this.address2 = address2;
    }    
    
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
    
    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }
    
    public String getZipPostalCode() {
        return zipPostalCode;
    }

    public void setZipPostalCode(String zipPostalCode) {
        this.zipPostalCode = zipPostalCode;
    }
    
    public String getCountry() {
        return country;
    }

    public void setCountry(String country) {
        this.country = country;
    }
    
    public String getNotes() {
        return notes;
    }
	
    public String getDispositionCode() {
        return dispositionCode;
    }

    public void setDispositionCode(String dispositionCode) {
        this.dispositionCode = dispositionCode;
    }
    
    public long getOrganizationProfileId() {
        return organizationProfileId;
    }

    public void setOrganizationProfileId(long organizationProfileId) {
        this.organizationProfileId = organizationProfileId;
    }
	
    public String getVirtualShipper() {
        return virtualShipper;
    }

    public void setVirtualShipper(String virtualShipper) {
        this.virtualShipper = virtualShipper;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }
	
	public String toString () {

		String sep = System.getProperty("line.separator");

		StringBuffer buffer = new StringBuffer();
		buffer.append(sep);
		buffer.append("shipperName = ");
		buffer.append(shipperName);
		buffer.append(sep);
		buffer.append("shipperType = ");
		buffer.append(shipperType);
		buffer.append(sep);
		buffer.append("shipperId = ");
		buffer.append(shipperId);
		buffer.append(sep);
		buffer.append("shipperStatus = ");
		buffer.append(shipperStatus);
		buffer.append(sep);
                buffer.append("shipperNumber = ");
		buffer.append(shipperNumber);
		buffer.append(sep);
		buffer.append("phone = ");
		buffer.append(phone);
		buffer.append(sep);
		buffer.append("address1 = ");
		buffer.append(address1);
		buffer.append(sep);
		buffer.append("address2 = ");
		buffer.append(address2);
		buffer.append(sep);
		buffer.append("city = ");
		buffer.append(city);
		buffer.append(sep);
		buffer.append("state = ");
		buffer.append(state);
		buffer.append(sep);
		buffer.append("zipPostalCode = ");
		buffer.append(zipPostalCode);
		buffer.append(sep);
		buffer.append("country = ");
		buffer.append(country);
		buffer.append(sep);
		buffer.append("notes = ");
		buffer.append(notes);
		buffer.append(sep);
		buffer.append("dispositionCode = ");
		buffer.append(dispositionCode);
                buffer.append("organizationProfileId = ");
		buffer.append(organizationProfileId);
		buffer.append(sep);
		buffer.append("virtualShipper = ");
		buffer.append(virtualShipper);
		buffer.append(sep);
			
		return buffer.toString();
	}
}
