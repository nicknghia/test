/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templatescompany
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.dao;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.sql.PreparedStatement;

import org.apache.log4j.Logger;
import org.hibernate.Session;

import com.ctu.tsa.fas.expandedsearch.model.CcsfFacility;

/*
 * @author Kevin.Tsou
 */
public class ExpandedSearchCcsfDAO {

    
    public static  String ccspFttDatabase = "CCSP-FTT";
    
    private static ExpandedSearchCcsfDAO instance = null;
    protected Logger logger = Logger.getLogger(getClass());    

    public ExpandedSearchCcsfDAO() {

    }

    public static ExpandedSearchCcsfDAO getInstance() {
        if (instance == null) {
            instance = new ExpandedSearchCcsfDAO();
        }
        return instance;
    }
    
    public List<Map> getCcsfInfoByCertNum(String searchData) throws Exception {
    	
    	logger.info("getCcsfInfoByCertNum");
    	
        Connection connection = null;
        String queryStr;
        String searchString = null;
        ResultSet sResultSet = null;
        Statement stmtDb = null;
        PreparedStatement stmt = null;
        

        try {
            connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionCcsf();
        } catch (Exception ex) {
            logger.error("getConnection failed! " + ex.getMessage());
            throw (ex);
        }
        
        try{
            stmtDb = connection.createStatement();
            stmtDb.execute("use [" + ccspFttDatabase + "]");
        } catch (Exception ex) {
            logger.error("use ccsp-ftt failed! " + ex.getMessage());
            throw (ex);
        } finally {
            if (stmtDb != null) {
                stmtDb.close();
            }
        }
        
        List<Map> esListMap;
        List<CcsfFacility> CcsfFacilities = new ArrayList<CcsfFacility>();
        Session session = null;
        String stProcName = "CCSP-FTT.dbo.SEL_REC_BY_CCSF_CERT_NUM";        
        String SQL = "select [CCSFCertificationNum], [FacilityID], [IACNum], [StaAuthorizationKey], [CertificationStatus], [inactive_datetime], [updated_datetime] ,\n" +
"           [IATACode], [CompanyName], [FacilityName], \n" +
"           [ApplicantTypeCode], [ApplicationStatus] \n" +
"           from [CCSP-FTT].[dbo].[Facilities] where UPPER (CCSFCertificationNum) LIKE UPPER (?) \n" +
"           ORDER BY [inactive_datetime] ASC, [updated_datetime] ASC;";   
        
        stmt = null;
        try {
            stmt = connection.prepareStatement(SQL);
            stmt.setString(1, searchData);
            sResultSet = stmt.executeQuery();
            esListMap = convertResultSetToListMapForSummaryPage (sResultSet);
            sResultSet.close();
        } catch (Exception ex) {
            logger.error("stmt.executeQuery failed" + ex.getMessage());
            throw (ex);
        } finally {
		    if (stmt != null) {
                stmt.close();
            }            
        }

        com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, stmt, sResultSet);
        
        return esListMap;
    }
    
    
    public List<Map> getCcsfInfoByFacilityName(String searchData) throws Exception {
    	
    	logger.info("getCcsfInfoByFacilityName");
    	
        Connection connection = null;
        String queryStr;
        String searchString = null;
        ResultSet sResultSet = null;
        Statement stmtDb;
        
        try {
	    connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionCcsf();
        } catch (Exception ex) {
            logger.error("getConnection failed! " + ex.getMessage());
            throw (ex);
        }
        
        stmtDb = null;
        try{
            stmtDb = connection.createStatement();
            stmtDb.execute("use [" + ccspFttDatabase + "]");
        } catch (Exception ex) {
            logger.error("use ccsp-ftt failed! " + ex.getMessage());
            throw (ex);
        } finally {
            if (stmtDb != null) {
                stmtDb.close();
            }
        }
        
        List<Map> esListMap;
        PreparedStatement stmt = null;
        List<CcsfFacility> CcsfFacilities = new ArrayList<CcsfFacility>();
        Session session = null;
        String stProcName = "CCSP-FTT.dbo.SEL_REC_BY_FACI_COMP_NAME";
        String SQL = "select [CCSFCertificationNum], [FacilityID], [IACNum], [StaAuthorizationKey], [CertificationStatus], [inactive_datetime],[updated_datetime], \n" +
"            [IATACode], [CompanyName], [FacilityName], \n" +
"            [ApplicantTypeCode], [ApplicationStatus] \n" +
"        from [CCSP-FTT].[dbo].[Facilities] where (UPPER([FacilityName]) LIKE UPPER (?) OR UPPER([CompanyName]) LIKE UPPER(?))\n" +
"           ORDER BY [inactive_datetime] ASC, [updated_datetime] ASC;";  
        
        try {
            stmt = connection.prepareStatement(SQL);
            stmt.setString(1, searchData);
            stmt.setString(2, searchData);
            sResultSet = stmt.executeQuery();
            esListMap = convertResultSetToListMapForSummaryPage (sResultSet);
            sResultSet.close();
        } catch (Exception ex) {
            logger.error("stmt.executeQuery failed" + ex.getMessage());
            throw (ex);
        } finally {
            if (stmt != null) {
                stmt.close();
            }
        }
        
        com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, stmt, sResultSet);

        return esListMap;
    }
    
    public List<Map> getCcsfDetailByFacilityName(String certNumber, String facilityName) throws Exception {
    	
    	logger.info("getCcsfDetailByFacilityName:" + facilityName);
    	
        Connection connection = null;
        String queryStr;
        String searchString = null;
        ResultSet sResultSet = null;
        Statement stmtDb = null;
        PreparedStatement stmt = null;
        
        try {
	    connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionCcsf();
        } catch (Exception ex) {
            logger.error("getConnection failed! " + ex.getMessage());
            throw (ex);
        }
        
        try{
            stmtDb = connection.createStatement();
            stmtDb.execute("use [" + ccspFttDatabase + "]");
        } catch (Exception ex) {
            logger.error("use ccsp-ftt failed! " + ex.getMessage());
            throw (ex);
        } finally {
            if (stmtDb != null) {
                stmtDb.close();
            }
        }
        
        List<Map> esListMap;
        List<CcsfFacility> CcsfFacilities = new ArrayList<CcsfFacility>();
        Session session = null;
        String stProcName = "CCSP-FTT.dbo.SEL_CCSF_DETAIL_BY_FACI_NAME";
        String SQL = "select [CCSFCertificationNum], [FacilityID], [IACNum], [StaAuthorizationKey], [CertificationStatus], [inactive_datetime],[updated_datetime], \n" +
"            [IATACode], [CompanyName], [FacilityName], [FacilityPhone], [FacilityStreetAddress], [FacilityCity], [FacilityState],\n" +
"            [FacilityZip], [FC1_FullName], [FC1_Title], [FC1_PrimaryPhone], [FC1_Email],\n" +
"            [FC2_FullName], [FC2_Title], [FC2_PrimaryPhone], [FC2_Email], [CPSC_Name],\n" +
"            [CPSC_Title], [CPSC_Phone], [CPSC_Email], \n" +
"            [FSC_Name], [FSC_Title], [FSC_Phone], [FSC_Email], \n" +
"            [Commodity_1_Specific], [Commodity_2_Specific], [Commodity_3_Specific], [Commodity_4_Specific], \n" +
"            [Commodity_5_Specific], [Commodity_6_Specific], [Commodity_7_Specific], [Commodity_8_Specific], \n" +
"            [Commodity_9_Specific], [Commodity_10_Specific], [Commodity_11_Specific], \n" +
"            [CPSC_Title], [CPSC_Email], [FSC_Name], [FSC_Title], [FSC_Phone], [NotesCertification], [Required_Recertification_Date],\n" +
"            [Recertification_Date], [RecertificationStatus], [MoveRecertStatus], [ApplicantTypeCode], [ApplicationStatus], [OperationalStatus],\n" +
"            [Suspense_Date], [SuspenseType], [CommodityTypesShipped], [Amendment], [Amendment_ExpireDate],\n" +
"            [Amendment_Details], [NotesFacility], [DSA_ChangeDetail], [NotesAssessment], [updated_by]\n" +
"        from [CCSP-FTT].[dbo].[Facilities] where UPPER([FacilityName]) LIKE UPPER (?) AND UPPER (CCSFCertificationNum) LIKE UPPER (?)\n" +
"           ORDER BY [inactive_datetime] ASC, [updated_datetime] ASC;"; 
        
        if ((certNumber == null) || (certNumber.equals(""))){
            SQL = "select [CCSFCertificationNum], [FacilityID], [IACNum], [StaAuthorizationKey], [CertificationStatus], [inactive_datetime],[updated_datetime], \n" +
"            [IATACode], [CompanyName], [FacilityName], [FacilityPhone], [FacilityStreetAddress], [FacilityCity], [FacilityState],\n" +
"            [FacilityZip], [FC1_FullName], [FC1_Title], [FC1_PrimaryPhone], [FC1_Email],\n" +
"            [FC2_FullName], [FC2_Title], [FC2_PrimaryPhone], [FC2_Email], [CPSC_Name],\n" +
"            [CPSC_Title], [CPSC_Phone], [CPSC_Email], \n" +
"            [FSC_Name], [FSC_Title], [FSC_Phone], [FSC_Email], \n" +
"            [Commodity_1_Specific], [Commodity_2_Specific], [Commodity_3_Specific], [Commodity_4_Specific], \n" +
"            [Commodity_5_Specific], [Commodity_6_Specific], [Commodity_7_Specific], [Commodity_8_Specific], \n" +
"            [Commodity_9_Specific], [Commodity_10_Specific], [Commodity_11_Specific], \n" +
"            [CPSC_Title], [CPSC_Email], [FSC_Name], [FSC_Title], [FSC_Phone], [NotesCertification], [Required_Recertification_Date],\n" +
"            [Recertification_Date], [RecertificationStatus], [MoveRecertStatus], [ApplicantTypeCode], [ApplicationStatus], [OperationalStatus],\n" +
"            [Suspense_Date], [SuspenseType], [CommodityTypesShipped], [Amendment], [Amendment_ExpireDate],\n" +
"            [Amendment_Details], [NotesFacility], [DSA_ChangeDetail], [NotesAssessment], [updated_by]\n" +
"        from [CCSP-FTT].[dbo].[Facilities] where UPPER([FacilityName]) = UPPER (?) \n" +
"           ORDER BY [inactive_datetime] ASC, [updated_datetime] ASC;";  
            try {
                stmt = connection.prepareStatement(SQL);
                stmt.setString(1, facilityName);
                sResultSet = stmt.executeQuery();
                esListMap = convertResultSetToListMap (sResultSet);
                sResultSet.close();
            } catch (Exception ex) {
                logger.error("stmt.executeQuery failed" + ex.getMessage());
                throw (ex);
            } finally {
                if (stmt != null) {
                   stmt.close();
                }
            }
        } else if ((facilityName == null) || (facilityName.equals(""))){
            SQL = "select [CCSFCertificationNum], [FacilityID], [IACNum], [StaAuthorizationKey], [CertificationStatus], [inactive_datetime],[updated_datetime], \n" +
"            [IATACode], [CompanyName], [FacilityName], [FacilityPhone], [FacilityStreetAddress], [FacilityCity], [FacilityState],\n" +
"            [FacilityZip], [FC1_FullName], [FC1_Title], [FC1_PrimaryPhone], [FC1_Email],\n" +
"            [FC2_FullName], [FC2_Title], [FC2_PrimaryPhone], [FC2_Email], [CPSC_Name],\n" +
"            [CPSC_Title], [CPSC_Phone], [CPSC_Email], \n" +
"            [FSC_Name], [FSC_Title], [FSC_Phone], [FSC_Email], \n" +
"            [Commodity_1_Specific], [Commodity_2_Specific], [Commodity_3_Specific], [Commodity_4_Specific], \n" +
"            [Commodity_5_Specific], [Commodity_6_Specific], [Commodity_7_Specific], [Commodity_8_Specific], \n" +
"            [Commodity_9_Specific], [Commodity_10_Specific], [Commodity_11_Specific], \n" +
"            [CPSC_Title], [CPSC_Email], [FSC_Name], [FSC_Title], [FSC_Phone], [NotesCertification], [Required_Recertification_Date],\n" +
"            [Recertification_Date], [RecertificationStatus], [MoveRecertStatus], [ApplicantTypeCode], [ApplicationStatus], [OperationalStatus],\n" +
"            [Suspense_Date], [SuspenseType], [CommodityTypesShipped], [Amendment], [Amendment_ExpireDate],\n" +
"            [Amendment_Details], [NotesFacility], [DSA_ChangeDetail], [NotesAssessment], [updated_by]\n" +
"        from [CCSP-FTT].[dbo].[Facilities] where  UPPER (CCSFCertificationNum) LIKE UPPER (?)\n" +
"           ORDER BY [inactive_datetime] ASC, [updated_datetime] ASC;"; 
            try {
                stmt = connection.prepareStatement(SQL);
                stmt.setString(1, certNumber);
                sResultSet = stmt.executeQuery();
                esListMap = convertResultSetToListMap (sResultSet);
                sResultSet.close();
            } catch (Exception ex) {
                logger.error("stmt.executeQuery failed" + ex.getMessage());
                throw (ex);
            } finally {
                if (stmt != null) {
                   stmt.close();
                }
            }
        } else {
            SQL = "select [CCSFCertificationNum], [FacilityID], [IACNum], [StaAuthorizationKey], [CertificationStatus], [inactive_datetime],[updated_datetime], \n" +
"            [IATACode], [CompanyName], [FacilityName], [FacilityPhone], [FacilityStreetAddress], [FacilityCity], [FacilityState],\n" +
"            [FacilityZip], [FC1_FullName], [FC1_Title], [FC1_PrimaryPhone], [FC1_Email],\n" +
"            [FC2_FullName], [FC2_Title], [FC2_PrimaryPhone], [FC2_Email], [CPSC_Name],\n" +
"            [CPSC_Title], [CPSC_Phone], [CPSC_Email], \n" +
"            [FSC_Name], [FSC_Title], [FSC_Phone], [FSC_Email], \n" +
"            [Commodity_1_Specific], [Commodity_2_Specific], [Commodity_3_Specific], [Commodity_4_Specific], \n" +
"            [Commodity_5_Specific], [Commodity_6_Specific], [Commodity_7_Specific], [Commodity_8_Specific], \n" +
"            [Commodity_9_Specific], [Commodity_10_Specific], [Commodity_11_Specific], \n" +
"            [CPSC_Title], [CPSC_Email], [FSC_Name], [FSC_Title], [FSC_Phone], [NotesCertification], [Required_Recertification_Date],\n" +
"            [Recertification_Date], [RecertificationStatus], [MoveRecertStatus], [ApplicantTypeCode], [ApplicationStatus], [OperationalStatus],\n" +
"            [Suspense_Date], [SuspenseType], [CommodityTypesShipped], [Amendment], [Amendment_ExpireDate],\n" +
"            [Amendment_Details], [NotesFacility], [DSA_ChangeDetail], [NotesAssessment], [updated_by]\n" +
"        from [CCSP-FTT].[dbo].[Facilities] where UPPER([FacilityName]) LIKE UPPER (?) AND UPPER (CCSFCertificationNum) LIKE UPPER (?)\n" +
"           ORDER BY [inactive_datetime] ASC, [updated_datetime] ASC;"; 
            
            try {
                stmt = connection.prepareStatement(SQL);
                stmt.setString(1, facilityName);
                stmt.setString(2, certNumber);
                sResultSet = stmt.executeQuery();
                esListMap = convertResultSetToListMap (sResultSet);
                sResultSet.close();
            } catch (Exception ex) {
                logger.error("stmt.executeQuery failed" + ex.getMessage());
                throw (ex);
            } finally {
                if (stmt != null) {
                   stmt.close();
                }
            }
        }
        
        com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, stmt, sResultSet);

        return esListMap;
    }
  
    
    private List<Map> convertResultSetToListMap (ResultSet searchResultSet) throws Exception{
        List<Map> listMap = new ArrayList();
        Map map = new HashMap();
        String allCommodityTypes;
        
      
        while (searchResultSet.next()){
            map = new HashMap();
            
            if (searchResultSet.getString("CCSFCertificationNum") == null){
                map.put("certificationNumber", "");
            } else {
                map.put("certificationNumber", searchResultSet.getString("CCSFCertificationNum"));
            }
            
            if (searchResultSet.getString("FacilityName") == null){
                map.put("facilityName", "");
            } else {
                map.put("facilityName", searchResultSet.getString("FacilityName"));
            }
            
            if (searchResultSet.getString("CompanyName") == null){
                map.put("companyName", "");
            } else {
                map.put("companyName", searchResultSet.getString("CompanyName"));
            }
            
            map.put("type", "FACILITYTYPE");
            
            if (searchResultSet.getString("IACNum") == null){
                map.put("iacNumber", "");
            } else {
                map.put("iacNumber", searchResultSet.getString("IACNum"));
            }
            
            if (searchResultSet.getString("StaAuthorizationKey") == null){
                map.put("staAuthorizationKey", "");
            } else {
                map.put("staAuthorizationKey", searchResultSet.getString("StaAuthorizationKey"));
            }
            
            if (searchResultSet.getString("inactive_datetime") == null){
                map.put("ccsfStatus", "Active");
            } else {
                map.put("ccsfStatus", "Inactive");
            }
            
            if (searchResultSet.getString("CertificationStatus") == null){
                map.put("certificationStatus", "");
            } else {
                map.put("certificationStatus", searchResultSet.getString("CertificationStatus"));
            }
            
            if (searchResultSet.getString("IATACode") == null){
                map.put("portCode", "");
            } else {
                map.put("portCode", searchResultSet.getString("IATACode"));
            }
            
            if (searchResultSet.getString("FacilityPhone") == null){
                map.put("phone", "");
            } else {
                map.put("phone", searchResultSet.getString("FacilityPhone"));
            }
            
            if (searchResultSet.getString("FacilityStreetAddress") == null){
                map.put("addressLine1", "");
            } else {
                map.put("addressLine1", searchResultSet.getString("FacilityStreetAddress"));
            }
            
            if (searchResultSet.getString("FacilityCity") == null){
                map.put("city", "");
            } else {
                map.put("city", searchResultSet.getString("FacilityCity"));
            }
            
            if (searchResultSet.getString("FacilityZip") == null){
                map.put("zipPostalCode", "");
            } else {
                map.put("zipPostalCode", searchResultSet.getString("FacilityZip"));
            }
            
            if (searchResultSet.getString("FacilityState") == null){
                map.put("stateProvinceCode", "");
            } else {
                map.put("stateProvinceCode", searchResultSet.getString("FacilityState"));
            }
            
            if (searchResultSet.getString("NotesFacility") == null){
                map.put("facilityNotes", "");
            } else {
                map.put("facilityNotes", searchResultSet.getString("NotesFacility"));
            }
            
            if (searchResultSet.getString("NotesCertification") == null){
                map.put("certificationNotes", "");
            } else {
                map.put("certificationNotes", searchResultSet.getString("NotesCertification"));
            }
            
            if (searchResultSet.getString("DSA_ChangeDetail") == null){
                map.put("dsaChangeDetails", "");
            } else {
                map.put("dsaChangeDetails", searchResultSet.getString("DSA_ChangeDetail"));
            }
            
            if (searchResultSet.getString("NotesAssessment") == null){
                map.put("assessmentNotes", "");
            } else {
                map.put("assessmentNotes", searchResultSet.getString("NotesAssessment"));
            }
            
            if (searchResultSet.getString("FC1_FullName") == null){
                map.put("fc1Fullname", "");
            } else {
                map.put("fc1Fullname", searchResultSet.getString("FC1_FullName"));
            }
            
            if (searchResultSet.getString("FC1_Title") == null){
                map.put("fc1Title", "");
            } else {
                map.put("fc1Title", searchResultSet.getString("FC1_Title"));
            }
            
            if (searchResultSet.getString("FC1_PrimaryPhone") == null){
                map.put("fc1PrimaryPhone", "");
            } else {
                map.put("fc1PrimaryPhone", searchResultSet.getString("FC1_PrimaryPhone"));
            }
            
            if (searchResultSet.getString("FC1_Email") == null){
                map.put("fc1Email", "");
            } else {
                map.put("fc1Email", searchResultSet.getString("FC1_Email"));
            }
            
            if (searchResultSet.getString("FC2_FullName") == null){
                map.put("fc2Fullname", "");
            } else {
                map.put("fc2Fullname", searchResultSet.getString("FC2_FullName"));
            }
            
            if (searchResultSet.getString("FC2_Title") == null){
                map.put("fc2Title", "");
            } else {
                map.put("fc2Title", searchResultSet.getString("FC2_Title"));
            }
            
            if (searchResultSet.getString("FC2_PrimaryPhone") == null){
                map.put("fc2PrimaryPhone", "");
            } else {
                map.put("fc2PrimaryPhone", searchResultSet.getString("FC2_PrimaryPhone"));
            }
            
            if (searchResultSet.getString("FC2_Email") == null){
                map.put("fc2Email", "");
            } else {
                map.put("fc2Email", searchResultSet.getString("FC2_Email"));
            }
            
            if (searchResultSet.getString("CPSC_Name") == null){
                map.put("cpscName", "");
            } else {
                map.put("cpscName", searchResultSet.getString("CPSC_Name"));
            }
            
            if (searchResultSet.getString("CPSC_Title") == null){
                map.put("cpscTitle", "");
            } else {
                map.put("cpscTitle", searchResultSet.getString("CPSC_Title"));
            }
            
            if (searchResultSet.getString("CPSC_Phone") == null){
                map.put("cpscPhone", "");
            } else {
                map.put("cpscPhone", searchResultSet.getString("CPSC_Phone"));
            }
            
            if (searchResultSet.getString("CPSC_Email") == null){
                map.put("cpscEmail", "");
            } else {
                map.put("cpscEmail", searchResultSet.getString("CPSC_Email"));
            }
            
            if (searchResultSet.getString("FSC_Name") == null){
                map.put("fscName", "");
            } else {
                map.put("fscName", searchResultSet.getString("FSC_Name"));
            }
            
            if (searchResultSet.getString("FSC_Title") == null){
                map.put("fscTitle", "");
            } else {
                map.put("fscTitle", searchResultSet.getString("FSC_Title"));
            }
            
            if (searchResultSet.getString("FSC_Phone") == null){
                map.put("fscPhone", "");
            } else {
                map.put("fscPhone", searchResultSet.getString("FSC_Phone"));
            }
            
            if (searchResultSet.getString("FSC_Email") == null){
                map.put("fscEmail", "");
            } else {
                map.put("fscEmail", searchResultSet.getString("FSC_Email"));
            }
            
            if (searchResultSet.getString("Required_Recertification_Date") == null){
                map.put("requiredRecertificationDate", "");
            } else {
                map.put("requiredRecertificationDate", searchResultSet.getString("Required_Recertification_Date"));
            }
            
            if (searchResultSet.getString("Recertification_Date") == null){
                map.put("recertificationDate", "");
            } else {
                map.put("recertificationDate", searchResultSet.getString("Recertification_Date"));
            }
            
            if (searchResultSet.getString("RecertificationStatus") == null){
                map.put("recertificationStatus", "");
            } else {
                map.put("recertificationStatus", searchResultSet.getString("RecertificationStatus"));
            }
            
            if (searchResultSet.getString("MoveRecertStatus") == null){
                map.put("moveRecertStatus", "");
            } else {
                map.put("moveRecertStatus", searchResultSet.getString("MoveRecertStatus"));
            }
            
            if (searchResultSet.getString("OperationalStatus") == null){
                map.put("operationalStatus", "");
            } else {
                map.put("operationalStatus", searchResultSet.getString("OperationalStatus"));
            }
            
            if (searchResultSet.getString("ApplicantTypeCode") == null){
                map.put("applicantTypeCode", "");
				map.put("applicationType", "");
            } else {
                map.put("applicantTypeCode", searchResultSet.getString("ApplicantTypeCode"));
		if (searchResultSet.getString("ApplicantTypeCode") != null) {
                    if (searchResultSet.getString("ApplicantTypeCode").equalsIgnoreCase("i")){
			map.put("applicationType", "Independent");
                    } else if (searchResultSet.getString("ApplicantTypeCode").equalsIgnoreCase("c")){
			map.put("applicationType", "Indirect Air Carrier");
                    } else if (searchResultSet.getString("ApplicantTypeCode").equalsIgnoreCase("s")){
			map.put("applicationType", "Shipper");
                    } else {
                        map.put("applicationType", searchResultSet.getString("ApplicantTypeCode"));
                    }
	        }
            }
            
            if (searchResultSet.getString("ApplicationStatus") == null){
                map.put("applicationStatus", "");
            } else {
                map.put("applicationStatus", searchResultSet.getString("ApplicationStatus"));
            }
            
            if (searchResultSet.getString("Suspense_Date") == null){
                map.put("suspenseDate", "");
            } else {
                 map.put("suspenseDate", searchResultSet.getString("Suspense_Date"));
            }
            
            if (searchResultSet.getString("SuspenseType") == null){
                map.put("suspenseType", "");
            } else {
                map.put("suspenseType", searchResultSet.getString("SuspenseType"));
            }
            
            if (searchResultSet.getString("CommodityTypesShipped") == null){
                map.put("commodityTypesShipped", "");
            } else {
                map.put("commodityTypesShipped", searchResultSet.getString("CommodityTypesShipped"));
            }
            
            if (searchResultSet.getString("Amendment") == null){
                map.put("amendment", "");
            } else {
                map.put("amendment", searchResultSet.getString("Amendment"));
            }
            
            if (searchResultSet.getString("Amendment_ExpireDate") == null){
                map.put("amendmentExpireDate", "");
            } else {
                map.put("amendmentExpireDate", searchResultSet.getString("Amendment_ExpireDate"));
            }
            
            if (searchResultSet.getString("Amendment_Details") == null){
                map.put("amendmentDetails", "");
            } else {
                map.put("amendmentDetails", searchResultSet.getString("Amendment_Details"));
            }
            
            if (searchResultSet.getString("Commodity_1_Specific") == null){
                map.put("commodity1Specific", "");
            } else {
                map.put("commodity1Specific", searchResultSet.getString("Commodity_1_Specific"));
            }
            
            allCommodityTypes = searchResultSet.getString("Commodity_1_Specific");
            
            if (searchResultSet.getString("Commodity_2_Specific") == null){
                map.put("commodity2Specific", "");
            } else {
                map.put("commodity2Specific", searchResultSet.getString("Commodity_2_Specific"));
                allCommodityTypes = allCommodityTypes + "," + searchResultSet.getString("Commodity_2_Specific");
            }
            
            if (searchResultSet.getString("Commodity_3_Specific") == null){
                map.put("commodity3Specific", "");
            } else {
                map.put("commodity3Specific", searchResultSet.getString("Commodity_3_Specific"));
                allCommodityTypes = allCommodityTypes + "," + searchResultSet.getString("Commodity_3_Specific");
            }
            
            if (searchResultSet.getString("Commodity_4_Specific") == null){
                map.put("commodity4Specific", "");
            } else {
                map.put("commodity4Specific", searchResultSet.getString("Commodity_4_Specific"));
                allCommodityTypes = allCommodityTypes + "," + searchResultSet.getString("Commodity_4_Specific");
            }
            
            if (searchResultSet.getString("Commodity_5_Specific") == null){
                map.put("commodity5Specific", "");
            } else {
                map.put("commodity5Specific", searchResultSet.getString("Commodity_5_Specific"));
                allCommodityTypes = allCommodityTypes + "," + searchResultSet.getString("Commodity_5_Specific");
            }
            
            if (searchResultSet.getString("Commodity_6_Specific") == null){
                map.put("commodity6Specific", "");
            } else {
                map.put("commodity6Specific", searchResultSet.getString("Commodity_6_Specific"));
                allCommodityTypes = allCommodityTypes + "," + searchResultSet.getString("Commodity_6_Specific");
            }
            
            if (searchResultSet.getString("Commodity_7_Specific") == null){
                map.put("commodity7Specific", "");
            } else {
                map.put("commodity7Specific", searchResultSet.getString("Commodity_7_Specific"));
                allCommodityTypes = allCommodityTypes + "," + searchResultSet.getString("Commodity_7_Specific");
            }
            
            if (searchResultSet.getString("Commodity_8_Specific") == null){
                map.put("commodity8Specific", "");
            } else {
                map.put("commodity8Specific", searchResultSet.getString("Commodity_8_Specific"));
                allCommodityTypes = allCommodityTypes + "," + searchResultSet.getString("Commodity_8_Specific");
            }
            
            if (searchResultSet.getString("Commodity_9_Specific") == null){
                map.put("commodity9Specific", "");
            } else {
                map.put("commodity9Specific", searchResultSet.getString("Commodity_9_Specific"));
                allCommodityTypes = allCommodityTypes + "," + searchResultSet.getString("Commodity_9_Specific");
            }
            
            if (searchResultSet.getString("Commodity_10_Specific") == null){
                map.put("commodity10Specific", "");
            } else {
                map.put("commodity10Specific", searchResultSet.getString("Commodity_10_Specific"));
                allCommodityTypes = allCommodityTypes + "," + searchResultSet.getString("Commodity_10_Specific");
            }
            
            if (searchResultSet.getString("Commodity_11_Specific") == null){
                map.put("commodity11Specific", "");
            } else {
                allCommodityTypes = allCommodityTypes + "," + searchResultSet.getString("Commodity_11_Specific");
            }
            
            map.put("commodity11Specific", allCommodityTypes);
            
            listMap.add(map);
        }
        
        return listMap;
    }
    
    private List<Map> convertResultSetToListMapForSummaryPage (ResultSet searchResultSet) throws Exception{
        List<Map> listMap = new ArrayList();
        Map map = new HashMap();
        String allCommodityTypes;
        
      
        while (searchResultSet.next()){
            map = new HashMap();
            
            if (searchResultSet.getString("CCSFCertificationNum") == null){
                map.put("certificationNumber", "");
            } else {
                map.put("certificationNumber", searchResultSet.getString("CCSFCertificationNum"));
            }
            
            if (searchResultSet.getString("FacilityName") == null){
                map.put("facilityName", "");
            } else {
                map.put("facilityName", searchResultSet.getString("FacilityName"));
            }
            
            if (searchResultSet.getString("CompanyName") == null){
                map.put("companyName", "");
            } else {
                map.put("companyName", searchResultSet.getString("CompanyName"));
            }
            
            map.put("type", "FACILITYTYPE");
            
            if (searchResultSet.getString("IACNum") == null){
                map.put("iacNumber", "");
            } else {
                map.put("iacNumber", searchResultSet.getString("IACNum"));
            }
            
            if (searchResultSet.getString("StaAuthorizationKey") == null){
                map.put("staAuthorizationKey", "");
            } else {
                map.put("staAuthorizationKey", searchResultSet.getString("StaAuthorizationKey"));
            }
            
            if (searchResultSet.getString("inactive_datetime") == null){
                map.put("ccsfStatus", "Active");
            } else {
                map.put("ccsfStatus", "Inactive");
            }
            
            if (searchResultSet.getString("CertificationStatus") == null){
                map.put("certificationStatus", "");
            } else {
                map.put("certificationStatus", searchResultSet.getString("CertificationStatus"));
            }
            
            if (searchResultSet.getString("IATACode") == null){
                map.put("portCode", "");
            } else {
                map.put("portCode", searchResultSet.getString("IATACode"));
            }
            
            if (searchResultSet.getString("ApplicantTypeCode") == null){
                map.put("applicantTypeCode", "");
				map.put("applicationType", "");
            } else {
                map.put("applicantTypeCode", searchResultSet.getString("ApplicantTypeCode"));
		if (searchResultSet.getString("ApplicantTypeCode") != null) {
                    if (searchResultSet.getString("ApplicantTypeCode").equalsIgnoreCase("i")){
			map.put("applicationType", "Independent");
                    } else if (searchResultSet.getString("ApplicantTypeCode").equalsIgnoreCase("c")){
			map.put("applicationType", "Indirect Air Carrier");
                    } else if (searchResultSet.getString("ApplicantTypeCode").equalsIgnoreCase("s")){
			map.put("applicationType", "Shipper");
                    } else {
                        map.put("applicationType", searchResultSet.getString("ApplicantTypeCode"));
                    }
	        }
            }
            
            if (searchResultSet.getString("ApplicationStatus") == null){
                map.put("applicationStatus", "");
            } else {
                map.put("applicationStatus", searchResultSet.getString("ApplicationStatus"));
            }
            
            listMap.add(map);
        }
        
        return listMap;
    }
}
