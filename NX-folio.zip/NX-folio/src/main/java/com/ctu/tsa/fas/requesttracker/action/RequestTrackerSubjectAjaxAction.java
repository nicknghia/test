/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.requesttracker.action;

import com.ctu.tsa.fas.requesttracker.dao.RequestTrackerDAO;
import com.ctu.tsa.fas.requesttracker.data.RequestReferenceData;
import com.ctu.tsa.fas.requesttracker.model.Request;
import java.util.LinkedHashMap;
import java.util.Map;
import com.opensymphony.xwork2.Action;

import java.util.List;
import org.apache.log4j.Logger;

public class RequestTrackerSubjectAjaxAction implements Action {

    private Map<String, String> requestorMap = new LinkedHashMap<String, String>();

    private String message = "";
    private String requestTypeValue;
    private String requestNumberValue;
    private String ajaxSubjectType, ajaxName;

	protected Logger logger = Logger.getLogger(getClass());

    public String execute() {
	    logger.debug("****** AjaxJsonAction  execute  Request Type:  "+ requestTypeValue);
        return SUCCESS;
    }

    public String checkDuplicateSubject() {
	    logger.debug("*** RequestTrackerSubjectAjaxAction.checkDuplicateSubject:  "+ ajaxSubjectType);      
        
        if (null == ajaxSubjectType) {
            return null;
        } else {
            String params[] = ajaxSubjectType.split("~~");
            
            RequestTrackerDAO dao = RequestTrackerDAO.getInstance();
            List<Request> requestList = null;
            try {
                requestList = dao.getRequestsForSubject(params[0], params[1]);

                if (null != requestList && !requestList.isEmpty()) {
                   for (Request request : requestList) {
                        message += request.getRequestNumber() + " ";
                    }
                }

            } catch (Exception e) {
                logger.debug("*** EXCEPTION 1::  "+ e.getMessage());               
            }
        }       
        
        return SUCCESS;
    }


    public String getRequestByRequestNumberAction() {
        RequestTrackerDAO dao = RequestTrackerDAO.getInstance();
        Request request = null;
        try {
            request = dao.getRequest(requestNumberValue);
            
            if (null != request) {
                String requestFields = request.toAjaxString().replaceAll("null", "");
                message = requestFields;
            }

        } catch (Exception e) {
		    logger.debug("*** EXCEPTION 1::  "+ e.getMessage());            
        }
        return SUCCESS;
    }


    public Map<String, String> getRequestorMap() {
        return requestorMap;
    }

    public void setRequestorMap(Map<String, String> requestorMap) {
        this.requestorMap = requestorMap;
    }

    public String getRequestTypeValue() {
        return requestTypeValue;
    }

    public void setRequestTypeValue(String requestTypeValue) {
        this.requestTypeValue = requestTypeValue;
    }

    public String getRequestNumberValue() {
        return requestNumberValue;
    }

    public void setRequestNumberValue(String requestNumberValue) {
        this.requestNumberValue = requestNumberValue;
    }

    public String getAjaxSubjectType() {
        return ajaxSubjectType;
    }

    public void setAjaxSubjectType(String ajaxSubjectType) {
        this.ajaxSubjectType = ajaxSubjectType;
    }

    public String getAjaxName() {
        return ajaxName;
    }

    public void setAjaxName(String ajaxName) {
        this.ajaxName = ajaxName;
    }
    
    

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
    
    
    
}
