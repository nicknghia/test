/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.dao;

import com.ctu.tsa.fas.expandedsearch.model.SubjectIndividualDetails;
import java.sql.Connection;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import java.util.List;
import java.util.*;
import org.hibernate.Session;
import java.sql.*;
import java.sql.DriverManager;
import java.util.Map;
import oracle.jdbc.OracleTypes;
import oracle.jdbc.pool.OracleDataSource;
import org.json.JSONArray;
import org.json.JSONObject;

/*
 * @author Binh.Nguyen
 */
public class ExpandedSearchSubjectIndividualDAO {	

	private static ExpandedSearchSubjectIndividualDAO instance = null;

	protected Logger logger = Logger.getLogger(getClass());

	public ExpandedSearchSubjectIndividualDAO() {

	}

	public static ExpandedSearchSubjectIndividualDAO getInstance() {
		if (instance == null) {
			instance = new ExpandedSearchSubjectIndividualDAO();
		}
		return instance;
	}

	public class MySqlResults {
		List<Map> sListMap;
		long totalCount;

		public List<Map> getSListMap() {
			return sListMap;
		}

		public void setSListMap(List<Map> sListMap) {
			this.sListMap = sListMap;
		}

		public long getTotalCount() {
			return totalCount;
		}

		public void setTotalCount(long totalCount) {
			this.totalCount = totalCount;
		}
	}

	public MySqlResults getRecordByStatIdSummaryPage(
			String subjectIndividualStatId) throws Exception {

		logger.info("ExpandedSujectIndividualSearchDAO - subjectIndividualStatId: "
						+ subjectIndividualStatId);

		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		MySqlResults sqlResults = new MySqlResults();
		int count;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<SubjectIndividualDetails> subjectIndividualDetails = new ArrayList<SubjectIndividualDetails>();
		Session session = null;

		String stProcName = "EGOV_IAC.FAS_SUBJECT_INDIVIDUAL.SEL_RECORD_BY_STAID";
		String tCallableStmtStr = "{call " + stProcName + "(?,?,?)}";

		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;

		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, subjectIndividualStatId);
                    eStatement.registerOutParameter(2, OracleTypes.CURSOR);
                    eStatement.registerOutParameter(3, OracleTypes.INTEGER);
                    eReturnCode = eStatement.execute();
                    count = (int) eStatement.getObject(3);
                    sResultSet = (ResultSet) eStatement.getObject(2);
                    esListMap = convertResultSetToListMapForSummaryPage(sResultSet);
                    sqlResults.sListMap = esListMap;
                    sqlResults.totalCount = count;
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getSubjectIndividualConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
                    if (eStatement != null) {
					   eStatement.close();
					}
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return sqlResults;
	}

	public MySqlResults getSubjectIndividualByLastName(
			String subjectIndividualLastName) throws Exception {

		logger.info("ExpandedSujectIndividualSearchDAO - subjectIndividualLastName: "
						+ subjectIndividualLastName);
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		MySqlResults sqlResults = new MySqlResults();
		int count;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<SubjectIndividualDetails> subjectIndividualDetails = new ArrayList<SubjectIndividualDetails>();
		Session session = null;

		String stProcName = "EGOV_IAC.FAS_SUBJECT_INDIVIDUAL.SEL_RECORD_BY_LAST_NAME";
		String tCallableStmtStr = "{call " + stProcName + "(?,?,?)}";

		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;

		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, subjectIndividualLastName);
                    eStatement.registerOutParameter(2, OracleTypes.CURSOR);
                    eStatement.registerOutParameter(3, OracleTypes.INTEGER);
                    eReturnCode = eStatement.execute();
                    count = (int) eStatement.getObject(3);
                    sResultSet = (ResultSet) eStatement.getObject(2);
                    esListMap = convertResultSetToListMapForLastNameSummaryPage(sResultSet);
                    sqlResults.sListMap = esListMap;
                    sqlResults.totalCount = count;
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getSubjectIndividualConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
                    if (eStatement != null) {
					   eStatement.close();
					}
                }

		
		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return sqlResults;
	}

	public MySqlResults getSubjectIndividualByFirstNameLastName(
			String subjectIndividualFirstName, String subjectIndividualLastName)
			throws Exception {

		logger.info("ExpandedSujectIndividualSearchDAO - subjectIndividualFirstName: "
						+ subjectIndividualFirstName);
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		MySqlResults sqlResults = new MySqlResults();
		int count;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<SubjectIndividualDetails> subjectIndividualDetails = new ArrayList<SubjectIndividualDetails>();
		Session session = null;

		String stProcName = "EGOV_IAC.FAS_SUBJECT_INDIVIDUAL.SEL_RECORD_BY_FIRST_LAST_NAME";
		String tCallableStmtStr = "{call " + stProcName + "(?,?,?,?)}";

		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;

		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, subjectIndividualFirstName);
                    eStatement.setString(2, subjectIndividualLastName);
                    eStatement.registerOutParameter(3, OracleTypes.CURSOR);
                    eStatement.registerOutParameter(4, OracleTypes.INTEGER);
                    eReturnCode = eStatement.execute();
                    count = (int) eStatement.getObject(4);
                    sResultSet = (ResultSet) eStatement.getObject(3);
                    esListMap = convertResultSetToListMapForLastNameSummaryPage(sResultSet);
                    sqlResults.sListMap = esListMap;
                    sqlResults.totalCount = count;
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getSubjectCompanyConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
		           if (eStatement != null) {
					   eStatement.close();
					}
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return sqlResults;
	}

	public List<Map> getSubjectIndividualDetailsByStatIdLastNameFirstName(
			String subjectIndividualStaId, String subjectIndividualLastName,
			String subjectIndividualFirstName) throws Exception {

		logger.info("ExpandedSujectIndividualSearchDAO - Detail - subjectIndividualStaId: "
						+ subjectIndividualStaId);
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<SubjectIndividualDetails> subjectIndividualDetails = new ArrayList<SubjectIndividualDetails>();
		Session session = null;

		String stProcName = "EGOV_IAC.FAS_SUBJECT_INDIVIDUAL.SEL_REC_DET_BY_STA_LAST_FIRST";
		String tCallableStmtStr = "{call " + stProcName + "(?,?,?,?)}";

		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;

		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, subjectIndividualStaId);
                    eStatement.setString(2, subjectIndividualLastName);
                    eStatement.setString(3, subjectIndividualFirstName);
                    eStatement.registerOutParameter(4, OracleTypes.CURSOR);
                    eReturnCode = eStatement.execute();
                    sResultSet = (ResultSet) eStatement.getObject(4);
                    esListMap = convertResultSetToListMapForDetailPage(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getSubjectCompanyConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
                    if (eStatement != null) {
					   eStatement.close();
					}
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
                    eStatement, sResultSet);

		return esListMap;
	}

	public List<Map> getSubjectIndividualByResidentialPhysical(String subjectIndividualStaId, 
                String subjectIndividualLastName, String subjectIndividualFirstName) 
                throws Exception {

		logger.info("ExpandedSujectIndividualSearchDAO - Physical - subjectIndividualStaId: "
						+ subjectIndividualStaId);
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<SubjectIndividualDetails> subjectIndividualDetails = new ArrayList<SubjectIndividualDetails>();
		Session session = null;

		String stProcName = "EGOV_IAC.FAS_SUBJECT_INDIVIDUAL.SEL_COMP_IN_PHY";
		String tCallableStmtStr = "{call " + stProcName + "(?,?,?,?)}";

		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;

		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, subjectIndividualStaId);
                    eStatement.setString(2, subjectIndividualLastName);
                    eStatement.setString(3, subjectIndividualFirstName);
                    eStatement.registerOutParameter(4, OracleTypes.CURSOR);
                    eReturnCode = eStatement.execute();
                    sResultSet = (ResultSet) eStatement.getObject(4);
                    esListMap = convertResultSetToListMapForResidentialPhysical(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getSubjectCompanyConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
                    if (eStatement != null) {
					   eStatement.close();
					}
                }
                
		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return esListMap;
	}

	public List<Map> getSubjectIndividualByPersonalInfor(String subjectIndividualStaId, String subjectIndividualLastName, 
                String subjectIndividualFirstName) throws Exception {

		logger.info("ExpandedSujectIndividualSearchDAO - Personal Infor - subjectIndividualStaId: "
						+ subjectIndividualStaId);
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<SubjectIndividualDetails> subjectIndividualDetails = new ArrayList<SubjectIndividualDetails>();
		Session session = null;

		String stProcName = "EGOV_IAC.FAS_SUBJECT_INDIVIDUAL.SEL_COMP_IN_PER";
		String tCallableStmtStr = "{call " + stProcName + "(?,?,?,?)}";

		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;

		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, subjectIndividualStaId);
                    eStatement.setString(2, subjectIndividualLastName);
                    eStatement.setString(3, subjectIndividualFirstName);
                    eStatement.registerOutParameter(4, OracleTypes.CURSOR);
                    eReturnCode = eStatement.execute();
                    sResultSet = (ResultSet) eStatement.getObject(4);
                    esListMap = convertResultSetToListMapForPersonalInfor(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getSubjectIndividualConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
                    if (eStatement != null) {
					   eStatement.close();
					}
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return esListMap;
	}

	public List<Map> getSubjectIndividualByCznInfor(String subjectIndividualStaId, String subjectIndividualLastName, 
                String subjectIndividualFirstName) throws Exception {

		logger.info("ExpandedSujectIndividualSearchDAO - Citizenship Infor - subjectIndividualStaId: "
						+ subjectIndividualStaId);
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<SubjectIndividualDetails> subjectIndividualDetails = new ArrayList<SubjectIndividualDetails>();
		Session session = null;

		String stProcName = "EGOV_IAC.FAS_SUBJECT_INDIVIDUAL.SEL_COMP_IN_CZN";
		String tCallableStmtStr = "{call " + stProcName + "(?,?,?,?)}";

		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;

		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, subjectIndividualStaId);
                    eStatement.setString(2, subjectIndividualLastName);
                    eStatement.setString(3, subjectIndividualFirstName);
                    eStatement.registerOutParameter(4, OracleTypes.CURSOR);
                    eReturnCode = eStatement.execute();
                    sResultSet = (ResultSet) eStatement.getObject(4);
                    esListMap = convertResultSetToListMapForCznInfor(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
			logger.error("getSubjectCompanyConnection failed" + ex.getMessage());
			throw (ex);
		} finally {
                    if (eStatement != null) {
					   eStatement.close();
					}
                }
                
		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return esListMap;
	}

	public List<Map> getSubjectIndividualByIac(String subjectIndividualStaId, String subjectIndividualLastName, 
                String subjectIndividualFirstName) throws Exception {

		logger.info("ExpandedSujectIndividualSearchDAO - IAC - subjectIndividualStaId: "
						+ subjectIndividualStaId);
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<SubjectIndividualDetails> subjectIndividualDetails = new ArrayList<SubjectIndividualDetails>();
		Session session = null;

		String stProcName = "EGOV_IAC.FAS_SUBJECT_INDIVIDUAL.SEL_COMP_IN_IAC";
		String tCallableStmtStr = "{call " + stProcName + "(?,?,?,?)}";

		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;

		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, subjectIndividualStaId);
                    eStatement.setString(2, subjectIndividualLastName);
                    eStatement.setString(3, subjectIndividualFirstName);
                    eStatement.registerOutParameter(4, OracleTypes.CURSOR);
                    eReturnCode = eStatement.execute();
                    sResultSet = (ResultSet) eStatement.getObject(4);
                    esListMap = convertResultSetToListMapForIac(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getSubjectCompanyConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
                    if (eStatement != null) {
					   eStatement.close();
					}
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return esListMap;
	}

	public List<Map> getSubjectIndividualByAgent(String subjectIndividualStaId, String subjectIndividualLastName, 
                String subjectIndividualFirstName) throws Exception {

		logger.info("ExpandedSujectIndividualSearchDAO - Agent - subjectIndividualStaId: "
						+ subjectIndividualStaId);
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<SubjectIndividualDetails> subjectIndividualDetails = new ArrayList<SubjectIndividualDetails>();
		Session session = null;

		String stProcName = "EGOV_IAC.FAS_SUBJECT_INDIVIDUAL.SEL_COMP_IN_AGENT";
		String tCallableStmtStr = "{call " + stProcName + "(?,?,?,?)}";

		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;

		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, subjectIndividualStaId);
                    eStatement.setString(2, subjectIndividualLastName);
                    eStatement.setString(3, subjectIndividualFirstName);
                    eStatement.registerOutParameter(4, OracleTypes.CURSOR);
                    eReturnCode = eStatement.execute();
                    sResultSet = (ResultSet) eStatement.getObject(4);
                    esListMap = convertResultSetToListMapForAgent(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
			logger.error("getSubjectCompanyConnection failed" + ex.getMessage());
			throw (ex);
		} finally {
                    if (eStatement != null) {
					   eStatement.close();
					}
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return esListMap;
	}

	public List<Map> getSubjectIndividualByAc(String subjectIndividualStaId, String subjectIndividualLastName, 
                String subjectIndividualFirstName) throws Exception {

		logger.info
				("ExpandedSujectIndividualSearchDAO - AC - subjectIndividualStaId: "
						+ subjectIndividualStaId);
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<SubjectIndividualDetails> subjectIndividualDetails = new ArrayList<SubjectIndividualDetails>();
		Session session = null;

		String stProcName = "EGOV_IAC.FAS_SUBJECT_INDIVIDUAL.SEL_COMP_IN_AC";
		String tCallableStmtStr = "{call " + stProcName + "(?,?,?,?)}";

		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;

		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, subjectIndividualStaId);
                    eStatement.setString(2, subjectIndividualLastName);
                    eStatement.setString(3, subjectIndividualFirstName);
                    eStatement.registerOutParameter(4, OracleTypes.CURSOR);
                    eReturnCode = eStatement.execute();
                    sResultSet = (ResultSet) eStatement.getObject(4);
                    esListMap = convertResultSetToListMapForAc(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
			logger.error("getSubjectIndividualConnection failed" + ex.getMessage());
			throw (ex);
		} finally {
                    if (eStatement != null) {
					   eStatement.close();
					}
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return esListMap;
	}

	private List<Map> convertResultSetToListMapForSummaryPage(
			ResultSet searchResultSet) throws Exception {
		List<Map> listMap = new ArrayList();
		Map map = new HashMap();
		String str = "";
		
		while (searchResultSet.next()) {

			map = new HashMap();
			if (searchResultSet.getString("STA_ID") == null) {
				map.put("subjectIndividualStaId", "");
			} else {
				map.put("subjectIndividualStaId",
						searchResultSet.getString("STA_ID"));
			}
			if (searchResultSet.getString("TYPE") == null) {
				map.put("subjectIndividualType", "");
			} else {
				map.put("subjectIndividualType",
						searchResultSet.getString("TYPE"));
			}

			if (searchResultSet.getString("SUBMITTED_BY_ENTITY") == null) {
				map.put("subjectIndividualSubmittedByEntity", "");
			} else {
				map.put("subjectIndividualSubmittedByEntity",
						searchResultSet.getString("SUBMITTED_BY_ENTITY"));
			}

			if (searchResultSet.getString("LAST_NAME") == null) {
				map.put("subjectIndividualLastName", "");
			} else {
				map.put("subjectIndividualLastName",
						searchResultSet.getString("LAST_NAME"));
			}

			if (searchResultSet.getString("FIRST_NAME") == null) {
				map.put("subjectIndividualFirstName", "");
			} else {
				map.put("subjectIndividualFirstName",
						searchResultSet.getString("FIRST_NAME"));
			}

			if (searchResultSet.getString("CREATION_DATE") == null) {
				map.put("subjectIndividualCreationDate", "");
			} else {
				str = searchResultSet.getString("CREATION_DATE");
				map.put("subjectIndividualCreationDate", str.substring(0, str.indexOf(' ')));
			}

			if (searchResultSet.getString("ISSUED_DATE") == null) {
				map.put("subjectIndividualIssuedDate", "");
			} else {
				str = searchResultSet.getString("ISSUED_DATE");
				map.put("subjectIndividualIssuedDate", str.substring(0, str.indexOf(' ')));
			}

			if (searchResultSet.getString("EXPIRATION_DATE") == null) {
				map.put("subjectIndividualExpirationDate", "");
			} else {
				str = searchResultSet.getString("EXPIRATION_DATE");
				map.put("subjectIndividualExpirationDate", str.substring(0, str.indexOf(' ')));
			}

			if (searchResultSet.getString("RECORD_STATUS") == null) {
				map.put("subjectIndividualRecordStatus", "");
			} else {
				if (searchResultSet.getString("RECORD_STATUS")
						.equalsIgnoreCase("A")) {
					map.put("subjectIndividualRecordStatus", "Active");
				} else if (searchResultSet.getString("RECORD_STATUS")
						.equalsIgnoreCase("I")) {
					map.put("subjectIndividualRecordStatus", "Inactive");
				}
			}

			if (searchResultSet.getString("STA_STATUS") == null) {
				map.put("subjectIndividualStaStatus", "");
				map.put("subjectIndividualIssuedDate", "");
			} else {
				if (searchResultSet.getString("STA_STATUS").equalsIgnoreCase(
						"STAAWAITINGPAYMNT")) {
					map.put("subjectIndividualStaStatus", "Awaiting Payment");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAERROR")) {
					map.put("subjectIndividualStaStatus", "STA Error");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAERRORTTAC")) {
					map.put("subjectIndividualStaStatus", "STA Error");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAINPROGRESS")) {
					map.put("subjectIndividualStaStatus", "STA In Progress"); 
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STADENIED")) {
					map.put("subjectIndividualStaStatus", "STA Denied");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAPASSED")) {
					map.put("subjectIndividualStaStatus", "Passed");					
					if (searchResultSet.getString("ISSUED_DATE") == null) {
				       map.put("subjectIndividualIssuedDate", "");
			        } else {
				      str = searchResultSet.getString("ISSUED_DATE");
				      map.put("subjectIndividualIssuedDate", str.substring(0, str.indexOf(' ')));
			        }
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("PAYCNFRMD")) {
					map.put("subjectIndividualStaStatus", "Payment Confirmed");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAINCOMPL")) {
					map.put("subjectIndividualStaStatus", "STA Incomplete"); 
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAEXPIRED")) {
					map.put("subjectIndividualStaStatus", "STA Expired"); 
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAPENDINGAPPRVL")) {
					map.put("subjectIndividualStaStatus", "STA Pending Approval");
					map.put("subjectIndividualIssuedDate", "");
				} else {
					map.put("subjectIndividualStaStatus",
							searchResultSet.getString("STA_STATUS"));
					map.put("subjectIndividualIssuedDate", "");
				}
			}
			listMap.add(map);

		}

		return listMap;
	}

	private List<Map> convertResultSetToListMapForLastNameSummaryPage(
			ResultSet searchResultSet) throws Exception {
		List<Map> listMap = new ArrayList();
		Map map = new HashMap();
		String str = "";
		
		while (searchResultSet.next()) {

			map = new HashMap();
			if (searchResultSet.getString("STA_ID") == null) {
				map.put("subjectIndividualStaId", "");
			} else {
				map.put("subjectIndividualStaId",
						searchResultSet.getString("STA_ID"));
			}

			if (searchResultSet.getString("LAST_NAME") == null) {
				map.put("subjectIndividualLastName", "");
			} else {
				map.put("subjectIndividualLastName",
						searchResultSet.getString("LAST_NAME"));
			}

			if (searchResultSet.getString("FIRST_NAME") == null) {
				map.put("subjectIndividualFirstName", "");
			} else {
				map.put("subjectIndividualFirstName",
						searchResultSet.getString("FIRST_NAME"));
			}
			
			if (searchResultSet.getString("CREATION_DATE") == null) {
				map.put("subjectIndividualCreationDate", "");
			} else {
				str = searchResultSet.getString("CREATION_DATE");
				map.put("subjectIndividualCreationDate", str.substring(0, str.indexOf(' ')));
			}

			if (searchResultSet.getString("ISSUED_DATE") == null) {
				map.put("subjectIndividualIssuedDate", "");
			} else {
				str = searchResultSet.getString("ISSUED_DATE");
				map.put("subjectIndividualIssuedDate", str.substring(0, str.indexOf(' ')));
			}

			if (searchResultSet.getString("EXPIRATION_DATE") == null) {
				map.put("subjectIndividualExpirationDate", "");
			} else {
				str = searchResultSet.getString("EXPIRATION_DATE");
				map.put("subjectIndividualExpirationDate", str.substring(0, str.indexOf(' ')));
			}
			
			if (searchResultSet.getString("RECORD_STATUS") == null) {
				map.put("subjectIndividualRecordStatus", "");
			} else {
				if (searchResultSet.getString("RECORD_STATUS")
						.equalsIgnoreCase("A")) {
					map.put("subjectIndividualRecordStatus", "Active");
				} else if (searchResultSet.getString("RECORD_STATUS")
						.equalsIgnoreCase("I")) {
					map.put("subjectIndividualRecordStatus", "Inactive");
				}
			}

			if (searchResultSet.getString("STA_STATUS") == null) {
				map.put("subjectIndividualStaStatus", "");
				map.put("subjectIndividualIssuedDate", "");
			} else {
				if (searchResultSet.getString("STA_STATUS").equalsIgnoreCase(
						"STAAWAITINGPAYMNT")) {
					map.put("subjectIndividualStaStatus", "Awaiting Payment");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAERROR")) {
					map.put("subjectIndividualStaStatus", "STA Error");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAERRORTTAC")) {
					map.put("subjectIndividualStaStatus", "STA Error");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STADENIED")) {
					map.put("subjectIndividualStaStatus", "STA Denied");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAINPROGRESS")) {
					map.put("subjectIndividualStaStatus", "STA In Progress");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAPASSED")) {
					map.put("subjectIndividualStaStatus", "Passed");					
					if (searchResultSet.getString("ISSUED_DATE") == null) {
				       map.put("subjectIndividualIssuedDate", "");
			        } else {
				       str = searchResultSet.getString("ISSUED_DATE");
				       map.put("subjectIndividualIssuedDate", str.substring(0, str.indexOf(' ')));
			        }
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("PAYCNFRMD")) {
					map.put("subjectIndividualStaStatus", "Payment Confirmed");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAINCOMPL")) {
					map.put("subjectIndividualStaStatus", "STA Incomplete");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAEXPIRED")) {
					map.put("subjectIndividualStaStatus", "STA Expired");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAPENDINGAPPRVL")) {
					map.put("subjectIndividualStaStatus",
							"STA Pending Approval");
					map.put("subjectIndividualIssuedDate", "");
				} else {
                                        map.put("subjectIndividualStaStatus", searchResultSet.getString("STA_STATUS")); 
                                        map.put("subjectIndividualIssuedDate", "");
                                }	
			}
			listMap.add(map);

		}

		return listMap;
	}

	private List<Map> convertResultSetToListMapForDetailPage(
			ResultSet searchResultSet) throws Exception {

		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {

			map = new HashMap();

			if (searchResultSet.getString("STA_ID") == null) {
				map.put("subjectIndividualStaId", "");
			} else {
				map.put("subjectIndividualStaId",
						searchResultSet.getString("STA_ID"));				
			}

			if (searchResultSet.getString("LAST_NAME") == null) {
				map.put("subjectIndividualLastName", "");
			} else {
				map.put("subjectIndividualLastName",
						searchResultSet.getString("LAST_NAME"));
			}

			if (searchResultSet.getString("FIRST_NAME") == null) {
				map.put("subjectIndividualFirstName", "");
			} else {
				map.put("subjectIndividualFirstName",
						searchResultSet.getString("FIRST_NAME"));
			}

			if (searchResultSet.getString("PERSON_MIDDLE_NAME") == null) {
				map.put("subjectIndividualMiddleName", "");
			} else {
				map.put("subjectIndividualMiddleName",
						searchResultSet.getString("PERSON_MIDDLE_NAME"));
			}

			if (searchResultSet.getString("PERSON_NAME_SUFFIX") == null) {
				map.put("subjectIndividualSuffix", "");
			} else {
				map.put("subjectIndividualSuffix",
						searchResultSet.getString("PERSON_NAME_SUFFIX"));
			}

			if (searchResultSet.getString("CREATION_DATE") == null) {
				map.put("subjectIndividualCreationDate", "");
			} else {
				map.put("subjectIndividualCreationDate",
						searchResultSet.getString("CREATION_DATE"));
			}

			if (searchResultSet.getString("ISSUED_ON_DATE") == null) {
				map.put("subjectIndividualIssuedDate", "");
			} else {
				map.put("subjectIndividualIssuedDate",
						searchResultSet.getString("ISSUED_ON_DATE"));
			}

			if (searchResultSet.getString("EXPIRES_ON_DATE") == null) {
				map.put("subjectIndividualExpirationDate", "");
			} else {
				map.put("subjectIndividualExpirationDate",
						searchResultSet.getString("EXPIRES_ON_DATE"));
			}

			if (searchResultSet.getString("STATUS") == null) {
				map.put("subjectIndividualRecordStatus", "");
			} else {
				if (searchResultSet.getString("STATUS").equalsIgnoreCase("A")) {
					map.put("subjectIndividualRecordStatus", "Active");
				} else if (searchResultSet.getString("STATUS")
						.equalsIgnoreCase("I")) {
					map.put("subjectIndividualRecordStatus", "Inactive");
				}
			}

			if (searchResultSet.getString("CURRENT_STATUS") == null) {
				map.put("subjectIndividualStaStatus", "");
				map.put("subjectIndividualIssuedDate", "");
			} else {
				if (searchResultSet.getString("CURRENT_STATUS")
						.equalsIgnoreCase("STAAWAITINGPAYMNT")) {
					map.put("subjectIndividualStaStatus", "Awaiting Payment");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("CURRENT_STATUS")
						.equalsIgnoreCase("STAERROR")) {
					map.put("subjectIndividualStaStatus", "STA Error");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("CURRENT_STATUS")
						.equalsIgnoreCase("STAERRORTTAC")) {
					map.put("subjectIndividualStaStatus", "STA Error");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("CURRENT_STATUS")
						.equalsIgnoreCase("STAINPROGRESS")) {
					map.put("subjectIndividualStaStatus", "STA In Progress");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("CURRENT_STATUS")
						.equalsIgnoreCase("STADENIED")) {
					map.put("subjectIndividualStaStatus", "STA Denied");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("CURRENT_STATUS")
						.equalsIgnoreCase("STAPASSED")) {
					map.put("subjectIndividualStaStatus", "Passed");
					if (searchResultSet.getString("ISSUED_ON_DATE") == null) {
						map.put("subjectIndividualIssuedDate", "");
					} else {
						map.put("subjectIndividualIssuedDate",
								searchResultSet.getString("ISSUED_ON_DATE"));
					}
				} else if (searchResultSet.getString("CURRENT_STATUS")
						.equalsIgnoreCase("PAYCNFRMD")) {
					map.put("subjectIndividualStaStatus", "Payment Confirmed");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("CURRENT_STATUS")
						.equalsIgnoreCase("STAINCOMPL")) {
					map.put("subjectIndividualStaStatus", "STA Incomplete");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("CURRENT_STATUS")
						.equalsIgnoreCase("STAEXPIRED")) {
					map.put("subjectIndividualStaStatus", "STA Expired");
					map.put("subjectIndividualIssuedDate", "");
				} else if (searchResultSet.getString("CURRENT_STATUS")
						.equalsIgnoreCase("STAPENDINGAPPRVL")) {
					map.put("subjectIndividualStaStatus",
							"STA Pending Approval");
					map.put("subjectIndividualIssuedDate", "");
				} else {
                                        map.put("subjectIndividualStaStatus",
							searchResultSet.getString("CURRENT_STATUS"));
					map.put("subjectIndividualIssuedDate", "");
                                }
			}

			if (searchResultSet.getString("KNOWN_AS") == null) {
				map.put("subjectIndividualAlias1", "");
			} else {
			    if (searchResultSet.getString("KNOWN_AS").equalsIgnoreCase(";;;")) {
					map.put("subjectIndividualAlias1", "");	    				
				} else {				
				    map.put("subjectIndividualAlias1", searchResultSet.getString("KNOWN_AS"));
				}				
			}

			if (searchResultSet.getString("KNOWN_AS2") == null) {
				map.put("subjectIndividualAlias2", "");
			} else {
				if (searchResultSet.getString("KNOWN_AS2").equalsIgnoreCase(";;;")) {
					map.put("subjectIndividualAlias2", "");	    				
				} else {				
				    map.put("subjectIndividualAlias2", searchResultSet.getString("KNOWN_AS2"));
				}
			}

			if (searchResultSet.getString("KNOWN_AS3") == null) {
				map.put("subjectIndividualAlias3", "");
			} else {
				if (searchResultSet.getString("KNOWN_AS3").equalsIgnoreCase(";;;")) {
					map.put("subjectIndividualAlias3", "");	    				
				} else {				
				    map.put("subjectIndividualAlias3", searchResultSet.getString("KNOWN_AS3"));
				}
			}

			if (searchResultSet.getString("STA_ADDRESS") == null) {
				map.put("subjectIndividualAddress1", "");
			} else {
				map.put("subjectIndividualAddress1",
						searchResultSet.getString("STA_ADDRESS"));
			}

			if (searchResultSet.getString("ADDRESS2") == null) {
				map.put("subjectIndividualAddress2", "");
			} else {
				map.put("subjectIndividualAddress2",
						searchResultSet.getString("ADDRESS2"));
			}

			if (searchResultSet.getString("STA_CITY") == null) {
				map.put("subjectIndividualCity", "");
			} else {
				map.put("subjectIndividualCity",
						searchResultSet.getString("STA_CITY"));
			}

			if (searchResultSet.getString("STA_STATE") == null) {
				map.put("subjectIndividualState", "");
			} else {
				map.put("subjectIndividualState",
						searchResultSet.getString("STA_STATE"));
			}

			if (searchResultSet.getString("STA_POSTAL_CODE") == null) {
				map.put("subjectIndividualZipPostalCode", "");
			} else {
				map.put("subjectIndividualZipPostalCode",
						searchResultSet.getString("STA_POSTAL_CODE"));
			}

			if (searchResultSet.getString("COUNTRY") == null) {
				map.put("subjectIndividualCountry", "");
			} else {
				map.put("subjectIndividualCountry",
						searchResultSet.getString("COUNTRY"));
			}

			listMap.add(map);

		}

		return listMap;
	}

	private List<Map> convertResultSetToListMapForResidentialPhysical(
			ResultSet searchResultSet) throws Exception {

		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {

			map = new HashMap();

			if (searchResultSet.getString("ADDRESS1") == null) {
				map.put("subjectIndividualResidentialPhysicalAddress", "");
			} else {
				map.put("subjectIndividualResidentialPhysicalAddress",
						searchResultSet.getString("ADDRESS1"));
			}

			if (searchResultSet.getString("CITY") == null) {
				map.put("subjectIndividualResidentialPhysicalCity", "");
			} else {
				map.put("subjectIndividualResidentialPhysicalCity",
						searchResultSet.getString("CITY"));
			}

			if (searchResultSet.getString("STATE") == null) {
				map.put("subjectIndividualResidentialPhysicalState", "");
			} else {
				map.put("subjectIndividualResidentialPhysicalState",
						searchResultSet.getString("STATE"));
			}

			if (searchResultSet.getString("POSTAL_CODE") == null) {
				map.put("subjectIndividualResidentialPhysicalZipPostalCode", "");
			} else {
				map.put("subjectIndividualResidentialPhysicalZipPostalCode",
						searchResultSet.getString("POSTAL_CODE"));				
			}

			if (searchResultSet.getString("COUNTRY") == null) {
				map.put("subjectIndividualResidentialPhysicalCountry", "");
			} else {
				map.put("subjectIndividualResidentialPhysicalCountry",
						searchResultSet.getString("COUNTRY"));
			}

			if (searchResultSet.getString("ADDRESS_EFFECTIVE_DATE") == null) {
				map.put("subjectIndividualResidentialPhysicalStartDate", "");
			} else {
				map.put("subjectIndividualResidentialPhysicalStartDate",
						searchResultSet.getString("ADDRESS_EFFECTIVE_DATE"));
			}

			if (searchResultSet.getString("ADDRESS_EXPIRATION_DATE") == null) {
				map.put("subjectIndividualResidentialPhysicalEndDate", "");
			} else {
				map.put("subjectIndividualResidentialPhysicalEndDate",
						searchResultSet.getString("ADDRESS_EXPIRATION_DATE"));
			}

			listMap.add(map);

		}

		return listMap;
	}

	private List<Map> convertResultSetToListMapForPersonalInfor(
			ResultSet searchResultSet) throws Exception {

		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {

			map = new HashMap();

			if (searchResultSet.getString("GENDER") == null) {
				map.put("subjectIndividualGender", "");
			} else {
				if (searchResultSet.getString("GENDER").equalsIgnoreCase("M")) {
					map.put("subjectIndividualGender", "Male");
				} else if (searchResultSet.getString("GENDER")
						.equalsIgnoreCase("F")) {
					map.put("subjectIndividualGender", "Female");
				} else if (searchResultSet.getString("GENDER")
						.equalsIgnoreCase("MALE")) {
					map.put("subjectIndividualGender", "Male");
				} else if (searchResultSet.getString("GENDER")
						.equalsIgnoreCase("FEMALE")) {
					map.put("subjectIndividualGender", "Female");
				} else if (searchResultSet.getString("GENDER")
						.equalsIgnoreCase("Male")) {
					map.put("subjectIndividualGender", "Male");
				}
			}

			if (searchResultSet.getString("PERSON_IDENTIFIER") == null) {			    
				map.put("subjectIndividualSsn", "");
			} else {			    
				map.put("subjectIndividualSsn", convertSsnStr(searchResultSet
						.getString("PERSON_IDENTIFIER")));
			}

			if (searchResultSet.getString("DATE_OF_BIRTH") == null) {
				map.put("subjectIndividualDateOfBirth", "");
			} else {
				map.put("subjectIndividualDateOfBirth",
						searchResultSet.getString("DATE_OF_BIRTH"));
			}

			if (searchResultSet.getString("CITY") == null) {
				map.put("subjectIndividualBirthCity", "");
			} else {
				map.put("subjectIndividualBirthCity",
						searchResultSet.getString("CITY"));
			}

			if (searchResultSet.getString("STATE") == null) {
				map.put("subjectIndividualBirthState", "");
			} else {
				map.put("subjectIndividualBirthState",
						searchResultSet.getString("STATE"));
			}

			if (searchResultSet.getString("COUNTRY") == null) {
				map.put("subjectIndividualBirthCountry", "");
			} else {
				map.put("subjectIndividualBirthCountry",
						searchResultSet.getString("COUNTRY"));
			}
			listMap.add(map);

		}

		return listMap;
	}

	private List<Map> convertResultSetToListMapForCznInfor(
			ResultSet searchResultSet) throws Exception {

		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {

			map = new HashMap();

			if (searchResultSet.getString("COUNTRY_CODE") == null) {
				map.put("subjectIndividualCountryOfCitizenship", "");
			} else {
				if (searchResultSet.getString("COUNTRY_CODE").equalsIgnoreCase(
						"US")) {
					map.put("subjectIndividualCountryOfCitizenship",
							"United States");
				} else if (searchResultSet.getString("COUNTRY_CODE")
						.equalsIgnoreCase("KR")) {
					map.put("subjectIndividualCountryOfCitizenship",
							"South Korea");
				} else if (searchResultSet.getString("COUNTRY_CODE")
						.equalsIgnoreCase("VN")) {
					map.put("subjectIndividualCountryOfCitizenship", "Vietnam");
				} else {
					map.put("subjectIndividualCountryOfCitizenship",
							searchResultSet.getString("COUNTRY_CODE"));
				}
			}

			if (searchResultSet.getString("DATE_RECOGNIZED") == null) {
				map.put("subjectIndividualNaturalizationDate", "");
			} else {
				map.put("subjectIndividualNaturalizationDate",
						searchResultSet.getString("DATE_RECOGNIZED"));
			}
			
			if (searchResultSet.getString("DOCUMENT_TYPE") == null) {			    
				map.put("subjectIndividualAlienNumber", "");
				map.put("subjectIndividualNaturalizationNumber", "");
			} else {
				if (searchResultSet.getString("DOCUMENT_TYPE")
						.equalsIgnoreCase("ALIEN")) {				    
					map.put("subjectIndividualNaturalizationNumber", "");
					if(searchResultSet.getString("DOCUMENT_REFERENCE") == null) {					   
					   map.put("subjectIndividualAlienNumber", "");
					} else {					  
					  map.put("subjectIndividualAlienNumber",
							searchResultSet.getString("DOCUMENT_REFERENCE"));
					}		
				} else if (searchResultSet.getString("DOCUMENT_TYPE")
						.equalsIgnoreCase("NATURALIZED")) {					
					map.put("subjectIndividualAlienNumber", "");					
					if (searchResultSet.getString("DOCUMENT_REFERENCE") == null) {					   
					   map.put("subjectIndividualNaturalizationNumber", "");
					} else {					   
					   map.put("subjectIndividualNaturalizationNumber",
							searchResultSet.getString("DOCUMENT_REFERENCE"));
                    }							
				}
			}

			if (searchResultSet.getString("ATTRIBUTE3") == null) {
				map.put("subjectIndividualUsPassportNumber", "");
			} else {
				map.put("subjectIndividualUsPassportNumber",
						searchResultSet.getString("ATTRIBUTE3"));
			}

			if (searchResultSet.getString("ATTRIBUTE4") == null) {
				map.put("subjectIndividualBirthAbroadCertificationNumber", "");
			} else {
				map.put("subjectIndividualBirthAbroadCertificationNumber",
						searchResultSet.getString("ATTRIBUTE4"));
			}

			listMap.add(map);

		}

		return listMap;
	}

	private List<Map> convertResultSetToListMapForIac(ResultSet searchResultSet)
			throws Exception {

		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {

			map = new HashMap();
			if (searchResultSet.getString("APPROVAL_NBR") == null) {
				map.put("subjectIndividualIacNumber", "");
			} else {
				map.put("subjectIndividualIacNumber",
						searchResultSet.getString("APPROVAL_NBR"));
			}

			if (searchResultSet.getString("SPONSOR_NAME") == null) {
				map.put("subjectIndividualIacName", "");
			} else {
				map.put("subjectIndividualIacName",
						searchResultSet.getString("SPONSOR_NAME"));
			}

			if (searchResultSet.getString("SPONSOR_CITY") == null) {
				map.put("subjectIndividualIacCity", "");
			} else {
				map.put("subjectIndividualIacCity",
						searchResultSet.getString("SPONSOR_CITY"));
			}

			if (searchResultSet.getString("SPONSOR_STATE") == null) {
				map.put("subjectIndividualIacState", "");
			} else {
				map.put("subjectIndividualIacState",
						searchResultSet.getString("SPONSOR_STATE"));
			}

			if (searchResultSet.getString("ASSOCIATION_START_DT") == null) {
				map.put("subjectIndividualIacStartDate", "");
			} else {
				map.put("subjectIndividualIacStartDate",
						searchResultSet.getString("ASSOCIATION_START_DT"));
			}

			if (searchResultSet.getString("ASSOCIATION_END_DT") == null) {
				map.put("subjectIndividualIacEndDate", "");
			} else {
				if ((searchResultSet.getString("ASSOCIATION_END_DT")
						.equalsIgnoreCase("4712-12-31 00:00:00.0"))
						|| (searchResultSet.getString("ASSOCIATION_END_DT")
								.equalsIgnoreCase("4712-12-31 00:00:01.0"))
						|| (searchResultSet.getString("ASSOCIATION_END_DT")
								.equalsIgnoreCase("4712-12-31 00:00:02.0"))
						|| (searchResultSet.getString("ASSOCIATION_END_DT")
								.equalsIgnoreCase("4712-12-31 00:00:03.0"))
						|| (searchResultSet.getString("ASSOCIATION_END_DT")
								.equalsIgnoreCase("4712-12-31 00:00:04.0"))
						|| (searchResultSet.getString("ASSOCIATION_END_DT")
								.equalsIgnoreCase("4712-12-31 00:00:05.0"))) {
					map.put("subjectIndividualIacEndDate", "");
				} else {
					map.put("subjectIndividualIacEndDate",
							searchResultSet.getString("ASSOCIATION_END_DT"));
				}
			}

			listMap.add(map);

		}

		return listMap;
	}

	private List<Map> convertResultSetToListMapForAgent(
			ResultSet searchResultSet) throws Exception {

		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {

			map = new HashMap();

			if (searchResultSet.getString("AGENT_NAME") == null) {
				map.put("subjectIndividualAgentName", "");
			} else {
				map.put("subjectIndividualAgentName",
						searchResultSet.getString("AGENT_NAME"));
			}

			if (searchResultSet.getString("AGENT_ID") == null) {
				map.put("subjectIndividualAgentId", "");
			} else {
				map.put("subjectIndividualAgentId",
						searchResultSet.getString("AGENT_ID"));
			}

			if (searchResultSet.getString("PARTY_ID") == null) {
				map.put("subjectIndividualPartyId", "");
			} else {
				map.put("subjectIndividualPartyId",
						searchResultSet.getString("PARTY_ID"));
			}

			if (searchResultSet.getString("SPONSOR_CITY") == null) {
				map.put("subjectIndividualAgentCity", "");
			} else {
				map.put("subjectIndividualAgentCity",
						searchResultSet.getString("SPONSOR_CITY"));
			}

			if (searchResultSet.getString("SPONSOR_STATE") == null) {
				map.put("subjectIndividualAgentState", "");
			} else {
				map.put("subjectIndividualAgentState",
						searchResultSet.getString("SPONSOR_STATE"));
			}

			if (searchResultSet.getString("SPONSOR_NAME") == null) {
				map.put("subjectIndividualAgentAssociatedIac", "");
			} else {
				map.put("subjectIndividualAgentAssociatedIac",
						searchResultSet.getString("SPONSOR_NAME"));
			}

			if (searchResultSet.getString("ASSOCIATION_START_DT") == null) {
				map.put("subjectIndividualAgentStartDate", "");
			} else {
				map.put("subjectIndividualAgentStartDate",
						searchResultSet.getString("ASSOCIATION_START_DT"));
			}

			if (searchResultSet.getString("ASSOCIATION_END_DT") == null) {
				map.put("subjectIndividualAgentEndDate", "");
			} else {
				if ((searchResultSet.getString("ASSOCIATION_END_DT")
						.equalsIgnoreCase("4712-12-31 00:00:00.0"))
						|| (searchResultSet.getString("ASSOCIATION_END_DT")
								.equalsIgnoreCase("4712-12-31 00:00:01.0"))
						|| (searchResultSet.getString("ASSOCIATION_END_DT")
								.equalsIgnoreCase("4712-12-31 00:00:02.0"))
						|| (searchResultSet.getString("ASSOCIATION_END_DT")
								.equalsIgnoreCase("4712-12-31 00:00:03.0"))
						|| (searchResultSet.getString("ASSOCIATION_END_DT")
								.equalsIgnoreCase("4712-12-31 00:00:04.0"))
						|| (searchResultSet.getString("ASSOCIATION_END_DT")
								.equalsIgnoreCase("4712-12-31 00:00:05.0"))) {
					map.put("subjectIndividualAgentEndDate", "");
				} else {
					map.put("subjectIndividualAgentEndDate",
							searchResultSet.getString("ASSOCIATION_END_DT"));
				}
			}

			listMap.add(map);

		}

		return listMap;
	}

	private List<Map> convertResultSetToListMapForAc(ResultSet searchResultSet)
			throws Exception {

		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {

			map = new HashMap();

			if (searchResultSet.getString("SPONSOR_NAME") == null) {
				map.put("subjectIndividualAcName", "");
			} else {
				map.put("subjectIndividualAcName",
						searchResultSet.getString("SPONSOR_NAME"));
			}
			if (searchResultSet.getString("PARTY_ID") == null) {
				map.put("subjectIndividualPartyId", "");
			} else {
				map.put("subjectIndividualPartyId",
						searchResultSet.getString("PARTY_ID"));
			}

			if (searchResultSet.getString("SPONSOR_CITY") == null) {
				map.put("subjectIndividualAcCity", "");
			} else {
				map.put("subjectIndividualAcCity",
						searchResultSet.getString("SPONSOR_CITY"));
			}

			if (searchResultSet.getString("SPONSOR_STATE") == null) {
				map.put("subjectIndividualAcState", "");
			} else {
				map.put("subjectIndividualAcState",
						searchResultSet.getString("SPONSOR_STATE"));
			}

			if (searchResultSet.getString("ASSOCIATION_START_DT") == null) {
				map.put("subjectIndividualAcStartDate", "");
			} else {
				map.put("subjectIndividualAcStartDate",
						searchResultSet.getString("ASSOCIATION_START_DT"));
			}

			if (searchResultSet.getString("ASSOCIATION_END_DT") == null) {
				map.put("subjectIndividualAcEndtDate", "");
			} else {
				if ((searchResultSet.getString("ASSOCIATION_END_DT")
						.equalsIgnoreCase("4712-12-31 00:00:00.0"))
						|| (searchResultSet.getString("ASSOCIATION_END_DT")
								.equalsIgnoreCase("4712-12-31 00:00:01.0"))
						|| (searchResultSet.getString("ASSOCIATION_END_DT")
								.equalsIgnoreCase("4712-12-31 00:00:02.0"))
						|| (searchResultSet.getString("ASSOCIATION_END_DT")
								.equalsIgnoreCase("4712-12-31 00:00:03.0"))
						|| (searchResultSet.getString("ASSOCIATION_END_DT")
								.equalsIgnoreCase("4712-12-31 00:00:04.0"))
						|| (searchResultSet.getString("ASSOCIATION_END_DT")
								.equalsIgnoreCase("4712-12-31 00:00:05.0"))) {
					map.put("subjectIndividualAcEndtDate", "");
				} else {
					map.put("subjectIndividualAcEndtDate",
							searchResultSet.getString("ASSOCIATION_END_DT"));
				}
			}

			listMap.add(map);

		}

		return listMap;
	}

	private String convertSsnStr(String inputStr) {
		String outputStr = "";
		int i;
		if (inputStr != null) {
			for (i = 0; i < inputStr.length(); i++) {
				outputStr = outputStr + inputStr.substring(i, (i + 1));
				if ((i == 2) || (i == 4)) {
					outputStr = outputStr + '-';
				}
			}
		}

		return (outputStr);
	}

        public JSONArray[] getStaByAuthKey(String authKey) throws Exception {

		logger.info("ExpandedSujectIndividualSearchDAO - authKey: " + authKey);
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;
                JSONArray[] ja;

		MySqlResults sqlResults = new MySqlResults();
		int count;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionStat();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<SubjectIndividualDetails> subjectIndividualDetails = new ArrayList<SubjectIndividualDetails>();
		Session session = null;

		String stProcName = "xxtsa.FAS_STAT_SUBJECT_INDIVIDUAL.SEL_STA_BY_AUTH_KEY";
		String tCallableStmtStr = "{call " + stProcName + "(?,?)}";

		CallableStatement eStatement = null;
                List<Map> esListMap;
                boolean eReturnCode;

		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, authKey);
                    eStatement.registerOutParameter(2, OracleTypes.CURSOR);
                    eReturnCode = eStatement.execute();
                    sResultSet = (ResultSet) eStatement.getObject(2);
                    ja = convertResultSetToJsonArray(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
			logger.error("getSubjectCompanyConnection failed" + ex.getMessage());
			throw (ex);
		} finally {
                    if (eStatement != null) {
					   eStatement.close();
					}
                }
                
		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,	eStatement, sResultSet);

		return ja;
	}
        
        public JSONArray[] getStatStaByPartyIdForCcsf(int partyId) throws Exception {

		logger.info("ExpandedSujectIndividualSearchDAO - partyId: " + partyId);
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;
                JSONArray[] ja;

		MySqlResults sqlResults = new MySqlResults();
		int count;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil.getConnectionStat();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<SubjectIndividualDetails> subjectIndividualDetails = new ArrayList<SubjectIndividualDetails>();
		Session session = null;

		String stProcName = "xxtsa.FAS_STAT_SUBJECT_INDIVIDUAL.SEL_STAT_STA_BY_PARTY_ID";
		String tCallableStmtStr = "{call " + stProcName + "(?,?)}";

		CallableStatement eStatement = null;
                List<Map> esListMap;
                boolean eReturnCode;

		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setInt(1, partyId);
                    eStatement.registerOutParameter(2, OracleTypes.CURSOR);
                    eReturnCode = eStatement.execute();
                    sResultSet = (ResultSet) eStatement.getObject(2);
                    ja = convertResultSetToJsonArray(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getSubjectCompanyConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
                    if (eStatement != null) {
					   eStatement.close();
					}
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,	eStatement, sResultSet);

		return ja;
	}
        
        private List<Map> convertResultSetToStaMap(ResultSet searchResultSet)
			throws Exception {
		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {
			map = new HashMap();

			if (searchResultSet.getString("STA_ID") == null) {
				map.put("staId", "");
			} else {
				map.put("staId", searchResultSet.getString("STA_ID"));
			}

			if (searchResultSet.getString("AGENT_NAME") == null) {
				map.put("agentName", "");
			} else {
				map.put("agentName", searchResultSet.getString("AGENT_NAME"));
			}

			if (searchResultSet.getString("STA_STATUS") == null) {
				map.put("staStatus", "");
			} else {
				if (searchResultSet.getString("STA_STATUS").equalsIgnoreCase(
						"ACTIVE")) {
					map.put("staStatus", "Active");
					map.put("issuedOnDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("INACTIVE")) {
					map.put("staStatus", "Inactive");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAAWAITINGPAYMNT")) {
					map.put("staStatus", "Awaiting Payment");
					map.put("issuedOnDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAERRORTTAC")) {
					map.put("staStatus", "STA ErrorTTAC");
					map.put("issuedOnDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAINCOMPL")) {
					map.put("staStatus", "STA Incomplete");
					map.put("issuedOnDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAEXPIRED")) {
					map.put("staStatus", "STA Expired");
					map.put("issuedOnDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STADENIED")) {
					map.put("staStatus", "STA Denied");
					map.put("issuedOnDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAINPROGRESS")) {
					map.put("staStatus", "STA In Progress");
					map.put("issuedOnDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAPASSED")) {
					map.put("staStatus", "Passed");
					if (searchResultSet.getString("ISSUED_ON_DATE") == null) {
						map.put("issuedOnDate", "");
					} else {
						map.put("issuedOnDate",
								searchResultSet.getString("ISSUED_ON_DATE"));
					}
				} else {
					map.put("staStatus",
							searchResultSet.getString("STA_STATUS"));
                                        map.put("issuedOnDate", "");
				}
			}

			if (searchResultSet.getString("STATUS") == null) {
				map.put("status", "");
			} else {
				if (searchResultSet.getString("STATUS").equalsIgnoreCase("A")) {
					map.put("status", "Active");
				} else if (searchResultSet.getString("STATUS")
						.equalsIgnoreCase("I")) {
					map.put("status", "Inactive");
				} else {
					map.put("status", searchResultSet.getString("STATUS"));
				}
			}

			if (searchResultSet.getString("CREATION_DATE") == null) {
				map.put("creationDate", "");
			} else {
				map.put("creationDate",
						searchResultSet.getString("CREATION_DATE"));
			}

			if (searchResultSet.getString("EXPIRES_ON_DATE") == null) {
				map.put("expiresOnDate", "");
			} else {
				if (searchResultSet.getString("STA_STATUS").equalsIgnoreCase(
						"STAERRORTTAC")) {
					map.put("expiresOnDate", "");
				} else {
					map.put("expiresOnDate",
							searchResultSet.getString("EXPIRES_ON_DATE"));
				}
			}

			if (searchResultSet.getString("FIRST_NAME") == null) {
				map.put("firstName", "");
			} else {
				map.put("firstName", searchResultSet.getString("FIRST_NAME"));
			}

			if (searchResultSet.getString("LAST_NAME") == null) {
				map.put("lastName", "");
			} else {
				map.put("lastName", searchResultSet.getString("LAST_NAME"));
			}

			if (searchResultSet.getString("SPONSOR_TYPE") == null) {
				map.put("sponsorType", "");
			} else {
				map.put("sponsorType",
						searchResultSet.getString("SPONSOR_TYPE"));
			}

			listMap.add(map);
		}

		return listMap;
	}
        
    private JSONArray[] convertResultSetToJsonArray(ResultSet rs)
			throws Exception {

	JSONArray directEmpJA = new JSONArray();
	JSONArray agentEmpJA = new JSONArray();
		
	JSONArray[] ja = new JSONArray[2];
        JSONObject jo = null;
        String tmp = null;

        while (rs.next()) {
            jo = new JSONObject();

            jo.put("staId", rs.getString("STA_ID"));
            jo.put("agentName", rs.getString("AGENT_NAME"));
            jo.put("expiresOnDate", 
                        (null == rs.getString("EXPIRES_ON_DATE")) ? "" : (rs.getString("EXPIRES_ON_DATE")).split(" ")[0]);
            jo.put("creationDate", (rs.getString("CREATION_DATE")).split(" ")[0]);	       	

            jo.put("firstName", rs.getString("FIRST_NAME"));
            jo.put("lastName", rs.getString("LAST_NAME"));

            tmp = rs.getString("STA_STATUS");

            if (tmp.equals("ACTIVE")) {
                    jo.put("staStatus", "Active");
                    jo.put("issuedOnDate", "");
            }
            else if (tmp.equals("INACTIVE")) {
                    jo.put("staStatus", "Inactive");
            } else if (tmp.equals("STAAWAITINGPAYMNT")) {
                    jo.put("staStatus", "Awaiting Payment");
                    jo.put("issuedOnDate", "");
            } else if (tmp.equals("STAERRORTTAC")) {
                    jo.put("staStatus", "STA ErrorTTAC");
                    jo.put("expiresOnDate", "");
                    jo.put("issuedOnDate", "");
            } else if (tmp.equals("STAINCOMPL")) {
                    jo.put("staStatus", "STA Incomplete");
                    jo.put("issuedOnDate", "");
            } else if (tmp.equals("STAEXPIRED")) {
                    jo.put("staStatus", "STA Expired");
                    jo.put("issuedOnDate", "");
            } else if (tmp.equals("STADENIED")) {
                    jo.put("staStatus", "STA Denied");
                    jo.put("issuedOnDate", "");
            } else if (tmp.equals("STAINPROGRESS")) {
                    jo.put("staStatus", "STA In Progress");
                    jo.put("issuedOnDate", "");
            } else if (tmp.equals("STAPASSED")) {
                    jo.put("staStatus", "Passed");
                    jo.put("issuedOnDate", 
                            (null == rs.getString("ISSUED_ON_DATE")) ? "" : (rs.getString("ISSUED_ON_DATE").split(" ")[0]));
            } else {
                    jo.put("staStatus",	tmp);
                    jo.put("issuedOnDate", "");
            }

            tmp = rs.getString("STATUS");

            if (tmp.equals("A")) {
                    jo.put("status", "Active");
            } else if (tmp.equals("I")) {
                    jo.put("status", "Inactive");
            } else {
                    jo.put("status", tmp);
            }


            if (rs.getString("SPONSOR_TYPE").equals("indirect carrier")){
                if (rs.getString("AGENT_NAME") != null) {
                       agentEmpJA.put(jo);
                } else {
                    directEmpJA.put(jo);
                }  
            } else if (!(rs.getString("SPONSOR_TYPE").equals("indirect carrier"))){
                agentEmpJA.put(jo);
            }
        }
        ja[0] = directEmpJA;
        ja[1] = agentEmpJA;

        return ja;
    }
}
