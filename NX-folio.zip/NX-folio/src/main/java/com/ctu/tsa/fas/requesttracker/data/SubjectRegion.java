/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package com.ctu.tsa.fas.requesttracker.data;

import java.util.Date;

/**
 *
 * @author Eswara.Somu
 */
public class SubjectRegion {
 
 private int subjectRegionID;
 private String regionName;
 private String description;
 private String creteUsername;
 private String lastUpdateusername;
 private Date createtimestamp;
 private Date lastupdateTimestamp;

 
 // constructors
	public SubjectRegion() {
	}
       

        
 //Getters and Setters
    //Subject region Objects
    public int getSubjectRegionID() {
        return subjectRegionID;
    }

    public String getRegionName() {
        return regionName;
    }

    public String getDescription() {
        return description;
    }

    public String getCreteUsername() {
        return creteUsername;
    }

    public String getLastUpdateusername() {
        return lastUpdateusername;
    }



    public void setSubjectRegionID(int subjectRegionID) {
        this.subjectRegionID = subjectRegionID;
    }

    public void setRegionName(String regionName) {
        this.regionName = regionName;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setCreteUsername(String creteUsername) {
        this.creteUsername = creteUsername;
    }

    public void setLastUpdateusername(String lastUpdateusername) {
        this.lastUpdateusername = lastUpdateusername;
    }



      public Date getCreatetimestamp() {
        return createtimestamp;
    }

    public Date getLastupdateTimestamp() {
        return lastupdateTimestamp;
    }

    public void setCreatetimestamp(Date createtimestamp) {
        this.createtimestamp = createtimestamp;
    }

    public void setLastupdateTimestamp(Date lastupdateTimestamp) {
        this.lastupdateTimestamp = lastupdateTimestamp;
    }      
            
}
