/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.requesttracker.action;

import com.ctu.tsa.fas.requesttracker.dao.RequestTrackerDAO;
import com.ctu.tsa.fas.requesttracker.model.Request;
import com.opensymphony.xwork2.Action;
import java.util.List;
import org.apache.log4j.Logger;

public class RequestTrackerSearchAjaxAction implements Action {

    List<Request> requestList = null;

    private String message = "";
    private String searchValues;
    private int requestCount = 0;
    protected Logger logger = Logger.getLogger(getClass());


    public String execute() {
        logger.debug("****** AjaxJsonAction  execute  searchValues:  "+ searchValues);   
        
        if (null == searchValues) {
            return null;
        } else {
            String params[] = searchValues.split("~~");
            
            RequestTrackerDAO dao = RequestTrackerDAO.getInstance();
            List<Request> requestList = null;
            try {
                requestList = dao.getRequestList(params[0], params[1]);

                if (null != requestList && !requestList.isEmpty()) {
                   for (Request request : requestList) {
                        message += request.getRequestNumber() + " ";
                    }
                }

                
                requestCount = requestList.size();

                
            } catch (Exception e) {
                logger.debug("*** EXCEPTION 1:  "+e.getMessage());               
            }
        }
        return SUCCESS;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    public String getSearchValues() {
        return searchValues;
    }

    public void setSearchValues(String searchValues) {
        this.searchValues = searchValues;
    }

    public List<Request> getRequestList() {
        return requestList;
    }

    public void setRequestList(List<Request> requestList) {
        this.requestList = requestList;
    }

    public int getRequestCount() {
        return requestCount;
    }

    public void setRequestCount(int requestCount) {
        this.requestCount = requestCount;
    }
    
    
    
}
