/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.action;

import javax.servlet.http.HttpServletRequest;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import javax.servlet.http.HttpSession;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.log4j.Logger;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.ServletActionContext;
import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import java.util.List;
import java.util.ArrayList;
import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchCcsfDAO;
import java.util.Map;
import java.util.HashMap;
import java.sql.*;
import java.lang.Integer;
import java.util.Iterator;
import org.apache.commons.lang3.StringEscapeUtils;
import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchIacDAO;
import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchSubjectIndividualDAO;
import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchStatSubjectIndividualDAO;
import org.json.JSONArray;

/**
 *
 * @author Kevin.Tsou
 */
public class FasFacilityInfoAction extends ActionSupport implements ServletRequestAware{
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();    
    private String loginTimeRoleMsg;
    private String ccsfFacilityName;
    private String ccsfCertificationNumber;
    private List<Map> ccsfList;
    private String facilityName;
    private String companyName;
    private String iacNumber;
    private String staAuthorizationKey;
    private String portCode;
    private String ccsfStatus;
    private String phone;
    private String certificationNumber;
    private String addressLine1;
    private String addressLine2;
    private String city;
    private String stateProvinceCode;
    private String zipPostalCode;
    private String countryCode;
    private String facilityNotes;
    private String certificationNotes;
    private String dsaChangeDetails;
    private String assessmentNotes;    
    private String fc1Fullname;
    private String fc1Title;
    private String fc1PrimaryPhone;
    private String fc1Email;
    private String fc2Fullname;
    private String fc2Title;
    private String fc2PrimaryPhone;
    private String fc2Email;
    private String cpscName;
    private String cpscTitle;
    private String cpscPhone;
    private String cpscEmail;
    private String fscName;
    private String fscTitle;
    private String fscPhone;
    private String fscEmail;
    private String requiredRecertificationDate;
    private String recertificationDate;
    private String recertificationStatus;
    private String moveRecertStatus;
    private String certificationStatus;
    private String applicationType;
    private String applicationStatus;
    private String applicantTypeCode;
    private String operationalStatus;
    private String suspenseDate;
    private String suspenseType;
    private String commodityTypesShipped;
    private String commodity1Specific;
    private String commodity2Specific;
    private String commodity3Specific;
    private String commodity4Specific;
    private String commodity5Specific;
    private String commodity6Specific;
    private String commodity7Specific;
    private String commodity8Specific;
    private String commodity9Specific;
    private String commodity10Specific;
    private String commodity11Specific;
    private String amendment;
    private String amendmentExpireDate;
    private String amendmentDetails;
    List<Map> agentEmpMap = new ArrayList();
    List<Map> dirEmpMap = new ArrayList();	
    List<Map> facContMap = new ArrayList();
    List<Map> facCertMap = new ArrayList();
    List<Map> appDetMap = new ArrayList();
    List<Map> ammDetMap = new ArrayList();
    List<Map> tempStaMap = new ArrayList();
    private String partyId;
    private String iacPartyId;
    private String partyName;	
    int tempInt=0;
    int statPartyId=0;
    
    @Override
    public String execute()throws Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        ExpandedSearchCcsfDAO dao = new ExpandedSearchCcsfDAO();
        ExpandedSearchIacDAO iacDao = new ExpandedSearchIacDAO();
        ExpandedSearchStatSubjectIndividualDAO statDao = new ExpandedSearchStatSubjectIndividualDAO();   
        ExpandedSearchSubjectIndividualDAO subIndiDao = new ExpandedSearchSubjectIndividualDAO(); 
        Map theFacilityMap = new HashMap();
        int listSize = 0;
        JSONArray[] staAry;
		
        List<Map> esListMap;
        
        logger.info("FasFacilityInfoAction execute(): begin");
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);                   
		
	SessionStore sessionStore = SessionStore.getInstance (request.getSession());						
						      
        setCcsfList(dao.getCcsfDetailByFacilityName(getCcsfCertificationNumber(), getCcsfFacilityName()));
        store.put (SessionKey.CCSF_LIST_DETAIL_REC, ccsfList); 
        
        if ((ccsfList == null) || (ccsfList.isEmpty())){
            listSize = 0;
        } else {
            listSize = ccsfList.size();
        }
        
        setStaAuthorizationKey(getStaAuthorizationKey());
        if (listSize > 0) {
            theFacilityMap = ccsfList.get(0);
            
            setFacilityName((String)theFacilityMap.get("facilityName"));
            setCompanyName((String)theFacilityMap.get("companyName"));
            setIacNumber((String)theFacilityMap.get("iacNumber"));
            if ((getIacNumber().equals("")) && 
                    (getStaAuthorizationKey().equals(""))){
                addActionError("Invalid Facility.  Please contact Air Cargo Help Desk at (866) 906-0891");
                return "displayIacFacilityInfo";
            } else if ((!(getIacNumber().equals(""))) && 
                    (!(getStaAuthorizationKey().equals("")))){
                addActionError("Invalid Facility.  Please contact Air Cargo Help Desk at (866) 906-0891");
                return "displayIacFacilityInfo";
            } else if (!(getStaAuthorizationKey().equals(""))){
                esListMap = (statDao.getPartyNameByAuthKey(getStaAuthorizationKey())).getSListMap();
                if (esListMap.isEmpty()){
                    addActionError("Invalid Facility.  Please contact Air Cargo Help Desk at (866) 906-0891");
                    return "displayIacFacilityInfo";
                } else {
                    setPartyId((String)esListMap.get(0).get("partyId"));
                    logger.info("getPartyId()=" + getPartyId());
                    try {
                        statPartyId = Integer.parseInt(getPartyId());
                    }
                    catch (Exception e){
                        logger.error("Integer.parseInt failed! " + getPartyId());
                    }  
                    setPartyName((String)esListMap.get(0).get("partyName"));                    
                }
            } else if (!(getIacNumber().equals(""))){
                esListMap = iacDao.getIacNameByIacNum(getIacNumber());
                if (esListMap.isEmpty()){
                    addActionError("Invalid Facility.  Please contact Air Cargo Help Desk at (866) 906-0891");
                    return "displayIacFacilityInfo";
                } else {
                    setIacPartyId((String)esListMap.get(0).get("partyId"));
                    logger.info("getIacPartyId()=" + getIacPartyId());
                }
            }
            
            setCcsfStatus((String)theFacilityMap.get("ccsfStatus"));
            setCertificationNumber((String)theFacilityMap.get("certificationNumber"));
            setPortCode((String)theFacilityMap.get("portCode"));
            setPhone((String)theFacilityMap.get("phone"));
            setAddressLine1((String)theFacilityMap.get("addressLine1"));
            setCity((String)theFacilityMap.get("city"));
            setZipPostalCode((String)theFacilityMap.get("zipPostalCode"));
            setStateProvinceCode((String)theFacilityMap.get("stateProvinceCode"));
            if (theFacilityMap.get("stateProvinceCode") != null && theFacilityMap.get("stateProvinceCode") != ""){
                setCountryCode("USA");
            }
            setFacilityNotes((String)theFacilityMap.get("facilityNotes"));
            setCertificationNotes((String)theFacilityMap.get("certificationNotes"));
            setDsaChangeDetails((String)theFacilityMap.get("dsaChangeDetails"));
            setAssessmentNotes((String)theFacilityMap.get("assessmentNotes"));
            
            setFc1Fullname((String)theFacilityMap.get("fc1Fullname"));
            setFc1Title((String)theFacilityMap.get("fc1Title"));
            setFc1PrimaryPhone((String)theFacilityMap.get("fc1PrimaryPhone"));
            setFc1Email((String)theFacilityMap.get("fc1Email"));
            setFc2Fullname((String)theFacilityMap.get("fc2Fullname"));
            setFc2Title((String)theFacilityMap.get("fc2Title"));
            setFc2PrimaryPhone((String)theFacilityMap.get("fc2PrimaryPhone"));
            setFc2Email((String)theFacilityMap.get("fc2Email"));
            
            setCpscName((String)theFacilityMap.get("cpscName"));
            setCpscTitle((String)theFacilityMap.get("cpscTitle"));
            setCpscPhone((String)theFacilityMap.get("cpscPhone"));
            setCpscEmail((String)theFacilityMap.get("cpscEmail"));
            setFscName((String)theFacilityMap.get("fscName"));
            setFscTitle((String)theFacilityMap.get("fscTitle"));
            setFscPhone((String)theFacilityMap.get("fscPhone"));
            setFscEmail((String)theFacilityMap.get("fscEmail"));
            
            setRequiredRecertificationDate((String)theFacilityMap.get("requiredRecertificationDate"));
            setRecertificationDate((String)theFacilityMap.get("recertificationDate"));
            setMoveRecertStatus((String)theFacilityMap.get("moveRecertStatus"));
            setRecertificationStatus((String)theFacilityMap.get("recertificationStatus"));
            setCertificationStatus((String)theFacilityMap.get("certificationStatus"));
            setOperationalStatus((String)theFacilityMap.get("operationalStatus"));
            setApplicantTypeCode((String)theFacilityMap.get("applicantTypeCode"));
            setApplicationType(getApplicantTypeCode());
            setApplicationStatus((String)theFacilityMap.get("applicationStatus"));
            setSuspenseDate((String)theFacilityMap.get("suspenseDate"));
            setSuspenseType((String)theFacilityMap.get("suspenseType"));
            setCommodityTypesShipped((String)theFacilityMap.get("commodityTypesShipped"));
            setAmendment((String)theFacilityMap.get("amendment"));
            setAmendmentExpireDate((String)theFacilityMap.get("amendmentExpireDate"));
            setAmendmentDetails((String)theFacilityMap.get("amendmentDetails"));
            setCommodity1Specific((String)theFacilityMap.get("commodity1Specific"));
            setCommodity2Specific((String)theFacilityMap.get("commodity2Specific"));
            setCommodity3Specific((String)theFacilityMap.get("commodity3Specific"));
            setCommodity4Specific((String)theFacilityMap.get("commodity4Specific"));
            setCommodity5Specific((String)theFacilityMap.get("commodity5Specific"));
            setCommodity6Specific((String)theFacilityMap.get("commodity6Specific"));
            setCommodity7Specific((String)theFacilityMap.get("commodity7Specific"));
            setCommodity8Specific((String)theFacilityMap.get("commodity8Specific"));
            setCommodity9Specific((String)theFacilityMap.get("commodity9Specific"));
            setCommodity10Specific((String)theFacilityMap.get("commodity10Specific"));
            setCommodity11Specific((String)theFacilityMap.get("commodity11Specific"));
                       			
			if ((getIacNumber()!= null) && !(getIacNumber().equals(""))) {
                tempStaMap = new ArrayList();
                try {
                    tempInt = Integer.parseInt (getIacPartyId());
                    staAry = iacDao.getStaByPartyId(tempInt);
                    session.setAttribute("STA_AGENT_EMP_LIST", staAry[1].toString());					
                    session.setAttribute("STA_DIR_EMP_LIST", staAry[0].toString());
                }
                catch (Exception e){
                    logger.error("iacDao.getStaByPartyId failed! " + e.getMessage());
                    throw (e);
                }             
                store.put (SessionKey.CCSF_DIR_EMP_MAP, dirEmpMap);
                store.put (SessionKey.CCSF_AG_EMP_MAP, agentEmpMap);           			
			} else if ((getStaAuthorizationKey()!= null) && !(getStaAuthorizationKey().equals(""))) {
                tempStaMap = new ArrayList();
                try {
                    staAry = subIndiDao.getStatStaByPartyIdForCcsf(statPartyId);
                    session.setAttribute("STA_AGENT_EMP_LIST", staAry[1].toString());					
                    session.setAttribute("STA_DIR_EMP_LIST", staAry[0].toString());
                }
                catch (Exception e){
                    logger.error("subIndiDao.getStatStaByPartyIdForCcsf! " + e.getMessage());
                    throw (e);
                }
                                
                store.put (SessionKey.CCSF_DIR_EMP_MAP, dirEmpMap);
                store.put (SessionKey.CCSF_AG_EMP_MAP, agentEmpMap);
            }                       
            
            setAmmDetMap(getCcsfList());
            session.setAttribute("CCSF_AMM_DET_MAP", IncludesUtil.convertMapListToJsonString(ammDetMap));	
            setFacContMap(getCcsfList());
            session.setAttribute("CCSF_FAC_CONT_MAP", IncludesUtil.convertMapListToJsonString(facContMap));
            setFacCertMap(getCcsfList());
            session.setAttribute("CCSF_FAC_CERT_MAP", IncludesUtil.convertMapListToJsonString(facCertMap));
            setAppDetMap(getCcsfList());		   
            session.setAttribute("CCSF_APP_DET_MAP", IncludesUtil.convertMapListToJsonString(appDetMap));
	
            store.put (SessionKey.CCSF_DIR_EMP_MAP, dirEmpMap);
            store.put (SessionKey.CCSF_FAC_CONT_MAP, facContMap);
            store.put (SessionKey.CCSF_FAC_CERT_MAP, facCertMap);
            store.put (SessionKey.CCSF_AMM_DET_MAP, ammDetMap);
            store.put (SessionKey.CCSF_AG_EMP_MAP, agentEmpMap);
            store.put (SessionKey.CCSF_APP_DET_MAP, appDetMap);				
        }

        return "displayIacFacilityInfo";
    }       		   				     
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
    
    @Override
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
    
    public String getCcsfFacilityName() {
        if (ccsfFacilityName == null){
            this.ccsfFacilityName = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(ccsfFacilityName);
    }
    
    public void setCcsfFacilityName(String ccsfFacilityName) {
	this.ccsfFacilityName = ccsfFacilityName;
    }  
    
    public String getCcsfCertificationNumber() {
        if (ccsfCertificationNumber == null){
            this.ccsfCertificationNumber = "";
	}
		
	return StringEscapeUtils.unescapeHtml4(ccsfCertificationNumber);
    }
    
    public void setCcsfCertificationNumber(String ccsfCertificationNumber) {
	this.ccsfCertificationNumber = ccsfCertificationNumber;
    }  
    
    public List<Map> getCcsfList() {
        return ccsfList;
    }

    public void setCcsfList(List<Map> ccsfList) {
        this.ccsfList = ccsfList;
    }
    
    public String getFacilityName() {
        if (facilityName == null){
            this.facilityName = "";
	}
		
	return facilityName;
    }
    
    public void setFacilityName(String  facilityName) {
	this.facilityName =  facilityName;
    }
    
    public String getCompanyName() {
        if (companyName == null){
            this.companyName = "";
	}
		
	return companyName;
    }
    
    public void setCompanyName(String  companyName) {
	this.companyName =  companyName;
    }
    
    public String getCertificationNumber() {
        if (certificationNumber == null){
            this.certificationNumber = "";
	}
		
	return certificationNumber;
    }
    
    public void setCertificationNumber(String certificationNumber) {
	this.certificationNumber = certificationNumber;
    }  
    
    public String getIacNumber() {
        if (iacNumber == null){
            this.iacNumber = "";
	}
		
	return iacNumber;
    }
    
    public void setIacNumber(String iacNumber) {
	this.iacNumber = iacNumber;
    }  
    
    public String getStaAuthorizationKey() {
        if (staAuthorizationKey == null){
            this.staAuthorizationKey = "";
	}
		
	return staAuthorizationKey;
    }
    
    public void setStaAuthorizationKey(String staAuthorizationKey) {
	this.staAuthorizationKey = staAuthorizationKey;
    }  
    
    public String getCcsfStatus() {
        if (ccsfStatus == null){
            this.ccsfStatus = "";
	}
		
	return ccsfStatus;
    }
    
    public void setCcsfStatus(String ccsfStatus) {
	this.ccsfStatus = ccsfStatus;
    }  
    
    public String getPortCode() {
        return portCode;
    }

    public void setPortCode(String portCode) {
        this.portCode = portCode;
    }
    
    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }
            
    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }        
        
    public String getAddressLine2() {
        return addressLine2;
    }

    public void setAddressLine2(String addressLine2) {
        this.addressLine2 = addressLine2;
    }    
    
    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }
    
    public String getStateProvinceCode() {
        return stateProvinceCode;
    }

    public void setStateProvinceCode(String stateProvinceCode) {
        this.stateProvinceCode = stateProvinceCode;
    }
    
    public String getZipPostalCode() {
        return zipPostalCode;
    }

    public void setZipPostalCode(String zipPostalCode) {
        this.zipPostalCode = zipPostalCode;
    }
    
    public String getCountryCode() {
        return countryCode;
    }

    public void setCountryCode(String countryCode) {
        this.countryCode = countryCode;
    }
    
    public String getFacilityNotes() {
        return facilityNotes;
    }

    public void setFacilityNotes(String facilityNotes) {
        this.facilityNotes = facilityNotes;
    }
    
    public String getCertificationNotes() {
        return certificationNotes;
    }

    public void setCertificationNotes(String certificationNotes) {
        this.certificationNotes = certificationNotes;
    }
    
    public String getDsaChangeDetails() {
        return dsaChangeDetails;
    }

    public void setDsaChangeDetails(String dsaChangeDetails) {
        this.dsaChangeDetails = dsaChangeDetails;
    }
    
    public String getAssessmentNotes() {
        return assessmentNotes;
    }

    public void setAssessmentNotes(String assessmentNotes) {
        this.assessmentNotes = assessmentNotes;
    }
    
    public String getFc1Fullname() {
        return fc1Fullname;
    }

    public void setFc1Fullname(String fc1Fullname) {
        this.fc1Fullname = fc1Fullname;
    }
    
    public String getFc1Title() {
        return fc1Title;
    }

    public void setFc1Title(String fc1Title) {
        this.fc1Title = fc1Title;
    }
    
    public String getFc1PrimaryPhone() {
        return fc1PrimaryPhone;
    }

    public void setFc1PrimaryPhone(String fc1PrimaryPhone) {
        this.fc1PrimaryPhone = fc1PrimaryPhone;
    }
    
    public String getFc1Email() {
        return fc1Email;
    }

    public void setFc1Email(String fc1Email) {
        this.fc1Email = fc1Email;
    }
    
    public String getFc2Fullname() {
        return fc2Fullname;
    }

    public void setFc2Fullname(String fc2Fullname) {
        this.fc2Fullname = fc2Fullname;
    }
    
    public String getFc2Title() {
        return fc2Title;
    }

    public void setFc2Title(String fc2Title) {
        this.fc2Title = fc2Title;
    }
    
    public String getFc2PrimaryPhone() {
        return fc2PrimaryPhone;
    }

    public void setFc2PrimaryPhone(String fc2PrimaryPhone) {
        this.fc2PrimaryPhone = fc2PrimaryPhone;
    }
    
    public String getFc2Email() {
        return fc2Email;
    }

    public void setFc2Email(String fc2Email) {
        this.fc2Email = fc2Email;
    }
    
    public String getCpscName() {
        return cpscName;
    }

    public void setCpscName(String cpscName) {
        this.cpscName = cpscName;
    }
    
    public String getCpscTitle() {
        return cpscTitle;
    }

    public void setCpscTitle(String cpscTitle) {
        this.cpscTitle = cpscTitle;
    }
    
    public String getCpscPhone() {
        return cpscPhone;
    }

    public void setCpscPhone(String cpscPhone) {
        this.cpscPhone = cpscPhone;
    }
    
    public String getCpscEmail() {
        return cpscEmail;
    }

    public void setCpscEmail(String cpscEmail) {
        this.cpscEmail = cpscEmail;
    }
    
    public String getFscName() {
        return fscName;
    }

    public void setFscName(String fscName) {
        this.fscName = fscName;
    }
    
    public String getFscTitle() {
        return fscTitle;
    }

    public void setFscTitle(String fscTitle) {
        this.fscTitle = fscTitle;
    }
    
    public String getFscPhone() {
        return fscPhone;
    }

    public void setFscPhone(String fscPhone) {
        this.fscPhone = fscPhone;
    }
    
    public String getFscEmail() {
        return fscEmail;
    }

    public void setFscEmail(String fscEmail) {
        this.fscEmail = fscEmail;
    }
    
    public String getRequiredRecertificationDate() {
        return requiredRecertificationDate;
    }

    public void setRequiredRecertificationDate(String requiredRecertificationDate) {
        this.requiredRecertificationDate = requiredRecertificationDate;
    }
    
    public String getRecertificationDate() {
        return recertificationDate;
    }

    public void setRecertificationDate(String recertificationDate) {
        this.recertificationDate = recertificationDate;
    }
    
    public String getRecertificationStatus() {
        return recertificationStatus;
    }

    public void setRecertificationStatus(String recertificationStatus) {
        this.recertificationStatus = recertificationStatus;
    }
    
    public String getMoveRecertStatus() {
        return moveRecertStatus;
    }

    public void setMoveRecertStatus(String moveRecertStatus) {
        this.moveRecertStatus = moveRecertStatus;
    }
    
    public String getCertificationStatus() {
        return certificationStatus;
    }

    public void setCertificationStatus(String certificationStatus) {
        this.certificationStatus = certificationStatus;
    }
    
    public String getOperationalStatus() {
        return operationalStatus;
    }

    public void setOperationalStatus(String operationalStatus) {
        this.operationalStatus = operationalStatus;
    }
	
	public String getApplicantTypeCode() {
        return applicantTypeCode;
    }

    public void setApplicantTypeCode(String applicantTypeCode) {
        this.applicantTypeCode = applicantTypeCode;
    }
    
    public String getApplicationType() {
        return applicationType;
    }

    public void setApplicationType(String applicationType) {		
	if ((applicationType != null) && !(applicationType.equals(""))) {
            if (applicationType.equalsIgnoreCase("i")){
                applicationType = "Independent";
            } else if (applicationType.equalsIgnoreCase("c")){
                applicationType = "Indirect Air Carrier";
            } else if (applicationType.equalsIgnoreCase("s")){
                applicationType = "Shipper";
            } 
        }
        
        this.applicationType = applicationType;
    }
    
    public String getApplicationStatus() {
        return applicationStatus;
    }

    public void setApplicationStatus(String applicationStatus) {
        this.applicationStatus = applicationStatus;
    }
    
    public String getSuspenseDate() {
        return suspenseDate;
    }

    public void setSuspenseDate(String suspenseDate) {
        this.suspenseDate = suspenseDate;
    }
    
    public String getSuspenseType() {
        return suspenseType;
    }

    public void setSuspenseType(String suspenseType) {
        this.suspenseType = suspenseType;
    }
    
    public String getCommodityTypesShipped() {
        return commodityTypesShipped;
    }

    public void setCommodityTypesShipped(String commodityTypesShipped) {
        this.commodityTypesShipped = commodityTypesShipped;
    }
    
    public String getCommodity1Specific() {
        return commodity1Specific;
    }

    public void setCommodity1Specific(String commodity1Specific) {
        this.commodity1Specific = commodity1Specific;
    }
    
    public String getCommodity2Specific() {
        return commodity2Specific;
    }

    public void setCommodity2Specific(String commodity2Specific) {
        this.commodity2Specific = commodity2Specific;
    }
    
    public String getCommodity3Specific() {
        return commodity3Specific;
    }

    public void setCommodity3Specific(String commodity3Specific) {
        this.commodity3Specific = commodity3Specific;
    }
    
    public String getCommodity4Specific() {
        return commodity4Specific;
    }

    public void setCommodity4Specific(String commodity4Specific) {
        this.commodity4Specific = commodity4Specific;
    }
    
    public String getCommodity5Specific() {
        return commodity5Specific;
    }

    public void setCommodity5Specific(String commodity5Specific) {
        this.commodity5Specific = commodity5Specific;
    }
    
    public String getCommodity6Specific() {
        return commodity6Specific;
    }

    public void setCommodity6Specific(String commodity6Specific) {
        this.commodity6Specific = commodity6Specific;
    }
    
    public String getCommodity7Specific() {
        return commodity7Specific;
    }

    public void setCommodity7Specific(String commodity7Specific) {
        this.commodity7Specific = commodity7Specific;
    }
    
    public String getCommodity8Specific() {
        return commodity8Specific;
    }

    public void setCommodity8Specific(String commodity8Specific) {
        this.commodity8Specific = commodity8Specific;
    }
    
    public String getCommodity9Specific() {
        return commodity9Specific;
    }

    public void setCommodity9Specific(String commodity9Specific) {
        this.commodity9Specific = commodity9Specific;
    }
    
    public String getCommodity10Specific() {
        return commodity10Specific;
    }

    public void setCommodity10Specific(String commodity10Specific) {
        this.commodity10Specific = commodity10Specific;
    }
    
    public String getCommodity11Specific() {
        return commodity11Specific;
    }

    public void setCommodity11Specific(String commodity11Specific) {
        this.commodity11Specific = commodity11Specific;
    }
    
    public String getAmendment() {
        return amendment;
    }

    public void setAmendment(String amendment) {
        this.amendment = amendment;
    }
    
    public String getAmendmentExpireDate() {
        return amendmentExpireDate;
    }

    public void setAmendmentExpireDate(String amendmentExpireDate) {
        this.amendmentExpireDate = amendmentExpireDate;
    }
    
    public String getAmendmentDetails() {
        return amendmentDetails;
    }

    public void setAmendmentDetails(String amendmentDetails) {
        this.amendmentDetails = amendmentDetails;
    }
    
    public String getPartyId() {
        return partyId;
    }

    public void setPartyId(String partyId) {
        this.partyId = partyId;
    }
    
    public String getIacPartyId() {
        return iacPartyId;
    }

    public void setIacPartyId(String iacPartyId) {
        this.iacPartyId = iacPartyId;
    }
    
    public String getPartyName() {
        return partyName;
    }

    public void setPartyName(String partyName) {
        this.partyName = partyName;
    }         
    	
	public List<Map> getFacContMap() {
        return facContMap;
    } 
	
	public List<Map> getFacCertMap() {
        return facCertMap;
    } 
	
	public List<Map> getAppDetMap() {
        return appDetMap;
    } 
	
	public List<Map> getAmmDetMap() {
        return ammDetMap;
    } 
	
	public void setFacContMap(List<Map> facContMap) {
        this.facContMap = facContMap;
    }
	
	public void setFacCertMap(List<Map> facCertMap) {
        this.facCertMap = facCertMap;
    }
	
	public void setAppDetMap(List<Map> appDetMap) {
        this.appDetMap = appDetMap;
    }
	
	public void setAmmDetMap(List<Map> ammDetMap) {
        this.ammDetMap = ammDetMap;
    }
	
    public List<Map> getDirEmpMap() {
        return dirEmpMap;
    } 
    
    public List<Map> getAgentEmpMap() {
        return agentEmpMap;
    } 
       
    public void setAgentEmpMap(List<Map> agentEmpMap) {
        this.agentEmpMap = agentEmpMap;
    }
    
    public void setDirEmpMap(List<Map> dirEmpMap) {
        this.dirEmpMap = dirEmpMap;
    }
      
    public List<Map> convertStaToDirEmpMap(List<Map> list) {
        List<Map> theDirEmpMap = new ArrayList();
        Map map = new HashMap();
        Iterator<Map>  itrList = list.iterator();
        Map tEmpMap = new HashMap();
	String temp;
        int starting_idx=0;
        int counter=0;
        
        starting_idx=0;
        counter=0;
        while (itrList.hasNext()) {
            tEmpMap = (Map)itrList.next();
            if ((counter) >=  starting_idx){
                map = new HashMap();
                map.put("staId", tEmpMap.get("staId"));
                map.put("agentName", tEmpMap.get("agentName"));
                if (tEmpMap.get("creationDate") != null && !(tEmpMap.get("creationDate").equals(""))){
                    temp = (String)tEmpMap.get("creationDate");
                    map.put("creationDate", temp.substring(0, (temp).indexOf(' ')));
                }   
                else {
                    map.put("creationDate", "");
                }
            
                if (tEmpMap.get("issuedOnDate") != null && !(tEmpMap.get("issuedOnDate").equals(""))){
                    temp = (String)tEmpMap.get("issuedOnDate");
                    map.put("issuedOnDate", temp.substring(0, (temp).indexOf(' ')));
                }
                else {
                    map.put("issuedOnDate", "");
                }
            
                if (tEmpMap.get("expiresOnDate") != null && !(tEmpMap.get("expiresOnDate").equals(""))){
                    temp = (String)tEmpMap.get("expiresOnDate");
                    map.put("expiresOnDate", temp.substring(0, (temp).indexOf(' ')));
                }
                else {
                    map.put("expiresOnDate", "");
                }
                map.put("staStatus", tEmpMap.get("staStatus"));
                map.put("status", tEmpMap.get("status"));
                map.put("firstName", tEmpMap.get("firstName"));
                map.put("lastName", tEmpMap.get("lastName"));
                map.put("sponsorType", tEmpMap.get("sponsorType"));
                if (tEmpMap.get("sponsorType").equals("indirect carrier")){
                    theDirEmpMap.add(map); 
                }
            }
            counter = counter + 1;
        }
        return (theDirEmpMap);
    }   
    
    public List<Map> convertStaToAgentEmpMap(List<Map> list) {
        List<Map> theAgentEmpMap = new ArrayList();
        Map map = new HashMap();
        Iterator<Map>  itrList = list.iterator();
        Map agentEmpMap = new HashMap();
		String temp;
        
        while (itrList.hasNext()) {
            agentEmpMap = (Map)itrList.next();
            map = new HashMap();
            map.put("staId", agentEmpMap.get("staId"));
            map.put("agentName", agentEmpMap.get("agentName"));
            
			if (agentEmpMap.get("creationDate") != null && !(agentEmpMap.get("creationDate").equals(""))){
				temp = (String)agentEmpMap.get("creationDate");
				map.put("creationDate", temp.substring(0, (temp).indexOf(' ')));
			}
			else {
				map.put("creationDate", "");
			}
            
			if (agentEmpMap.get("issuedOnDate") != null && !(agentEmpMap.get("issuedOnDate").equals(""))){
				temp = (String)agentEmpMap.get("issuedOnDate");
				map.put("issuedOnDate", temp.substring(0, (temp).indexOf(' ')));
			}
			else {
				map.put("issuedOnDate", "");
			}
            
			if (agentEmpMap.get("expiresOnDate") != null && !(agentEmpMap.get("expiresOnDate").equals(""))){
				temp = (String)agentEmpMap.get("expiresOnDate");
				map.put("expiresOnDate", temp.substring(0, (temp).indexOf(' ')));
			}
			else {
				map.put("expiresOnDate", "");
			}
			
            map.put("staStatus", agentEmpMap.get("staStatus"));
            map.put("status", agentEmpMap.get("status"));
            map.put("firstName", agentEmpMap.get("firstName"));
            map.put("lastName", agentEmpMap.get("lastName"));
            map.put("sponsorType", agentEmpMap.get("sponsorType"));
            if (!(agentEmpMap.get("sponsorType").equals("indirect carrier"))){
                theAgentEmpMap.add(map); 
            }
        }
        
        return (theAgentEmpMap);
    }   
}
