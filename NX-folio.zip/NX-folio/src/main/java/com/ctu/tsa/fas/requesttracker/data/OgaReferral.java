/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
/**
 *
 * @author Eswara.Somu
 */

package com.ctu.tsa.fas.requesttracker.data;


import java.util.Date;


public class OgaReferral {
 


 
 private int ogaReferralID; 
 private String requestorAgency;
 private String description;
 private String creteUserId;
 private String lastUpdateuserId;
 private Date createtimestamp;
 private Date lastUpdateTimestamp;
 

    
 public OgaReferral() {

 
 }
public OgaReferral(int ogaReferralID, String requestorAgency, String description, String creteUserId, String lastUpdateuserId, Date createtimestamp) 
{
        this.ogaReferralID = ogaReferralID;
         this.requestorAgency = requestorAgency;
          this.description = description; 
          this.creteUserId = creteUserId; 
          this.lastUpdateuserId = lastUpdateuserId;
           this.createtimestamp = createtimestamp;
          
}

    public int getOgaReferralID() {
        return ogaReferralID;
    }

    public String getRequestorAgency() {
        return requestorAgency;
    }

    public String getDescription() {
        return description;
    }

    public String getCreteUserId() {
        return creteUserId;
    }

    public String getLastUpdateuserId() {
        return lastUpdateuserId;
    }



    public void setOgaReferralID(int ogaReferralID) {
        this.ogaReferralID = ogaReferralID;
    }
       public Date getCreatetimestamp() {
        return createtimestamp;
    }



    public void setCreatetimestamp(Date createtimestamp) {
        this.createtimestamp = createtimestamp;
    }

 
    public Date getLastUpdateTimestamp() {
        return lastUpdateTimestamp;
    }

    public void setLastUpdateTimestamp(Date lastUpdateTimestamp) {
        this.lastUpdateTimestamp = lastUpdateTimestamp;
    }

    public void setRequestorAgency(String requestorAgency) {
        this.requestorAgency = requestorAgency;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public void setCreteUserId(String creteUserId) {
        this.creteUserId = creteUserId;
    }

    public void setLastUpdateuserId(String lastUpdateuserId) {
        this.lastUpdateuserId = lastUpdateuserId;
    }



 
}

    

