/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Binh.Nguyen
 */
public class SubjectIndividualAcModel implements Serializable{
    private static final long serialVersionUID = -8767337899673261248L;
    private String subjectIndividualAcName;
    private String subjectIndividualPartyId;
	private String subjectIndividualAcCity;
	private String subjectIndividualAcState;
	private String subjectIndividualAcStartDate;
	private String subjectIndividualAcEndtDate;
		
    public SubjectIndividualAcModel() {
    }
        
    public SubjectIndividualAcModel(String subjectIndividualAcName, String subjectIndividualPartyId,
	    String subjectIndividualAcCity, String subjectIndividualAcState, 
		String subjectIndividualAcStartDate, String subjectIndividualAcEndtDate) {
		
		this.subjectIndividualAcName = subjectIndividualAcName;
                this.subjectIndividualPartyId = subjectIndividualPartyId;
        this.subjectIndividualAcCity = subjectIndividualAcCity;
		this.subjectIndividualAcState = subjectIndividualAcState;       
		this.subjectIndividualAcStartDate = subjectIndividualAcStartDate;
		this.subjectIndividualAcEndtDate = subjectIndividualAcEndtDate;		
    }
    
    public String getSubjectIndividualAcName() {        	
	return subjectIndividualAcName;
    }
    
    public void setSubjectIndividualAcName(String subjectIndividualAcName) {
	this.subjectIndividualAcName = subjectIndividualAcName;
    }
    
    public String getSubjectIndividualPartyId() {        	
	return subjectIndividualPartyId;
    }
    
    public void setSubjectIndividualPartyId(String subjectIndividualPartyId) {
	this.subjectIndividualPartyId = subjectIndividualPartyId;
    }
	
	public String getSubjectIndividualAcCity() {        	
	return subjectIndividualAcCity;
    }
    
    public void setSubjectIndividualAcCity(String subjectIndividualAcCity) {
	this.subjectIndividualAcCity = subjectIndividualAcCity;
    }
	
	public String getSubjectIndividualAcState() {        	
	return subjectIndividualAcState;
    }
    
    public void setSubjectIndividualAcState(String subjectIndividualAcState) {
	this.subjectIndividualAcState = subjectIndividualAcState;
    }
	
	public String getSubjectIndividualAcStartDate() {        	
	return subjectIndividualAcStartDate;
    }
    
    public void setSubjectIndividualAcStartDate(String subjectIndividualAcStartDate) {
	this.subjectIndividualAcStartDate = subjectIndividualAcStartDate;
    }
	
	public String getSubjectIndividualAcEndtDate() {        	
	return subjectIndividualAcEndtDate;
    }
    
    public void setSubjectIndividualAcEndtDate(String subjectIndividualAcEndtDate) {
	this.subjectIndividualAcEndtDate = subjectIndividualAcEndtDate;
    }
	
    public String toString () {

	String sep = System.getProperty("line.separator");

	StringBuffer buffer = new StringBuffer();
	buffer.append(sep);			
        buffer.append("subjectIndividualAcName= ");
	buffer.append(subjectIndividualAcName);
	buffer.append(sep);
	buffer.append("subjectIndividualPartyId= ");
	buffer.append(subjectIndividualPartyId);
	buffer.append(sep);
        buffer.append("subjectIndividualAcCity= ");
	buffer.append(subjectIndividualAcCity);
	buffer.append(sep);
	buffer.append("subjectIndividualAcState= ");
	buffer.append(subjectIndividualAcState);
	buffer.append(sep);
	buffer.append("subjectIndividualAcStartDate= ");
	buffer.append(subjectIndividualAcStartDate);
	buffer.append(sep);		
	buffer.append("subjectIndividualAcEndtDate= ");
	buffer.append(subjectIndividualAcEndtDate);
	buffer.append(sep);		
	
	return buffer.toString();
    }
}
