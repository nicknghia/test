/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;

/**
 *
 * @author Binh.Nguyen
 */
public class ShipperModel implements Serializable{
    private static final long serialVersionUID = -1106837298377580912L;
    
    private String shipperStatus = "";
    private String shipperId = "";
    private String shipperName = "";
    private String iacNumber = "";
    private String shipperType = "";
    private String iacAcCompanyName = "";
      
	
    public ShipperModel() {
    }
    
    public ShipperModel(String shipperName, String shipperType, String shipperId, String shipperStatus, String iacNumber, 
              String iacAcCompanyName) {
	
        this.shipperName = shipperName;
        this.shipperType = shipperType;
        this.shipperId = shipperId;
        this.shipperStatus = shipperStatus;
        this.iacNumber = iacNumber;       
        this.iacAcCompanyName = iacAcCompanyName;
	
    }
    
    public void setShipperStatus (String shipperStatus) {
		this.shipperStatus = shipperStatus; 
	}

	public void setShipperId (String shipperId) {
		this.shipperId = shipperId; 
	}

	public void setShipperName (String shipperName) {
		this.shipperName = shipperName; 
	}
        
    public void setIacAcCompanyName (String iacAcCompanyName) {
		this.iacAcCompanyName = iacAcCompanyName; 
	}

	public void setIacNumber (String iacNumber) {
		this.iacNumber = iacNumber; 
	}
        
     public void setShipperType (String shipperType) {
		this.shipperType = shipperType; 
	}

	public String getShipperStatus () {
		return (this.shipperStatus); 
	}

	public String getShipperId () {
		return (this.shipperId); 
	}

	public String getShipperName () {
		return (this.shipperName); 
	}
        
    public String getIacAcCompanyName () {
		return (this.iacAcCompanyName); 
	}

	public String getIacNumber () {
		return (this.iacNumber); 
	}
        
    public String getShipperType () {
		return (this.shipperType); 
	}
    	
    public String toString () {
	String sep = System.getProperty("line.separator");

	StringBuffer buffer = new StringBuffer();
	buffer.append(sep);			
    buffer.append("shipperName= ");
	buffer.append(shipperName);
	buffer.append(sep);
	buffer.append("shipperType= ");
	buffer.append(shipperType);
	buffer.append(sep);
	buffer.append("shipperId= ");
	buffer.append(shipperId);
	buffer.append(sep);
	buffer.append("shipperStatus= ");
	buffer.append(shipperStatus);
	buffer.append(sep);		
	buffer.append("iacNumber= ");
	buffer.append(iacNumber);
	buffer.append(sep);	
	buffer.append("iacAcCompanyName= ");
	buffer.append(iacAcCompanyName);
	buffer.append(sep);	
	
	return buffer.toString();
    }
    
}