/*
 * Any changes to this class must be in sync with CtuRequet.hbm.xml and CtuRequest table.
 */
package com.ctu.tsa.fas.requesttracker.data;

import java.sql.Timestamp;
import java.util.Date;

public class RequestTrackerData {

    private String type;
    private String requestNumber;
    private Date requestDate;
    private String requestType;
    private int requesterAgencyID;
    private String staInformation;
    private int jointOperations;
    private int ogaReferral;
    private int cargoIncident;
    private int ccsfApproval;
    private int airportID;
    private int psiid;
    private String airportName;
    private String requestor;
    private String requestorId;
    private String requestorName;
    private String subjectIndividual;
    private String subjectCompany;
    private String leadtargeter;
    private int staRequestID;
    private String cotargeter;
    private boolean derogFound;
    private String derogLevel;
    private String subjectRegion;
    private String recommendation;
    private String comments;
    private String userId;
    private String createUserName;
    private java.sql.Timestamp createTimestamp;
    private String lastUpdateUserName;
    private java.sql.Timestamp lastUpdateTimestamp;
    private boolean invComplete;
    private String inLieuAirport;

    public String getRequestNumber() {
        return requestNumber;
    }

    public void setRequestNumber(String requestNumber) {
        this.requestNumber = requestNumber;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getAirportName() {
        return airportName;
    }

    public void setAirportName(String airportName) {
        this.airportName = airportName;
    }

    public int getAirportID() {
        return airportID;
    }

    public void setAirportID(int airportID) {
        this.airportID = airportID;
    }

    public String getRequestType() {
        return requestType;
    }

    public void setRequestType(String requestType) {
        this.requestType = requestType;
    }

    public int getCargoIncident() {
        return cargoIncident;
    }

    public void setCargoIncident(int cargoIncident) {
        this.cargoIncident = cargoIncident;
    }

    public int getJointOperations() {
        return jointOperations;
    }

    public void setJointOperations(int jointOperations) {
        this.jointOperations = jointOperations;
    }

    public int getOgaReferral() {
        return ogaReferral;
    }

    public void setOgaReferral(int ogaReferral) {
        this.ogaReferral = ogaReferral;
    }

    public int getCcsfApproval() {
        return ccsfApproval;
    }

    public void setCcsfApproval(int ccsfApproval) {
        this.ccsfApproval = ccsfApproval;
    }

    public int getPsiid() {
        return psiid;
    }

    public void setPsiid(int psiid) {
        this.psiid = psiid;
    }
 
    public int getStaRequestID() {
        return staRequestID;
    }

    public void setStaRequestID(int staRequestID) {
        this.staRequestID = staRequestID;
    }

    public int getRequesterAgencyID() {
        return requesterAgencyID;
    }

    public void setRequesterAgencyID(int requesterAgencyID) {
        this.requesterAgencyID = requesterAgencyID;
    }

    public String getLeadtargeter() {
        return leadtargeter;
    }

    public void setLeadtargeter(String leadtargeter) {
        this.leadtargeter = leadtargeter;
    }

    public String getCotargeter() {
        return cotargeter;
    }

    public void setCotargeter(String cotargeter) {
        this.cotargeter = cotargeter;
    }

    public Date getRequestDate() {
        return requestDate;
    }

    public void setRequestDate(Date requestDate) {
        this.requestDate = requestDate;
    }

    public String getSubjectRegion() {
        return subjectRegion;
    }

    public void setSubjectRegion(String subjectRegion) {
        this.subjectRegion = subjectRegion;
    }

    public boolean isDerogFound() {
        return derogFound;
    }

    public boolean getDerogFound() {
        return derogFound;
    }

    public void setDerogFound(boolean derogFound) {
        this.derogFound = derogFound;
    }

    public String getDerogLevel() {
        return derogLevel;
    }

    public void setDerogLevel(String derogLevel) {
        this.derogLevel = derogLevel;
    }

    public String getRequestor() {
        return requestor;
    }

    public void setRequestor(String requestor) {
        this.requestor = requestor;
    }

    public String getRequestorName() {
        return requestorName;    /// upperCase ?
    }

    public void setRequestorName(String requestorName) {
        this.requestorName = requestorName;   
    }

    public String getRecommendation() {
        return (null == recommendation? "" : recommendation.toUpperCase());
    }

    public void setRecommendation(String recommendation) {
        this.recommendation = recommendation;
    }

    public String getComments() {
        return (null == comments? "" : comments.toUpperCase());
    }

    public void setComments(String comments) {
        this.comments = comments;
    }

    public String getSubjectIndividual() {
        return (null == subjectIndividual? "" : subjectIndividual.toUpperCase());
    }

    public void setSubjectIndividual(String subjectIndividual) {
        this.subjectIndividual = subjectIndividual;
    }

    public String getSubjectCompany() {
        return (null == subjectCompany? "" : subjectCompany.toUpperCase());
    }

    public void setSubjectCompany(String subjectCompany) {
        this.subjectCompany = subjectCompany;
    }

    public boolean isInvComplete() {
        return invComplete;
    }

    public void setInvComplete(boolean invComplete) {
        this.invComplete = invComplete;
    }

    public String getStaInformation() {
        return staInformation;
    }

    public void setStaInformation(String staInformation) {
        this.staInformation = staInformation;
    }


    public String getRequestorId() {
        return requestorId;
    }

    public void setRequestorId(String requestorId) {
        this.requestorId = requestorId;
    }

    public String getUserId() {
        return userId;
    }

    public void setUserId(String userId) {
        this.userId = userId;
    }

    public String getCreateUserName() {
        return createUserName;
    }

    public void setCreateUserName(String createUserName) {
        this.createUserName = createUserName;
    }

    public String getLastUpdateUserName() {
        return lastUpdateUserName;
    }

    public void setLastUpdateUserName(String lastUpdateUserName) {
        this.lastUpdateUserName = lastUpdateUserName;
    }

    public Timestamp getLastUpdateTimestamp() {
        return lastUpdateTimestamp;
    }

    public void setLastUpdateTimestamp(Timestamp lastUpdateTimestamp) {
        this.lastUpdateTimestamp = lastUpdateTimestamp;
    }

    public Timestamp getCreateTimestamp() {
        return createTimestamp;
    }

    public void setCreateTimestamp(Timestamp createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    public String getInLieuAirport() {
        return inLieuAirport;
    }

    public void setInLieuAirport(String inLieuAirport) {
        this.inLieuAirport = inLieuAirport;
    }

    @Override
    public String toString() {
        return "RequestTrackerData{" + "type=" + type + ", requestNumber=" + requestNumber + ", requestDate=" + requestDate + ", requestType=" + requestType + ", requesterAgencyID=" + requesterAgencyID + ", staInformation=" + staInformation + ", jointOperations=" + jointOperations + ", ogaReferral=" + ogaReferral + ", cargoIncident=" + cargoIncident + ", ccsfApproval=" + ccsfApproval + ", airportID=" + airportID + ", psiid=" + psiid + ", airportName=" + airportName + ", requestor=" + requestor + ", requestorId=" + requestorId + ", requestorName=" + requestorName + ", subjectIndividual=" + subjectIndividual + ", subjectCompany=" + subjectCompany + ", leadtargeter=" + leadtargeter + ", staRequestID=" + staRequestID + ", cotargeter=" + cotargeter + ", derogFound=" + derogFound + ", derogLevel=" + derogLevel + ", subjectRegion=" + subjectRegion + ", recommendation=" + recommendation + ", comments=" + comments + ", userId=" + userId + ", createUserId=" + createUserName + ", createTimestamp=" + createTimestamp + ", lastUpdateUserId=" + lastUpdateUserName + ", lastUpdateTimestamp=" + lastUpdateTimestamp + ", invComplete=" + invComplete + ", inLieuAirport=" + inLieuAirport + '}';
    }

    
    
}
