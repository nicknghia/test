/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.action;

import javax.servlet.http.HttpServletRequest;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import javax.servlet.http.HttpSession;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.log4j.Logger;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.ServletActionContext;
import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import java.util.List;
import java.util.ArrayList;
import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchSubjectIndividualDAO;
import com.ctu.tsa.fas.expandedsearch.model.SubjectIndividualDetails; 
import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.LcpConstants;
import java.util.Map;
import java.util.HashMap;
import java.sql.*;
import java.util.Collections;
import java.util.Iterator;
import com.ctu.tsa.fas.expandedsearch.dao.ExpandedSearchSubjectIndividualDAO.MySqlResults;
import org.json.JSONArray;
import org.json.JSONObject;
import com.freightdesk.fdcommons.ApplicationTabs;

/**
 *
 * @author Binh.Nguyen
 */

public class SubjectIndividualSearchAction extends ActionSupport implements ServletRequestAware{
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();    
    private String loginTimeRoleMsg;
    private String expandedSearchType = "";
    private String basicBtnClicked = "";
    private List<String> searchTypeList = new ArrayList<>();
    private String subjectIndividualStaId = "";
    private String subjectIndividualType = "";
    private String subjectIndividualSubmittedByEntity = "";
    private String subjectIndividualFirstName = "";
    private String subjectIndividualLastName = "";
    private String hdnSubjectIndividualLastName = "";
    private String hdnSubjectIndividualFirstName = "";
    private String hdnSubjectIndividualStaId = "";
    
    private List<Map> subjectIndividualListMap;
    private List<Map> subjectIndividualList;
    
    private long recordCount=0;
    private String pagerOffset;
    private int noOfSubjectIndividualRecordsToLoad = 100000;
    private String noOfSubjectIndividualRecordsToLoadStr;         
	private int pageSize = 25;

	private long[] elapsedTime = new long[4];
    private Runtime runtime = Runtime.getRuntime();
	private String debugMsg = null;
    
	
    
    @Override
    public String execute()throws Exception {
    	
        elapsedTime[0] = System.currentTimeMillis();
    	
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        ExpandedSearchSubjectIndividualDAO dao = new ExpandedSearchSubjectIndividualDAO();       
		List<SubjectIndividualDetails> subjectIndividualDetails = new ArrayList<SubjectIndividualDetails>();
        ResultSet searchResultSet;
        MySqlResults iacSqlResults;
        
        logger.info("SubjectIndividualSearchAction - execute(): begin");
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);               

        SessionStore sessionStore = SessionStore.getInstance (request.getSession());
        sessionStore.put(SessionKey.CURRENT_TAB, ApplicationTabs.EXPANDEDSEARCH);        		
		
        try {            
            noOfSubjectIndividualRecordsToLoad = 100;
            noOfSubjectIndividualRecordsToLoadStr = Integer.toString(noOfSubjectIndividualRecordsToLoad);            
        } catch (Exception ignored) {
            logger.debug ("ADDRESSBOOK_MAXIMUM_RESULTS property is not set, defaulting to 4000 " + ignored);          
        }
        
        setNoOfSubjectIndividualRecordsToLoad(getNoOfSubjectIndividualRecordsToLoad());
        
        
        searchTypeList = initSearchTypeList (searchTypeList);       
                
        logger.info("subjectIndividualSearchAction - pager.offset: " + request.getParameter("pager.offset"));
        
         //For Paging          
        if (request.getParameter("pager.offset") != null) {
        	
		    try {
              pageSize = Integer.valueOf((String)sessionStore.get(SessionKey.RESULT_PER_PAGE_SUB_IND));			  			  			              
            } catch(Exception parseExceptionIgnored) {
	            logger.error ("Exception parseExceptionIgnored" + parseExceptionIgnored);
	        }
		    
		    setPagerOffset(request.getParameter("pager.offset"));
        	logger.info("PAGING:" + pagerOffset);

        	store.put (SessionKey.INDEX, pagerOffset);
                
            subjectIndividualList = (List<Map>)store.get(SessionKey.SubjectIndividual_LIST);
            subjectIndividualListMap = convertToSubjectIndividualListMap(subjectIndividualList);
                       
            setRecordCount ((long)(sessionStore.get(SessionKey.TOTAL_COUNT))); 
            
    		debugMsg = "SubjectIndividual **** Memory used: " + (runtime.totalMemory() - runtime.freeMemory())/1000 + " Elapsed Time :" + (System.currentTimeMillis() - elapsedTime[0]);
    		logger.info(debugMsg);
    	    session.setAttribute("DEBUG_MSG", debugMsg);
                    
            
            return "displaySubjectIndividual";
        }

    	logger.info("INITIAL SEARCH:" + pageSize);
        sessionStore.put(SessionKey.SubjectIndividual_LIST, Collections.emptyList());

        if ((getSubjectIndividualStaId().length() == 0) && (getSubjectIndividualLastName().length() == 1)){
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(0) );
            addFieldError("userDetailsErrorsHeader", getText("errors.header"));
            addActionError("Minimum of 2 alphanumeric characters must be entered in the Last Name search field");
            return "displaySubjectIndividual";
        } else if ((getSubjectIndividualStaId().length() < 3) && (getSubjectIndividualLastName().length() <= 1) 
                && (getSubjectIndividualFirstName().length() <= 1)){
            sessionStore.put (SessionKey.TOTAL_COUNT, new Long(0) );
            addFieldError("userDetailsErrorsHeader", getText("errors.header"));
            addActionError("Minimum of 3 alphanumeric characters must be entered in the STA ID search field");
            return "displaySubjectIndividual";
        } 
        
        setSubjectIndividualStaId(getSubjectIndividualStaId().toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt"));
        setSubjectIndividualLastName(getSubjectIndividualLastName().toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt"));
        setSubjectIndividualFirstName(getSubjectIndividualFirstName().toUpperCase().replaceAll("<", "&lt").replaceAll(">", "&gt"));
            
	// Initial search	    
        if (! getSubjectIndividualStaId().trim().equals("")){
            setHdnSubjectIndividualStaId(getSubjectIndividualStaId());
            setHdnSubjectIndividualLastName("");
            iacSqlResults = (MySqlResults) dao.getRecordByStatIdSummaryPage(getSubjectIndividualStaId());

        } else if ((! getSubjectIndividualFirstName().trim().equals("")) && 
                (getSubjectIndividualLastName().trim().equals(""))){
            subjectIndividualList = new ArrayList<Map>();
            setRecordCount ( 0);
            addFieldError("userDetailsErrorsHeader", getText("errors.header"));
            addActionError("Last Name is required.");
            return "displaySubjectIndividual";
            
        } else if (! getSubjectIndividualFirstName().trim().equals("")){
            setHdnSubjectIndividualFirstName(getSubjectIndividualFirstName());
            setHdnSubjectIndividualLastName("");
            iacSqlResults = (MySqlResults) dao.getSubjectIndividualByFirstNameLastName
		    (getSubjectIndividualFirstName(), getSubjectIndividualLastName());

        } else if (! getSubjectIndividualLastName().trim().equals("")){
            setHdnSubjectIndividualLastName(getSubjectIndividualLastName());
            setHdnSubjectIndividualFirstName("");
            iacSqlResults = (MySqlResults) dao.getSubjectIndividualByLastName(getSubjectIndividualLastName());

        } else {
            iacSqlResults = (MySqlResults) dao.getRecordByStatIdSummaryPage("%");
            
        }				

        setSubjectIndividualList(iacSqlResults.getSListMap());
        
    	subjectIndividualListMap = convertToSubjectIndividualListMap(subjectIndividualList);

        setRecordCount ( subjectIndividualList.size());
        sessionStore.put (SessionKey.TOTAL_COUNT, new Long(getRecordCount()));
        session.setAttribute("STA_LIST", convertMapListToJsonString(subjectIndividualList));		
	    
		debugMsg = "SUBJECT INDIVIDUAL **** Memory used: " + (runtime.totalMemory() - runtime.freeMemory())/1000 + " Elapsed Time :" + (System.currentTimeMillis() - elapsedTime[0]);
		logger.info(debugMsg);
	    session.setAttribute("DEBUG_MSG", debugMsg);
        
	    

        return "displaySubjectIndividual";


    }
    
    public String respondBtnSearchTypeReturn() throws java.lang.Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials) + "<br>" + IncludesUtil.getExpireMsg(credentials);

        logger.debug("Starting respondBtnSearchTypeReturn ");
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        return "display";
    }          
    
    public String getExpandedSearchType() {
	return expandedSearchType;
    }
        
    public void setExpandedSearchType(String expandedSearchType) {
	this.expandedSearchType = expandedSearchType; 
    }
    
    public String getSubjectIndividualStaId() {
	return subjectIndividualStaId.toUpperCase();
    }
    
	public String getSubjectIndividualType() {
		return subjectIndividualType.toUpperCase();
    }
	
	public String getSubjectIndividualSubmittedByEntity() {
		return subjectIndividualSubmittedByEntity.toUpperCase();
    }
	
	public String getSubjectIndividualLastName() {
	return subjectIndividualLastName.toUpperCase();
    }
	
	public String getSubjectIndividualFirstName() {
	return subjectIndividualFirstName.toUpperCase();
    }
	
    public void setSubjectIndividualType(String subjectIndividualType) {
	this.subjectIndividualType = subjectIndividualType; 
    }
	
    public void setSubjectIndividualSubmittedByEntity(String subjectIndividualSubmittedByEntity) {
	this.subjectIndividualSubmittedByEntity = subjectIndividualSubmittedByEntity; 
    }
        
    public void setSubjectIndividualLastName(String subjectIndividualLastName) {
	this.subjectIndividualLastName = subjectIndividualLastName; 
    }
    
    public void setSubjectIndividualFirstName(String subjectIndividualFirstName) {
	this.subjectIndividualFirstName = subjectIndividualFirstName; 
    }
	
    public void setSubjectIndividualStaId(String subjectIndividualStaId) {
	this.subjectIndividualStaId = subjectIndividualStaId; 
    }
    
    public String getHdnSubjectIndividualStaId() {
	return hdnSubjectIndividualStaId;
    }
    
    public void setHdnSubjectIndividualStaId(String hdnSubjectIndividualStaId) {
	this.hdnSubjectIndividualStaId = hdnSubjectIndividualStaId; 
    }
	
    public String getHdnSubjectIndividualLastName() {
	return hdnSubjectIndividualLastName;
    }
	
    public void setHdnSubjectIndividualLastName(String hdnSubjectIndividualLastName) {
	this.hdnSubjectIndividualLastName = hdnSubjectIndividualLastName; 
    }
    
	public String getHdnSubjectIndividualFirstName() {
	return hdnSubjectIndividualFirstName;
    }
	
    public void setHdnSubjectIndividualFirstName(String hdnSubjectIndividualFirstName) {
	this.hdnSubjectIndividualFirstName = hdnSubjectIndividualFirstName; 
    }
	
    public List<String> getSearchTypeList() {
	return searchTypeList;
    }
        
    public void setSearchTypeList(List<String> searchTypeList) {
	this.searchTypeList = searchTypeList; 
    }
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }

    @Override
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
    
    public String getBasicBtnClicked() {
        return basicBtnClicked;
    }

    public void setBasicBtnClicked(String basicBtnClicked) {
        this.basicBtnClicked = basicBtnClicked;
    }
    
    public long getRecordCount() {
	return recordCount;
    }
        
    public void setRecordCount(long recordCount) {
	this.recordCount = recordCount; 
    }
    
    private List<String> initSearchTypeList (List<String> inSearchTypeList){
        inSearchTypeList = new ArrayList<>();
	inSearchTypeList.add("Subject Individual");
        inSearchTypeList.add("CCSF");
        inSearchTypeList.add("IAC");
        inSearchTypeList.add("Shipper"); 
        inSearchTypeList.add("Subject Company");
        
        return inSearchTypeList;
    }
    
    public List<Map> getSubjectIndividualListMap() {
        return subjectIndividualListMap;
    }

    public void setSubjectIndividualtMap(List<Map> subjectIndividualListMap) {
        this.subjectIndividualListMap = subjectIndividualListMap;
    }
    
    public List<Map> getSubjectIndividualList() {
        return subjectIndividualList;
    }

    public void setSubjectIndividualList(List<Map> subjectIndividualList) {
        this.subjectIndividualList = subjectIndividualList;
    }
    
    public String getPagerOffset() {
        return pagerOffset;
    }

    public void setPagerOffset(String pagerOffset) {
        this.pagerOffset = pagerOffset;
    }
      
    
    List<Map> convertToSubjectIndividualListMap(List<Map> theSubjectIndividualList){
        int starting_idx=0;
        List<Map> theSubjectIndividualListMap;
        

        if (request.getParameter("pager.offset") != null) {
            starting_idx = Integer.parseInt((String)request.getParameter("pager.offset"));
        }
        
        
        logger.info(starting_idx + ":-----startIdx - pageSize---:" + pageSize + " listSize:" + theSubjectIndividualList.size());

        theSubjectIndividualListMap = theSubjectIndividualList.subList(starting_idx, Math.min(starting_idx + pageSize, theSubjectIndividualList.size()));
        return theSubjectIndividualListMap ;
    }
       
    
    public void setNoOfSubjectIndividualRecordsToLoad(int noOfSubjectIndividualRecordsToLoad){
        this.noOfSubjectIndividualRecordsToLoad = noOfSubjectIndividualRecordsToLoad;
    }

    public int getNoOfSubjectIndividualRecordsToLoad() {
        return noOfSubjectIndividualRecordsToLoad;
    }         
     
    public List<Map> addListMap (List<Map> listMapA, List<Map> listMapB){
        for (int i=0; i < listMapB.size(); i++){
            listMapA.add(listMapB.get(i));
        }
        
        return listMapA;
    }
    
     private String convertMapListToJsonString(List<Map> list) {

		JSONArray ja = new JSONArray();
	    JSONObject jo = null;
		String dataStr = null;
	
	    try {
	        if (null != list && !list.isEmpty()) {
	
				for (Map<String, String> map : list) {
			      jo = new JSONObject();
			      for (Map.Entry<String, String> entry : map.entrySet()) {
			    	  jo.put(entry.getKey(), entry.getValue());
			      }
			      ja.put (jo);
	           }
				dataStr = ja.toString ();				
	        }
	    } catch(Exception e) {
	      logger.error ("Exception JSON conversion" + e);
	    }
	    return dataStr;
    
    }
}
