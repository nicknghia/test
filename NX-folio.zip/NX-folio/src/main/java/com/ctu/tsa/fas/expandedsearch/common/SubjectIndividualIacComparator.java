/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.common;
import java.io.Serializable;
import java.util.Comparator;

import org.apache.log4j.Logger;
import com.ctu.tsa.fas.expandedsearch.model.SubjectIndividualIacModel;

/**
 *
 * @author Binh.Nguyen
 */
public class SubjectIndividualIacComparator implements Comparator<SubjectIndividualIacModel>, Serializable{
    private static final long serialVersionUID = 11L;

    private Logger logger = Logger.getLogger(SubjectIndividualIacComparator.class);
    private boolean ascendingIac;
    private String colName;
    
    public SubjectIndividualIacComparator(String colName, boolean ascendingIac) {
	this.ascendingIac = ascendingIac;
	this.colName = colName;
    }
    
    @SuppressWarnings("unchecked")
    public int compare(SubjectIndividualIacModel o1, SubjectIndividualIacModel o2) {
        int result = 0;
        
      try {
            Object value1 = null;
            Object value2 = null;
            
        if (colName.equalsIgnoreCase("subjectIndividualIacNumber")) {
		   value1 = o1.getSubjectIndividualIacNumber();
		   value2 = o2.getSubjectIndividualIacNumber();
        } else if (colName.equalsIgnoreCase("subjectIndividualIacName")) {
		   value1 = o1.getSubjectIndividualIacName();
		   value2 = o2.getSubjectIndividualIacName();
        } else if (colName.equalsIgnoreCase("subjectIndividualIacCity")) {
		   value1 = o1.getSubjectIndividualIacCity();
		   value2 = o2.getSubjectIndividualIacCity();
		} else if (colName.equalsIgnoreCase("subjectIndividualIacState")) {
		   value1 = o1.getSubjectIndividualIacState();
		   value2 = o2.getSubjectIndividualIacState();
        } else if (colName.equalsIgnoreCase("subjectIndividualIacStartDate")) {
		   value1 = o1.getSubjectIndividualIacStartDate();
		   value2 = o2.getSubjectIndividualIacStartDate();	
        } else if (colName.equalsIgnoreCase("subjectIndividualIacEndDate")) {
		   value1 = o1.getSubjectIndividualIacEndDate();
		   value2 = o2.getSubjectIndividualIacEndDate();	   			
        } else {
		logger.warn("Could not map " + colName + " to class attribute");
        }
            
        // Null is lesser than anything else.
        if ((value1 == null) && (value2 == null)) {
		       result = 0;            
        } else if (value1 instanceof Comparable) {
		    // the attribute values are Comparable, we have hit the JackPot.  We have absolutely nothing intelligent to do
		      @SuppressWarnings("rawtypes")
		      Comparable comp1 = (Comparable) value1;
		      @SuppressWarnings("rawtypes")
		      Comparable comp2 = (Comparable) value2;
		      result = comp1.compareTo(comp2);
        } else {
		       logger.warn("Dont know how to sort by " + colName);
        }

        if (!ascendingIac) {
		result = 0 - result;
        }
      }
      catch (Exception ex) {
            //ex.printStackTrace();
            logger.error("Exception : " + ex.getMessage());
	 }
        return result;
    }
}
