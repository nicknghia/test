/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;

/**
 *
 * @author Binh.Nguyen
 */
public class SubjectCompanyDetails implements Serializable{
    private static final long serialVersionUID = -8767337899673261247L;

    private String subjectCompanyStatus = "";
    private String subjectCompanyId = "";
    private String subjectCompanyName = "";
    private String subjectCompanyType = "";
    private String subjectCompanyState = "";  
    private String subjectCompanyPhone = "";
    private String subjectCompanyAddress1 = "";
    private String subjectCompanyAddress2 = "";
    private String subjectCompanyCity = "";
    private String subjectCompanyZipPostalCode = "";
    private String subjectCompanyCountry = "";
	private String subjectCompanyEinNumber = "";
	private String subjectCompanyKnownAs1 = "";
	private String subjectCompanyKnownAs2 = "";
	private String subjectCompanyKnownAs3 = "";
	private String subjectCompanyFirstName = "";
	private String subjectCompanyLastName = "";
	private String subjectCompanyEmail = "";
	private String subjectCompanyDesignation = "";
	private String subjectCompanyTitle = "";
	private long subjectCompanyCredential = 0;
	private String subjectCompanyInitialApprovalDate = "";
	private String subjectCompanyLastApprovalDate = "";
	private String subjectCompanyExpirationDate = "";
	private String subjectCompanyApprovingAgent = "";
	private String subjectCompanyComments = "";
	
	
	public String getSubjectCompanyComments() {        	
	return subjectCompanyComments;
    }
    
    public void setSubjectCompanyComments(String subjectCompanyComments) {
	this.subjectCompanyComments = subjectCompanyComments;
    }  
	
	public String getSubjectCompanyInitialApprovalDate() {        
	return subjectCompanyInitialApprovalDate;
    }
    
    public void setSubjectCompanyInitialApprovalDate(String subjectCompanyInitialApprovalDate) {
	this.subjectCompanyInitialApprovalDate = subjectCompanyInitialApprovalDate;
    }
	
	public String getSubjectCompanyLastApprovalDate() {       
	return subjectCompanyLastApprovalDate;
    }
    
    public void setSubjectCompanyLastApprovalDate(String subjectCompanyLastApprovalDate) {
	this.subjectCompanyLastApprovalDate = subjectCompanyLastApprovalDate;
    }
	
	public String getSubjectCompanyExpirationDate() {       	
	return subjectCompanyExpirationDate;
    }
    
    public void setSubjectCompanyExpirationDate(String subjectCompanyExpirationDate) {
	this.subjectCompanyExpirationDate = subjectCompanyExpirationDate;
    }
	
	public String getSubjectCompanyApprovingAgent() {        	
	return subjectCompanyApprovingAgent;
    }
    
    public void setSubjectCompanyApprovingAgent(String subjectCompanyApprovingAgent) {
	this.subjectCompanyApprovingAgent = subjectCompanyApprovingAgent;
    }
	
	public long getSubjectCompanyCredential() {	
    return subjectCompanyCredential;
    }

    public void setSubjectCompanyCredential(long subjectCompanyCredential) {
        this.subjectCompanyCredential = subjectCompanyCredential;
    }
	
	public String getSubjectCompanyDesignation() {	
    return subjectCompanyDesignation;
    }

    public void setSubjectCompanyDesignation(String subjectCompanyDesignation) {
        this.subjectCompanyDesignation = subjectCompanyDesignation;
    }
	
	public String getSubjectCompanyTitle() {	
    return subjectCompanyTitle;
    }

    public void setSubjectCompanyTitle(String subjectCompanyTitle) {
        this.subjectCompanyTitle = subjectCompanyTitle;
    }
	
    public String getSubjectCompanyEinNumber() {	
    return subjectCompanyEinNumber;
    }

    public void setSubjectCompanyEinNumber(String subjectCompanyEinNumber) {
        this.subjectCompanyEinNumber = subjectCompanyEinNumber;
    }
	
	public String getSubjectCompanyKnownAs1() {	    
    return subjectCompanyKnownAs1;
    }

    public void setSubjectCompanyKnownAs1(String subjectCompanyKnownAs1) {
        this.subjectCompanyKnownAs1 = subjectCompanyKnownAs1;
    } 
	
	public String getSubjectCompanyKnownAs2() {	    
    return subjectCompanyKnownAs2;
    }

    public void setSubjectCompanyKnownAs2(String subjectCompanyKnownAs2) {
        this.subjectCompanyKnownAs2 = subjectCompanyKnownAs2;
    } 

	public String getSubjectCompanyKnownAs3() {	    
    return subjectCompanyKnownAs3;
    }

    public void setSubjectCompanyKnownAs3(String subjectCompanyKnownAs3) {
        this.subjectCompanyKnownAs3 = subjectCompanyKnownAs3;
    }
	
	public String getSubjectCompanyFirstName() {	    
    return subjectCompanyFirstName;
    }

    public void setSubjectCompanyFirstName(String subjectCompanyFirstName) {
        this.subjectCompanyFirstName = subjectCompanyFirstName;
    }
	
	public String getSubjectCompanyLastName() {	    
    return subjectCompanyLastName;
    }

    public void setSubjectCompanyLastName(String subjectCompanyLastName) {
        this.subjectCompanyLastName = subjectCompanyLastName;
    }
	
	public String getSubjectCompanyEmail() {	    
    return subjectCompanyEmail;
    }

    public void setSubjectCompanyEmail(String subjectCompanyEmail) {
        this.subjectCompanyEmail = subjectCompanyEmail;
    }
	
	public void setSubjectCompanyStatus (String subjectCompanyStatus) {
        this.subjectCompanyStatus = subjectCompanyStatus; 
     }

    public void setSubjectCompanyId (String subjectCompanyId) {
        this.subjectCompanyId = subjectCompanyId; 
     }

    public void setSubjectCompanyName (String subjectCompanyName) {
        this.subjectCompanyName = subjectCompanyName; 
     }

    public void setSubjectCompanyState (String subjectCompanyState) {
	this.subjectCompanyState = subjectCompanyState; 
     }
	    
    public void setSubjectCompanyType (String subjectCompanyType) {
	this.subjectCompanyType = subjectCompanyType; 
    }

    public String getSubjectCompanyStatus () {
	return (this.subjectCompanyStatus); 
    }
	   
    public String getSubjectCompanyId () {
	return (this.subjectCompanyId); 
    }

    public String getSubjectCompanyName () {
	return (this.subjectCompanyName); 
    }

    public String getSubjectCompanyState () {
	return (this.subjectCompanyState); 
    }
    
    public String getSubjectCompanyType () {
	return (this.subjectCompanyType); 
    }

    public String getSubjectCompanyPhone() {
        return subjectCompanyPhone;
    }

    public void setSubjectCompanyPhone(String subjectCompanyPhone) {
        this.subjectCompanyPhone = subjectCompanyPhone;
    }
            
    public String getSubjectCompanyAddress1() {
        return subjectCompanyAddress1;
    }

    public void setSubjectCompanyAddress1(String subjectCompanyAddress1) {
        this.subjectCompanyAddress1 = subjectCompanyAddress1;
    }        
        
    public String getSubjectCompanyAddress2() {
        return subjectCompanyAddress2;
    }

    public void setSubjectCompanyAddress2(String subjectCompanyAddress2) {
        this.subjectCompanyAddress2 = subjectCompanyAddress2;
    }    
    
    public String getsubjectCompanyCity() {
        return subjectCompanyCity;
    }

    public void setSubjectCompanyCity(String subjectCompanyCity) {
        this.subjectCompanyCity = subjectCompanyCity;
    }
        
    public String getSubjectCompanyZipPostalCode() {
        return subjectCompanyZipPostalCode;
    }

    public void setSubjectCompanyZipPostalCode(String subjectCompanyZipPostalCode) {
        this.subjectCompanyZipPostalCode = subjectCompanyZipPostalCode;
    }
    
    public String getSubjectCompanyCountry() {
        return subjectCompanyCountry;
    }

    public void setSubjectCompanyCountry(String subjectCompanyCountry) {
        this.subjectCompanyCountry = subjectCompanyCountry;
    }
    
	public String toString () {

		String sep = System.getProperty("line.separator");

		StringBuffer buffer = new StringBuffer();
		buffer.append(sep);       
		buffer.append("subjectCompanyName = ");
		buffer.append(subjectCompanyName);
		buffer.append(sep);
		buffer.append("subjectCompanyType = ");
		buffer.append(subjectCompanyType);
		buffer.append(sep);
		buffer.append("subjectCompanyId = ");
		buffer.append(subjectCompanyId);
		buffer.append(sep);
		buffer.append("subjectCompanyStatus = ");
		buffer.append(subjectCompanyStatus);
		buffer.append(sep);
        buffer.append("subjectCompanyState = ");
		buffer.append(subjectCompanyState);
		buffer.append(sep);				
		buffer.append("subjectCompanyAddress1 = ");
		buffer.append(subjectCompanyAddress1);
		buffer.append(sep);
		buffer.append("subjectCompanyAddress2 = ");
		buffer.append(subjectCompanyAddress2);
		buffer.append(sep);
		buffer.append("subjectCompanyCity = ");
		buffer.append(subjectCompanyCity);
		buffer.append(sep);
		buffer.append("subjectCompanyZipPostalCode = ");
		buffer.append(subjectCompanyZipPostalCode);
		buffer.append(sep);
		buffer.append("subjectCompanyCountry = ");
		buffer.append(subjectCompanyCountry);
		buffer.append(sep);
		buffer.append("subjectCompanyPhone = ");
		buffer.append(subjectCompanyPhone);
		buffer.append(sep);	
        buffer.append("subjectCompanyEinNumber = ");
		buffer.append(subjectCompanyEinNumber);
		buffer.append(sep);	
		buffer.append("subjectCompanyKnownAs1= ");
		buffer.append(subjectCompanyKnownAs1);
		buffer.append(sep);
		buffer.append("subjectCompanyKnownAs2= ");
		buffer.append(subjectCompanyKnownAs2);
		buffer.append(sep);
		buffer.append("subjectCompanyKnownAs3= ");
		buffer.append(subjectCompanyKnownAs3);
		buffer.append(sep);
		buffer.append("subjectCompanyFirstName= ");
		buffer.append(subjectCompanyFirstName);
		buffer.append(sep);
		buffer.append("subjectCompanyLastName= ");
		buffer.append(subjectCompanyLastName);
		buffer.append(sep);
		buffer.append("subjectCompanyEmail= ");
		buffer.append(subjectCompanyEmail);
		buffer.append(sep);
		buffer.append("subjectCompanyDesignation= ");
		buffer.append(subjectCompanyDesignation);
		buffer.append(sep);
		buffer.append("subjectCompanyTitle= ");
		buffer.append(subjectCompanyTitle);
		buffer.append(sep);
		buffer.append("subjectCompanyCredential= ");
		buffer.append(subjectCompanyCredential);
		buffer.append(sep);
		buffer.append("subjectCompanyInitialApprovalDate= ");
		buffer.append(subjectCompanyInitialApprovalDate);
		buffer.append(sep);
		buffer.append("subjectCompanyLastApprovalDate= ");
		buffer.append(subjectCompanyLastApprovalDate);
		buffer.append(sep);
		buffer.append("subjectCompanyExpirationDate= ");
		buffer.append(subjectCompanyExpirationDate);
		buffer.append(sep);
		buffer.append("subjectCompanyApprovingAgent= ");
		buffer.append(subjectCompanyApprovingAgent);
		buffer.append(sep);
		buffer.append("subjectCompanyComments= ");
		buffer.append(subjectCompanyComments);
		buffer.append(sep);
		
		return buffer.toString();
	}
}
