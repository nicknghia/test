package com.ctu.tsa.fas.requesttracker.data;

import java.io.Serializable;
import java.util.Date;

public class CtuStaInLieuOf implements Serializable {

    private int staInLieuOfId;
    private String staInLieuOfType;
    private String description;
    private String creteUserId;
    private String lastUpdateuserId;
    private Date createtimestamp;
    private Date lastUpdateTimestamp;

    public CtuStaInLieuOf() {

    }

    public CtuStaInLieuOf(int staInLieuOfId, String staInLieuOfType, String description, String creteUserId, String lastUpdateuserId, Date createtimestamp) {
        this.staInLieuOfId = staInLieuOfId;
        this.staInLieuOfType = staInLieuOfType;
        this.description = description;
        this.creteUserId = creteUserId;
        this.lastUpdateuserId = lastUpdateuserId;
        this.createtimestamp = createtimestamp;

    }

    public int getStaInLieuOfId() {
        return staInLieuOfId;
    }

    public void setStaInLieuOfId(int staInLieuOfId) {
        this.staInLieuOfId = staInLieuOfId;
    }

    public String getStaInLieuOfType() {
        return staInLieuOfType;
    }

    public void setStaInLieuOfType(String staInLieuOfType) {
        this.staInLieuOfType = staInLieuOfType;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreteUserId() {
        return creteUserId;
    }

    public void setCreteUserId(String creteUserId) {
        this.creteUserId = creteUserId;
    }

    public String getLastUpdateuserId() {
        return lastUpdateuserId;
    }

    public void setLastUpdateuserId(String lastUpdateuserId) {
        this.lastUpdateuserId = lastUpdateuserId;
    }

    public Date getCreatetimestamp() {
        return createtimestamp;
    }

    public void setCreatetimestamp(Date createtimestamp) {
        this.createtimestamp = createtimestamp;
    }

    public Date getLastUpdateTimestamp() {
        return lastUpdateTimestamp;
    }

    public void setLastUpdateTimestamp(Date lastUpdateTimestamp) {
        this.lastUpdateTimestamp = lastUpdateTimestamp;
    }

}
