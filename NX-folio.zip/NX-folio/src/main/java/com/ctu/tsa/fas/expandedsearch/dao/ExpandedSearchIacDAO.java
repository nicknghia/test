/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.dao;

import com.ctu.tsa.fas.expandedsearch.model.IacDetails;
import java.sql.Connection;
import java.util.ArrayList;
import org.apache.log4j.Logger;
import java.util.List;
import java.util.*;
import org.hibernate.Session;
import java.sql.*;
import java.sql.DriverManager;
import java.util.Map;
import oracle.jdbc.OracleTypes;
import oracle.jdbc.pool.OracleDataSource;
import org.json.JSONArray;
import org.json.JSONObject;
import org.json.XML;

/*
 * @author STCI
 */
public class ExpandedSearchIacDAO {

	private static ExpandedSearchIacDAO instance = null;
	protected Logger logger = Logger.getLogger(getClass());

	public ExpandedSearchIacDAO() {

	}

	public static ExpandedSearchIacDAO getInstance() {
		if (instance == null) {
			instance = new ExpandedSearchIacDAO();
		}
		return instance;
	}

	public class MySqlResults {
		List<Map> sListMap;
		long totalCount;

		public List<Map> getSListMap() {
			return sListMap;
		}

		public void setSListMap(List<Map> sListMap) {
			this.sListMap = sListMap;
		}

		public long getTotalCount() {
			return totalCount;
		}

		public void setTotalCount(long totalCount) {
			this.totalCount = totalCount;
		}
	}
        
        public MySqlResults getIacRecordsByIacNum(String iacId) throws Exception {
		logger.info("ExpandedSearchIacDAO - iacId: " + iacId);

		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;
		MySqlResults sqlResults = new MySqlResults();
		int count;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<IacDetails> iacDetails = new ArrayList<IacDetails>();
		Session session = null;
		String stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_REC_BY_IAC_NUM";
		if (iacId.equals("0")) {
			stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_REC_BY_IAC_NUM_1";
		} else {
			stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_REC_BY_IAC_NUM";
		}

		String tCallableStmtStr = "{call " + stProcName + "(?,?,?)}";
		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;
		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, iacId);
                    eStatement.registerOutParameter(2, OracleTypes.CURSOR);
                    eStatement.registerOutParameter(3, OracleTypes.INTEGER);
                    eReturnCode = eStatement.execute();
                    count = (int) eStatement.getObject(3);
                    sResultSet = (ResultSet) eStatement.getObject(2);
                    esListMap = convertResultSetToListMapForSummaryPage(sResultSet);
                    sqlResults.sListMap = esListMap;
                    sqlResults.totalCount = count;
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getIacConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
                   if (eStatement != null) { 
					  eStatement.close();
				   }
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection, eStatement, sResultSet);

		return sqlResults;
	}
        
        public MySqlResults getIacRecordsByIacName(String iacName) throws Exception {
		logger.info("ExpandedSearchIacDAO - iacName: " + iacName);

		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;
		MySqlResults sqlResults = new MySqlResults();
		int count;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<IacDetails> iacDetails = new ArrayList<IacDetails>();
		Session session = null;
		String stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_REC_BY_IAC_NAME";
		String tCallableStmtStr = "{call " + stProcName + "(?,?,?)}";
		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;
		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, iacName);
                    eStatement.registerOutParameter(2, OracleTypes.CURSOR);
                    eStatement.registerOutParameter(3, OracleTypes.INTEGER);
                    eReturnCode = eStatement.execute();
                    count = (int) eStatement.getObject(3);
                    sResultSet = (ResultSet) eStatement.getObject(2);
                    esListMap = convertResultSetToListMapForSummaryPage(sResultSet);
                    sqlResults.sListMap = esListMap;
                    sqlResults.totalCount = count;
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getIacConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
                   if (sResultSet != null) { 
					  sResultSet.close();
				   }
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return sqlResults;
	}

	public List<Map> getIacDetailsByIacName(String iacNum, String iacName)
			throws Exception {
		logger.info("ExpandedSearchIacDAO - iacNum: " + iacNum);
		logger.info("ExpandedSearchIacDAO - iacName: " + iacName);

		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<IacDetails> iacDetails = new ArrayList<IacDetails>();
		Session session = null;

		String stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_IAC_DETAILS_BY_IAC_NAME";
		String tCallableStmtStr = "{call " + stProcName + "(?,?,?)}";

		if (iacNum.equals("0")) {
			stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_IAC_DETAILS_BY_IAC_NAME_1";
			tCallableStmtStr = "{call " + stProcName + "(?,?)}";
		}

		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;
                
		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    logger.info(" eStatement:" + eStatement);
                    if (iacNum.equals("0")) {
                        eStatement.setString(1, iacName);
                        eStatement.registerOutParameter(2, OracleTypes.CURSOR);
                    } else {
                        eStatement.setString(1, iacNum);
                        eStatement.setString(2, iacName);
                        eStatement.registerOutParameter(3, OracleTypes.CURSOR);
                    }
                    eReturnCode = eStatement.execute();
                    if (iacNum.equals("0")) {
			sResultSet = (ResultSet) eStatement.getObject(2);
                    } else {
                        sResultSet = (ResultSet) eStatement.getObject(3);
                    }
                    esListMap = convertResultSetToListMap(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getIacConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
                   if (eStatement != null) { 
					  eStatement.close();
				   }
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return esListMap;
	}
        
	public JSONArray getIacDetailsByIacNumber(String iacNum) throws Exception {
		logger.info("ExpandedSearchIacDAO - iacNum: " + iacNum);

		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<IacDetails> iacDetails = new ArrayList<IacDetails>();
		Session session = null;

		String stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_IAC_DETAILS_BY_IAC_NAME";
		String tCallableStmtStr = "{call " + stProcName + "(?,?,?)}";

		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;
                JSONArray iacDetailArray;
                
		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    logger.info(" eStatement:" + eStatement);
                    eStatement.setString(1, iacNum);
                    eStatement.setString(2, ""); // not used
                    eStatement.registerOutParameter(3, OracleTypes.CURSOR);
                    eReturnCode = eStatement.execute();
                    sResultSet = (ResultSet) eStatement.getObject(3);
                    esListMap = convertResultSetToListMap(sResultSet);
                    iacDetailArray = getJsonIacDetails(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getIacConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
                    if (eStatement != null) {
					   eStatement.close();
					}
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return iacDetailArray;
	}
	
	public JSONArray getJsonIacDetails(ResultSet resultSet) throws Exception {

		logger.info("-------------:getRequestsByFields:");

		JSONArray array = new JSONArray();

		try {

			while (resultSet.next()) {

				logger.info("-------------:getRequestsByFields:" + resultSet);

				JSONObject obj = new JSONObject();

				obj.put("PARTY_NAME",
						(null == resultSet.getString("PARTY_NAME")) ? ""
								: resultSet.getString("PARTY_NAME").toString());
				obj.put("PARTY_ID",
						(null == resultSet.getString("PARTY_ID")) ? ""
								: resultSet.getString("PARTY_ID").toString());
				obj.put("STATUS", (null == resultSet.getString("STATUS")) ? ""
						: resultSet.getString("STATUS").toString());
				obj.put("ADDRESS1",
						(null == resultSet.getString("ADDRESS1")) ? ""
								: resultSet.getString("ADDRESS1").toString());
				obj.put("ADDRESS2",
						(null == resultSet.getString("ADDRESS2")) ? ""
								: resultSet.getString("ADDRESS2").toString());
				obj.put("CITY", (null == resultSet.getString("CITY")) ? ""
						: resultSet.getString("CITY").toString());
				obj.put("POSTAL_CODE",
						(null == resultSet.getString("POSTAL_CODE")) ? ""
								: resultSet.getString("POSTAL_CODE").toString());
				obj.put("STATE", (null == resultSet.getString("STATE")) ? ""
						: resultSet.getString("STATE").toString());
				obj.put("PHONE_NUMBER",
						(null == resultSet.getString("PHONE_NUMBER")) ? ""
								: resultSet.getString("PHONE_NUMBER")
										.toString());

				logger.info(obj + ":getJsonIacDetails:" + XML.toString(obj));
				array.put(obj);
			}

		} catch (Exception hqEx) {
			logger.error("====exception in DAO getJsonIacDetails:"
					+ hqEx.getMessage());
			throw hqEx;
		}		

		return array;
	}
	
	public List<Map> getPrincipleCord(int partyId) throws Exception {

		logger.info("ExpandedSearchIacDAO - iacId: " + partyId);
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<IacDetails> iacDetails = new ArrayList<IacDetails>();
		Session session = null;
		String stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_PRINCIPLE_CORD_BY_PARTY_ID";
		String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
		logger.info(" before connection.prepareCall :" + tCallableStmtStr);
		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;
                
		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setInt(1, partyId);
                    eStatement.registerOutParameter(2, OracleTypes.CURSOR);
                    eReturnCode = eStatement.execute();
                    sResultSet = (ResultSet) eStatement.getObject(2);
                    esListMap = convertResultSetToPrincipleCord(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
			logger.error("getIacConnection failed" + ex.getMessage());
			throw (ex);
		} finally {
                   if (eStatement != null) { 
					  eStatement.close();
				   }
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return esListMap;
	}

	public JSONArray[] getStaByPartyId(int partyId) throws Exception {

        long startTime = System.currentTimeMillis();

		logger.info("ExpandedSearchIacDAO - getStaByPartyId iacId: " + partyId);
		Connection connection = null;
		ResultSet sResultSet = null;
		JSONArray[] ja;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		String stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_STA_BY_PARTY_ID";
		String tCallableStmtStr = "{call " + stProcName + "(?,?)}";

		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;
                
		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setInt(1, partyId);
                    eStatement.registerOutParameter(2, OracleTypes.CURSOR);
                    eReturnCode = eStatement.execute();
                    sResultSet = (ResultSet) eStatement.getObject(2);
                    ja = convertResultSetToJsonArray(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getIacConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
                    if (eStatement != null) {
					   eStatement.close();
					}
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return ja;
	}
	

	public List<Map> getStaByIacNum(String iacNum) throws Exception {

		logger.info("ExpandedSearchIacDAO/getStaByIacNum - iacId: " + iacNum);
		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<IacDetails> iacDetails = new ArrayList<IacDetails>();
		Session session = null;
		String stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_STA_BY_IAC_NUM";
		String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap = null;
		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, iacNum);
                    eStatement.registerOutParameter(2, OracleTypes.CURSOR);
                    eReturnCode = eStatement.execute();
                    sResultSet = (ResultSet) eStatement.getObject(2);
                    esListMap = convertResultSetToStaMap(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getIacConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
                    if (eStatement != null) {
					  eStatement.close();
					}
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return esListMap;
	}

	public List<Map> getStationByIacNum(String iacId) throws Exception {
		logger.info("ExpandedSearchIacDAO - iacId: " + iacId);

		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<IacDetails> iacDetails = new ArrayList<IacDetails>();
		Session session = null;
		String stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_STATION_BY_IAC_NUM";
		String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
		logger.info(" before connection.prepareCall :"
				+ tCallableStmtStr);
		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;
                
		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, iacId);
                    eStatement.registerOutParameter(2, OracleTypes.CURSOR);
                    eReturnCode = eStatement.execute();
                    sResultSet = (ResultSet) eStatement.getObject(2);
                    esListMap = convertResultSetToListMapForStation(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getIacConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
                    if (eStatement != null) {
					   eStatement.close();
					}
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return esListMap;
	}

	public List<Map> getAgentByIacNum(String iacId) throws Exception {
		logger.info("ExpandedSearchIacDAO - iacId: " + iacId);

		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<IacDetails> iacDetails = new ArrayList<IacDetails>();
		Session session = null;
		String stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_AGENT_BY_IAC_NUM";
		String tCallableStmtStr = "{call " + stProcName + "(?,?)}";
		logger.info(" before connection.prepareCall :"
				+ tCallableStmtStr);
		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;
                
		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, iacId);
                    eStatement.registerOutParameter(2, OracleTypes.CURSOR);
                    eReturnCode = eStatement.execute();
                    sResultSet = (ResultSet) eStatement.getObject(2);
                    esListMap = convertResultSetToListMapForAgent(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getIacConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
                    if (eStatement != null) {
					  eStatement.close();
					}
                }

		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return esListMap;
	}

	private List<Map> convertResultSetToListMap(ResultSet searchResultSet)
			throws Exception {
		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {
			map = new HashMap();
			if (searchResultSet.getString("PARTY_NAME") == null) {
				map.put("iacName", "");
			} else {
				map.put("iacName", searchResultSet.getString("PARTY_NAME"));
			}

			if (searchResultSet.getString("APPROVAL_NBR") == null) {
				map.put("iacId", "");
			} else {
				map.put("iacId", searchResultSet.getString("APPROVAL_NBR"));
			}

			if (searchResultSet.getString("IAC_STATUS") == null) {
				map.put("iacStatus", "");
			} else {
				if (searchResultSet.getString("IAC_STATUS").equalsIgnoreCase(
						"Y")) {
					map.put("iacStatus", "Active");
				} else if (searchResultSet.getString("IAC_STATUS")
						.equalsIgnoreCase("N")) {
					map.put("iacStatus", "Inactive");
				} else {
					map.put("iacStatus",
							searchResultSet.getString("IAC_STATUS"));
				}
			}

			if (searchResultSet.getString("EIN_NBR") == null) {
				map.put("iacEinNumber", "");
			} else {
				map.put("iacEinNumber", searchResultSet.getString("EIN_NBR"));
			}

			if (searchResultSet.getString("ADDRESS1") == null) {
				map.put("iacAddress1", "");
			} else {				
				map.put("iacAddress1", searchResultSet.getString("ADDRESS1"));
			}

			if (searchResultSet.getString("ADDRESS2") == null) {
				map.put("iacAddress2", "");
			} else {
				map.put("iacAddress2", searchResultSet.getString("ADDRESS2"));
			}

			if (searchResultSet.getString("CITY") == null) {
				map.put("iacCity", "");
			} else {
				map.put("iacCity", searchResultSet.getString("CITY"));
			}

			if (searchResultSet.getString("STATE") == null) {
				map.put("iacState", "");
			} else {
				map.put("iacState", searchResultSet.getString("STATE"));
			}

			if (searchResultSet.getString("POSTAL_CODE") == null) {
				map.put("iacZipPostalCode", "");
			} else {
				map.put("iacZipPostalCode",
						searchResultSet.getString("POSTAL_CODE"));
			}

			if (searchResultSet.getString("SIC_CODE") == null) {
				map.put("iacSicCode", "");
			} else {
				map.put("iacSicCode", searchResultSet.getString("SIC_CODE"));
			}

			if (searchResultSet.getString("PHONE_NUMBER") == null) {
				map.put("iacPhone", "");
			} else {
				map.put("iacPhone", searchResultSet.getString("PHONE_NUMBER"));
			}

			if (searchResultSet.getString("KNOWN_AS") == null) {
				map.put("iacKnownAs1", "");
			} else {
			    if (searchResultSet.getString("KNOWN_AS").equalsIgnoreCase(";;;")) {
					map.put("iacKnownAs1", "");	    				
				} else {				
				    map.put("iacKnownAs1", searchResultSet.getString("KNOWN_AS"));
				}
			}

			if (searchResultSet.getString("KNOWN_AS2") == null) {
				map.put("iacKnownAs2", "");
			} else {
				if (searchResultSet.getString("KNOWN_AS2").equalsIgnoreCase(";;;")) {
					map.put("iacKnownAs2", "");	    				
				} else {				
				    map.put("iacKnownAs2", searchResultSet.getString("KNOWN_AS2"));
				}
			}

			if (searchResultSet.getString("KNOWN_AS3") == null) {
				map.put("iacKnownAs3", "");
			} else {
				if (searchResultSet.getString("KNOWN_AS3").equalsIgnoreCase(";;;")) {
					map.put("iacKnownAs3", "");	    				
				} else {				
				    map.put("iacKnownAs3", searchResultSet.getString("KNOWN_AS3"));
				}
			}

			if (searchResultSet.getString("FIRST_NAME") == null) {
				map.put("iacFirstName", "");
			} else {
				map.put("iacFirstName", searchResultSet.getString("FIRST_NAME"));
			}

			if (searchResultSet.getString("LAST_NAME") == null) {
				map.put("iacLastName", "");
			} else {
				map.put("iacLastName", searchResultSet.getString("LAST_NAME"));
			}

			if (searchResultSet.getString("EMAIL_ADDRESS") == null) {
				map.put("iacEmail", "");
			} else {
				map.put("iacEmail", searchResultSet.getString("EMAIL_ADDRESS"));
			}

			if (searchResultSet.getString("DESIGNATION") == null) {
				map.put("iacDesignation", "");
			} else {
				map.put("iacDesignation",
						searchResultSet.getString("DESIGNATION"));
			}

			if (searchResultSet.getString("PARTY_ID") == null) {
				map.put("partyId", 0);
			} else {
				map.put("partyId",
						Integer.parseInt(searchResultSet.getString("PARTY_ID")));
			}

			if (searchResultSet.getString("TITLE") == null) {
				map.put("iacTitle", "");
			} else {
				map.put("iacTitle", searchResultSet.getString("TITLE"));
			}
			
                        if (searchResultSet.getString("COORDINATOR_ID") == null) {
				map.put("iacCredential", (long)0);
			} else if (searchResultSet.getLong("COORDINATOR_ID") == 0) {
				map.put("iacCredential", (long)0);
			} else {
                            map.put("iacCredential",
                                searchResultSet.getLong("COORDINATOR_ID"));
                        }

			if (searchResultSet.getString("APPROVAL_DT") == null) {
				map.put("iacInitialApprovalDate", "");
			} else {
				map.put("iacInitialApprovalDate",
						searchResultSet.getString("APPROVAL_DT"));
			}

			if (searchResultSet.getString("APPROVING_AGT") == null) {
				map.put("iacApprovingAgent", "");
			} else {
				map.put("iacApprovingAgent",
						searchResultSet.getString("APPROVING_AGT"));
			}

			if (searchResultSet.getString("LAST_RENEWAL_DT") == null) {
				map.put("iacLastApprovalDate", "");
			} else {
				map.put("iacLastApprovalDate",
						searchResultSet.getString("LAST_RENEWAL_DT"));
			}

			if (searchResultSet.getString("NEXT_EXPIRATION_DT") == null) {
				map.put("iacExpirationDate", "");
			} else {
				map.put("iacExpirationDate",
						searchResultSet.getString("NEXT_EXPIRATION_DT"));
			}

			if (searchResultSet.getString("COMMENTS") == null) {
				map.put("iacComments", "");
			} else {
				map.put("iacComments", searchResultSet.getString("COMMENTS"));
			}

			listMap.add(map);
		}

		return listMap;
	}

	private List<Map> convertResultSetToListMapForSummaryPage(
			ResultSet searchResultSet) throws Exception {
		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {
			map = new HashMap();

			if (searchResultSet.getString("PARTY_NAME") == null) {
				map.put("iacName", "");
			} else {
				map.put("iacName", org.apache.commons.lang3.StringEscapeUtils.escapeHtml4(searchResultSet.getString("PARTY_NAME")));
			}

			if (searchResultSet.getString("APPROVAL_NBR") == null) {
				map.put("iacId", "");
			} else {
				map.put("iacId", searchResultSet.getString("APPROVAL_NBR"));
			}
                        
            map.put("iacType", "IAC");

			if (searchResultSet.getString("IAC_STATUS") == null) {
				map.put("iacStatus", "");
			} else {
				if (searchResultSet.getString("IAC_STATUS").equalsIgnoreCase(
						"ACTIVE")) {
					map.put("iacStatus", "Active");
				} else if (searchResultSet.getString("IAC_STATUS")
						.equalsIgnoreCase("INACTIVE")) {
					map.put("iacStatus", "Inactive");
				} else if (searchResultSet.getString("IAC_STATUS")
						.equalsIgnoreCase("NEEDSREVIEW")) {
					map.put("iacStatus", "Needs Review");
				} else if (searchResultSet.getString("IAC_STATUS")
						.equalsIgnoreCase("RENEWREQUEST")) {
					map.put("iacStatus", "Renewal Requested");
				} else if (searchResultSet.getString("IAC_STATUS")
						.equalsIgnoreCase("RENEWREQUIRE")) {
					map.put("iacStatus", "Renewal Required");
				} else if (searchResultSet.getString("IAC_STATUS")
						.equalsIgnoreCase("APPREQUEST")) {
					map.put("iacStatus", "Application Requested");
				} else {
					map.put("iacStatus",
							searchResultSet.getString("IAC_STATUS"));
				}
			}

			listMap.add(map);
		}
                logger.info("convertResultSetToListMapForSummaryPage SIZE:" + listMap.size());

		return listMap;
	}
        
        private List<Map> convertResultSetToListMapForCcsfPage(
			ResultSet searchResultSet) throws Exception {
		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {
			map = new HashMap();

			if (searchResultSet.getString("PARTY_NAME") == null) {
				map.put("iacName", "");
			} else {
				map.put("iacName", searchResultSet.getString("PARTY_NAME"));
			}
                        
                        if (searchResultSet.getString("PARTY_ID") == null) {
				map.put("partyId", "");
			} else {
				map.put("partyId", searchResultSet.getString("PARTY_ID"));
			}

			if (searchResultSet.getString("APPROVAL_NBR") == null) {
				map.put("iacId", "");
			} else {
				map.put("iacId", searchResultSet.getString("APPROVAL_NBR"));
			}
                        
                        map.put("iacType", "IAC");

			if (searchResultSet.getString("IAC_STATUS") == null) {
				map.put("iacStatus", "");
			} else {
				if (searchResultSet.getString("IAC_STATUS").equalsIgnoreCase(
						"ACTIVE")) {
					map.put("iacStatus", "Active");
				} else if (searchResultSet.getString("IAC_STATUS")
						.equalsIgnoreCase("INACTIVE")) {
					map.put("iacStatus", "Inactive");
				} else if (searchResultSet.getString("IAC_STATUS")
						.equalsIgnoreCase("NEEDSREVIEW")) {
					map.put("iacStatus", "Needs Review");
				} else if (searchResultSet.getString("IAC_STATUS")
						.equalsIgnoreCase("RENEWREQUEST")) {
					map.put("iacStatus", "Renewal Requested");
				} else if (searchResultSet.getString("IAC_STATUS")
						.equalsIgnoreCase("RENEWREQUIRE")) {
					map.put("iacStatus", "Renewal Required");
				} else if (searchResultSet.getString("IAC_STATUS")
						.equalsIgnoreCase("APPREQUEST")) {
					map.put("iacStatus", "Application Requested");
				} else {
					map.put("iacStatus",
							searchResultSet.getString("IAC_STATUS"));
				}
			}

			listMap.add(map);
		}
                logger.info("convertResultSetToListMapForCcsfPage SIZE:" + listMap.size());

		return listMap;
	}

	private List<Map> convertResultSetToPrincipleCord(ResultSet searchResultSet)
			throws Exception {
		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {
			map = new HashMap();

			if (searchResultSet.getString("CREDENTIAL") == null) {
				map.put("credential", "");
			} else {
				map.put("credential", searchResultSet.getString("CREDENTIAL"));
			}

			if (searchResultSet.getString("PERSON_FIRST_NAME") == null) {
				map.put("firstName", "");
			} else {
				map.put("firstName",
						searchResultSet.getString("PERSON_FIRST_NAME"));
			}

			if (searchResultSet.getString("PERSON_MIDDLE_NAME") == null) {
				map.put("middleName", "");
			} else {
				map.put("middleName",
						searchResultSet.getString("PERSON_MIDDLE_NAME"));
			}

			if (searchResultSet.getString("PERSON_LAST_NAME") == null) {
				map.put("lastName", "");
			} else {
				map.put("lastName",
						searchResultSet.getString("PERSON_LAST_NAME"));
			}

			if (searchResultSet.getString("PERSON_TITLE") == null) {
				map.put("personTitle", "");
			} else {
				map.put("personTitle",
						searchResultSet.getString("PERSON_TITLE"));
			}

			if (searchResultSet.getString("PHONE_NUMBER") == null) {
				map.put("phoneNumber", "");
			} else {
				map.put("phoneNumber",
						searchResultSet.getString("PHONE_NUMBER"));
			}

			if (searchResultSet.getString("EMAIL_ADDRESS") == null) {
				map.put("emailAddress", "");
			} else {
				map.put("emailAddress",
						searchResultSet.getString("EMAIL_ADDRESS"));
			}

			if (searchResultSet.getString("STATE") == null) {
				map.put("state", "");
			} else {
				map.put("state", searchResultSet.getString("STATE"));
			}

			if (searchResultSet.getString("COUNTRY") == null) {
				map.put("country", "");
			} else {
				map.put("country", searchResultSet.getString("COUNTRY"));
			}

			listMap.add(map);
		}

		return listMap;
	}

	private List<Map> convertResultSetToListMapForStation(
			ResultSet searchResultSet) throws Exception {
		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {
			map = new HashMap();

			if (searchResultSet.getString("PARTY_NAME") == null) {
				map.put("partyName", "");
			} else {
				map.put("partyName", searchResultSet.getString("PARTY_NAME"));
			}
			if (searchResultSet.getString("PARTY_ID") == null) {
				map.put("partyId", 0);
			} else {
				map.put("partyId",
						Integer.parseInt(searchResultSet.getString("PARTY_ID")));
			}

			if (searchResultSet.getString("OBJECT_ID") == null) {
				map.put("objectId", 0);
			} else {
				map.put("objectId", Integer.parseInt(searchResultSet
						.getString("OBJECT_ID")));
			}

			if (searchResultSet.getString("CITY") == null) {
				map.put("city", "");
			} else {
				map.put("city", searchResultSet.getString("CITY"));
			}

			if (searchResultSet.getString("STATE") == null) {
				map.put("state", "");
			} else {
				map.put("state", searchResultSet.getString("STATE"));
			}

			if (searchResultSet.getString("ACTIVE_FLAG") == null) {
				map.put("active", "");
			} else {
				map.put("active", searchResultSet.getString("ACTIVE_FLAG"));
			}

			listMap.add(map);
		}

		return listMap;
	}

	private List<Map> convertResultSetToListMapForAgent(
			ResultSet searchResultSet) throws Exception {
		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {
			map = new HashMap();

			if (searchResultSet.getString("PARTY_NAME") == null) {
				map.put("partyName", "");
			} else {
				map.put("partyName", searchResultSet.getString("PARTY_NAME"));
			}

			if (searchResultSet.getString("PARTY_ID") == null) {
				map.put("partyId", "");
			} else {
				map.put("partyId", searchResultSet.getString("PARTY_ID"));
			}

			if (searchResultSet.getString("AGENT_ID") == null) {
				map.put("agentId", "");
			} else {
				map.put("agentId", searchResultSet.getString("AGENT_ID"));
			}

			if (searchResultSet.getString("CITY") == null) {
				map.put("city", "");
			} else {
				map.put("city", searchResultSet.getString("CITY"));
			}

			if (searchResultSet.getString("STATE") == null) {
				map.put("state", "");
			} else {
				map.put("state", searchResultSet.getString("STATE"));
			}

			if (searchResultSet.getString("STATUS_CODE") == null) {
				map.put("status", "");
			} else {
			    if (searchResultSet.getString("STATUS_CODE").equalsIgnoreCase("Y")) {
					map.put("status", "ACTIVE");	
				}		
			
			    else if (searchResultSet.getString("STATUS_CODE").equalsIgnoreCase("N")) {
					map.put("status", "INACTIVE");	
				}				
			}

			listMap.add(map);
		}

		return listMap;
	}	

	private JSONArray[] convertResultSetToJsonArray(ResultSet rs)
			throws Exception {

		JSONArray directEmpJA = new JSONArray();
		JSONArray agentEmpJA = new JSONArray();
		
		JSONArray[] ja = new JSONArray[2];
	    JSONObject jo = null;
	    String tmp = null;

		while (rs.next()) {
		    jo = new JSONObject();

	       	jo.put("staId", rs.getString("STA_ID"));
	       	jo.put("agentName", rs.getString("AGENT_NAME"));
	       	jo.put("expiresOnDate", 
	       			(null == rs.getString("EXPIRES_ON_DATE")) ? "" : (rs.getString("EXPIRES_ON_DATE")).split(" ")[0]);
	       	jo.put("creationDate", (rs.getString("CREATION_DATE")).split(" ")[0]);	       	
			
	       	jo.put("firstName", rs.getString("FIRST_NAME"));
	       	jo.put("lastName", rs.getString("LAST_NAME"));

	       	tmp = rs.getString("STA_STATUS");

                if (tmp.equals("ACTIVE")) {
                        jo.put("staStatus", "Active");
                        jo.put("issuedOnDate", "");
                }
                else if (tmp.equals("INACTIVE")) {
                        jo.put("staStatus", "Inactive");
                } else if (tmp.equals("STAAWAITINGPAYMNT")) {
                        jo.put("staStatus", "Awaiting Payment");
                        jo.put("issuedOnDate", "");
                } else if (tmp.equals("STAERRORTTAC")) {
                        jo.put("staStatus", "STA ErrorTTAC");
                        jo.put("expiresOnDate", "");
                        jo.put("issuedOnDate", "");
                } else if (tmp.equals("STAINCOMPL")) {
                        jo.put("staStatus", "STA Incomplete");
                        jo.put("issuedOnDate", "");
                } else if (tmp.equals("STAEXPIRED")) {
                        jo.put("staStatus", "STA Expired");
                        jo.put("issuedOnDate", "");
                } else if (tmp.equals("STADENIED")) {
                        jo.put("staStatus", "STA Denied");
                        jo.put("issuedOnDate", "");
                } else if (tmp.equals("STAINPROGRESS")) {
                        jo.put("staStatus", "STA In Progress");
                        jo.put("issuedOnDate", "");
                } else if (tmp.equals("STAPASSED")) {
                        jo.put("staStatus", "Passed");
                        jo.put("issuedOnDate", 
                                (null == rs.getString("ISSUED_ON_DATE")) ? "" : (rs.getString("ISSUED_ON_DATE").split(" ")[0]));
                } else {
                        jo.put("staStatus",	tmp);
                        jo.put("issuedOnDate", "");
                }
			
	       	tmp = rs.getString("STATUS");

                if (tmp.equals("A")) {
                        jo.put("status", "Active");
                } else if (tmp.equals("I")) {
                        jo.put("status", "Inactive");
                } else {
                        jo.put("status", tmp);
                }


	       	if (rs.getString("SPONSOR_TYPE").equals("indirect carrier")){
			    if (rs.getString("AGENT_NAME") != null) {
				   agentEmpJA.put(jo);
				} else {
    			  directEmpJA.put(jo);
				}  
            }
	       	else if (rs.getString("SPONSOR_TYPE").equals("indirect carrier agent")){
    			agentEmpJA.put(jo);
            }
		}
		ja[0] = directEmpJA;
		ja[1] = agentEmpJA;
		
		return ja;
	}

	public List<Map> getIacNameByIacNum(String iacId) throws Exception {
		logger.info("ExpandedSearchIacDAO - iacId: " + iacId);

		OracleDataSource ods = null;
		Connection connection = null;
		String queryStr;
		String searchString = null;
		ResultSet sResultSet = null;

		try {
			connection = com.freightdesk.fdcommons.ConnectionUtil
					.getConnectionIacms();
		} catch (Exception ex) {
			logger.error("ods.getConnection() failed");
			throw (ex);
		}

		List<IacDetails> iacDetails = new ArrayList<IacDetails>();
		Session session = null;
		String stProcName = "EGOV_IAC.FAS_IAC_SEARCH.SEL_IAC_NAME_BY_IAC_NUM";
		String tCallableStmtStr = "{call " + stProcName + "(?,?)}";		
		CallableStatement eStatement = null;
                boolean eReturnCode;
                List<Map> esListMap;
                
		try {
                    eStatement = connection.prepareCall(tCallableStmtStr);
                    eStatement.setString(1, iacId);
                    eStatement.registerOutParameter(2, OracleTypes.CURSOR);
                    eReturnCode = eStatement.execute();
                    sResultSet = (ResultSet) eStatement.getObject(2);
                    esListMap = convertResultSetToListMapForCcsfPage(sResultSet);
                    sResultSet.close();
		} catch (Exception ex) {
                    logger.error("getIacConnection failed" + ex.getMessage());
                    throw (ex);
		} finally {
                    if (eStatement != null) {
					   eStatement.close();
					}
                }
                
		com.freightdesk.fdcommons.ConnectionUtil.closeResources(connection,
				eStatement, sResultSet);

		return esListMap;
	}
	
	private List<Map> convertResultSetToStaMap(ResultSet searchResultSet)
			throws Exception {
		List<Map> listMap = new ArrayList();
		Map map = new HashMap();

		while (searchResultSet.next()) {
			map = new HashMap();

			if (searchResultSet.getString("STA_ID") == null) {
				map.put("staId", "");
			} else {
				map.put("staId", searchResultSet.getString("STA_ID"));
			}

			if (searchResultSet.getString("AGENT_NAME") == null) {
				map.put("agentName", "");
			} else {
				map.put("agentName", searchResultSet.getString("AGENT_NAME"));
			}

			if (searchResultSet.getString("STA_STATUS") == null) {
				map.put("staStatus", "");
			} else {
				if (searchResultSet.getString("STA_STATUS").equalsIgnoreCase(
						"ACTIVE")) {
					map.put("staStatus", "Active");
					map.put("issuedOnDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("INACTIVE")) {
					map.put("staStatus", "Inactive");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAAWAITINGPAYMNT")) {
					map.put("staStatus", "Awaiting Payment");
					map.put("issuedOnDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAERRORTTAC")) {
					map.put("staStatus", "STA ErrorTTAC");
					map.put("issuedOnDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAINCOMPL")) {
					map.put("staStatus", "STA Incomplete");
					map.put("issuedOnDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAEXPIRED")) {
					map.put("staStatus", "STA Expired");
					map.put("issuedOnDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STADENIED")) {
					map.put("staStatus", "STA Denied");
					map.put("issuedOnDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAINPROGRESS")) {
					map.put("staStatus", "STA In Progress");
					map.put("issuedOnDate", "");
				} else if (searchResultSet.getString("STA_STATUS")
						.equalsIgnoreCase("STAPASSED")) {
					map.put("staStatus", "Passed");
					if (searchResultSet.getString("ISSUED_ON_DATE") == null) {
						map.put("issuedOnDate", "");
					} else {
						map.put("issuedOnDate",
								searchResultSet.getString("ISSUED_ON_DATE"));
					}
				} else {
					map.put("staStatus",
							searchResultSet.getString("STA_STATUS"));
                                        map.put("issuedOnDate", "");
				}
			}

			if (searchResultSet.getString("STATUS") == null) {
				map.put("status", "");
			} else {
				if (searchResultSet.getString("STATUS").equalsIgnoreCase("A")) {
					map.put("status", "Active");
				} else if (searchResultSet.getString("STATUS")
						.equalsIgnoreCase("I")) {
					map.put("status", "Inactive");
				} else {
					map.put("status", searchResultSet.getString("STATUS"));
				}
			}

			if (searchResultSet.getString("CREATION_DATE") == null) {
				map.put("creationDate", "");
			} else {
				map.put("creationDate",
						searchResultSet.getString("CREATION_DATE"));
			}

			if (searchResultSet.getString("EXPIRES_ON_DATE") == null) {
				map.put("expiresOnDate", "");
			} else {
				if (searchResultSet.getString("STA_STATUS").equalsIgnoreCase(
						"STAERRORTTAC")) {
					map.put("expiresOnDate", "");
				} else {
					map.put("expiresOnDate",
							searchResultSet.getString("EXPIRES_ON_DATE"));
				}
			}

			if (searchResultSet.getString("FIRST_NAME") == null) {
				map.put("firstName", "");
			} else {
				map.put("firstName", searchResultSet.getString("FIRST_NAME"));
			}

			if (searchResultSet.getString("LAST_NAME") == null) {
				map.put("lastName", "");
			} else {
				map.put("lastName", searchResultSet.getString("LAST_NAME"));
			}

			if (searchResultSet.getString("SPONSOR_TYPE") == null) {
				map.put("sponsorType", "");
			} else {
				map.put("sponsorType",
						searchResultSet.getString("SPONSOR_TYPE"));
			}

			listMap.add(map);
		}

		return listMap;
	}

	
}
