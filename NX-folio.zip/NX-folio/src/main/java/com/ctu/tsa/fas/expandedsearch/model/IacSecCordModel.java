/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Kevin.Tsou
 */
public class IacSecCordModel implements Serializable{
    private static final long serialVersionUID = -8767337899673261248L;
    private String iacFirstName;
    private String iacLastName;
    private String iacEmail;
    private String iacDesignation;
    private String iacPhone;

    public IacSecCordModel() {
    }
        
    public IacSecCordModel(String iacFirstName, String iacLastName, String iacEmail, 
		String iacDesignation, String iacPhone) {
		this.iacFirstName = iacFirstName;
        this.iacLastName = iacLastName;
		this.iacEmail = iacEmail;
        this.iacDesignation = iacDesignation;
		this.iacPhone = iacPhone;
    }
    
    public void setIacFirstName (String iacFirstName) {
		this.iacFirstName = iacFirstName; 
    }

    public void setIacLastName (String iacLastName) {
		this.iacLastName = iacLastName; 
    }
	
    public void setIacEmail(String iacEmail) {
		this.iacEmail = iacEmail; 
    }
        
    public void setIacDesignation (String iacDesignation) {
		this.iacDesignation = iacDesignation; 
    }
	
    public void setIacPhone(String iacPhone) {
    	this.iacPhone = iacPhone; 
    }
        
    public String getIacFirstName () {
		return (this.iacFirstName); 
    }

    public String getIacLastName () {
    	return (this.iacLastName); 
    }

    public String getIacEmail () {
        return (this.iacEmail); 
    }
        
    public String getIacDesignation () {
		return (this.iacDesignation); 
    }
	
    public String getIacPhone () {
		return (this.iacPhone); 
    }

    public String toString () {

	String sep = System.getProperty("line.separator");

	StringBuffer buffer = new StringBuffer();
	buffer.append(sep);		
	buffer.append("iacLastName = ");
	buffer.append(iacLastName);
	buffer.append(sep);
	buffer.append("iacFirstName = ");
	buffer.append(iacFirstName);
        buffer.append(sep);
	buffer.append("iacDesignation = ");
	buffer.append(iacDesignation);
	buffer.append(sep);
	buffer.append("iacEmail = ");
	buffer.append(iacEmail);
	buffer.append(sep);
	buffer.append("iacPhone = ");
	buffer.append(iacPhone);
	buffer.append(sep);     		
	
	return buffer.toString();
    }
}
