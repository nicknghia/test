/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 *
 * @author Binh.Nguyen
 */
public class SubjectIndividualRePhyModel implements Serializable{
    private static final long serialVersionUID = -8767337899673261248L;
    private String subjectIndividualResidentialPhysicalAddress;
	private String subjectIndividualResidentialPhysicalCity;
	private String subjectIndividualResidentialPhysicalState;	
	private String subjectIndividualResidentialPhysicalZipPostalCode;
	private String subjectIndividualResidentialPhysicalCountry;
	private String subjectIndividualResidentialPhysicalStartDate;
	private String subjectIndividualResidentialPhysicalEndDate;
		
    public SubjectIndividualRePhyModel() {
    }
        
    public SubjectIndividualRePhyModel(String subjectIndividualResidentialPhysicalAddress, 
	    String subjectIndividualResidentialPhysicalCity, String subjectIndividualResidentialPhysicalState, 
		String subjectIndividualResidentialPhysicalZipPostalCode, String subjectIndividualResidentialPhysicalCountry,
		String subjectIndividualResidentialPhysicalStartDate, String subjectIndividualResidentialPhysicalEndDate) {
		this.subjectIndividualResidentialPhysicalAddress = subjectIndividualResidentialPhysicalAddress;
        this.subjectIndividualResidentialPhysicalCity = subjectIndividualResidentialPhysicalCity;
		this.subjectIndividualResidentialPhysicalState = subjectIndividualResidentialPhysicalState;       
		this.subjectIndividualResidentialPhysicalZipPostalCode = subjectIndividualResidentialPhysicalZipPostalCode;
		this.subjectIndividualResidentialPhysicalCountry = subjectIndividualResidentialPhysicalCountry;
		this.subjectIndividualResidentialPhysicalStartDate = subjectIndividualResidentialPhysicalStartDate;
		this.subjectIndividualResidentialPhysicalEndDate = subjectIndividualResidentialPhysicalEndDate;
    }
    
    public void setSubjectIndividualResidentialPhysicalAddress(String subjectIndividualResidentialPhysicalAddress) {
        this.subjectIndividualResidentialPhysicalAddress = subjectIndividualResidentialPhysicalAddress;
    }
	
	public void setSubjectIndividualResidentialPhysicalCity(String subjectIndividualResidentialPhysicalCity) {
        this.subjectIndividualResidentialPhysicalCity = subjectIndividualResidentialPhysicalCity;
    }			
	
	public void setSubjectIndividualResidentialPhysicalState(String subjectIndividualResidentialPhysicalState) {
        this.subjectIndividualResidentialPhysicalState = subjectIndividualResidentialPhysicalState;
    }
	
	public void setSubjectIndividualResidentialPhysicalZipPostalCode(String subjectIndividualResidentialPhysicalZipPostalCode) {
	this.subjectIndividualResidentialPhysicalZipPostalCode = subjectIndividualResidentialPhysicalZipPostalCode;
    }
	
	public void setSubjectIndividualResidentialPhysicalCountry(String subjectIndividualResidentialPhysicalCountry) {
	this.subjectIndividualResidentialPhysicalCountry = subjectIndividualResidentialPhysicalCountry;
    }
		
	public void setSubjectIndividualResidentialPhysicalStartDate(String subjectIndividualResidentialPhysicalStartDate) {
	this.subjectIndividualResidentialPhysicalStartDate = subjectIndividualResidentialPhysicalStartDate;
    }
	
	public void setSubjectIndividualResidentialPhysicalEndDate(String subjectIndividualResidentialPhysicalEndDate) {
	this.subjectIndividualResidentialPhysicalEndDate = subjectIndividualResidentialPhysicalEndDate;
    }  
	
	public String getSubjectIndividualResidentialPhysicalAddress() {	    
    return subjectIndividualResidentialPhysicalAddress;
    }

	public String getSubjectIndividualResidentialPhysicalCity() {	
    return subjectIndividualResidentialPhysicalCity;
    }

    public String getSubjectIndividualResidentialPhysicalState() {	
    return subjectIndividualResidentialPhysicalState;
    }
	
	public String getSubjectIndividualResidentialPhysicalZipPostalCode() {        
	return subjectIndividualResidentialPhysicalZipPostalCode;
    }
	
	public String getSubjectIndividualResidentialPhysicalCountry() {       
	return subjectIndividualResidentialPhysicalCountry;
    }
	
    public String getSubjectIndividualResidentialPhysicalStartDate() {        	
	return subjectIndividualResidentialPhysicalStartDate;
    }
       
	public String getSubjectIndividualResidentialPhysicalEndDate() {        	
	return subjectIndividualResidentialPhysicalEndDate;
    }    
	
    public String toString () {

	String sep = System.getProperty("line.separator");

	StringBuffer buffer = new StringBuffer();
	buffer.append(sep);			
    buffer.append("subjectIndividualResidentialPhysicalAddress= ");
	buffer.append(subjectIndividualResidentialPhysicalAddress);
	buffer.append(sep);
	buffer.append("subjectIndividualResidentialPhysicalCity= ");
	buffer.append(subjectIndividualResidentialPhysicalCity);
	buffer.append(sep);
	buffer.append("subjectIndividualResidentialPhysicalState= ");
	buffer.append(subjectIndividualResidentialPhysicalState);
	buffer.append(sep);		
	buffer.append("subjectIndividualResidentialPhysicalZipPostalCode= ");
	buffer.append(subjectIndividualResidentialPhysicalZipPostalCode);
	buffer.append(sep);
	buffer.append("subjectIndividualResidentialPhysicalCountry= ");
	buffer.append(subjectIndividualResidentialPhysicalCountry);
	buffer.append(sep);		
	buffer.append("subjectIndividualResidentialPhysicalStartDate= ");
	buffer.append(subjectIndividualResidentialPhysicalStartDate);
	buffer.append(sep);
	buffer.append("subjectIndividualResidentialPhysicalEndDate= ");
	buffer.append(subjectIndividualResidentialPhysicalEndDate);
	buffer.append(sep);	
	
	return buffer.toString();
    }
}
