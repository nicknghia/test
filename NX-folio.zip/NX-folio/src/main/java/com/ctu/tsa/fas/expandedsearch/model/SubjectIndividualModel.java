/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.ctu.tsa.fas.expandedsearch.model;

import java.io.Serializable;

/**
 *
 * @author Binh.Nguyen
 */
public class SubjectIndividualModel implements Serializable{
    private static final long serialVersionUID = -1106837298377580912L;
       
    private String subjectIndividualStaId = "";
	private String subjectIndividualFirstName = "";
	private String subjectIndividualLastName = "";
    private String subjectIndividualCreationDate = "";
    private String subjectIndividualIssuedDate = "";
	private String subjectIndividualExpirationDate = "";
	private String subjectIndividualRecordStatus = "";
	private String subjectIndividualStaStatus = "";
	
	private String subjectIndividualState = "";   
    private String subjectIndividualAddress1 = "";
    private String subjectIndividualAddress2 = "";		
    private String subjectIndividualSicCode = "";
    private String subjectIndividualCity = "";
    private String subjectIndividualZipPostalCode = "";
    private String subjectIndividualCountry = ""; 
	
	
	
    public SubjectIndividualModel() {
    }
    
    public SubjectIndividualModel(String subjectIndividualCreationDate, String subjectIndividualIssuedDate, String subjectIndividualStaId, 
	String subjectIndividualRecordStatus, String subjectIndividualStaStatus, String subjectIndividualExpirationDate, String subjectIndividualAddress1, String subjectIndividualAddress2, String subjectIndividualCity, String subjectIndividualState, String subjectIndividualZipPostalCode, String subjectIndividualCountry, String subjectIndividualSicCode, String subjectIndividualFirstName, String subjectIndividualLastName) {
	    
    this.subjectIndividualStaId = subjectIndividualStaId;
	this.subjectIndividualFirstName = subjectIndividualFirstName;
	this.subjectIndividualLastName = subjectIndividualLastName;
    this.subjectIndividualCreationDate = subjectIndividualCreationDate;
	this.subjectIndividualIssuedDate = subjectIndividualIssuedDate;
	this.subjectIndividualExpirationDate = subjectIndividualExpirationDate;
	this.subjectIndividualRecordStatus = subjectIndividualRecordStatus;
	this.subjectIndividualStaStatus = subjectIndividualStaStatus;  
	
    this.subjectIndividualState = subjectIndividualState;   
    this.subjectIndividualSicCode = subjectIndividualSicCode;
	this.subjectIndividualAddress1 = subjectIndividualAddress1;
    this.subjectIndividualAddress2 = subjectIndividualAddress2;   
    this.subjectIndividualCity = subjectIndividualCity;
    this.subjectIndividualZipPostalCode = subjectIndividualZipPostalCode;
    this.subjectIndividualCountry = subjectIndividualCountry;	
    }
    
    public void setSubjectIndividualFirstName (String subjectIndividualFirstName) {
	this.subjectIndividualFirstName = subjectIndividualFirstName; 
    }
	
	public void setSubjectIndividualLastName (String subjectIndividualLastName) {
	this.subjectIndividualLastName = subjectIndividualLastName; 
    }
	
	public void setSubjectIndividualRecordStatus (String subjectIndividualRecordStatus) {
	this.subjectIndividualRecordStatus = subjectIndividualRecordStatus; 
    }
	
	public void setSubjectIndividualStaStatus (String subjectIndividualStaStatus) {
	this.subjectIndividualStaStatus = subjectIndividualStaStatus; 
    }

    public void setSubjectIndividualStaId (String subjectIndividualStaId) {
	this.subjectIndividualStaId = subjectIndividualStaId; 
    }

    public void setSubjectIndividualCreationDate (String subjectIndividualCreationDate) {
	this.subjectIndividualCreationDate = subjectIndividualCreationDate; 
    }
   
	public void setSubjectIndividualSicCode (String subjectIndividualSicCode) {
	this.subjectIndividualSicCode = subjectIndividualSicCode; 
    }
	   
    public void setSubjectIndividualIssuedDate (String subjectIndividualIssuedDate) {
	this.subjectIndividualIssuedDate = subjectIndividualIssuedDate; 
    }

    public String getSubjectIndividualRecordStatus () {
	return (this.subjectIndividualRecordStatus); 
    }
	
	public String getSubjectIndividualStaStatus () {
	return (this.subjectIndividualStaStatus); 
    }
	
	public String getSubjectIndividualFirstName () {
	return (this.subjectIndividualFirstName); 
    }
	
	public String getSubjectIndividualLastName () {
	return (this.subjectIndividualLastName); 
    }
	
    public String getSubjectIndividualStaId () {
	return (this.subjectIndividualStaId); 
    }

    public String getSubjectIndividualCreationDate () {
	return (this.subjectIndividualCreationDate); 
    }

    public String getSubjectIndividualSicCode () {
	return (this.subjectIndividualSicCode); 
    }
     
    public String getSubjectIndividualIssuedDate () {
	return (this.subjectIndividualIssuedDate); 
    }
    
	
    public String getSubjectIndividualExpirationDate() {
        return subjectIndividualExpirationDate;
    }

    public void setSubjectIndividualExpirationDate(String subjectIndividualExpirationDate) {
        this.subjectIndividualExpirationDate = subjectIndividualExpirationDate;
    }
            
    public String getSubjectIndividualAddress1() {
        return subjectIndividualAddress1;
    }

    public void setSubjectIndividualAddress1(String subjectIndividualAddress1) {
        this.subjectIndividualAddress1 = subjectIndividualAddress1;
    }        
        
    public String getSubjectIndividualAddress2() {
        return subjectIndividualAddress2;
    }

    public void setSubjectIndividualAddress2(String subjectIndividualAddress2) {
        this.subjectIndividualAddress2 = subjectIndividualAddress2;
    }
	
    public String getSubjectIndividualCity() {
        return subjectIndividualCity;
    }

    public void setSubjectIndividualCity(String subjectIndividualCity) {
        this.subjectIndividualCity = subjectIndividualCity;
    }
    
    public String getSubjectIndividualState() {
        return subjectIndividualState;
    }

    public void setSubjectIndividualState(String subjectIndividualState) {
        this.subjectIndividualState = subjectIndividualState;
    }
    
    public String getSubjectIndividualZipPostalCode() {
        return subjectIndividualZipPostalCode;
    }

    public void setSubjectIndividualZipPostalCode(String subjectIndividualZipPostalCode) {
        this.subjectIndividualZipPostalCode = subjectIndividualZipPostalCode;
    }
	
    public String getSubjectIndividualCountry() {
        return subjectIndividualCountry;
    }

    public void setSubjectIndividualCountry(String subjectIndividualCountry) {
        this.subjectIndividualCountry = subjectIndividualCountry;
    }
        	
    @Override
    public String toString() {
        return "SubjectIndividualModel{" + "subjectIndividualCreationDate=" + subjectIndividualCreationDate + ", subjectIndividualIssuedDate=" + subjectIndividualIssuedDate + ", subjectIndividualStaId=" + subjectIndividualStaId + 
        ", subjectIndividualRecordStatus=" + subjectIndividualRecordStatus + ", subjectIndividualFirstName=" + subjectIndividualFirstName + ", subjectIndividualLastName=" + subjectIndividualLastName + ", subjectIndividualExpirationDate=" + subjectIndividualExpirationDate +  ", subjectIndividualStaStatus=" + subjectIndividualStaStatus + ", subjectIndividualAddress1=" + subjectIndividualAddress1 +  ", subjectIndividualAddress2=" + subjectIndividualAddress2  + 
        ", subjectIndividualCity=" + subjectIndividualCity  + ", subjectIndividualState=" + subjectIndividualState  +  ", subjectIndividualZipPostalCode=" + subjectIndividualZipPostalCode  +  ", subjectIndividualCountry=" + subjectIndividualCountry  + '}';
    }
}
   