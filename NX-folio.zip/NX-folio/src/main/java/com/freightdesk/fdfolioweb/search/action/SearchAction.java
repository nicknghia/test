/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/search/action/SearchAction.java,v 1.12.2.3 2010/09/23 19:35:26 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: SearchAction.java,v $
 *  Revision 1.12.2.3  2010/09/23 19:35:26  mechevarria
 *  remove ejb layer for instantiating objects.  direct calls to bean class now made
 *
 *  Revision 1.12.2.2  2010/08/22 23:08:45  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.12.2.1  2009/09/23 18:03:31  mechevarria
 *  import cleanup via eclipse
 *
 *  Revision 1.12  2006/10/17 18:14:52  dbansal
 *  changes for address home lookup in conveyance
 *
 *  Revision 1.11  2006/06/27 10:32:23  ranand
 *  removed redudant code
 *
 *  Revision 1.10  2006/05/11 22:18:55  aarora
 *  Small change as the SessionKey class has been added to com.freightdesk.fdfolio.commons
 *
 *  Revision 1.9  2006/05/11 16:55:28  aarora
 *  Many changes as the SessionKey class has been added to com.freightdesk.fdfolio.commons
 *
 *  Revision 1.8  2006/03/28 21:23:06  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.7  2005/08/29 08:04:35  ranand
 *  added leg stops in Routing template leg
 *
 *  Revision 1.6  2005/08/24 02:59:32  amrinder
 *  Improved comments, formatting and removed methods defined in base class
 *
 *  Revision 1.5  2005/04/16 15:15:24  nsehra
 *  Container Advance search
 *
 *  Revision 1.4  2005/04/14 09:09:09  nsehra
 *  no message
 *
 *  Revision 1.3  2005/04/07 08:02:52  nsehra
 *  Paging enhancement
 *
 *  Revision 1.2  2004/09/21 08:47:42  ranand
 *  package of Manager classes  changed from folioweb to folio
 *
 *  Revision 1.1  2004/09/15 13:36:28  asingh
 *  2.6 Baseline
 */

package com.freightdesk.fdfolioweb.search.action;

import java.util.ArrayList;
import java.util.List;
import java.util.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.ServletActionContext;
import com.opensymphony.xwork2.ActionSupport;

import com.freightdesk.fdfolio.search.SearchManager;

import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.LcpConstants;
import com.freightdesk.fdcommons.LoggedInAction;
import com.freightdesk.fdcommons.OperationInfo;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.StackManager;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdfolio.dao.OrghierarchyDAO;
import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;
import com.freightdesk.fdfolio.search.SearchManager;
import com.freightdesk.fdfolio.search.ejb.SearchBean;
import com.freightdesk.fdfolio.useraccess.model.SystemUserModel;

/**
 * The Struts Action class associated with AddressHome.jsp and the AddressHomeForm.
 */
public class SearchAction extends ActionSupport implements ServletRequestAware
{
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();
    private String hdnProcess;
    private String process;

    private String origin;
    private String link;
    private String lookup;
    private String pickup;
    private String search;
    private long orgId;
    private String type;
    private String invokedFrom;
    private String orgName;
    
    /** Identifies the actions and delegates the respective method. **/
    public String execute()
        throws java.lang.Exception
    {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
        
        String actionForward = null;

        try {
            logger.info("SearchBean started .....");
            

            SearchManager searchManager = new SearchManager();
            String type = request.getParameter("type");
            logger.info("type=" + type);

            String process = getProcess(request);
            SessionStore sessionStore = SessionStore.getInstance(request.getSession());
            StackManager sm = (StackManager) sessionStore.get(SessionKey.STACK);
            logger.info("process is " + process);
            
            
            String originStr = getOrigin();
            logger.info("Interceptor origin is " + originStr);
            setOrigin(originStr);
            String linkStr = getLink();
            logger.info("Interceptor link is " + linkStr);
            setLink(linkStr);
            String lookupStr = getLookup();
            logger.info("Interceptor lookup is " + lookupStr);
            setLookup(lookupStr);
            String searchStr = getSearch();
            logger.info("Interceptor search is " + searchStr);
            setSearch(searchStr);
            
            String typeStr = getType();
            logger.info("Interceptor type is " + typeStr);
            setType(typeStr);
            
            String invokedFromStr = getInvokedFrom();
            logger.info("Interceptor invokedFrom is " + invokedFromStr);
            setInvokedFrom(invokedFromStr);
            
            String orgNameStr = getOrgName();
            logger.info("Interceptor orgName is " + orgNameStr);
            setOrgName(orgNameStr);
            
            long tOrgId = getOrgId();
            logger.info("Interceptor orgId is " + tOrgId);
            setOrgId(tOrgId);

            if ((process.equalsIgnoreCase("Cancel")) || (type != null && type.equalsIgnoreCase("Cancel"))) {
                return respondBtnCancel(sm);
            } else if (process.equalsIgnoreCase("lookup")) {
                logger.debug("respondBtnLookUp ");
                return respondBtnLookUp(sm);
            } else if (process.equalsIgnoreCase("pickup")) {
                return respondBtnPickUp(sm);
            } else if (process.equalsIgnoreCase("addressHome") || process.equalsIgnoreCase("searchAddress")) {
                return "addressHome";                
            }

            logger.debug("actionForward is " + actionForward);

            return actionForward;
        } catch (Exception ex) {

            logger.error("execute : unexpected expection ", ex);
            throw ex;
        }
    }// end of execute method 

    public String respondBtnPickUp(StackManager sm)
        throws Exception
    {
        request = ServletActionContext.getRequest();
                HttpSession session = request.getSession(false);
                SessionStore store = SessionStore.getInstance(session);
                Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        try {
            logger.info("respondBtnPickUp started ");
            SearchManager searchManager = new SearchManager();
            String origin = request.getParameter("origin");
            String lookup = request.getParameter("lookup");
            logger.debug("orgin is " + origin);

            if (lookup.equalsIgnoreCase("conveyInstanceOrgAssoc")) {
                popStack(request);
                pushStack(getHdnProcess(),"ConveyInstanceOrgAssoc","",request);
                SessionStore ss = SessionStore.getInstance(request.getSession());
                ss.put(SessionKey.IS_FORWARDED,"YES");
                return "conveyInstanceOrgAssoc";
            }
            
            if (lookup.equalsIgnoreCase("user")) {
                SearchBean searcher = new SearchBean();
                OrghierarchyDAO orgDAO = new OrghierarchyDAO();
                
                logger.info("orgId = " + orgId);
                OrghierarchyModel orgModel = orgDAO.retrieve(orgId, "CON");
                String parentOrgName = orgDAO.retrieveOrgNameByOrgID(orgModel.getParentOrgId().longValue());
                if (orgModel != null) {
                    store.put(SessionKey.USER_CONTACT_MODEL, orgModel);
                }
                SystemUserModel systemUserModel = (SystemUserModel)store.get(SessionKey.USER_MODEL);
                systemUserModel.setOrgId(orgId);
                setProcess("userAdd");
                return "userDetails";
            }
            else {
                return "userDetails";
            }
            
        } catch (Exception ex) {
            logger.error("respondBtnPickUp : unexpected exception ", ex);
            throw ex;
        }
        
    }

    public String respondBtnLookUp(StackManager sm)
        throws Exception
    {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
        String origin = request.getParameter("origin");
        
        logger.info("origin=" + origin);
        
        String searchStr = request.getParameter("search");
        
        logger.info("search=" + searchStr);
        
        SearchManager searchManager = new SearchManager();

        try {
            logger.info("origin is " + origin);
            logger.info("origin is (try) " + origin);

            if (origin.equalsIgnoreCase("shipEvent")) {
                ArrayList searchDetails = searchManager.eventShipSearch(request, credentials);
                session.setAttribute("eventShipments", searchDetails);
                request.setAttribute("ind", "1");
                sm.closeEvent();
                return "eventHomeResults";
            } else if (origin.equalsIgnoreCase("address") || origin.equalsIgnoreCase("useraddress") || origin.equalsIgnoreCase("containerAdvanceSearch")||
                    origin.equalsIgnoreCase("user")) {
                return "addressHome";
            } 

            throw new RuntimeException("respondBtnLookUp no matching conditions ");

        } catch (Exception ex) {
            logger.error("respondBtnLookUp : unexpected exception ", ex);
            throw ex;
        }

    }

    public String respondBtnCancel(StackManager sm)
    {

        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        String process = getHdnProcess();
        String origin = getOrigin();
        String lookup = getLookup();

        logger.info("respondBtnCancel started ");
        logger.debug("process " + process);
        logger.debug("origin " + origin);
        logger.debug("lookup " + lookup);

        if (process.equalsIgnoreCase("legPickUp")) {

            sm.closeEvent();
            sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
            return "shipmentLeg";
        }


        else if (process.equalsIgnoreCase("pickup")) {
            if (origin.equalsIgnoreCase("location")) {
                sm.closeEvent();
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                return "location";
            }
            if (origin.equalsIgnoreCase("contact")) {
                sm.closeEvent();
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                return "contact";
            }
            if (origin.equalsIgnoreCase("tariff_detail")) {
                sm.closeEvent();
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                return "rateDetails";
            }
            if (lookup.equalsIgnoreCase("involve")) {

                sm.closeEvent();
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                return "involvedParty";
            }

            if (lookup.equalsIgnoreCase("item")) {
                sm.closeEvent();
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                return "packageLineItem";
            }

            if (lookup.equalsIgnoreCase("lineItem")) {
                sm.closeEvent();
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                return "pOLineItem";
            }


            if (lookup.equalsIgnoreCase("origin") || lookup.equalsIgnoreCase("dest")) {

                sm.closeEvent();
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                return "shipmentDetails";
            }

            if (lookup.equalsIgnoreCase("POorigin") || lookup.equalsIgnoreCase("POdest")) {

                sm.closeEvent();
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                return "pODetails";
            }

            if (lookup.equalsIgnoreCase("POReleaseOrigin") || lookup.equalsIgnoreCase("POReleaseDest")) {
                sm.closeEvent();
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                return "pOReleaseDetails";
            }

            if (lookup.equalsIgnoreCase("originleg") || lookup.equalsIgnoreCase("destleg")) {
                sm.closeEvent();
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                return "shipmentLeg";
            }

            if (lookup.equalsIgnoreCase("originlegIS")) {
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                sm.closeEvent();
                return "intermediateStop";
            }
            if (lookup.equalsIgnoreCase("originlegRIS")) {
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                sm.closeEvent();
                return "routingIntermediateStop";
            }

            if (lookup.equalsIgnoreCase("event")) {
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                sm.closeEvent();
                return "eventdetail";
            }

            if (lookup.equalsIgnoreCase("originRoutingLookup")) {
                return "routingTemplateOrigin";
            }

            if (lookup.equalsIgnoreCase("destRoutingLookup")) {
                return "routingTemplateLeg";
            }

            if (origin.equalsIgnoreCase("originloclookup") || origin.equalsIgnoreCase("destloclookup")) {
                return "ratequote";
            }

            if (lookup.equalsIgnoreCase("placeChooserLookup")) {
                return "placeChooser";
            }
            if (lookup.equalsIgnoreCase("containerAdvanceSearch")) {
                return "containerAdvanceSearch";

            }
            if (lookup.equalsIgnoreCase("user")) {
                sm.closeEvent();
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                return "userDetails";
            }
            
            if (lookup.equalsIgnoreCase("conveyInstanceOrgAssoc")) {
                sm.closeEvent();
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                return "conveyInstanceOrgAssoc";
            }

            if (lookup.equalsIgnoreCase("inspection")) {
                sm.closeEvent();
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                return "inspectionRequest";
            } else if (lookup.equalsIgnoreCase("invoiceOrigin") || "invoiceDest".equalsIgnoreCase(lookup)) {
                sm.closeEvent();
                sessionStore.put(SessionKey.IS_FORWARDED, "Yes");
                return "invoiceDetails";
            }

        }
        throw new RuntimeException("no matching conditions ");
    }

    private String getProcess(HttpServletRequest request)
    {
        logger.info("getProcess(): begin");

        String isForwarded = (String) getFromSessionStore(request, SessionKey.IS_FORWARDED);
        logger.debug("execute : Forward Flag from Session " + isForwarded);
        if (isForwarded != null && isForwarded.equalsIgnoreCase("Yes")) {
            /*getting the current operation info from the stack to identify the process(if the request is
             forwarded from some other part of the appication)*/
            StackManager sm = (StackManager) getFromSessionStore(request, SessionKey.STACK);
            OperationInfo operationInfo = (OperationInfo) sm.currentEvent();
            logger.debug("stack is " + sm);
            return operationInfo.getAction();
        }
        return getHdnProcess();
    }
    
        public void	setProcess(String process)  {

		this.process = process;
	}
        //getter and setter methods
	public void	setHdnProcess(String hdnProcess)  {

		this.hdnProcess = hdnProcess;
	}
	public String getHdnProcess()  {

		return hdnProcess;
	}

	public void	setOrigin(String origin)  {

		this.origin = origin;
	}
	public String getOrigin()  {

		return origin;
	}

	public void	setLink(String link)  {

		this.link = link;
	}
	public String getLink()  {

		return link;
	}

	public void	setLookup(String lookup)  {

		this.lookup = lookup;
	}
	public String getLookup()  {

		return lookup;
	}
        
        public void	setSearch(String search)  {

		this.search = search;
	}
	public String getSearch()  {

		return search;
	}

	public void	setPickup(String pickup)  {

		this.pickup = pickup;
	}
	public String getPickup()  {

		return pickup;
	}
        
    public long getOrgId() {
        return orgId;
    }

    public void setOrgId(long orgId) {
        this.orgId = orgId;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }
    
    public String getInvokedFrom() {
        return invokedFrom;
    }

    public void setInvokedFrom(String invokedFrom) {
        this.invokedFrom = invokedFrom;
    }

    public String getOrgName() {
        if (orgName == null) {
            return "";
        } else {
            return orgName.toUpperCase();
        }
    }

    public void setOrgName(String orgName) {
        this.orgName = orgName;
    }

    
    
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return request;
    }
    
    /**
     * A convenience method to popcom.freightdesk.fdfolio.utiluses
     * {@link com.ntelx.nxcommons.StackManager#closeEvent()}for the
     * StackManager object stored in the session.
     */
    public void popStack(HttpServletRequest request)
    {
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        StackManager stackManager = (StackManager) sessionStore.get(SessionKey.STACK);
        if (stackManager != null) {
            stackManager.closeEvent();
        }
    }
    
    /**
     * A convenience method to create a new event on the stack
     */
    public void pushStack(String newAction, String newMgr, String newOprType, HttpServletRequest request) {
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        StackManager stackManager = (StackManager) (sessionStore.get(SessionKey.STACK));
        if (stackManager == null) {
            stackManager = new StackManager();
            sessionStore.put(SessionKey.STACK, stackManager);
        }

        if (newAction != null && !newAction.trim().equals("")) {
            stackManager.createEvent(new OperationInfo(newMgr, newOprType, newAction, "", "", ""));
        }
    }
    
    /** Gets an object from session store. */
    public Object getFromSessionStore(HttpServletRequest request, SessionKey sessionKey)
    {
        SessionStore sessionStore = SessionStore.getInstance(request.getSession());
        return sessionStore.get(sessionKey);
    }
    
} //end of SearchAction class

