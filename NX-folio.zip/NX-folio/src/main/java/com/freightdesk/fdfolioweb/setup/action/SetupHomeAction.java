/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/setup/action/SetupHomeAction.java,v 1.11.4.8 2010/12/01 19:01:27 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: SetupHomeAction.java,v $
 *  Revision 1.11.4.8  2010/12/01 19:01:27  mechevarria
 *  use new simplified properties
 *
 *  Revision 1.11.4.7  2010/08/22 23:08:38  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.11.4.6  2010/07/21 18:54:02  mechevarria
 *  reset email settings
 *
 *  Revision 1.11.4.5  2010/06/10 16:38:34  mechevarria
 *  reset the FDSuiteProperties as well
 *
 *  Revision 1.11.4.4  2010/04/23 18:47:27  mechevarria
 *  reload userreferencedata as well
 *
 *  Revision 1.11.4.3  2010/04/22 22:59:51  mechevarria
 *  reload systemessage with runtime data
 *
 *  Revision 1.11.4.2  2009/11/02 21:14:55  mechevarria
 *  reset the optionbeans
 *
 *  Revision 1.11.4.1  2009/09/23 18:02:17  mechevarria
 *  import clean via eclipse
 *
 *  Revision 1.11  2006/07/06 13:18:07  dkumar
 *  changed signature of AppicationProperties.getShipmentHomeReferencesList
 *
 *  Revision 1.10  2006/07/06 11:13:37  dkumar
 *  seperate refrence property for shipment home and details
 *
 *  Revision 1.9  2006/06/12 11:11:41  dkumar
 *  added usre feedback message for loading Application Properties and reference data
 *
 *  Revision 1.8  2006/06/09 09:50:19  dkumar
 *  setted dshBoardTileMap to null in servletContext after loading Application
 *  Properties to reflect the changes
 *
 *  Revision 1.7  2006/05/11 22:18:55  aarora
 *  Small change as the SessionKey class has been added to com.freightdesk.fdfolio.commons
 *
 *  Revision 1.6  2006/04/19 11:01:02  dkumar
 *  added logging statements
 *
 *  Revision 1.5  2006/04/19 10:37:07  dkumar
 *  added reloadApplicationProperties() method and called the same when clicking apply application properties
 *
 *  Revision 1.4  2006/03/28 21:22:59  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.3  2005/10/01 15:52:07  amrinder
 *  Added access control logic for reference data reload
 *
 *  Revision 1.2  2005/08/20 12:35:36  pjain
 *  DAO movement impact
 *
 *  Revision 1.1  2004/09/15 13:36:28  asingh
 *  2.6 Baseline
 */


package com.freightdesk.fdfolioweb.setup.action;

import javax.servlet.http.HttpServletRequest;

//import org.apache.struts.action.ActionForm;
//import org.apache.struts.action.ActionForward;
//import org.apache.struts.action.ActionMapping;

import javax.servlet.http.HttpServletResponse;

import com.freightdesk.fdfolio.common.LcpReferenceData;

import crt.com.freightdesk.fdfolio.common.UserSetupReferenceData;
import crt.com.freightdesk.fdfolio.setup.AppPropertiesManager;

import com.freightdesk.fdcommons.ApplicationTabs;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.FDSuiteProperties;
import com.freightdesk.fdcommons.OperationInfo;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.StackManager;

import crt.com.ntelx.nxcommons.email.EmailBodyFactory;

import com.freightdesk.fdcommons.EmailSender;
import com.freightdesk.fdcommons.ObjectLock;
import com.freightdesk.fdcommons.SystemUnavailableException;

import crt.com.ntelx.nxcommons.reporting.OptionCollectionManager;
import crt.com.ntelx.nxcommons.reporting.ReportProperties;


//import org.apache.struts.action.ActionMessage;
//import org.apache.struts.action.ActionMessages;
import com.freightdesk.fdcommons.ActionMessage;
import com.freightdesk.fdcommons.ActionMessages;

import javax.servlet.http.HttpSession;

import com.opensymphony.xwork2.ActionSupport;

import org.apache.log4j.Logger;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.ServletActionContext;

import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import crt.com.freightdesk.fdfolio.setup.SystemMessageManager;
import crt.com.freightdesk.fdfolio.setup.model.SystemMessageModel;

/**
 * The Struts Action class associated with SetupHome.jsp and the SetupHomeForm.
 * The execute method is the only method that needs to be declared public.
 *
 * @author Amrinder Arora
 */
public class SetupHomeAction extends ActionSupport implements ServletRequestAware
{
    /**
     * Executes the request.
     *
     * It also allows you to:
     * <UL>
     *   <LI>Reload the LCP properties
     *   <LI>Reload the log4j properties
     *   <LI>Reload the reference data for a particular domain
     *   <LI>Reload the reference data for all domains
     *   <LI>Stop and restart the notification managers
     * </UL>
     *
     * @return The ActionForward that the Struts Action servlet should use to serve the response
     */
    
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();
    private String messageText;
    private String faqTxt;
    private String loginTimeRoleMsg;
    
    public String execute()throws Exception {
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
        logger.info("execute(): begin");
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);
        
        // POAM HttpOnly Secure
        HttpServletResponse response = (HttpServletResponse)ServletActionContext.getResponse();
        String secure = "";
        if (request.isSecure())
        {
          secure = "; Secure";
        }
        response.setHeader("SET-COOKIE", "JSESSIONID=" + request.getSession().getId()
                         + "; Path=" + request.getContextPath() + "; HttpOnly" + secure);        
        
        SystemMessageManager messageManager = SystemMessageManager.getInstance();
        SystemMessageModel model = new SystemMessageModel();
        faqTxt = messageManager.getMessageModel().getFaqTxt();
        messageText = messageManager.getMessageModel().getMessageText();

        // clears the state
        clearState(request);

        // sets the home tab
        SessionStore sessionStore = SessionStore.getInstance (request.getSession());
        sessionStore.put (SessionKey.CURRENT_TAB, ApplicationTabs.SETUP);

        // creates a stack manager, and puts that in the session store
        if (sessionStore.get(SessionKey.STACK) == null){
            StackManager stackManager = new StackManager();
            stackManager.createEvent(new OperationInfo("SetUpManager", "SetUp_home", "SetUp_display", "", "", ""));
            sessionStore.put(SessionKey.STACK, stackManager);
        }

        String action = request.getParameter ("action");
        if ("reload".equalsIgnoreCase (action)) {
            logger.debug("request to reload data");
            
            // clear the singleton data
            OptionCollectionManager.getInstance().reset();
            SystemMessageManager.getInstance().reset();
            FDSuiteProperties.reset();
            reloadApplicationProperties(request);
            EmailSender.reset();
            EmailBodyFactory.reset();
            LcpReferenceData.clearReferenceData();
            UserSetupReferenceData userRefData = UserSetupReferenceData.getInstance(credentials.getDomainName());
            userRefData.load(credentials.getDomainName());
            setActionMessage(request,new String[]{"message.resetData"});
        }

        return "display";
    }
    
    /**
     * Initializes Application properties.
     */
    private void reloadApplicationProperties(HttpServletRequest request)
    {
    	logger.debug("attempting to reload system property files");
        
        String messageKey=null;

        try {

            try {
                
            	AppPropertiesManager propsManager = new AppPropertiesManager();
            	
            	logger.debug("Resetting application properties");
            	propsManager.resetAppProperties();
            	
            	logger.debug("Resetting FDSuite properties");
            	FDSuiteProperties.reset();
            	
            	logger.debug("Reloading reports");
            	ReportProperties.reset();
            	
                messageKey="message.loadedApplicationProperties";
                setActionMessage(request,new String[]{messageKey});
                
                // After loading Application Properties set all references to null that chache or store Application
                // Properties.
                /*
                ServletContext sc = this.servlet.getServletContext();
                if(sc.getAttribute("dashBoardTileMap" )!= null) {
                    sc.setAttribute("dashBoardTileMap", null);  
                }
                */
            } catch (Exception e) {
            	logger.debug("SetupHomeAction: An unexpected error has occured.");
                //e.printStackTrace(System.err);
				logger.error("Exception : " + e.getMessage());
                messageKey="error.loadedApplicationProperties";
                setActionMessage(request,new String[]{messageKey});
            }

        } catch (Exception e) {
            messageKey="error.loadedApplicationProperties";
            setActionMessage(request,new String[]{messageKey});
            logger.debug ("[Ignoring]:: Exception closing file stream: " + e);
        }
        logger.debug("reloadApplicationProperties : end");
    }
    
    public String getFaqTxt() {
        if (faqTxt == null){
            this.faqTxt = "";
	}
		
	return faqTxt;
    }
    
    public void setFaqTxt(String faqTxt) {
	this.faqTxt = faqTxt;
    }
        
    public String getMessageText() {
	return messageText;
    }
        
    public void setMessageText(String messageText) {
	this.messageText = messageText; 
    }
    
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
    
    public void setActionMessage(HttpServletRequest request, String[] messageKeyObject) {
        int length = messageKeyObject.length;
        logger.debug("messageKeyObject.length = " + length);
        ActionMessage actionMessage = null;
        switch (length) {
            case 2:
                logger.debug("messagekeyvalues" + messageKeyObject[0]);
                actionMessage = new ActionMessage(messageKeyObject[0], (Object) messageKeyObject[1]);
                break;
            case 3:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2]);
                break;
            case 4:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3]);
                break;
            case 5:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3], messageKeyObject[4]);
                break;
            default:
                actionMessage = new ActionMessage(messageKeyObject[0]);
        }

        ActionMessages messages = new ActionMessages();
        messages.add(ActionMessages.GLOBAL_MESSAGE, actionMessage);

        logger.debug("message has been set on request");
    }
    
    /** The clearState method.  Declared final. */
    protected final void clearState(HttpServletRequest request)
    {
        // clear any state info from request and session
        logger.info ("clearState(): begin");
        HttpSession session = request.getSession();
        SessionStore sessionStore = SessionStore.getInstance (session);
        Credentials credentials = (Credentials)sessionStore.get(SessionKey.CREDENTIALS);
        if (credentials != null)
        {
           ObjectLock objectLock = (ObjectLock)sessionStore.get(SessionKey.OBJECT_LOCK);
            if (objectLock != null)
            {   logger.info("Object lock is not null");
                objectLock.releaseAllLocksForUser(credentials.getSystemUserId());
            }
        }
        sessionStore.retainOnlyGeneralKeys();
        if ("SE".equals(FDSuiteProperties.getProperty("system.availability.status"))) {
            throw new SystemUnavailableException("SE");
        }
    }
}

