/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/applet/LocationApplet.java,v 1.9.6.1 2010/08/22 23:08:28 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: 
 */
package com.freightdesk.fdfolioweb.applet;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.net.URL;
import java.util.Collection;
import java.util.Iterator;

import javax.swing.ImageIcon;
import javax.swing.JApplet;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;

import com.freightdesk.fdfolio.common.Locatable;

/**
 * Shows an interactive view of a locatable object.
 *  
 * <B>Usage:</B> The applet should be embedded inside the HTML as follows: <BR>
 *  &lt;applet code="ContainerLocationApplet.class" width="600" Height="400" &gt;
 *  &lt;/applet&gt;
 *
 * <P>The logging inside the applet is done using System.out, not using log4j,
 * because applet is executed in a client JVM (through the browser plugin).
 *
 * @author Rajender Anand
 * @author Devendra Khoker
 * @author Amrinder Arora
 */
public abstract class LocationApplet extends JApplet
    implements ActionListener
{
    /** Main panel of the applet */
    protected JPanel mainPanel = null;

    /** List of map options */
    protected static JComboBox mapOptions = new JComboBox (GeoMap.mapOptions);

    /** Map image for the background */
    protected static GeoMap geoMap = null;

    /** Image of a container */
    protected ImageIcon objectIcon = null;
    
    /** Integer ONE for the second layer of the layered pane */
    public Integer ONE = new Integer (1);
    /**
    /** Integer TWO for the second layer of the layered pane */
    public Integer TWO = new Integer (2);
    
    /** Layered Pane of JApplet */
    protected JLayeredPane lp = null;

    /** Map as a Jlabel*/
    protected JLabel mapAsLabel = null;


    /**
     * This method is called when Applet is loaded in the browser.
     * Retrieves the active containers from the servlet 
     * and renders it on the mapImage. 
     */
    public void init ()
    {
        // Methods provided by concrete instance
        objectIcon = getObjectIcon();

        createMainPanel();

        System.out.println ("CodeBase: " + getCodeBase());

        drawObjects (getDataObjects());
    }

    public void createMainPanel()
    {
        lp = getLayeredPane();
        lp.removeAll();
        mainPanel = new JPanel();
        mainPanel.add (getControlPanel());
        // Following null check is placed, because this method is called from click action also
        if (geoMap == null)
            geoMap = GeoMap.WORLD;
        mapAsLabel = new JLabel (geoMap.getImageIcon ());
        mapAsLabel.setPreferredSize (new Dimension (720, 360));
        mainPanel.add(mapAsLabel);
        mainPanel.setBounds(0,0,728,364);
        lp.add(mainPanel,ONE);
    }
    
    /**
     * Draws the Objects on the Map.
     */
    protected void drawObjects (Collection dataObjects)
    {
        Iterator iterator = dataObjects.iterator();
        System.out.println("dataObjects size= " + dataObjects.size());
        while (iterator.hasNext()) {
            Locatable locatableObject = (Locatable)iterator.next();
            double latitude = locatableObject.getLatitude();                    
            double longitude = locatableObject.getLongitude();              
            int x = geoMap.getXCoordinate(longitude) + (int)mapAsLabel.getBounds().getX();
            int y = geoMap.getYCoordinate(latitude)+ (int)mapAsLabel.getBounds().getY();
            JLabel objectAsLabel = new JLabel(objectIcon);
            objectAsLabel.setToolTipText("<html><body>" + locatableObject.getDescription() + "</body></html>");
            objectAsLabel.setBounds(x,y,10,10);
            lp.add(objectAsLabel, TWO);
        }
    }

    /**
     * Gets the object icon. 
     *
     * Concrete subclasses may:
     * <OL>
     *  <LI>Customize this method, 
     *  <LI>Customize the getImagePath method, or 
     *  <LI>Not overwrite anything at all.
     * </OL> 
     *
     * @see com.freightdesk.fdfolioweb.applet.LocationApplet#getImagePath()
     */
    public ImageIcon getObjectIcon ()
    {
        URL organizationUrl = getClass().getResource(getImagePath());
        return new ImageIcon(organizationUrl);
    }

    /**
     * Gets the image path.  Concrete subclasses can customize by providing the path of icon.
     * Default image is a red square. 
     */
    public String getImagePath ()
    {
        return "/maps/container.jpg";
    }
    
    /**
     * Gets the control panel.
     */
    public JPanel getControlPanel ()
    {
        JButton button = new JButton("  OK  ");
        button.addActionListener (this);
        JPanel controlPanel = new JPanel();
        controlPanel.add(mapOptions);
        controlPanel.add(button);
        return controlPanel;
    }

    /**
     * Gets the relevant data objects. 
     */
    public abstract Collection getDataObjects();

    public void actionPerformed (ActionEvent ae)
    {
        String selectedMap = mapOptions.getSelectedItem().toString();
        geoMap = GeoMap.getInstance (selectedMap);
        createMainPanel();
        drawObjects (getDataObjects());
    }
}

