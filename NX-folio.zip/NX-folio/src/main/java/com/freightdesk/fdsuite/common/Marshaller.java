/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDSuite/src/com/freightdesk/fdsuite/common/Marshaller.java,v 1.1 2006/08/11 20:51:41 dkumar Exp $
 * 
 *  Modification History:
 *  $Log: Marshaller.java,v $
 *  Revision 1.1  2006/08/11 20:51:41  dkumar
 *  chages for making fdsuite struts based application
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdsuite.common;

import java.util.StringTokenizer;

/**
 * Marshaller marshals and unmarshals data to/from byte arrays.
 *
 * @author Amrinder Arora
 */
public class Marshaller {

    private static final String filler1 = "9|8%__j^Fs(32*";
    private static final String filler2 = "12345678901234567890";
    private static final String filler4 = "j_+skl=89";

    protected String byteDelimiter = ".";

    public Marshaller ()
    {
    }

    public Marshaller (String byteDelimiter)
    {
        this.byteDelimiter = byteDelimiter;
    }

    /**
     * Marshalls the given text into a dot (.) separated String
     */
    public String marshall (byte[] byteArray) {
        StringBuffer sb = new StringBuffer();
        for (int i = 0; i < byteArray.length; i++) {
            sb.append ((int)(byteArray[i]) + byteDelimiter);
        }
        sb.deleteCharAt (sb.length() - 1);
        // logger.debug ("marshalled (" + new String (byteArray) + "): " + sb);
        return sb.toString();
    }

    /**
     * Unmarshalls the given String text, and returns the byte array
     * ignoring the byte delimiters.
     *
     * All the delimiters occuring in the input text are ignored.
     */
    public byte[] unmarshall (String text) {
        StringTokenizer st = new StringTokenizer (text, byteDelimiter);
        int numTokens = st.countTokens();
        byte[] unmarshalled = new byte[numTokens];
        for (int i=0; i<numTokens; i++) {
            byte b = Byte.parseByte (st.nextToken());
            unmarshalled[i] = b;
        }
        // logger.debug ("unmarshall(" + text + "): " + new String (unmarshalled));

        // next takes the xor and returns the result
        return unmarshalled;
    }

    public String marshall (String userId, String password, String iNetAddress)
    {
        StringBuffer sb = new StringBuffer ();
        sb.append (filler1);
        sb.append (userId);
        sb.append (filler2);
        sb.append (password);
        sb.append (filler2);
        sb.append (iNetAddress);
        sb.append (filler4);
        // logger.debug ("marshall (" + userId + ", " + password + 
                // ", " + iNetAddress + "): " + sb);
        return sb.toString();
    }

    public void unmarshall (String text, StringBuffer userId, StringBuffer password, StringBuffer iNetAddress)
    {
        // logger.debug ("text to unmarshall is: " + text);
        // removes the first filler
        text =  text.substring (filler1.length());
        // removes the last filler
        text =  text.substring (0, text.length() - filler4.length());
        // logger.debug ("text after removing first and last fillers: " + text);
        String[] splits = text.split (filler2);
        if (splits.length < 3) {
            // logger.error ("After splitting, num Strings: " + splits.length);
            throw new IllegalArgumentException ("After splitting, num Strings: " + splits.length + ", should have been 3");
        }
        userId.append (splits[0]);
        password.append (splits[1]);
        iNetAddress.append (splits[2]);
        // logger.debug ("Results of unmarshalling:: userId: " + userId +
                // ", password: " + password + ", iNetAddress:" + iNetAddress);
    }
}

