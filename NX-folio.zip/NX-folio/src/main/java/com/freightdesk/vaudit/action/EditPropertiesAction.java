/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/setup/action/Attic/EditPropertiesAction.java,v 1.6.4.4 2010/12/01 21:57:01 mechevarria Exp $ 
 * 
 *  Modification History:
 *  $Log: EditPropertiesAction.java,v $
 *  Revision 1.6.4.4  2010/12/01 21:57:01  mechevarria
 *  use just runtime home
 *
 *  Revision 1.6.4.3  2010/12/01 19:01:27  mechevarria
 *  use new simplified properties
 *
 *  Revision 1.6.4.2  2010/08/22 23:08:38  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.6.4.1  2007/03/28 20:25:13  mechevarria
 *  merged changes from head branch to fix domain admin rights issue
 *
 *  Revision 1.6  2006/04/19 09:16:35  dkumar
 *  replaced References to LCP_RUNTIME_HOME with FD-RUNTIME_HOME
 *
 *  Revision 1.5  2006/03/28 21:22:59  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.4  2005/10/01 15:51:37  amrinder
 *  Added comments
 *
 *  Revision 1.3  2005/07/28 08:13:06  pjain
 *  added constant APPLICATION_PROPERTY_FILE
 *
 *  Revision 1.2  2005/07/27 08:25:37  pjain
 *  changed LcpProperties.getInstance()
 *
 *  Revision 1.1  2005/07/27 08:08:20  pjain
 *  Baseline
 */
package com.freightdesk.vaudit.action;

import java.io.File;
import java.sql.SQLException;
import java.util.Properties;
import java.util.TreeMap;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;

import org.apache.struts2.ServletActionContext;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.Credentials;

import crt.com.freightdesk.fdfolio.setup.AppPropertiesManager;
import crt.com.freightdesk.fdfolio.setup.model.FasAppProperties;
import crt.com.freightdesk.fdfolio.common.IncludesUtil;

import com.opensymphony.xwork2.ActionSupport;

import com.freightdesk.fdcommons.ActionMessage;
import com.freightdesk.fdcommons.ActionMessages;

import org.apache.commons.lang.StringEscapeUtils;

/**
 * Handles the requests to and from the edit data JSP, which is
 * used to edit the application properties.
 *
 * @author Pankaj Jain
 * @author Amrinder Arora 
 */
public class EditPropertiesAction extends ActionSupport implements ServletRequestAware {
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();
    private String loginTimeRoleMsg;
    
    private static final long serialVersionUID = 1L;

    private String process;
    private String [] referenceKey;
    private String [] referenceValue;
    private Properties referenceProperties;
    TreeMap propertiesTreeMap;
    
    private String lastUpdateUserId     = null;
    private String lastUpdateTimestamp   = null; 
    private String lastUpdateDomainname = null;
    private String createUserId         = null;
    private String createTimestamp      = null;

    String FDFOLIO_RUNTIME_HOME = System.getProperty ("RUNTIME_HOME") +  File.separator + "FDfolio-runtime" + File.separator;
	   
    /** Executes the request. */
    public String execute() throws Exception 
    {
        logger.debug("Execute(): begin");
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
        // POAM HttpOnly Secure
        HttpServletResponse response = (HttpServletResponse)ServletActionContext.getResponse();
        String secure = "";
        if (request.isSecure()) {
          secure = "; Secure";
        }
        response.setHeader("SET-COOKIE", "JSESSIONID=" + request.getSession().getId()
                         + "; Path=" + request.getContextPath() + "; HttpOnly" + secure);      
        
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);

        return displayPage();
    }

    public String displayPage() 
        throws Exception 
    {
        String process = getProcess();
        
        if ("SAVE".equalsIgnoreCase(process))
        {
            logger.debug("Saving");
            try {
                    if (saveProperties() == "TRUE"){
                        addActionMessage(getText("editproperties.save"));
                    }

            } catch (Exception e) {
                    setActionMessage(request, new String[] { "editproperties.error" });
                    logger.error("editproperties.error" + e);
            }
        }
        else if ("CANCEL".equalsIgnoreCase(process))
        {	    
            logger.debug("Canceling");
            setReferenceProperties(ApplicationProperties.getProps());
            
            addActionMessage(getText("setup.operation.cancel"));
            return "cancel"; 
        }
        
        AppPropertiesManager appManager = new AppPropertiesManager();        
        FasAppProperties prop =  appManager.getLastUpdateInfo();
        
        setLastUpdateUserId    ( prop.getLastUpdateUserId() );
        setLastUpdateDomainname( prop.getDomainName()       );
        setCreateUserId        ( prop.getCreateUserId()     );    
        try
        {
            setLastUpdateTimestamp  ( prop.getLastUpdateTimestamp().toString() );
            setCreateTimestamp     ( prop.getCreateTimestamp().toString()     );
        }
        catch ( NullPointerException nExp )
        {
            logger.error( "One of the create timestamps is null " +  nExp); 
        }
        
        setReferenceProperties(ApplicationProperties.getProps());
        propertiesTreeMap = new TreeMap (referenceProperties);
        
        return "display";
    }
   
   
    private String saveProperties() throws SQLException
    {
        logger.debug("saveProperties(): begin");
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
        AppPropertiesManager appManager = new AppPropertiesManager();

        String referenceKey   [] = getReferenceKey();
        String referenceValue [] = getReferenceValue();
        
        int totalKeys = referenceKey.length;
        int tempInt=0;
        for (int i=0; i<totalKeys; i++)
        {            
            
            if (referenceKey[i].contains("password.allowedFailedLogins") ||
                    referenceKey[i].contains("ADDRESSBOOK_MAXIMUM_RESULTS") ||
                    referenceKey[i].contains("ADDRESS_HOME_PAGING") ||
                    referenceKey[i].contains("RequestTracker.paging") ||
                    referenceKey[i].contains("password.autoExpire") ||
                    referenceKey[i].contains("password.emailWarningDays") ||
                    referenceKey[i].contains("password.historyLength") ||
                    referenceKey[i].contains("password.warnExpire") ||
                    referenceKey[i].contains("ExpandedSearch.paging")){
                try {
                    tempInt = Integer.parseInt(referenceValue[i]);
                    if (tempInt < 1){
                        addActionError("Invalid input for " + referenceKey[i] + " field");
                        return "FALSE";
                    }
                } catch (NumberFormatException e) {
                    addActionError("Invalid input for " + referenceKey[i] + " field");
					logger.error("Invalid input for" + e);
                    return "FALSE";
                }
            }			
            else if (referenceKey[11].contains("password.remoteAuthorization") ||
                referenceKey[13].contains("version")) {														
                    referenceValue[11] = StringEscapeUtils.escapeHtml(referenceValue[11].replaceAll("&lt;", "").replaceAll("&quot;", "").replaceAll("&gt;", ""));
                    if ((referenceValue[13] == null) || (referenceValue[13]).equals("")){
                        addActionError("Invalid input for " + referenceKey[13] + " field");
                        referenceValue[13] = "";
                        return "FALSE";
                    } else {
                        referenceValue[13] = StringEscapeUtils.escapeHtml(referenceValue[13].replaceAll("&lt;", "").replaceAll("&quot;", "").replaceAll("&gt;", ""));
                    }
            }
        }
        
        for (int i=0; i<totalKeys; i++)
        {
            appManager.setAppProperty( referenceKey[i], referenceValue[i], credentials.getUserId(), credentials.getDomainName() );
        }
        return "TRUE";
    }
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
    
    public TreeMap getPropertiesTreeMap() {
        return propertiesTreeMap;
    }

    public void setPropertiesTreeMap(TreeMap propertiesTreeMap) {
        this.propertiesTreeMap = propertiesTreeMap;
    }
    
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return request;
    }
    
    /**
     * @return Returns the referenceKey.
     */
    public String[] getReferenceKey() {
        return referenceKey;
    }
    /**
     * @param referenceKey The referenceKey to set.
     */
    public void setReferenceKey(String[] referenceKey) {
        this.referenceKey = referenceKey;
    }
    /**
     * @return Returns the referenceValue.
     */
    public String[] getReferenceValue() {
        return referenceValue;
    }
    /**
     * @param referenceValue The referenceValue to set.
     */
    public void setReferenceValue(String[] referenceValue) {
        this.referenceValue = referenceValue;
    }
    /**
     * @return Returns the referenceProperties.
     */
    public Properties getReferenceProperties() {
        return referenceProperties;
    }
    /**
     * @param referenceProperties The referenceProperties to set.
     */
    public void setReferenceProperties(Properties referenceProperties) {
        this.referenceProperties = referenceProperties;
    }
    
    /**
     * @return Returns the process.
     */
    public String getProcess() {
        return process;
    }
    /**
     * @param process The process to set.
     */
    public void setProcess(String process) {
        this.process = process;
    }
	public String getLastUpdateUserId()
	{
		return lastUpdateUserId;
	}
	public void setLastUpdateUserId(String lastUpdateUserId)
	{
		this.lastUpdateUserId = lastUpdateUserId;
	}
	public String getLastUpdateTimestamp()
	{
		return lastUpdateTimestamp;
	}
	public void setLastUpdateTimestamp(String lastUpdateTimestamp)
	{
		this.lastUpdateTimestamp = lastUpdateTimestamp;
	}
	public String getLastUpdateDomainname()
	{
		return lastUpdateDomainname;
	}
	public void setLastUpdateDomainname(String lastUpdateDomainname)
	{
		this.lastUpdateDomainname = lastUpdateDomainname;
	}
	public String getCreateUserId()
	{
		return createUserId;
	}
	public void setCreateUserId(String createUserId)
	{
		this.createUserId = createUserId;
	}
	public String getCreateTimestamp()
	{
		return createTimestamp;
	}
	public void setCreateTimestamp(String createTimestamp)
	{
		this.createTimestamp = createTimestamp;
	}
        
    public void setActionMessage(HttpServletRequest request, String[] messageKeyObject) {
        int length = messageKeyObject.length;
        logger.debug("messageKeyObject.length = " + length);
        ActionMessage actionMessage = null;
        switch (length) {
            case 2:
                logger.debug("messagekeyvalues" + messageKeyObject[0]);
                actionMessage = new ActionMessage(messageKeyObject[0], (Object) messageKeyObject[1]);
                break;
            case 3:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2]);
                break;
            case 4:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3]);
                break;
            case 5:
                actionMessage = new ActionMessage(messageKeyObject[0], messageKeyObject[1], messageKeyObject[2], messageKeyObject[3], messageKeyObject[4]);
                break;
            default:
                actionMessage = new ActionMessage(messageKeyObject[0]);
        }

        ActionMessages messages = new ActionMessages();
        messages.add(ActionMessages.GLOBAL_MESSAGE, actionMessage);

        logger.debug("message has been set on request");
    }
}

