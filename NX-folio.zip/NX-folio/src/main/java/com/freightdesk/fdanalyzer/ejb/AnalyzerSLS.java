/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/analyzer/ejb/Attic/AnalyzerSLS.java,v 1.5.4.1 2010/08/22 23:08:26 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: AnalyzerSLS.java,v $
 *  Revision 1.5.4.1  2010/08/22 23:08:26  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.5  2006/03/28 21:22:59  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.4  2006/02/13 08:22:52  pjain
 *  Refactored UserModel to BaseXmlModel
 *
 *  Revision 1.3  2004/09/15 13:03:03  ranand
 *  2.6 Baseline
 *
 * 
 */


package com.freightdesk.fdanalyzer.ejb;

import java.rmi.RemoteException;

import javax.ejb.EJBObject;

import com.freightdesk.fdcommons.BaseXmlModel;

/**
 * @author Ajeet Sachan [ajeet.sachan]
 *
 */
public interface AnalyzerSLS extends EJBObject {
    
    public void insert(BaseXmlModel model) throws RemoteException;
    
    public void post(BaseXmlModel model) throws RemoteException;
    
    public void preProcess(BaseXmlModel model) throws RemoteException;
    
    public void postProcess(BaseXmlModel model) throws RemoteException;

}
