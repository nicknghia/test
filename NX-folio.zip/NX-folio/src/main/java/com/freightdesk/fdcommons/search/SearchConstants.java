/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/search/SearchConstants.java,v 1.4 2008/06/19 09:32:09 ranand Exp $
 * 
 *  Modification History:
 *  $Log: SearchConstants.java,v $
 *  Revision 1.4  2008/06/19 09:32:09  ranand
 *  added new method
 *
 *  Revision 1.3  2007/06/18 19:42:45  ranand
 *  added new method
 *
 *  Revision 1.2  2007/06/11 21:29:49  ranand
 *  Added new properties
 *
 *  Revision 1.1  2007/06/06 20:52:01  ranand
 *  new files for serach Framework
 *
 *  
 */
package com.freightdesk.fdcommons.search;

public class SearchConstants
{
    public static final int EQUALS = 0;

    public static final int GT_THAN = 1;

    public static final int GT_THAN_EQUALS = 2;

    public static final int IN = 3;

    public static final int IS_NOT_NULL = 4;

    public static final int IS_NULL = 5;

    public static final int LESS_THAN = 6;

    public static final int LESS_THAN_EQUALS = 7;

    public static final int NOT_EQUALS = 8;

    public static final int LIKE = 9;

    public static final String ASC = "ASC";

    public static final String DESC = "DESC";

    public static final String BEGINSWITH = "beginsWith";

    public static final String ENDSWITH = "endsWith";

    public static final String CONTAINS = "contains";

    public static final String EXACT = "exact";
    
    public static String getOperatorString(int operator){
        
        if(EQUALS == operator){
            return "=";
        }
        if(GT_THAN == operator){
            return ">";
        }
        if(GT_THAN_EQUALS == operator){
            return ">=";
        }
        if(IN == operator){
            return "IN";
        }
        if(IS_NOT_NULL == operator){
            return "IS NOT NULL";
        }
        if(IS_NULL == operator){
            return "IS NULL";
        }
        if(LESS_THAN == operator){
            return "<";
        }
        if(LESS_THAN_EQUALS == operator){
            return "<=";
        }
        if(NOT_EQUALS == operator){
            return "!=";
        }

        if(LIKE == operator){
            return " like ";
        }

        throw new RuntimeException("Unknown SQL Operator Code: "+operator);
    }
    
    public static int getSearchConstant(String text){

        if(BEGINSWITH.equals(text) || ENDSWITH.equals(text) || CONTAINS.equals(text)){
            return 9;
        }
        if(EXACT.equals(text)) {
            return 0;
        }

        throw new RuntimeException("Unknown SQL Operator Code: "+text);
    }
    
}
