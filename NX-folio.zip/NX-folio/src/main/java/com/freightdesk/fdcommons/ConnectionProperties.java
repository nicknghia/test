package com.freightdesk.fdcommons;

import java.sql.Connection;

public class ConnectionProperties
{
    private Connection connection;

    private long idleTime;

    private long lastAccessTime;

    public Connection getConnection()
    {
        return connection;
    }

    public void setConnection(Connection connection)
    {
        this.connection = connection;
    }     

    public long getIdleTime()
    {
        return idleTime;
    }

    public void setIdleTime(long idleTime)
    {
        this.idleTime = idleTime;
    }

    public long getLastAccessTime()
    {
        return lastAccessTime;
    }

    public void setLastAccessTime(long lastAccessTime)
    {
        this.lastAccessTime = lastAccessTime;
    }
}
