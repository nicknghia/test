package com.freightdesk.fdcommons;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;
/**
 * manages log for login activities only
 * in future may be used for other activity that need to have a log in the DB	 
 */

public class ActivityLogDAO extends BaseDao{	
	 /** A logger */
    protected Logger logger = Logger.getLogger (getClass());
    /** constants for activity type */
    //password change acivity
    public static final String PASSWORD_CHANGE_ACTIVITY = "PCHNG";
    //user add activity
    public static final String USR_ADD_ACTIVITY = "USADD";
    //login activity
    public static final String LOGIN_ACTIVITY = "LOGIN";
    //user reset activity
    public static final String USR_RESET_ACTIVITY = "USRST";
    //admin reset activity
    public static final String ADMIN_RESET_ACTIVITY = "ADRST";
    
    public static final String USER_START_ACTIVITY = "START";
    
    public static final String USER_STOP_ACTIVITY = "STOP";
    
    public static final String ADMIN_CHECKIN_ACTIVITY = "CHKIN";
    
    public static final String ADMIN_CHECKOUT_ACTIVITY = "CHKOT";
    
    /** constants for result type */
    public static final String SUCCESS = "SUCCESS";
    
    public static final String FAILURE = "FAILURE";
    
    /** constant for anonymous user type */
    public static final String ANON = "ANON";

	 /** 
     * creates the ActivityLog for the specified user. 
     *   
     */
    public void createActivityLog (String activtyType,String userId, String result, String doneBy, String ipAddress) throws SQLException       
    {
        logger.info("createActivityLog(): begin");    

        String query = "insert into activitylog(ACTIVITYLOGID,ACTIVITYTYPE, USERID, RESULT, DONEBY, IPADDRESS) values (?,?,?,?,?,?)";
        Connection connection = null;
        PreparedStatement pStmt = null;
        try
        {
            connection = getConnection();
            long activityLogId = getNextID("activitylogid");
            pStmt = connection.prepareStatement(query);
            pStmt.setLong(1, activityLogId);  
            pStmt.setString(2, activtyType);            
            pStmt.setString(3, userId);
            pStmt.setString(4, result);
            pStmt.setString(5, doneBy);
            pStmt.setString(6, ipAddress);
            pStmt.executeUpdate();
            logger.debug ("Finished createActivityLog()");
        }
        catch (SQLException sqEx)
        {
            logger.error("Exception in createActivityLog():" , sqEx);  
            throw sqEx;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }   
}
