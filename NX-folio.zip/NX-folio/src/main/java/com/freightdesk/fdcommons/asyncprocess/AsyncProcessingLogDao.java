/** 
* Copyright (c) 2000-2002 NTELX 
*  All rights reserved. 
* 
* This software is the confidential and proprietary information of NTELX 
* ("Confidential Information").  You shall not disclose such Confidential Information 
* and shall use it only in accordance with the terms of the license agreement you entered 
* into with NTELX. 
* 
* 
*  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/asyncprocess/AsyncProcessingLogDao.java,v 1.4.4.3 2010/03/15 13:47:19 mechevarria Exp $ 
* 
*  Modification History:
*  $Log: AsyncProcessingLogDao.java,v $
*  Revision 1.4.4.3  2010/03/15 13:47:19  mechevarria
*  now log ip address
*
*  Revision 1.4.4.2  2008/12/11 13:50:44  mechevarria
*  brought over from head
*
*  Revision 1.7  2008/05/19 10:38:41  ranand
*  minor changes
*
*  Revision 1.6  2008/05/17 06:26:33  ranand
*  added debug statements
*
*  Revision 1.5  2008/05/16 11:16:06  ranand
*  added new property in AsyncProcessLogModel
*
*  Revision 1.4  2007/03/12 15:47:59  dkumar
*  method for deleting all logs for a user
*
*  Revision 1.3  2007/03/07 15:40:55  dkumar
*  added check for feedback length
*
*  Revision 1.2  2007/03/07 15:31:50  dkumar
*  async processing changes
*
*  Revision 1.1  2007/03/02 10:11:40  dkumar
*  Classes For Time Consuming Asynchronous Requests
*
*  Revision 1.1  2007/02/27 16:31:46  dkumar
*  Asynchronous processing for time consuming task functionality
*
*/
/**
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 */
package com.freightdesk.fdcommons.asyncprocess;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.ConnectionUtil;


/**
 * @author Deepak Kumar
 *
 */
public class AsyncProcessingLogDao  extends BaseDao
{
    private Logger daoLogger = Logger.getLogger("com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogDao");

    public AsyncProcessingLogModel create(AsyncProcessingLogModel model)
            throws SQLException {
        daoLogger.debug("create(): begin");
        PreparedStatement pstmt = null;
        Connection con = null;
        try {
            long asyncProcessLogId = getNextID("ASYNCPROCESSINGLOGID");
            model.setAsyncProcessingLogId(asyncProcessLogId);
            String insertQuery = "INSERT INTO ASYNCPROCESSINGLOG ( ASYNCPROCESSINGLOGID, DESCRIPTION, MODULENAME, FEEDBACK, STATUS, CREATEUSERID, CREATETIMESTAMP, " +
                                    "LASTUPDATEUSERID, LASTUPDATETIMESTAMP, DOMAINNAME, GUID, IPADDRESS, BROWSER, BVERSION ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?,?,?,?)"; 
            con = getConnection();
            pstmt = con.prepareStatement(insertQuery);
            pstmt.setLong(1,model.getAsyncProcessingLogId());
    
            if(model.getDescription()!=null)
            {
                //Covert Description to upper case (used for sinple search)
                pstmt.setString(2,model.getDescription().toUpperCase());
            }
            else
            {
                pstmt.setNull(2,Types.VARCHAR);
            }
            pstmt.setString(3,model.getModuleName());

            if(model.getFeedBack()!=null)
            {
                String feedback = model.getFeedBack();
                //There is FeedBack DB size Restriction of 2000 characters
                if(feedback.length()>2000)
                    feedback = model.getFeedBack().substring(0,2000);
                pstmt.setString(4,feedback);
            }
            else
            {
                pstmt.setNull(4,Types.VARCHAR);
            }

            pstmt.setString(5,model.getStatus());
            pstmt.setString(6,model.getCreateUserId());
            pstmt.setTimestamp(7,model.getCreateTimestamp());
            pstmt.setString(8,model.getLastUpdateUserId());
            pstmt.setTimestamp(9,model.getLastUpdateTimestamp());
            pstmt.setString(10,model.getDomainName());
            pstmt.setString(11, model.getGUID());
            pstmt.setString(12, model.getIpAddress());
            pstmt.setString(13, model.getBrowser());
            pstmt.setDouble(14, model.getBrowserVersion());
            pstmt.executeUpdate();
        }
        catch(SQLException e)
        {
            daoLogger.error("Exception in create ", e);
            throw e;
        }
        finally
        {
            ConnectionUtil.closeResources(con, pstmt, null);
        }
        return model;
    }

    public  void update(AsyncProcessingLogModel model) throws SQLException {
        daoLogger.debug("update: begin");
        PreparedStatement pstmt = null;
        Connection con = null;
        try {
            String updateQuery = "UPDATE ASYNCPROCESSINGLOG SET DESCRIPTION=? , MODULENAME=?, FEEDBACK=?, STATUS=?, " +
                                    "LASTUPDATEUSERID=?, LASTUPDATETIMESTAMP=?, DOMAINNAME=? WHERE ASYNCPROCESSINGLOGID=? "; 
            con =getConnection();
            pstmt = con.prepareStatement(updateQuery);
            if(model.getDescription()!=null)
            {
                //Covert Description to upper case (used for sinple search)
                pstmt.setString(1,model.getDescription().toUpperCase());
            }
            else
            {
                pstmt.setNull(1,Types.VARCHAR);
            }
            pstmt.setString(2,model.getModuleName());
      
            if(model.getFeedBack()!=null)
            {
                String feedback = model.getFeedBack();
                //There is FeedBack DB size Restriction of 2000 characters
                if(feedback.length()>2000)
                    feedback = model.getFeedBack().substring(0,2000);
                pstmt.setString(3,feedback);
            }
            else
            {
                pstmt.setNull(3,Types.VARCHAR);
            }
   
            pstmt.setString(4,model.getStatus());
            pstmt.setString(5,model.getLastUpdateUserId());
            pstmt.setTimestamp(6,model.getLastUpdateTimestamp());
            pstmt.setString(7,model.getDomainName());
            pstmt.setLong(8,model.getAsyncProcessingLogId());
            pstmt.executeUpdate();
        }
        catch(SQLException e)
        {
            daoLogger.error("Exception in update ", e);
            throw e;
        }
        finally
        {
            ConnectionUtil.closeResources(con, pstmt, null);
        }
        daoLogger.debug("update(): end");
    }
    
    public void delete(long id) throws SQLException {
    	daoLogger.debug("delete(): begin");
        String query = "delete from ASYNCPROCESSINGLOG where ASYNCPROCESSINGLOGID = ?";
        deleteRecord(query, id);
    }

    public  void deleteAll(String createUserId, String domainName)
    throws SQLException {
        daoLogger.debug("deleteAll: begin");
        PreparedStatement pstmt = null;
        Connection con = null;
        try {
            String query = "DELETE FROM ASYNCPROCESSINGLOG WHERE CREATEUSERID = ? AND DOMAINNAME = ?";
            con =getConnection();
            pstmt = con.prepareStatement(query);
            pstmt.setString(1,createUserId);
            pstmt.setString(2,domainName);
            pstmt.executeUpdate();
        }
        catch(SQLException e)
        {
            daoLogger.error("Exception in update ", e);
            throw e;
        }
        finally
        {
            ConnectionUtil.closeResources(con, pstmt, null);
        }
    }
    
    public List retrieveHomeList(String createUserId, String domainName, String serachStr) throws SQLException
    {
        Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        boolean isSearchMode = false;
        List asyncProcessList = new ArrayList();

        try {
            logger.info("retrieveHomeList():begin " );
            
            String query = "SELECT ASYNCPROCESSINGLOGID, DESCRIPTION, MODULENAME, FEEDBACK, STATUS, CREATEUSERID, CREATETIMESTAMP, " +
                                    "LASTUPDATEUSERID, LASTUPDATETIMESTAMP, DOMAINNAME, GUID, IPADDRESS" +
                                    " FROM ASYNCPROCESSINGLOG WHERE CREATEUSERID=? AND DOMAINNAME=? ";
								           
			connection = getConnection();
            pStmt = connection.prepareStatement(query);
            pStmt.setString(1,createUserId);
            pStmt.setString(2,domainName);

			if(serachStr!=null && !"".equals(serachStr.trim()))
            {
                isSearchMode = true;
                query = query + " AND DESCRIPTION LIKE ? " ;
            }
            query = query + " ORDER BY CREATETIMESTAMP ASC" ;
            logger.debug("DQL Query="+query);
            
            /*connection = getConnection();
            pStmt = connection.prepareStatement(query);
            pStmt.setString(1,createUserId);
            pStmt.setString(2,domainName);*/
            //if(isSearchMode)
			if(isSearchMode == true)	
            {
                pStmt.setString(3,"%"+serachStr+"%");				
               
            }
            
            rs = pStmt.executeQuery();
            while (rs.next())
            {
                AsyncProcessingLogModel asyncProcessModel = new AsyncProcessingLogModel();
                asyncProcessModel.setAsyncProcessingLogId(rs.getLong("ASYNCPROCESSINGLOGID"));
                asyncProcessModel.setDescription(rs.getString("DESCRIPTION"));
                asyncProcessModel.setModuleName(rs.getString("MODULENAME"));
                String guid = rs.getString("GUID");
                asyncProcessModel.setFeedBack(rs.getString("FEEDBACK"));
                asyncProcessModel.setStatus(rs.getString("STATUS"));
                asyncProcessModel.setCreateUserId(rs.getString("CREATEUSERID"));
                asyncProcessModel.setCreateTimestamp(rs.getTimestamp("CREATETIMESTAMP"));
                asyncProcessModel.setLastUpdateUserId(rs.getString("LASTUPDATEUSERID"));
                asyncProcessModel.setLastUpdateTimestamp(rs.getTimestamp("LASTUPDATETIMESTAMP"));
                asyncProcessModel.setDomainName(rs.getString("DOMAINNAME"));
                asyncProcessModel.setIpAddress(rs.getString("IPADDRESS"));
                asyncProcessModel.setGUID(guid);
                asyncProcessList.add(asyncProcessModel);
            }
        }
        catch(SQLException e)
        {
            logger.error("Exception in retrieveHomeList ", e);
            throw e;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return asyncProcessList;
    }

}
