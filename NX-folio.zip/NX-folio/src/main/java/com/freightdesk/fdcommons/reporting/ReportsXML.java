/** 
 * 
 * Copyright (c) 2000-2002 NTELX, LLC 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX, LLC 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX, LLC. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/reporting/ReportsXML.java,v 1.1.4.1 2009/08/06 16:07:33 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: ReportsXML.java,v $
 *  Revision 1.1.4.1  2009/08/06 16:07:33  mechevarria
 *  using the head version for the ability to use role based reports
 *
 *  Revision 1.2  2007/10/26 09:43:34  dkumar
 *  Added Roles to Report
 *
 *  Revision 1.1  2006/06/21 11:20:25  dkumar
 *  repackaging of ReportUtility to FDCommons
 *
 *  Revision 1.2  2005/07/07 09:32:03  ranand
 *  property header and footer added
 *
 *  Revision 1.1  2004/09/15 13:36:28  asingh
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons.reporting;

import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import org.apache.log4j.Logger;

/**
 * @author Mike Echevarria
 */

@XmlRootElement(name = "REPORTS")
@XmlAccessorType(XmlAccessType.NONE)
public class ReportsXML {
	protected final Logger logger = Logger.getLogger(ReportsXML.class);

	@XmlElement(name = "REPORT")
	private List<ReportXML> reportXML = new ArrayList<ReportXML>();

	public List<ReportXML> getReportXML() {
		return reportXML;
	}

	public void setReportXML(List<ReportXML> reportXML) {
		this.reportXML = reportXML;
	}

	public List<ReportXML> getReportXMLByRole(String roleCode) {
		logger.debug("Searching for reports for " + roleCode);

		List<ReportXML> filteredReports = new ArrayList<ReportXML>();
		if (roleCode == null || "".equals(roleCode)) {
			return reportXML;
		}
		for (int i = 0; i < reportXML.size(); i++) {
			ReportXML report = reportXML.get(i);
			List<String> roleList = report.getRoles();
			if (roleList.size() == 0 || roleList.contains(roleCode) || roleList.contains("ALL")) {
				filteredReports.add(report);
			}
		}
		logger.debug("Found " + filteredReports.size() + " reports for role " + roleCode);

		return filteredReports;
	}

	public ReportXML getReportByName(String name) {
		logger.debug("Searching for report with name of " + name);

		for (ReportXML currReport : reportXML) {
			if (currReport.getName().equalsIgnoreCase(name))
				return currReport;
		}

		logger.warn("Could not find report with name of " + name + ", returning null");
		return null;
	}

}
