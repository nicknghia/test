/** 
* Copyright (c) 2000-2002 NTELX 
*  All rights reserved. 
* 
* This software is the confidential and proprietary information of NTELX 
* ("Confidential Information").  You shall not disclose such Confidential Information 
* and shall use it only in accordance with the terms of the license agreement you entered 
* into with NTELX. 
* 
* 
*  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/licensing/LicenseConstants.java,v 1.1.4.1.2.2 2009/07/22 18:30:18 mechevarria Exp $ 
* 
*  Modification History:
*  $Log: LicenseConstants.java,v $
*  Revision 1.1.4.1.2.2  2009/07/22 18:30:18  mechevarria
*  toupper on code names
*
*  Revision 1.1.4.1.2.1  2009/07/21 20:40:41  cdoan
*  Renamed vActiveMonitor to Monitor
*
*  Revision 1.1.4.1  2007/05/18 18:51:04  mechevarria
*  add new licensing
*
*  Revision 1.1  2007/04/12 16:31:14  dkumar
*  base version
*
*/
package com.freightdesk.fdcommons.licensing;

import java.util.HashMap;
import java.util.Map;

public class LicenseConstants
{
    public final static String DATE_FORMAT ="ddMMyyyy";
 
    public final static Byte KEY_MAJOR_MIN = new Byte((byte)1);
    public final static Byte KEY_MAJOR_MAX = new Byte((byte)9);
    
    public final static Byte KEY_MINOR_MAX = new Byte((byte)99);
    public final static Byte KEY_MINOR_MIN = new Byte((byte)0);
    
    public final static String suiteName = new String("FDSuite");

    
    
    public static class LicenseType
    {
        public final static Byte Demo = new Byte((byte)1);
        public final static Byte Full = new Byte((byte)2);
        
        public static final byte getLicenseTypeCode(String licenseType)
        {
           if("DEMO".equalsIgnoreCase(licenseType))
               return Demo.byteValue();
           else if("FULL".equalsIgnoreCase(licenseType))
               return Full.byteValue();
           else 
               return -1;
        }

        public static final String getLicenseType(byte licenseTypeCode)
        {
            if(licenseTypeCode == Demo.byteValue())
                return "DEMO";
            else if(licenseTypeCode == Full.byteValue())
                return "FULL";
            else
                return null;
        }
        
    }

    public static class ProductCode
    {
        private static final Map configCodes = new HashMap();

        public final static Byte FDSuite = new Byte((byte)1);

        static
        {
            configCodes.put(suiteName.toUpperCase(),FDSuite);
        }
        
        public static final byte getConfigCode(String productName)
        {
            if(productName != null)
                productName = productName.toUpperCase();
            
           Byte productCode = (Byte) ProductCode.configCodes.get(productName);
           if(productCode!=null)
           {
               return productCode.byteValue();
           }
           else
           {
               return -1;
           }
        }
        
    }
    
    public static String[] getProductNames() {
    	String[] productNames = {suiteName};
    	return productNames;
    }

}
