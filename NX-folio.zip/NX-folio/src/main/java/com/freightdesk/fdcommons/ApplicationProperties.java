/**
 * Copyright (c) NTELX All rights reserved.
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with NTELX.
 * $Header:
 * /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/common/ApplicationProperties.java,v
 * 1.2 2005/07/28 08:13:06 pjain Exp $ Modification History: $Log:
 * ApplicationProperties.java,v $ Revision 1.2 2005/07/28 08:13:06 pjain added
 * constant APPLICATION_PROPERTY_FILE Revision 1.1 2005/07/27 09:01:17 ranand
 * renamed from LcpProperties to ApplicationProperties Revision 1.4 2005/04/07
 * 06:56:20 nsehra no message Revision 1.3 2004/09/15 13:03:45 ranand 2.6
 * Baseline
 */

package com.freightdesk.fdcommons;

import java.io.File;
import java.util.List;
import java.util.Properties;
import org.apache.log4j.Logger;

/**
 * Encapsulates all application properties that can be set differently for each
 * deployment, but are not saved to the DB. For example, the number of records
 * to show on a page, or the decimal format to be used for monetary values. In
 * future, it is possible that some properties may migrate from
 * ApplicationProperties to the DB, as preferences of each user. Implemented as
 * a singleton, and only allows a visiting BootstrapServlet to initialize it.
 * 
 * @author Mike Echevarria
 */
public class ApplicationProperties {
	
	protected static Logger logger = Logger.getLogger("com.freightdesk.fdcommons.ApplicationProperties");
	public static final String APPLICATION_PROPERTY_FILE = "Application.properties";

	/**
	 * The key used for the product
	 */
	public static final String PRODUCT = "product";

	/**
	 * The key used for maximum results to show on the addressbook pages
	 */
	public static final String ADDRESSBOOK_MAXIMUM_RESULTS = "ADDRESSBOOK_MAXIMUM_RESULTS";

	/**
	 * The key used for maximum results to show on the item pages
	 */
	public static final String ITEM_MAXIMUM_RESULTS = "ITEM_MAXIMUM_RESULTS";

	/**
	 * The key used for maximum results to show on the item pages
	 */
	public static final String TARIFF_MAXIMUM_RESULTS = "TARIFF_MAXIMUM_RESULTS";

	/**
	 * The (only) instance of this Singleton
	 */
	protected static ApplicationProperties _instance;

	/**
	 * The interal data structure used to store the properties
	 */
	private static Properties props = new Properties();

	/** The List of defaultReferences */
	protected static List<String> homeReferencesList = null;

	/**
	 * Gets the file URI for the given property. The returned URI has the
	 * correct file separator and uses the system property LCP_RUNTIME_HOME the
	 * file root, and uses the property specified in lcp.properties as the
	 * relative URL off of the LCP_RUNTIME_HOME.
	 * 
	 * @param key
	 *            The key for the property in lcp.properties
	 * @return The URI for the file property corresponding to the key
	 */
	public static String getURI(String key) {
		String uri = System.getProperty("LCP_RUNTIME_HOME") + File.separator + getProperty(key);
		logger.info("uri (" + key + "): " + uri);
		return uri;
	}

	public static String getProperty(String key) {
		getInstance();
		return props.getProperty(key);
	}
	
	public static Properties getProps() {
		return props;
	}
	
	public static void setProps(Properties props) {
		ApplicationProperties.props = props;
	}

	/**
	 * Requires a secret to be initialized.
	 */
	private synchronized static void load() 
	{		
		// Do Nothing.  Properties are now loaded in the
		//   BootStrap Servlet		
		
		homeReferencesList = null;
	}
	
	public static void reset() {
		if(props != null)
		  props.clear();
		load();
	}

	/**
	 * Only constructor is declared private.
	 */
	private ApplicationProperties() {
		load();
	}
	
	private static ApplicationProperties getInstance() {
		if (_instance == null) {
			_instance = new ApplicationProperties();
		}
		return _instance;
	}

}
