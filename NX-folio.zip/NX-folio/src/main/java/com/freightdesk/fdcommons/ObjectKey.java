/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/ObjectKey.java,v 1.1 2006/03/29 22:05:35 ranand Exp $
 * 
 *  Modification History:
 *  $Log: ObjectKey.java,v $
 *  Revision 1.1  2006/03/29 22:05:35  ranand
 *  moved files from folio
 *
 *  Revision 1.1  2006/03/28 21:20:06  aarora
 *  Creating an fdcommons folder
 *
 *  Revision 1.4  2004/11/29 12:46:52  biju
 *  DAO/EJB changes for UM
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons;

import java.io.Serializable;

public class ObjectKey implements Serializable {
    private String domainObjectCode;
    private  long domainObjectId;

    // constructors
    public ObjectKey () {
    }
    
    /** Constructor for creating the an instance of ObjectKey
	 * @param domainObjectCode -identifies the domainObjectType
	 * @param domainObjectId - identifies the unique key within domainObjectType
    */
    
    public ObjectKey (String domainObjectCode, long domainObjectId) {
        this.domainObjectCode = domainObjectCode;
        this.domainObjectId = domainObjectId;        
     }
    
    public String getDomainObjectCode()
    {
       return this.domainObjectCode;
    }
    
    public void setDomainObjectCode(String domainObjectCode) 
    {
    	this.domainObjectCode = domainObjectCode;
    }
    public long getDomainObjectId()
    {
    	return this.domainObjectId;
    }
    
    public void setDomainObjectId(long domainObjectId)
    {
    	this.domainObjectId = domainObjectId;
    }
    
	public boolean equals(Object object1)
	{
    		
	   ObjectKey objectKey =(ObjectKey)object1;
         if (this.domainObjectCode.equals( objectKey.getDomainObjectCode()) && (this.domainObjectId== objectKey.getDomainObjectId()))
	     {
			
		   return true;
	     }
		   	
		  return false;
	}
	
	 public int hashCode()
	 {
		   return (int)this.domainObjectId;		   		
	 }
    
}
