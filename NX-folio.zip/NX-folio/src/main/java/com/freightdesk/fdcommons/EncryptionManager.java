/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/EncryptionManager.java,v 1.1.2.1.2.1 2010/10/02 20:35:49 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: EncryptionManager.java,v $
 *  Revision 1.1.2.1.2.1  2010/10/02 20:35:49  mechevarria
 *  added stacktrace for encryption errors
 *
 *  Revision 1.1.2.1  2007/05/18 18:52:00  mechevarria
 *  merge with main branch
 *
 *  Revision 1.2  2007/04/12 16:34:17  dkumar
 *  methods to encrypt with symmetric cipher
 *
 *  Revision 1.1  2006/12/12 10:26:48  dkumar
 *  recpackaging of encryptionManager from suite to fdcommons
 *
 *  Revision 1.1  2006/08/11 20:51:41  dkumar
 *  chages for making fdsuite struts based application
 *
 *  Revision 1.2  2006/04/15 01:25:29  aarora
 *  Removed redundant code
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons;

import org.apache.log4j.Logger;
import java.security.GeneralSecurityException;


/**
 * EncryptionManager provides basic encryption services.  No fancy objectives
 * here, just simple symmetric encryption.
 *
 * @author Amrinder Arora
 * @author Deepak Kumar
 */
public class EncryptionManager 
{
    /**
     * A logger
     */
    protected Logger logger = Logger.getLogger (getClass());

	private byte[] SERVER_KEY_BYTES = "server's key goes here some passphrase".getBytes();

    /**
     * Encrypts a text with the server's key.  The encrypted text may
     * be sent on an unsecured channel or stored on untrusted computers.  Server's
     * key is required to decrypt it.
     */
    public byte[] encrypt (byte[] text) {
        // Takes the xor and returns the result
        // byte[] encrypted = xor (text, SERVER_KEY);
        // logger.debug ("encrypted (" + text + "): " + new String (encrypted));
        return xor (text, SERVER_KEY_BYTES);
    }

    /**
     * Decrypts a text with the server's key.
     */
    public byte[] decrypt (byte[] text) {
        // Takes the xor and returns the result
        return xor (text, SERVER_KEY_BYTES);
    }

    /**
     * Takes an XOR of two Strings, returning a result which is the size of the
     * first String.  If the first String is longer than the second, then the
     * second is repeated.  If the second String is longer, some portion of it
     * is unused.
     */
    private byte[] xor (byte[] b1, byte[] b2)
    {
        while (b1.length > b2.length) {
            b2 = (new String (b2) + new String (b2)).getBytes();
        }

        byte[] b3 =  new byte[b1.length];
        for (int i = 0; i<b1.length; i++) {
            b3[i] = (byte) (b1[i] ^ b2[i]);
        }
        // String text1 = new String(b1);
        // String text3 = new String(b3);
        // logger.debug ("xor (" + text1 + "," + key + "): " + text3);
        return b3;
    }
    
    /**
     * Encrypts the text bytes using Symmetric Key Encryption
     */
    public byte[] encryptWithSC(byte[] text)
    {
        SymmetricCipher symmetricCipher = SymmetricCipher.getInstance();
        try {
            return symmetricCipher.encrypt(text);
        } catch (GeneralSecurityException e) {
            throw new RuntimeException("Error in Encryption");
        }
    }
    
    /**
     * Decrypts a text using Symmetric Key
     */
    public byte[] decryptWithSC (byte[] data) 
    {
        SymmetricCipher symmetricCipher = SymmetricCipher.getInstance();
        try {
            return symmetricCipher.decrypt(data);
        } catch (GeneralSecurityException e) {
        	//e.printStackTrace();
			logger.error("Exception : " + e.getMessage());
            throw new RuntimeException("Error in Decryption");
        }
    }

}

