/**
 * into with NTELX.
 *
 *
 * Module Description: Model is corresponding to the acknowlegment of header xml.
 *  $ID:$
 *
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/AcknowledgementMethod.java,v 1.1 2006/06/14 15:03:19 nsehra Exp $
 *
 *  Modification History:
 *  $Log: AcknowledgementMethod.java,v $
 *  Revision 1.1  2006/06/14 15:03:19  nsehra
 *  first version
 *
 *  Revision 1.2  2004/09/21 01:17:09  agarg
 *  Merging package names and the new error handling
 *
 *  Revision 1.5  2003/10/06 10:34:28  agarg
 *  for DEE
 *
 *  Revision 1.4  2003/08/21 21:35:56  agarg
 *  Making the XML Models to serializable models
 *
 *  Revision 1.3  2003/06/05 10:49:00  agarg
 *  Including URL, Faxnumber,phone number also in the header (Acknowledgement method)
 *
 *  Revision 1.2  2002/12/20 14:27:30  agarg
 *  Code clean up activity for xmlintmanager
 *
 *  Revision 1.1  2002/12/10 08:49:55  agarg
 *  for insert Inv party and ShipmentREL2.0
 *
 *
 *
 */
package com.freightdesk.fdcommons;
import java.io.Serializable;

public class AcknowledgementMethod   implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private String emailAddress;
	private String url;
	private String phoneNumber;
	private String faxNumber;
	public void setEmailAddress(String emailAddress)
	{
		this.emailAddress = emailAddress;
	}
	public String getEmailAddress()
	{
		return emailAddress;
	}

	public void setUrl(String url)
	{
		this.url = url;
	}
	public String getUrl()
	{
		return url;
	}

	public void setPhoneNumber(String phoneNumber)
	{
		this.phoneNumber = phoneNumber;
	}
	public String getPhoneNumber()
	{
		return phoneNumber;
	}

	public void setFaxNumber(String faxNumber)
	{
		this.faxNumber = faxNumber;
	}
	public String getFaxNumber()
	{
		return faxNumber;
	}
}
