/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/BaseForm.java,v 1.1 2007/07/16 17:56:06 ranand Exp $ 
 *
 *  Modification History:
 *  $Log: BaseForm.java,v $
 *  Revision 1.1  2007/07/16 17:56:06  ranand
 *  Added new BaseForm Class
 *
 *  Revision 1.1  2006/04/27 18:21:10  ranand
 *  repackaged the classes from fdfusion to fdanalyzer
 *
 *  Revision 1.1  2006/03/19 20:31:00  aarora
 *  Creating initial version of FDAnalyzer
 *
 *  Revision 1.3  2005/03/10 05:32:25  pjain
 *  changed author name format
 *
 *  Revision 1.2  2005/03/09 14:30:05  pjain
 *  class comments
 *
 *  Revision 1.1  2005/02/14 10:17:27  pjain
 *  Form Bean for FDfusion
 *
 */

package com.freightdesk.fdcommons;

//import org.apache.struts.action.ActionForm;

/**
 * Base form extented by all of the Fusion struts form bean. 
 * 
 * @author Pankaj Jain
 */
//public class BaseForm extends ActionForm
public class BaseForm
{
   private String action;
   
   private String fromTab;
   
	/**
	 * Constructor for DefaultForm
	 */
    public BaseForm() {
	    super();
        this.action = "";
	}

    /**
     * @return Returns the action.
     */
    public String getAction() {
        return action;
    }
    /**
     * @param action The action to set.
     */
    public void setAction(String action) {
        this.action = action;
    }
        
    /**
     * @return Returns the fromTab.
     */
    public String getFromTab() {
    	return fromTab;
    }
    /**
     * @param fromTab The fromTab to set.
     */
    public void setFromTab(String fromTab) {
    	this.fromTab = fromTab;
    }
}
