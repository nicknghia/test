/**
 * into with NTELX.
 *
 *
 * Module Description: Model to change the date in a requires format .
 *  $ID:$
 *
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/DisplayDate.java,v 1.1 2006/06/21 11:19:54 dkumar Exp $
 *
 *  Modification History:
 *  $Log: DisplayDate.java,v $
 *  Revision 1.1  2006/06/21 11:19:54  dkumar
 *  repackaging to FDCommons
 *
 *  Revision 1.2  2004/09/21 01:17:09  agarg
 *  Merging package names and the new error handling
 *
 *  Revision 1.2  2002/12/20 14:26:53  agarg
 *  Code clean up activity for xmlintmanager
 *
 *  Revision 1.1  2002/12/10 08:49:55  agarg
 *  for insert Inv party and ShipmentREL2.0
 *
 *
 *
 */
package com.freightdesk.fdcommons;

import java.util.*;
import java.text.SimpleDateFormat;

public class DisplayDate
{
	public String DISPLAY_TIME_FORMAT = "yyyyMMdd-hhmmss-SSSS";

	public String getTimeStampForDisplay()
	{
		Date displayDate = new Date();

		SimpleDateFormat dateFormatter = new SimpleDateFormat(DISPLAY_TIME_FORMAT);
		String timeStampString = dateFormatter.format(displayDate);

		return timeStampString;
	}
}
