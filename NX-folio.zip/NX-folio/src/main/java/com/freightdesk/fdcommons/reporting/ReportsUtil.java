/** 
 * Copyright (c) NTELX, LLC 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX, LLC 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX, LLC. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/reporting/ReportsUtil.java,v 1.4.2.1.2.15 2010/12/01 21:57:17 mechevarria Exp $ 
 * 
 *  Modification History:
 *  $Log: ReportsUtil.java,v $
 *  Revision 1.4.2.1.2.15  2010/12/01 21:57:17  mechevarria
 *  use runtime only
 *
 *  Revision 1.4.2.1.2.14  2010/11/24 16:42:41  mechevarria
 *  clean up html generation
 *
 *  Revision 1.4.2.1.2.13  2010/11/03 19:27:32  mechevarria
 *  add checkbox implementation
 *
 *  Revision 1.4.2.1.2.12  2010/07/28 20:28:07  mechevarria
 *  minor debug fix
 *
 *  Revision 1.4.2.1.2.11  2010/05/17 18:39:47  jhansford
 *  Changed the way option list are handled.
 *
 *  Revision 1.4.2.1.2.10  2010/03/01 14:21:33  mechevarria
 *  use stringescapeutils
 *
 *  Revision 1.4.2.1.2.9  2009/11/19 20:04:39  mechevarria
 *  add single quote cleaner on html generation
 *
 *  Revision 1.4.2.1.2.8  2009/11/09 16:25:08  mechevarria
 *  additional report field type, yuiDate.
 *
 *  Revision 1.4.2.1.2.7  2009/11/02 21:18:08  mechevarria
 *  use optionCollectionManager
 *
 *  Revision 1.4.2.1.2.6  2009/10/29 21:37:45  mechevarria
 *  new html type of 'collection' added.  loads the collection of OptionBeans from the SystemReferenceData class
 *
 *  Revision 1.4.2.1.2.5  2009/10/26 13:21:23  jhansford
 *  Added ReportDir parameter to map passed into reports.  This allows us to load images into the report.
 *
 *  Revision 1.4.2.1.2.4  2009/08/10 20:15:39  mechevarria
 *  explicitly put parameters in jasper reports.  problems with how different versions of suite required this
 *
 *  Revision 1.4.2.1.2.3  2009/08/06 16:07:33  mechevarria
 *  using the head version for the ability to use role based reports
 *
 */
package com.freightdesk.fdcommons.reporting;

import crt.com.ntelx.nxcommons.reporting.ReportParamValidator;
import crt.com.ntelx.nxcommons.reporting.OptionCollectionManager;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.sql.Connection;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import net.sf.jasperreports.engine.JasperCompileManager;
import net.sf.jasperreports.engine.JasperFillManager;
import net.sf.jasperreports.engine.JasperPrint;
import net.sf.jasperreports.engine.JasperReport;
import net.sf.json.JSONArray;

import org.apache.log4j.Logger;
import org.directwebremoting.io.FileTransfer;

import crt.com.ntelx.nxcommons.AuthenticationUtils;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.InvalidUserException;

public class ReportsUtil {
	protected static String QUARTER_TO_DATE = "QUARTER_TO_DATE";

	protected static String MONTH_TO_DATE = "MONTH_TO_DATE";

	protected static Map<String, String> dateFormatMap = null;

	protected ReportGeneratorUtil generator = new ReportGeneratorUtil();
		
	private static OptionCollectionManager optionManager = OptionCollectionManager.getInstance();

	private static Logger logger = Logger.getLogger(ReportsUtil.class);

    private byte[] generateStream(ReportXML reportXML, Credentials credentials) throws Exception {
    	ByteArrayOutputStream buffer = new ByteArrayOutputStream();
		Connection connection = null;
		
		try {
	        String configFilePath = System.getProperty("RUNTIME_HOME") + File.separator + "reports" + File.separator + reportXML.getConfigFile();
			Map<String,Object> parameterValuesMap = getParameterValuesMap(reportXML, credentials);
			connection = ConnectionUtil.getConnection();
	        
			logger.debug("compiling: " +configFilePath);
	        JasperReport jasperReport = JasperCompileManager.compileReport(configFilePath);
	        
	        logger.debug("Filling report with data");
	        JasperPrint jasperPrint = JasperFillManager.fillReport(jasperReport, parameterValuesMap, connection);
	        
	        logger.debug("Exporting report to stream");
	        generator.generateReport(reportXML.getSelectedFormat(), jasperPrint, buffer);
						
		} catch (Exception ex) {			
			logger.error("Exception - Failed to run report: " + ex.getMessage());			
			throw ex;
		} finally {
            if (connection != null) {
		       connection.close();
		    }
        }
		
    	return buffer.toByteArray();
    }

	public Map<String, List<ReportXML>> groupReportByCategory(List<ReportXML> reportList) {
		logger.debug("grouping reports by category");

		Map<String, List<ReportXML>> categoryMap = new HashMap<String, List<ReportXML>>();
		String category = "";
		for(ReportXML report : reportList) {
                    category = report.getCategory();
			
             /*       if (category.equalsIgnoreCase("custom.report")){
			if (!categoryMap.containsKey(category)) {
				List<ReportXML> categoryReports = new ArrayList<ReportXML>();
				logger.debug("Added " + report.getName() + " to NEW category " + category);
				categoryReports.add(report);
				categoryMap.put(category, categoryReports);
			} else {
				List<ReportXML> categoryReports = categoryMap.get(category);
				logger.debug("Added " + report.getName() + " to category " + category);
				categoryReports.add(report);
			}
                    }  */
                    if (!categoryMap.containsKey(category)) {
				List<ReportXML> categoryReports = new ArrayList<ReportXML>();
				logger.debug("Added " + report.getName() + " to NEW category " + category);
				categoryReports.add(report);
				categoryMap.put(category, categoryReports);
			} else {
				List<ReportXML> categoryReports = categoryMap.get(category);
				logger.debug("Added " + report.getName() + " to category " + category);
				categoryReports.add(report);
			}
			}
		return categoryMap;
	}

	/**
	 * Gets the map of parameter values that can be used to generate the report.
	 */
	public Map<String, Object> getParameterValuesMap(ReportXML reportXML, Credentials credentials) {
		Map<String, Object> parametersMap = new HashMap<String, Object>();
		List<ParamXML> paramList = reportXML.getParams();
		
		for(ParamXML param : paramList) {
			parametersMap.put(param.getName(), param.getValue());
		}
		
		// General Parameters
		parametersMap.put("DOMAINNAME", credentials.getDomainName());
		parametersMap.put("USERID", credentials.getUserId());
		parametersMap.put("USERORGID", "" + credentials.getOrgId());

		String runtimeDirPath = System.getProperty("RUNTIME_HOME");
		String reportDir = runtimeDirPath + File.separator + "reports" + File.separator;
		parametersMap.put("REPORTDIR", reportDir);

		logger.debug("Parameters: " + parametersMap);
		return parametersMap;
	}

	public static String getReportJSON(ReportXML reportXML) {
		String json = JSONArray.fromObject(reportXML).toString();
		//yui json parser does not like the beginning [ and ending ] for single items
		if(json!= null && json.length() > 2) {
		  json = json.substring(json.indexOf("[")+1, json.length());
		  json = json.substring(0,json.lastIndexOf("]"));
		  
		  // escape any single quotes to prevent JSON parse errors
		  json = json.replaceAll("'", "&#39;");
		}
		
		return json;
	}
	
	public static String getCollectionJSON(String collectionName) throws Exception {
		// for security
		if(AuthenticationUtils.getCredentialsForDWR() == null)
			throw new InvalidUserException("User credentials not in session");
		
		String json = optionManager.getJSON(collectionName);
		if(json != null) {
		  json = json.replaceAll("\"label\"", "label");
		  json = json.replaceAll("\"value\"", "value");
		}
		return json;
	}
	
	public FileTransfer exportReport(ReportXML reportXML) throws Exception {
		logger.debug("Begining report export");
		
		Credentials credentials = AuthenticationUtils.getCredentialsForDWR();
		if(credentials == null)
			throw new InvalidUserException("User credentials not in session");
		
		ReportParamValidator paramChecker = new ReportParamValidator(reportXML);
		
		if(paramChecker.isInvalid())
			throw new SecurityException("Report " + reportXML.getName() + " has improperly modified parameters.");
		
		String fileName = reportXML.getFileName()+"."+reportXML.getSelectedFormat();
		String mimeType = "application/"+reportXML.getSelectedFormat();
		byte[] rawBytes = generateStream(reportXML,credentials);
	    
		return new FileTransfer(fileName, mimeType, rawBytes);
	}
}
