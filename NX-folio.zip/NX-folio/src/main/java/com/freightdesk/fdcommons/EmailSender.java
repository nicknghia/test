/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/EmailSender.java,v 1.4.4.3 2009/10/14 19:30:50 jhansford Exp $
 * 
 *  Modification History:
 *  $Log: EmailSender.java,v $
 *  Revision 1.4.4.3  2009/10/14 19:30:50  jhansford
 *  Emails now work with HTML
 *
 *  Revision 1.4.4.2  2009/10/06 14:59:47  mechevarria
 *  pulled from head
 *
 *  Revision 1.13  2008/08/28 11:36:52  narora
 *  Email fromAddress set from runtime property.
 *
 *  Revision 1.12  2008/06/11 13:02:50  narora
 *  EmailSender processEvent method code reverted.
 *
 *  Revision 1.8  2008/05/20 21:32:14  aarora
 *  Major surgery, many overloads removed
 *
 *  Revision 1.7  2008/04/21 12:11:07  atripathi
 *  getInstance() method added and sendMail overloaded method added.
 *
 *  Revision 1.6  2008/01/31 12:21:24  dkumar
 *  minor log class change
 *
 *  Revision 1.5  2007/11/20 09:05:36  atripathi
 *  null check added for BCC_ADDRESS
 *
 *  Revision 1.4  2006/11/21 18:28:42  aarora
 *  Now getting bcc address from app properties
 *
 *  Revision 1.3  2006/10/09 12:15:33  dkumar
 *  created seperate FDSuite properties
 *
 *  Revision 1.2  2006/07/18 23:43:02  aarora
 *  Simplified a comment
 *
 *  Revision 1.1  2006/03/29 23:57:54  aarora
 *  new files into fdcommons
 *
 *  Revision 1.8  2006/03/29 23:33:33  ranand
 *  removed dependancy on CommunicationMethod model
 *
 *  Revision 1.7  2006/03/28 21:23:01  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.6  2005/07/27 09:31:30  ranand
 *  Class name changed from LcpProperties to ApplicationProperties
 *
 *  Revision 1.5  2005/07/15 22:53:59  amrinder
 *  Trying to load configProperties just once
 *
 *  Revision 1.4  2005/01/24 06:59:25  pjain
 *  removed footer
 *
 *  Revision 1.3  2005/01/21 13:54:58  pjain
 *  moved footer to implementing classes
 *
 *  Revision 1.2  2004/10/11 11:14:19  asaxena
 *  set teh content type of the mail body
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdcommons;

import java.util.ArrayList;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Properties;
import java.util.StringTokenizer;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.codec.binary.Base64;
import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.FDSuiteProperties;
import com.freightdesk.fdcommons.LcpApplicationException;

/**
 * Send E-Mail messages.
 * 
 * @author Ajeet Sachan
 * @author Amrinder Arora
 * @author Amit Tripathi
 */
public class EmailSender
{
    /** The standard FROM_ADDRESS */
    public static InternetAddress FROM_ADDRESS = null;

    /** The standard BCC_ADDRESS */
    public static InternetAddress BCC_ADDRESS = null;

    /** Default system admin email.  A value specified in Application Properties overrides
     * this value.  Default value is used only if no sys ad email is set in ApplicationProperties. */
    public final static String DEFAULT_SYS_AD_EMAIL = "system@ntelx.com";

    /** Instance of this "pseudo-singleton".  It is pseudo singleton, because the public
     * constructor cannot be removed due to backward compatibility reasons. */
    public static EmailSender _instance = null;

    /** A logger */
    protected static Logger logger = Logger.getLogger(EmailSender.class);

    /** Configuration properties used to create connection */
    private static Properties configProperties = new Properties();

    static {
        try {
            String fromAddressStr = FDSuiteProperties.getProperty("SENDER_EMAIL_ADDRESS");
            FROM_ADDRESS = new InternetAddress(fromAddressStr);
        } catch (Exception e) {
            logger.warn("From address could not be set correctly", e);
        }
        try {
            String bccAddressStr = ApplicationProperties.getProperty("BCC_ADDRESS");
            if ((bccAddressStr != null) && (bccAddressStr.trim().length() > 0)) {
                BCC_ADDRESS = new InternetAddress(bccAddressStr);
            }
        } catch (Exception e) {
            logger.warn("BCC address could not be set correctly", e);
        }
        // Gets the smtp address from application deployment properties 
        // and sets it on the local Properties object
        configProperties.put("mail.smtp.host", FDSuiteProperties.getProperty("SMTP_HOST"));
        logger.debug("mail.smtp.host: " + configProperties.get("mail.smtp.host"));
        
        // add authentication parameters
        configProperties.put("mail.smtp.auth", FDSuiteProperties.getProperty("SMTP_AUTH"));
        configProperties.put("mail.smtp.username", FDSuiteProperties.getProperty("SMTP_USER"));
        configProperties.put("mail.smtp.password", new String(Base64.decodeBase64(FDSuiteProperties.getProperty("SMTP_ENCODED_PASS").getBytes())));
        
        logger.debug("mail.smtp.auth: " + configProperties.get("mail.smtp.auth"));
    }

    /**
     * gets instance of EmailSender class
     * @return EmailSender
     */
    public static EmailSender getInstance()
    {
        if (_instance == null) {
            _instance = new EmailSender();
        }
        return _instance;
    }
    
    public static void reset() {
    	_instance = null;
    }

    /** Creates an instance */
    public EmailSender()
    {
    }

    /**
     * Sends mail message to the specified recipients.  The list of recipients can be comma
     * or semicolon delimited.
     *  
     * <br/><b>Warning:</b> 
     * <OL>
     * <LI>Passing parametes should not be null, except the subject.
     * <LI>It only sends messages without attachments.
     * </OL>
     */
    public void sendMail(String recipients, String subject, StringBuffer body)
        throws LcpApplicationException
    {
        logger.info("sendMail(): begin, to: " + recipients);

        // Tests primary condition
        if (recipients == null || "".equals(recipients.trim())) {
            logger.warn("Target address is not defined.  No emails sent.");
            return;
        }
        // Tests secondary condition
        if (body == null || "".equals(body.toString().trim())) {
            if (subject == null || "".equals(subject.trim())) {
                logger.warn("Both body and subject is empty, no emails sent");
                return;
            }
        }

        try {
            // Parses the recipients from the given recipients string, tokenizing on comma, semicolon
            List recipientsList = new ArrayList();
            StringTokenizer st = new StringTokenizer(recipients, ",; ");
            while (st.hasMoreTokens()) {
                String recipient = st.nextToken();
                recipientsList.add(recipient);
                logger.debug("recipient: " + recipient);
            }

            Iterator recipientsIterator = recipientsList.iterator();

            // Loops on each recipient, and sends a Mime message
            while (recipientsIterator.hasNext()) {
                //Set addressTo information
                InternetAddress toAddress = new InternetAddress((String) recipientsIterator.next());

                // get the default Session
                Session session = Session.getDefaultInstance(configProperties, null);
                session.setDebug(false);

                // create a message
                Message msg = new MimeMessage(session);

                // set the from and to address
                msg.setFrom(FROM_ADDRESS);
                msg.setRecipient(Message.RecipientType.TO, toAddress);
                if (BCC_ADDRESS != null) {
                    msg.setRecipient(Message.RecipientType.BCC, BCC_ADDRESS);
                }

                // Optional : We can also set our custom headers in the Email if we Want
                // msg.addHeader("MyHeaderName", "myHeaderValue");
                // To show the mail having high/low importance for Microsoft Outlook and Outlook Expres only.
                // msg.setHeader("X-Priority", "High");
                msg.setSentDate(new Date());

                // Setting the Subject and Content Type
                msg.setSubject(subject);
                msg.setContent(body.toString(), "text/html;charset=\"UTF-8\"");
                //Send message
                Transport.send(msg);
                logger.debug("Message sent on date: " + msg.getSentDate() + ", received on date: " + msg.getReceivedDate());
            }
        } catch (MessagingException msgExp) {
            logger.error("Error occurred during sendMail", msgExp);
            throw new LcpApplicationException("Error occurred during sendMail", msgExp);
        }
    }
}
