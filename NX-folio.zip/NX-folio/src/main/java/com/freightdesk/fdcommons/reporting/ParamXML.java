/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/reporting/ParamXML.java,v 1.1 2006/06/21 11:20:25 dkumar Exp $
 * 
 *  Modification History:
 *  $Log: ParamXML.java,v $
 *  Revision 1.1  2006/06/21 11:20:25  dkumar
 *  repackaging of ReportUtility to FDCommons
 *
 *  Revision 1.2  2006/02/24 21:31:49  ranand
 *  Code Merged from Nafith branch
 *
 *  Revision 1.1.2.1  2005/11/28 13:00:05  ranand
 *  added new parameter
 *
 *  Revision 1.1  2004/09/15 13:36:28  asingh
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdcommons.reporting;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;

@XmlAccessorType(XmlAccessType.NONE)
public class ParamXML {
	@XmlElement(name="NAME")
	private String name;

	@XmlElement(name="TYPE")
	private String type;

	@XmlElement(name="LABEL")
	private String label;

	@XmlElement(name="VALUE")
	private String value;

	public String getName() {
		return name;
	}

	public String getType() {
		return type;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getValue() {
		if (value != null && value.equalsIgnoreCase("null"))
			return null;
		else
			return value;
	}

	public void setValue(String value) {
		this.value = value;
	}
}
