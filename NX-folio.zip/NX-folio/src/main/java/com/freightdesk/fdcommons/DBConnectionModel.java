/** 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/DBConnectionModel.java,v 1.6.2.1 2009/07/28 18:55:39 cdoan Exp $ 
 * 
 *  Modification History:
 *  $Log: DBConnectionModel.java,v $
 *  Revision 1.6.2.1  2009/07/28 18:55:39  cdoan
 *  Additional classes for Monitor
 *
 *  Revision 1.6  2009/03/10 09:19:10  narora
 *  Minor change in getConnection method.
 *
 *  Revision 1.5  2008/11/19 06:34:14  atripathi
 *  getInstance method signature changed in ConnectionPool class and used here.
 *
 *  Revision 1.4  2008/11/17 22:06:08  nsehra
 *  we were doing password decryption but never used that variable. Fixed
 *
 *  Revision 1.3  2008/10/17 06:57:48  atripathi
 *  ConnectionPooling implemented for watchPointDB.
 *
 *  Revision 1.2  2008/07/17 07:11:53  narora
 *  Comments added.
 *
 *  Revision 1.1  2008/07/16 08:33:06  narora
 *  first version
 *
 */

package com.freightdesk.fdcommons;

import java.io.Serializable;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import org.apache.log4j.Logger;

/**
 * The DBConnectionModel class is used for storing connection specific details and establishing connection.
 * Also, object of this class is bind in NamingContext for registering Monitor WatchPoints. 
 * 
 * @author Nipun Arora
 */
public class DBConnectionModel implements Serializable
{

    private static final long serialVersionUID = 1L;

    private static Logger logger = Logger.getLogger ("com.freightdesk.fdcommons.DBConnectionModel");
    
    private String sourceSubType;    
    
    private String sourceURI;    
    
    private String userName;    
    
    private String password;
    
    private long maxConnection;
    
    private long maxIdleTime;
    
    public String getSourceSubType() {
        return sourceSubType;
    }
    
    public void setSourceSubType(String sourceSubType) {
        this.sourceSubType = sourceSubType;
    }
    
    public String getSourceURI() {
        return sourceURI;
    }
    
    public void setSourceURI(String sourceURI) {
        this.sourceURI = sourceURI;
    }
    
    public String getUserName() {
        return userName;
    }
    
    public void setUserName(String userName) {
        this.userName = userName;
    }
    
    public String getPassword() {
        return password;
    }
    
    public void setPassword(String password) {
        this.password = password;
    }
    
    public Connection getConnection() throws SQLException{
        logger.debug("getConnection(): begin");
        Connection conn = null ;
        String pswd = new String(password);
        try {
            if (pswd != null)
            {
                EncryptionManager manager = new EncryptionManager();
                byte[] b = manager.decrypt(pswd.getBytes());
                pswd = new String(b);
            }     
            ConnectionPool connectionPool = ConnectionPool.getInstance(sourceURI, sourceSubType, userName, pswd, maxConnection, maxIdleTime, false);
            conn = connectionPool.checkOut(sourceURI, userName, pswd, sourceSubType);
            if (conn ==  null){
                if (LcpConstants.WatchPointSubSourceType.ORACLE.equalsIgnoreCase(sourceSubType))
                    Class.forName("oracle.jdbc.driver.OracleDriver");
                else if (LcpConstants.WatchPointSubSourceType.MYSQL.equalsIgnoreCase(sourceSubType))
                    Class.forName ("com.mysql.jdbc.Driver");
                else if (LcpConstants.WatchPointSubSourceType.SQLSERVER.equalsIgnoreCase(sourceSubType))
                    Class.forName ("com.microsoft.jdbc.sqlserver.SQLServerDriver");
                conn = DriverManager.getConnection(sourceURI, userName, pswd);
            }
            return conn ;
        } catch (SQLException e) {
            logger.error("Exception in getConnection(): ",e);
            throw e;
        } catch (Exception e) {
            logger.error(e);
            throw new RuntimeException(e);
        }
    }

    public long getMaxConnection()
    {
        return maxConnection;
    }

    public void setMaxConnection(long maxConnection)
    {
        this.maxConnection = maxConnection;
    }

    public long getMaxIdleTime()
    {
        return maxIdleTime;
    }

    public void setMaxIdleTime(long maxIdleTime)
    {
        this.maxIdleTime = maxIdleTime;
    }   
}

