/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/LicenseProperties.java,v 1.1.2.1 2007/05/18 18:52:00 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: LicenseProperties.java,v $
 *  Revision 1.1.2.1  2007/05/18 18:52:00  mechevarria
 *  merge with main branch
 *
 *  Revision 1.2  2007/04/12 16:36:25  dkumar
 *  major changes, using hashmap in place of Property inner object
 *
 *  Revision 1.1  2006/07/04 15:47:26  dkumar
 *  repackaged to fdcommons
 *
 *  Revision 1.4  2006/05/23 22:18:16  aarora
 *  Added a method to see if a product is licensed
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 * 
 */


package com.freightdesk.fdcommons;

import java.sql.Timestamp;
import java.util.HashMap;
import java.util.Map;

/**
 * Encapsulates the FDSuite License properties.
 *
 * Implemented as a singleton, and only allows a visiting
 * BootstrapServlet to initialize it.
 *
 * @author  Biju Joseph
 * @author  Deepak Kumar
 * @version 3.4.2
 */
public class LicenseProperties 
{
    // Extensions added to product name for LicenseProperties
    public static final String LIC_ENABLED_EXT = ".isEnabled";
    public static final String LIC_EXP_DATE_EXT = ".expirationDate";
    public static final String LIC_TYPE_EXT = ".licenseType";
   
    /**
     * The (only) instance of this Singleton
     */
    protected static LicenseProperties _instance;

    /**
     * The interal data structure used to store the properties
     */
    private Map inner;

    /**
     * Gets the property using the given key
     * @param key The key for the mapping
     * @return The property corresponding to the key
     */
    public static Object get (String key) {
        return getInstance().inner.get(key);
    }

    /**
     * Only constructor is declared private.
     */
    private LicenseProperties() {
        inner = new HashMap();
    }

    /**
     * The getInstance() method for this Singleton.
     * Creates an instance if necessary.
     */
    public static LicenseProperties getInstance() {
        if (_instance == null) {
            _instance = new LicenseProperties();
        }
        return _instance;
    }
    
    /**
     * Clear the License Properties.
     */
    public static void clear()
    {
        getInstance().inner.clear();
    }
    
    /**
     * Evaluates the License of the product and also checks if it has expired.
     * @param productName
     * @return
     */
    public static boolean isProductLicensed(String productName)
    {
        boolean isLicensed = false;
        boolean isEnabled = false;
        
        if(get(productName+LIC_ENABLED_EXT)!= null)
        {
            isEnabled = ((Boolean) get(productName+LIC_ENABLED_EXT)).booleanValue();
        }

        if (isEnabled)
        {
            Timestamp expDate = (Timestamp) get(productName+LIC_EXP_DATE_EXT);
            isLicensed = expDate.after(new Timestamp(System.currentTimeMillis()));
        }
        return isLicensed;
    }
    
    public Object put(String key, Object value)
    {
        return getInstance().inner.put(key,value);
    }
}
