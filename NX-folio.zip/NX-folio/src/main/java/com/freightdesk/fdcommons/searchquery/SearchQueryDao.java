/**
 * Copyright (c) 2000-2002 NTELX
 *  All rights reserved. 
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with NTELX. 
 *
 *
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/searchquery/SearchQueryDao.java,v 1.5 2007/08/23 11:45:47 atripathi Exp $
 *
 *  Modification History:
 *  $Log: SearchQueryDao.java,v $
 *  Revision 1.5  2007/08/23 11:45:47  atripathi
 *  changed retrieveSearchQuery method for userid and domainaname.
 *
 *  Revision 1.4  2007/08/22 11:28:34  atripathi
 *  METHODS FOR DELETE, DELETE ALL, AND SEARCHQUERIES BY USER ADDED.
 *
 *  Revision 1.3  2007/08/10 18:52:05  ranand
 *  sequence dattype chanegd to int
 *
 *  Revision 1.2  2007/08/07 19:53:11  ranand
 *  SearchQueryModel
 *
 *  Revision 1.1  2007/07/30 23:25:11  ranand
 *  Added for save Search Query framework
 *
 */

package com.freightdesk.fdcommons.searchquery;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.ConnectionUtil;


/**
 * 
 * Data Access Object for SearchQuery.
 * 
 * @author Rajender Anand
 *
 */
public class SearchQueryDao extends BaseDao
{

    /**
     * save SearchQueryModel to the DB.
     * 
     * @param searchQueryModel
     */
    public void createSearchQuery(SearchQueryModel searchQueryModel)
        throws Exception
    {
        logger.debug("saveSearchQuery(): begin");
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String query = "INSERT INTO SEARCHQUERY (SEARCHQUERYID, QUERY, COUNTQUERY, NAME, OBJECTTYPE, CREATEUSERID, CREATETIMESTAMP, LASTUPDATEUSERID, "
                + " LASTUPDATETIMESTAMP, DOMAINNAME) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        
        
        try {
            long queryId = getNextID("SEARCHQUERYID");
            connection = ConnectionUtil.getConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setLong(1, queryId);
            preparedStatement.setString(2, searchQueryModel.getQuery());
            preparedStatement.setString(3, searchQueryModel.getCountQuery());
            preparedStatement.setString(4, searchQueryModel.getName());
            preparedStatement.setString(5, searchQueryModel.getObjectType());
            preparedStatement.setString(6, searchQueryModel.getCreateUserId());
            preparedStatement.setTimestamp(7, searchQueryModel.getCreateTimestamp());
            preparedStatement.setString(8, searchQueryModel.getLastUpdateUserId());
            preparedStatement.setTimestamp(9, searchQueryModel.getLastUpdateTimestamp());
            preparedStatement.setString(10, searchQueryModel.getDomainName());
            preparedStatement.execute();
            
            createQueryParam(searchQueryModel.getQueryParam(), queryId);
            
            logger.debug("saveSearchQuery(): end");
        } catch (SQLException sql) {
            logger.error("Exception in saveSearchQuery(): ", sql);
            throw sql;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, null);
        }
    }

    /**
     * Retrievs SearchQuery for given User, Object Type and Domain.
     * 
     * @param searchQueryModel
     */
    public List retrieveSearchQuery(String objectType, String userId, String domainName)
        throws Exception
    {
        logger.debug("retrieveSearchQuery(): begin");
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        List searchQueryList = new ArrayList();

        String query = "SELECT SEARCHQUERYID, QUERY, COUNTQUERY, NAME FROM SEARCHQUERY WHERE OBJECTTYPE = ?  AND CREATEUSERID = ? AND DOMAINNAME = ?";

        try {
            connection = ConnectionUtil.getConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setString(1, objectType);
            preparedStatement.setString(2, userId);
            preparedStatement.setString(3, domainName);
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                SearchQueryModel model = new SearchQueryModel();
                model.setSearchQueryId(rs.getLong(1));
                model.setQuery(rs.getString(2));
                model.setCountQuery(rs.getString(3));
                model.setName(rs.getString(4));
                searchQueryList.add(model);
            }

            logger.debug("retrieveSearchQuery(): end");
        } catch (SQLException sql) {
            logger.error("Exception in retrieveSearchQuery(): ", sql);
            throw sql;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, rs);
        }
        return searchQueryList;
    }
    
    /**
     * Retrievs SearchQuery for given User and Domain.
     * 
     * @param searchQueryModel
     */
    public List retrieveSearchQuery(String userId, String domainName)
        throws Exception
    {
        logger.debug("retrieveSearchQuery(): begin");
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        List searchQueryList = new ArrayList();

        String query = "SELECT SEARCHQUERYID, QUERY, COUNTQUERY, NAME, OBJECTTYPE,CREATETIMESTAMP FROM SEARCHQUERY WHERE CREATEUSERID = ? AND DOMAINNAME = ? ORDER BY OBJECTTYPE,NAME";

        try {
            connection = ConnectionUtil.getConnection();
            preparedStatement = connection.prepareStatement(query);            
            preparedStatement.setString(1, userId);
            preparedStatement.setString(2, domainName);
            rs = preparedStatement.executeQuery();

            while (rs.next()) {
                SearchQueryModel model = new SearchQueryModel();
                model.setSearchQueryId(rs.getLong(1));
                model.setQuery(rs.getString(2));
                model.setCountQuery(rs.getString(3));
                model.setName(rs.getString(4));
                model.setObjectType(rs.getString(5));
                model.setCreateTimestamp(rs.getTimestamp(6));
                searchQueryList.add(model);
            }

            logger.debug("retrieveSearchQuery(): end");
        } catch (SQLException sql) {
            logger.error("Exception in retrieveSearchQuery(): ", sql);
            throw sql;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, rs);
        }
        return searchQueryList;
    }

    /**
     * Deletes the searchQuery.
     * 
     * @param searchQueryId
     */
    public void delete(long searchQueryId)
        throws Exception
    {
        logger.debug("delete(): begin");
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        String query = "DELETE FROM  SEARCHQUERY WHERE SEARCHQUERYID = ?";

        try {
            connection = ConnectionUtil.getConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setLong(1, searchQueryId);
            preparedStatement.execute();
            logger.debug("delete(): end");
        } catch (SQLException sql) {
            logger.error("Exception in delete(): ", sql);
            throw sql;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, null);
        }
    }
    
    /**
     * Deletes all the searchQueries.
     * 
     * 
     */
    public void deleteAll(String userId, String domainName)
        throws Exception
    {
        logger.debug("deleteAll(): begin");
        Connection connection = null;
        PreparedStatement preparedStatement = null;

        String query = "DELETE FROM  SEARCHQUERY where CREATEUSERID = ? AND DOMAINNAME = ?";

        try {
            connection = ConnectionUtil.getConnection();
            preparedStatement = connection.prepareStatement(query); 
            preparedStatement.setString(1,userId);
            preparedStatement.setString(2,domainName);
            preparedStatement.execute();
            logger.debug("deleteAll(): end");
        } catch (SQLException sql) {
            logger.error("Exception in deleteAll(): ", sql);
            throw sql;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, null);
        }
    }
    
    /**
     * Creates SerachQueryParam.
     * 
     * @param params
     * @param searchQueryId
     * @throws Exception
     */
    private void createQueryParam(List params, long searchQueryId) throws Exception
    {

        logger.debug("createQueryParam(): begin");
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        String query = "INSERT INTO SEARCHQUERYPARAM (SEARCHQUERYPARAMID, SEARCHQUERYID, PARAMVALUE, SEQUENCE, CREATEUSERID, CREATETIMESTAMP, LASTUPDATEUSERID, "
                + " LASTUPDATETIMESTAMP, DOMAINNAME) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try {
            connection = ConnectionUtil.getConnection();
            preparedStatement = connection.prepareStatement(query);

            for (int i = 0; i < params.size(); i++) {
                long queryParamId = getNextID("SEARCHQUERYPARAMID");
                SearchQueryParam queryParam = (SearchQueryParam) params.get(i);
                
                preparedStatement.setLong(1, queryParamId);
                preparedStatement.setLong(2, searchQueryId);
                preparedStatement.setString(3, queryParam.getParamValue());
                preparedStatement.setInt(4, queryParam.getSequence());
                preparedStatement.setString(5, queryParam.getCreateUserId());
                preparedStatement.setTimestamp(6, queryParam.getCreateTimestamp());
                preparedStatement.setString(7, queryParam.getLastUpdateUserId());
                preparedStatement.setTimestamp(8, queryParam.getLastUpdateTimestamp());
                preparedStatement.setString(9, queryParam.getDomainName());
                preparedStatement.execute();
            }
            logger.debug("createQueryParam(): end");
        } catch (SQLException sql) {
            logger.error("Exception in saveSearchQuery(): ", sql);
            throw sql;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, null);
        }
    }
    
    /**
     * retrieves SerachQueryParam List.
     * 
     * @param params
     * @param searchQueryId
     * @throws Exception
     */
    public List retrieveQueryParam(long searchQueryId) throws Exception
    {

        logger.debug("retrieveQueryParam(): begin");
        Connection connection = null;
        PreparedStatement preparedStatement = null;
        ResultSet rs = null;
        List queryParamList = new ArrayList();
        
        String query = "SELECT SEARCHQUERYPARAMID, SEARCHQUERYID, PARAMVALUE, SEQUENCE  FROM SEARCHQUERYPARAM  WHERE SEARCHQUERYID = ? ORDER BY SEQUENCE ASC";

        try {
            connection = ConnectionUtil.getConnection();
            preparedStatement = connection.prepareStatement(query);
            preparedStatement.setLong(1, searchQueryId);
            rs = preparedStatement.executeQuery();
            
            while(rs.next()) {
                SearchQueryParam queryParam = new SearchQueryParam();
                queryParam.setSearchQueryParamId(rs.getLong(1));
                queryParam.setSearchQueryId(rs.getLong(2));
                queryParam.setParamValue(rs.getString(3));
                queryParam.setSequence(rs.getInt(4));
                
                queryParamList.add(queryParam);
            }
            
            logger.debug("retrieveQueryParam(): end");
        } catch (SQLException sql) {
            logger.error("Exception in saveSearchQuery(): ", sql);
            throw sql;
        } finally {
            ConnectionUtil.closeResources(connection, preparedStatement, rs);
        }
        return queryParamList;
    }
    
}