/** 
* Copyright (c) 2000-2002 NTELX 
*  All rights reserved. 
* 
* This software is the confidential and proprietary information of NTELX 
* ("Confidential Information").  You shall not disclose such Confidential Information 
* and shall use it only in accordance with the terms of the license agreement you entered 
* into with NTELX. 
* 
* 
*  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/ConfigurationProperties.java,v 1.1 2006/10/27 10:05:15 ranand Exp $ 
* 
*  Modification History:
*  $Log: ConfigurationProperties.java,v $
*  Revision 1.1  2006/10/27 10:05:15  ranand
*  Added to read XML properties file
*
*/

package com.freightdesk.fdcommons;

import java.util.List;

/**
 * 
 * This class contains list of properties grouped in 
 * different categories to configure the 
 * application.
 * 
 * @author Rajender Anand
 *
 */
public class ConfigurationProperties
{

    List categoryList;

    /**
     * @return Returns the categoryList.
     */
    public List getCategoryList()
    {
        return categoryList;
    }

    /**
     * @param categoryList The categoryList to set.
     */
    public void setCategoryList(List categoryList)
    {
        this.categoryList = categoryList;
    }

}
