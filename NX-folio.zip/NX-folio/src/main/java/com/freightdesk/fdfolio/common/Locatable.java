 /** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/common/Locatable.java,v 1.1.8.1 2010/08/22 23:08:26 mechevarria Exp $ 
 * 
 *  Modification History:
 *  $Log: Locatable.java,v $
 *  Revision 1.1.8.1  2010/08/22 23:08:26  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.1  2005/04/14 12:39:59  dkhoker
 *  Interface for Locatable Objects
 *
 */
 package com.freightdesk.fdfolio.common;

 /**
  * @author Devendra Khoker
  * Interface for objects Locatable on the map
  * 
  */
public interface Locatable {

	/**
	 * Gets latitude of the Locatable object
	 * @return
	 */
	public double getLatitude();

	/**
	 * Gets longitude of the Locatable object 
	 * @return
	 */
	public double getLongitude();

	/**
	 * Gets description of the Locatable object
	 * @return
	 */
	public String getDescription();
}
