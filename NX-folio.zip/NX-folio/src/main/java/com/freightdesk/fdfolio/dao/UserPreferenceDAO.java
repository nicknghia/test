/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/dao/UserPreferenceDAO.java,v 1.7.4.3 2010/10/01 19:57:26 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: UserPreferenceDAO.java,v $
 *  Revision 1.7.4.3  2010/10/01 19:57:26  mechevarria
 *  jboss6 upgrade
 *
 *  Revision 1.7.4.2  2010/08/22 23:08:29  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.7.4.1  2008/06/03 12:39:04  mechevarria
 *  gov_solutions merge updates
 *
 *  Revision 1.9  2007/05/22 06:15:26  atripathi
 *  DAO moved to hibernate 3.
 *
 *  Revision 1.8  2007/04/25 08:44:25  atripathi
 *  moved to hibernate 3
 *
 *  Revision 1.7  2006/04/20 15:10:38  dkumar
 *  added check before calling executeQueryForDelete in delete methods
 *
 *  Revision 1.6  2006/03/28 21:28:06  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.5  2006/03/28 21:22:59  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.4  2006/03/16 15:37:02  dkumar
 *  changed Exception message
 *
 *  Revision 1.3  2006/03/13 14:26:16  dkumar
 *  changed executeQueryForDelete to use CriteriaQuery for retrieving the objects to be deleted.
 *
 *  Revision 1.2  2006/03/10 06:38:55  dkumar
 *  Modified to use Hibernate in place of JDBC to access Database
 *
 *  Revision 1.1  2005/08/20 12:30:16  pjain
 *  centralized DAO package
 *
 *  Revision 1.3  2005/06/15 12:00:36  ranand
 *  delete method calls to Base DAO delete method
 *
 *  Revision 1.2  2004/10/20 04:01:21  amrinder
 *  Changed some logging and the constructor need not throw a NamingException anymore
 *
 *  Revision 1.1  2004/09/15 13:07:11  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdfolio.dao;




import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;

import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.UserPreferenceModel;
import com.freightdesk.fdfolio.common.SessionFactoryUtil;



/**
 * Data access class for retrieving, creating, updating and deleting User Preference data.
 *  @author Sangeeta Taneja
 */
public class UserPreferenceDAO extends BaseDao {

    public UserPreferenceDAO() {
        super();
    }

    /**
     * Persists the UserPreferenceModel into the DB.  
     * @param userPreferenceModel The UserPreferenceModel to be persisted in the DB
     * @return UserPreferenceModel 
     */
    public UserPreferenceModel create(UserPreferenceModel userPreferenceModel) throws SQLException {
       
    	logger.debug("create(): begin");
        Session session = null;
        try {
       		session = SessionFactoryUtil.getSession();
            session.save(userPreferenceModel);
            session.flush();
        }
        catch (Exception e) {
    	    logger.error("Exception in create()", e);
            throw new SQLException(e.toString());
        }
        finally {
    	    SessionFactoryUtil.closeSession (session);
        }
      
        return userPreferenceModel;
    }

	  /** Deletes the preference of the user.  
		* @param userPreferenceModel 
		* @exception SQLException 
		*/
    public void delete(UserPreferenceModel userPreferenceModel) throws SQLException {
        if(userPreferenceModel.getUserPreferenceId()!=-1)
        	this.executeQueryForDelete(userPreferenceModel.getUserPreferenceId(),-1,null);
    }

	/** Deletes the preference of the user.  
	 * @param userPreferenceId 
	 * @exception SQLException 
	 */
    public void delete(long userPreferenceId) throws SQLException {
       if(userPreferenceId!=-1)
    	   this.executeQueryForDelete(userPreferenceId,-1,null);
    }

    /**
     * Updates UserPreference data using the provided UserPreferenceModel.
     *
     * @param userPreferenceModel The updated UserPreferenceModel object that has the updated data.
     */
    public void update(UserPreferenceModel userPreferenceModel)  throws SQLException {
       
    	logger.debug("update(): begin");
        Session session = null;
        try {
            session = SessionFactoryUtil.getSession();
            session.update(userPreferenceModel);
            session.flush();
        }
        catch (Exception e) {
            logger.error("Exception in update():", e);
            throw new SQLException(e.toString());
        }
        finally {
            SessionFactoryUtil.closeSession (session);
        }
    }

    /**
     * Retrieves a UserPreference model from the DB given the userPreferenceId
     * @param userPreferenceId The primary key for the data
     * @return UserPreferenceModel representing the data from the DB
     */
    public UserPreferenceModel retrieve(long userPreferenceId)
        throws SQLException {
       
       	return (UserPreferenceModel)(this.executeQueryForRetrieve(userPreferenceId,-1)).get(0);
    }

    /**
     * Retrieves a Map of PreferenceCode and PreferenceValueList.
     * @param systemUserId
     * @return Map of PreferenceCode and PreferenceValueList
     */
    public Map retrieveAllByUserId (long systemUserId)
        throws SQLException {
    	Map preferenceMap = new HashMap();
    	List userPreferenceModelList= null;
    	List preferenceValueList = null;
    	
      	userPreferenceModelList=this.executeQueryForRetrieve( -1,systemUserId);
    	for(Iterator it=userPreferenceModelList.iterator();it.hasNext();) {
			UserPreferenceModel userPreferenceModel =(UserPreferenceModel)it.next();
    		String preferenceCode = userPreferenceModel.getPreferenceCode();		
			preferenceValueList = preferenceMap.containsKey(preferenceCode)?(List)preferenceMap.get(preferenceCode):new ArrayList();
			preferenceValueList.add(userPreferenceModel);
			if (!preferenceMap.containsKey(preferenceCode)) {
				preferenceMap.put(preferenceCode,preferenceValueList);
			}
		}
    	
        return preferenceMap;
    }
    
    
	/**
	 * Retrieves List of all preferences for the user.
	 * @param systemUserId
	 * @return List of prerferences
	 */
	public List<UserPreferenceModel> retrieveAllPreferencesByUserId (long systemUserId)
		throws SQLException {
		List<UserPreferenceModel> preferenceValueList = new ArrayList<UserPreferenceModel>();
		preferenceValueList=this.executeQueryForRetrieve(-1,systemUserId);
		return preferenceValueList;
	}


	/**
	 * Deletes all preferences of the user. 
	 * @param systemUserId The user id of the user.
	 */
    
	public void deleteAllByUserId(long systemUserId) throws SQLException {
		if(systemUserId!=-1)
			this.executeQueryForDelete(-1,systemUserId,null);
	}

	/**
	 * Deletes all userPreferences for the given preferenceCode. 
	 * @param systemUserId The user id of the user.
	 * @param preferenceCode Type of preference
	 */
	public void deleteAllUserPreferencesByCode(long systemUserId,String preferenceCode) throws SQLException {
		if((systemUserId!=-1)&&(preferenceCode!=null))
			this.executeQueryForDelete(-1,systemUserId,preferenceCode);
	}
 
	
	
	@SuppressWarnings("unchecked")
	private List<UserPreferenceModel> executeQueryForRetrieve (long userPreferenceId,long systemUserId)throws SQLException {
		logger.info("executeQueryForRetrieve(): begin");
        List<UserPreferenceModel> userPreferenceModelList = null;
        Session session = null;
        try {
            // Gets the Session Instance
            session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(UserPreferenceModel.class);
            if (userPreferenceId != -1)
                criteria.add( Restrictions.eq("userPreferenceId", new Long(userPreferenceId)));
            if (systemUserId != -1)
                criteria.add( Restrictions.eq("systemUserId", new Long(systemUserId)));
            userPreferenceModelList = criteria.list();
        }
        catch (Exception e) {
            logger.error("Error during retrieval",e);
            throw new SQLException(e.toString());
        }
        finally {
            SessionFactoryUtil.closeSession(session);
        }  
        return userPreferenceModelList;
    }
	
	
	/**
	 * Deletes all userPreferences for the given userPreferenceId or systemUserId and/or preferenceCode
	 * @param userPreferenceId The Id of userPreference
	 * @param systemUserId The user id of the user.
	 * @param preferenceCode Type of preference
	 */
	private void executeQueryForDelete(long userPreferenceId,long systemUserId,String preferenceCode)throws SQLException {
		logger.info("executeQueryForDelete() : begin");
	
		Session session = null;
	    List userPreferenceModelList = null;
        try {
            // Gets the Session Instance
            session = SessionFactoryUtil.getSession();
            Criteria criteria = session.createCriteria(UserPreferenceModel.class);
            if (userPreferenceId != -1)
                criteria.add( Restrictions.eq("userPreferenceId", new Long(userPreferenceId)));
            if (systemUserId != -1)
                criteria.add( Restrictions.eq("systemUserId", new Long(systemUserId)));
            if (preferenceCode!=null)
            	criteria.add( Restrictions.eq("preferenceCode", preferenceCode));
            userPreferenceModelList = criteria.list();
            
            Transaction tx = session.beginTransaction();
            for(Iterator i=userPreferenceModelList.iterator(); i.hasNext() ;) {
            	session.delete((UserPreferenceModel)i.next());            	
            }
            tx.commit();
        }
		catch (Exception e) {
            logger.error("Error during Deleting :",e);
            throw new SQLException(e.toString());
        }
        finally {
            SessionFactoryUtil.closeSession(session);
        }  
	}

}
	