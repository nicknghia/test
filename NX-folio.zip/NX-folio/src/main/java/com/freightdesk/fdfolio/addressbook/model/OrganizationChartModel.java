/**
 * Copyright (c) NTELX All rights reserved.
 * 
 * This software is the confidential and proprietary information of FreightDesk
 * Technologies, LLC ("Confidential Information"). You shall not disclose such
 * Confidential Information and shall use it only in accordance with the terms
 * of the license agreement you entered into with NTELX.
 * 
 * 
 * $Header:
 * /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/addressbook/model/OrganizationChartModel.java,v
 * 1.3 2008/09/11 16:03:02 fdoughty Exp $
 * 
 * Modification History: $Log: OrganizationChartModel.java,v $
 * Modification History: Revision 1.4  2008/10/23 08:18:47  atripathi
 * Modification History: previous changes rolled back, the changes should have been committed to OAS branch if this functionality was not needed.
 * Modification History: Revision 1.3
 * 2008/09/11 16:03:02 fdoughty *** empty log message ***
 * 
 * Revision 1.2 2008/08/15 15:34:17 fdoughty *** empty log message ***
 * 
 * Revision 1.1 2007/06/26 04:27:12 atripathi new model for viewing
 * orghjierarchy
 * 
 */
package com.freightdesk.fdfolio.addressbook.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class OrganizationChartModel implements Serializable
{
    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private long parentOrgId;

    private long orgId;

    private String orgName;

    private String orgHierarchyTypeCode;
    
    private String status;
    
    private List<OrganizationChartModel> childOrgChartModelList = new ArrayList<OrganizationChartModel>();

    public OrganizationChartModel()
    {

    }

    public OrganizationChartModel(String orgName)
    {
        this.orgName = orgName;
    }

    public OrganizationChartModel(String orgName, long orgId, long parentorgId, String orgHierarchyTypeCode, String status)
    {
        this.orgName = orgName;
        this.orgId = orgId;
        this.parentOrgId = parentorgId;
        this.orgHierarchyTypeCode = orgHierarchyTypeCode;
        this.status = status;
    }

    public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public String getOrgName()
    {
        return orgName;
    }

    public void setOrgName(String orgName)
    {
        this.orgName = orgName;
    }

    public long getParentOrgId()
    {
        return parentOrgId;
    }

    public void setParentOrgId(long parentOrgId)
    {
        this.parentOrgId = parentOrgId;
    }

    public List<OrganizationChartModel> getChildOrgChartModelList()
    {
        return childOrgChartModelList;
    }

    public void setChildOrgChartModelList(List<OrganizationChartModel> childOrgChartModelList)
    {
        this.childOrgChartModelList = childOrgChartModelList;
    }

    public long getOrgId()
    {
        return orgId;
    }

    public void setOrgId(long orgId)
    {
        this.orgId = orgId;
    }

	public String getOrgHierarchyTypeCode()
	{
		return orgHierarchyTypeCode;
	}

	public void setOrgHierarchyTypeCode(String orgHierarchyTypeCode)
	{
		this.orgHierarchyTypeCode = orgHierarchyTypeCode;
	}
}
