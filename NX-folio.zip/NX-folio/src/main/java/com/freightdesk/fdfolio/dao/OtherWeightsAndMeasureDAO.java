/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/dao/OtherWeightsAndMeasureDAO.java,v 1.2.6.2 2010/08/22 23:08:30 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: OtherWeightsAndMeasureDAO.java,v $
 *  Revision 1.2.6.2  2010/08/22 23:08:30  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.2.6.1  2010/03/15 14:45:11  mechevarria
 *  fix jdbc methods to use bind vars
 *
 *  Revision 1.2  2006/03/28 21:22:59  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.1  2005/08/20 12:30:16  pjain
 *  centralized DAO package
 *
 *  Revision 1.4  2005/06/15 11:24:26  ranand
 *  delete method calls to Base DAO delete method
 *
 *  Revision 1.3  2004/11/30 09:39:33  asingh
 *  1) Minimize log statements, changed level from INFO to DEBUG where necessary.
 *
 *  Revision 1.2  2004/11/10 10:25:30  biju
 *  method name changes + removal of NamingException
 *
 *  Revision 1.1  2004/09/23 13:41:20  ranand
 *  package changed from settlement to invoice
 *
 *  Revision 1.1  2004/09/15 13:20:00  ranand
 *  2.6 Baseline
 *
 * 
 */

package com.freightdesk.fdfolio.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.sql.Types;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdfolio.invoice.model.OtherWeightsAndMeasureModel;

/**
 * Data access class for retrieving, creating, updating and deleting otherweightsandmeasure data.
 *
 * @author Biju Joseph
 * @author Amrinder Arora
 */
public class OtherWeightsAndMeasureDAO extends BaseDao
{    

    /**
     * Persists the OtherWeightsAndMeasureModel into the DB.  It updates
     * the OtherWeightsAndMeasureModel with the otherWeightsAndMeasure ID obtained from the
     * DB sequence, and returns the updated otherWeightsAndMeasureModel.
     * Any prior value set in the primary key field is ignored.
     *
     * @param otherWeightsAndMeasureModel The otherWeightsAndMeasureModel to be persisted in the DB
     *
     * @return OtherWeightsAndMeasureModel updated with the otherWeightsAndMeasureID using the DB sequence
     */
    public OtherWeightsAndMeasureModel create(OtherWeightsAndMeasureModel otherWeightsAndMeasureModel) 
        throws SQLException
    {
        PreparedStatement pStmt = null;
        Connection connection = null;
        StringBuffer otherWeightsAndMeasureCreateDML = new StringBuffer("INSERT INTO OTHERWEIGHTSANDMEASURES(OTHERWEIGHTSANDMEASURESID,DOMAINOBJECTID,EVENTID");
        otherWeightsAndMeasureCreateDML.append(",INVOICELINEITEMID,MEASUREVALUETYPECODE,MEASUREVALUE,MEASUREVALUEQUALIFIER,MEASUREVALUEUOM,DOMAINOBJECTCODE");
        otherWeightsAndMeasureCreateDML.append(",CREATEUSERID,CREATETIMESTAMP,LASTUPDATEUSERID,LASTUPDATETIMESTAMP,DOMAINNAME, SHIPMENTID, INVOICEID, INVOICEDETAILID )");
        otherWeightsAndMeasureCreateDML.append("VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
        try
        {
            logger.debug ("create(otherWeightsAndMeasureModel)::begin. DQL: " + otherWeightsAndMeasureCreateDML.toString());
            connection = getConnection();
            pStmt = connection.prepareStatement(otherWeightsAndMeasureCreateDML.toString());
            if (otherWeightsAndMeasureModel.getOtherWeightsAndMeasureId() == 0)
            {
                otherWeightsAndMeasureModel.setOtherWeightsAndMeasureId(getNextID("OTHERWEIGHTSANDMEASURESID"));
            }
            pStmt.setLong(1, otherWeightsAndMeasureModel.getOtherWeightsAndMeasureId());
            if (otherWeightsAndMeasureModel.getDomainObjectId() != 0)
                pStmt.setLong(2, otherWeightsAndMeasureModel.getDomainObjectId());
            else
                pStmt.setNull(2, Types.NUMERIC);
            if (otherWeightsAndMeasureModel.getEventId() != 0)
                pStmt.setLong(3, otherWeightsAndMeasureModel.getEventId());
            else
                pStmt.setNull(3, Types.NUMERIC);
            if (otherWeightsAndMeasureModel.getInvoiceLineItemId() != 0)
                pStmt.setLong(4, otherWeightsAndMeasureModel.getInvoiceLineItemId());
            else
                pStmt.setNull(4, Types.NUMERIC);
            pStmt.setString(5, otherWeightsAndMeasureModel.getMeasureTypeCode());
            pStmt.setDouble(6, otherWeightsAndMeasureModel.getMeasureValue());
            pStmt.setString(7, otherWeightsAndMeasureModel.getMeasureQualifer());
            pStmt.setString(8, otherWeightsAndMeasureModel.getUnitOfMeasure());
            pStmt.setString(9, otherWeightsAndMeasureModel.getDomainObjectType());
            pStmt.setString(10, otherWeightsAndMeasureModel.getCreateUserId());
            pStmt.setTimestamp(11, otherWeightsAndMeasureModel.getCreateTimestamp());
            pStmt.setString(12, otherWeightsAndMeasureModel.getLastUpdateUserId());
            pStmt.setTimestamp(13, otherWeightsAndMeasureModel.getLastUpdateTimestamp());
            pStmt.setString(14, otherWeightsAndMeasureModel.getDomainName());
            if (otherWeightsAndMeasureModel.getShipmentId() != 0)
                pStmt.setLong(15, otherWeightsAndMeasureModel.getShipmentId());
            else
                pStmt.setNull(15, Types.NUMERIC);
        
            if(otherWeightsAndMeasureModel.getInvoiceId() != 0)
                pStmt.setLong(16, otherWeightsAndMeasureModel.getInvoiceId());
            else
                pStmt.setNull(16, Types.NUMERIC);

           if(otherWeightsAndMeasureModel.getInvoiceDetailId() != 0)
                pStmt.setLong(17, otherWeightsAndMeasureModel.getInvoiceDetailId());
            else
                pStmt.setNull(17, Types.NUMERIC);
                        
            pStmt.executeUpdate();
            return otherWeightsAndMeasureModel;
        }
        catch (SQLException e)
        {
            logger.error("Error occurred during create(otherWeightsAndMeasureModel) ", e);
            throw e;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }

    public void delete(OtherWeightsAndMeasureModel otherWeightsAndMeasureModel) 
        throws SQLException
    {
        delete(otherWeightsAndMeasureModel.getOtherWeightsAndMeasureId());
    }

    public void delete(long otherWeightsAndMeasureId) 
        throws SQLException
    {
        String otherWeightsAndMeasureDeleteDML = "DELETE OTHERWEIGHTSANDMEASURES WHERE OTHERWEIGHTSANDMEASURESID = ?";
        deleteRecord (otherWeightsAndMeasureDeleteDML,otherWeightsAndMeasureId);
    }

    public void deleteAllByInvoiceLineId(long invoiceLineItemId) 
        throws SQLException
    {
        String otherWeightsAndMeasureDeleteDML = "DELETE OTHERWEIGHTSANDMEASURES WHERE INVOICELINEITEMID = ?";
        HashMap<Integer, Object> paramMap = new HashMap<Integer, Object>();
        paramMap.put(1, invoiceLineItemId);
        
        executeUpdate(otherWeightsAndMeasureDeleteDML,paramMap);
    }

    /**
     * Updates OtherWeightsAndMeasure data using the provided OtherWeightsAndMeasureModel.
     * The OtherWeightsAndMeasureModel must have the correct primary key (OtherWeightsAndMeasureId).
     *
     * @param otherWeightsAndMeasureModel The updated otherWeightsAndMeasureModel object that has the updated data.
     */
    public void update(OtherWeightsAndMeasureModel otherWeightsAndMeasureModel) 
        throws SQLException
    {
        PreparedStatement pStmt = null;
        Connection connection = null;
        StringBuffer otherWeightsAndMeasureUpdateDML = new StringBuffer("UPDATE OTHERWEIGHTSANDMEASURES SET (OTHERWEIGHTSANDMEASURESID = ?,DOMAINOBJECTID = ?,EVENTID = ?");
        otherWeightsAndMeasureUpdateDML.append(",INVOICELINEITEMID = ?,MEASUREVALUETYPECODE = ? ,MEASUREVALUE = ?");
        otherWeightsAndMeasureUpdateDML.append(",MEASUREVALUEQUALIFIER = ?,MEASUREVALUEUOM = ?,DOMAINOBJECTCODE = ?");
        otherWeightsAndMeasureUpdateDML.append(",CREATEUSERID = ?,CREATETIMESTAMP = ?,LASTUPDATEUSERID = ? ");
        otherWeightsAndMeasureUpdateDML.append(",LASTUPDATETIMESTAMP = ?,DOMAINNAME = ?, SHIPMENTID = ? ) WHERE OTHERWEIGHTSANDMEASURESID = ? ");
        try
        {
            logger.debug ("update(otherWeightsAndMeasureModel) begin. \n[DML] " + otherWeightsAndMeasureUpdateDML.toString());
            connection = getConnection();
            pStmt = connection.prepareStatement(otherWeightsAndMeasureUpdateDML.toString());
            pStmt.setLong(1, otherWeightsAndMeasureModel.getOtherWeightsAndMeasureId());
            if (otherWeightsAndMeasureModel.getDomainObjectId() != 0)
                pStmt.setLong(2, otherWeightsAndMeasureModel.getDomainObjectId());
            else
                pStmt.setNull(2, Types.NUMERIC);
            if (otherWeightsAndMeasureModel.getEventId() != 0)
                pStmt.setLong(3, otherWeightsAndMeasureModel.getEventId());
            else
                pStmt.setNull(3, Types.NUMERIC);
            if (otherWeightsAndMeasureModel.getInvoiceLineItemId() != 0)
                pStmt.setLong(4, otherWeightsAndMeasureModel.getInvoiceLineItemId());
            else
                pStmt.setNull(4, Types.NUMERIC);
            pStmt.setString(5, otherWeightsAndMeasureModel.getMeasureTypeCode());
            pStmt.setDouble(6, otherWeightsAndMeasureModel.getMeasureValue());
            pStmt.setString(7, otherWeightsAndMeasureModel.getMeasureQualifer());
            pStmt.setString(8, otherWeightsAndMeasureModel.getUnitOfMeasure());
            pStmt.setString(9, otherWeightsAndMeasureModel.getDomainObjectType());
            pStmt.setString(10, otherWeightsAndMeasureModel.getCreateUserId());
            pStmt.setTimestamp(11, otherWeightsAndMeasureModel.getCreateTimestamp());
            pStmt.setString(12, otherWeightsAndMeasureModel.getLastUpdateUserId());
            pStmt.setTimestamp(13, otherWeightsAndMeasureModel.getLastUpdateTimestamp());
            pStmt.setString(14, otherWeightsAndMeasureModel.getDomainName());
            if (otherWeightsAndMeasureModel.getShipmentId() != 0)
                pStmt.setLong(15, otherWeightsAndMeasureModel.getShipmentId());
            else
                pStmt.setNull(15, Types.NUMERIC);
            pStmt.setLong(16, otherWeightsAndMeasureModel.getOtherWeightsAndMeasureId());
            pStmt.executeUpdate();
        }
        catch (SQLException e)
        {
            logger.error("Error occurred during update(otherWeightsAndMeasureModel) ", e);
            throw e;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }

    /**
     * Retrieves a OtherWeightsAndMeasure Model from the DB given the otherWeightsAndMeasure ID (primary key)
     * for the table.
     *
     * @param otherWeightsAndMeasureId The primary key for the data
     * @return OtherWeightsAndMeasureModel representing the data from the DB
     */
    public OtherWeightsAndMeasureModel retrieve(long otherWeightsAndMeasureId) 
        throws SQLException
    {
        OtherWeightsAndMeasureModel otherWeightsAndMeasureModel = null;
        Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        try
        {
            StringBuffer otherWeightsAndMeasureQuery = new StringBuffer("SELECT OTHERWEIGHTSANDMEASURESID,DOMAINOBJECTID,EVENTID");
            otherWeightsAndMeasureQuery.append(",INVOICELINEITEMID,MEASUREVALUETYPECODE,MEASUREVALUE,MEASUREVALUEQUALIFIER,MEASUREVALUEUOM,DOMAINOBJECTCODE");
            otherWeightsAndMeasureQuery.append(",CREATEUSERID,CREATETIMESTAMP,LASTUPDATEUSERID,LASTUPDATETIMESTAMP,DOMAINNAME FROM OTHERWEIGHTSANDMEASURES WHERE OTHERWEIGHTSANDMEASURESID = ?");
            logger.debug("retrieve (otherWeightsAndMeasureId[" + otherWeightsAndMeasureId + "]): begin. \n[DQL] "+otherWeightsAndMeasureQuery);
            connection = getConnection();
            pStmt = connection.prepareStatement(otherWeightsAndMeasureQuery.toString());
            pStmt.setLong(1, otherWeightsAndMeasureId);
            rs = pStmt.executeQuery();
            if (!rs.next())
                return null;
            long domainObjectId = rs.getLong(2);
            long eventId = rs.getLong(3);
            long invoiceLineItemId = rs.getLong(4);
            String measureTypeCode = rs.getString(5);
            double measureValue = rs.getDouble(6);
            String measureQualifer = rs.getString(7);
            String unitOfMeasure = rs.getString(8);
            String domainObjectType = rs.getString(9);
            String createUserId = rs.getString(10);
            Timestamp createTimestamp = rs.getTimestamp(11);
            String lastUpdateUserId = rs.getString(12);
            Timestamp lastUpdateTimestamp = rs.getTimestamp(13);
            String domainName = rs.getString(14);
            otherWeightsAndMeasureModel = new OtherWeightsAndMeasureModel(otherWeightsAndMeasureId, domainObjectId, eventId, invoiceLineItemId, measureTypeCode, measureValue, measureQualifer, unitOfMeasure, domainObjectType, createUserId, createTimestamp, lastUpdateUserId, lastUpdateTimestamp, domainName);
        }
        catch (SQLException ex)
        {
            logger.error("Error occurred during retrieve (otherWeightsAndMeasureId[" + otherWeightsAndMeasureId + "]) ", ex);
            throw ex;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return otherWeightsAndMeasureModel;
    }

    /**
     * Retrieves a list of all OtherWeightsAndMeasureModels for this domain name.
     *
     * @param domainName The domain name for which otherweightsandmeasures should be retrieved
     *
     * @return List of otherWeightsAndMeasureModel elements
     */
    public List retrieveAll(String domainName) 
        throws SQLException
    {
        List otherWeightsAndMeasureList = new ArrayList();
        Connection connection = null;
        PreparedStatement pStmt = null;
        OtherWeightsAndMeasureModel otherWeightsAndMeasureModel = null;
        ResultSet rs = null;
        try
        {
            StringBuffer otherWeightsAndMeasureQuery = new StringBuffer("SELECT OTHERWEIGHTSANDMEASURESID,DOMAINOBJECTID,EVENTID");
            otherWeightsAndMeasureQuery.append(",INVOICELINEITEMID,MEASUREVALUETYPECODE,MEASUREVALUE,MEASUREVALUEQUALIFIER,MEASUREVALUEUOM,DOMAINOBJECTCODE");
            otherWeightsAndMeasureQuery.append(",CREATEUSERID,CREATETIMESTAMP,LASTUPDATEUSERID,LASTUPDATETIMESTAMP,DOMAINNAME FROM OTHERWEIGHTSANDMEASURES ");
            otherWeightsAndMeasureQuery.append(" WHERE DOMAINNAME = ? ");
            logger.debug("retrieveAll(domainName["+domainName+"]) begin.\n [DQL] "+otherWeightsAndMeasureQuery.toString() + domainName);
            connection = getConnection();
            pStmt = connection.prepareStatement(otherWeightsAndMeasureQuery.toString());
            pStmt.setString(1, domainName);
            rs = pStmt.executeQuery();
            while (rs.next())
            {
                long otherWeightsAndMeasureId = rs.getLong(1);
                long domainObjectId = rs.getLong(2);
                long eventId = rs.getLong(3);
                long invoiceLineItemId = rs.getLong(4);
                String measureTypeCode = rs.getString(5);
                double measureValue = rs.getDouble(6);
                String measureQualifer = rs.getString(7);
                String unitOfMeasure = rs.getString(8);
                String domainObjectType = rs.getString(9);
                String createUserId = rs.getString(10);
                Timestamp createTimestamp = rs.getTimestamp(11);
                String lastUpdateUserId = rs.getString(12);
                Timestamp lastUpdateTimestamp = rs.getTimestamp(13);
                otherWeightsAndMeasureModel = new OtherWeightsAndMeasureModel(otherWeightsAndMeasureId, domainObjectId, eventId, invoiceLineItemId, measureTypeCode, measureValue, measureQualifer, unitOfMeasure, domainObjectType, createUserId, createTimestamp, lastUpdateUserId, lastUpdateTimestamp, domainName);
                otherWeightsAndMeasureList.add(otherWeightsAndMeasureModel);
            }
        }
        catch (SQLException ex)
        {
            logger.error("Error occurred during retrieveAll(domainName) ", ex);
            throw ex;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return otherWeightsAndMeasureList;
    }

    /**
     * Retrieves a list of all OtherWeightsAndMeasureModels for the given Invoice Line Item.
     *
     * @param invoiceLineItemId The Invoice Line Item ID for which otherweightsandmeasures should be retrieved
     *
     * @return List of otherWeightsAndMeasureModel elements
     */
    public List retrieveAllByInvoiceLineItemId(long invoiceLineItemId) 
        throws SQLException
    {
        List otherWeightsAndMeasureList = new ArrayList();
        Connection connection = null;
        PreparedStatement pStmt = null;
        OtherWeightsAndMeasureModel otherWeightsAndMeasureModel = null;
        ResultSet rs = null;
        try
        {
            StringBuffer otherWeightsAndMeasureQuery = new StringBuffer("SELECT OTHERWEIGHTSANDMEASURESID,DOMAINOBJECTID,EVENTID");
            otherWeightsAndMeasureQuery.append(",INVOICELINEITEMID,MEASUREVALUETYPECODE,MEASUREVALUE,MEASUREVALUEQUALIFIER,MEASUREVALUEUOM,DOMAINOBJECTCODE");
            otherWeightsAndMeasureQuery.append(",CREATEUSERID,CREATETIMESTAMP,LASTUPDATEUSERID,LASTUPDATETIMESTAMP,DOMAINNAME FROM OTHERWEIGHTSANDMEASURES WHERE INVOICELINEITEMID = ?");
            logger.debug ("retrieveAllByInvoiceLineItemId( invoiceLineItemId[" + invoiceLineItemId + 
                    "]) begin. \n [DQL] " + otherWeightsAndMeasureQuery.toString());
            connection = getConnection();
            pStmt = connection.prepareStatement(otherWeightsAndMeasureQuery.toString());
            pStmt.setLong(1, invoiceLineItemId);
            rs = pStmt.executeQuery();
            while (rs.next())
            {
                long otherWeightsAndMeasureId = rs.getLong(1);
                long domainObjectId = rs.getLong(2);
                long eventId = rs.getLong(3);
                String measureTypeCode = rs.getString(5);
                double measureValue = rs.getDouble(6);
                String measureQualifer = rs.getString(7);
                String unitOfMeasure = rs.getString(8);
                String domainObjectType = rs.getString(9);
                String createUserId = rs.getString(10);
                Timestamp createTimestamp = rs.getTimestamp(11);
                String lastUpdateUserId = rs.getString(12);
                Timestamp lastUpdateTimestamp = rs.getTimestamp(13);
                String domainName = rs.getString(14);
                otherWeightsAndMeasureModel = new OtherWeightsAndMeasureModel(otherWeightsAndMeasureId, domainObjectId, eventId, invoiceLineItemId, measureTypeCode, measureValue, measureQualifer, unitOfMeasure, domainObjectType, createUserId, createTimestamp, lastUpdateUserId, lastUpdateTimestamp, domainName);
                otherWeightsAndMeasureList.add(otherWeightsAndMeasureModel);
            }
        }
        catch (SQLException ex)
        {
            logger.error("Exception retrieving records by invoiceLineItemId", ex);
            throw ex;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return otherWeightsAndMeasureList;
    }

    /**
     * Retrieves a list of all OtherWeightsAndMeasureModels for the given Event.
     *
     * @param eventId The Event ID for which otherweightsandmeasures should be retrieved
     *
     * @return List of otherWeightsAndMeasureModel elements
     */
    public List retrieveAllByEventId(long eventId) 
        throws SQLException
    {
        List otherWeightsAndMeasureList = new ArrayList();
        Connection connection = null;
        PreparedStatement pStmt = null;
        OtherWeightsAndMeasureModel otherWeightsAndMeasureModel = null;
        ResultSet rs = null;
        try
        {
            StringBuffer otherWeightsAndMeasureQuery = new StringBuffer("SELECT OTHERWEIGHTSANDMEASURESID,DOMAINOBJECTID,EVENTID");
            otherWeightsAndMeasureQuery.append(",INVOICELINEITEMID,MEASUREVALUETYPECODE,MEASUREVALUE,MEASUREVALUEQUALIFIER,MEASUREVALUEUOM,DOMAINOBJECTCODE");
            otherWeightsAndMeasureQuery.append(",CREATEUSERID,CREATETIMESTAMP,LASTUPDATEUSERID,LASTUPDATETIMESTAMP,DOMAINNAME FROM OTHERWEIGHTSANDMEASURES WHERE EVENTID = ?");
            logger.debug("retrieveAllByEventId(eventId["+eventId+"]) begin.\n [DQL] "+otherWeightsAndMeasureQuery.toString());
            connection = getConnection();
            pStmt = connection.prepareStatement(otherWeightsAndMeasureQuery.toString());
            pStmt.setLong(1, eventId);
            rs = pStmt.executeQuery();
            while (rs.next())
            {
                long otherWeightsAndMeasureId = rs.getLong(1);
                long domainObjectId = rs.getLong(2);
                long invoiceLineItemId = rs.getLong(4);
                String measureTypeCode = rs.getString(5);
                double measureValue = rs.getDouble(6);
                String measureQualifer = rs.getString(7);
                String unitOfMeasure = rs.getString(8);
                String domainObjectType = rs.getString(9);
                String createUserId = rs.getString(10);
                Timestamp createTimestamp = rs.getTimestamp(11);
                String lastUpdateUserId = rs.getString(12);
                Timestamp lastUpdateTimestamp = rs.getTimestamp(13);
                String domainName = rs.getString(14);
                otherWeightsAndMeasureModel = new OtherWeightsAndMeasureModel(otherWeightsAndMeasureId, domainObjectId, eventId, invoiceLineItemId, measureTypeCode, measureValue, measureQualifer, unitOfMeasure, domainObjectType, createUserId, createTimestamp, lastUpdateUserId, lastUpdateTimestamp, domainName);
                otherWeightsAndMeasureList.add(otherWeightsAndMeasureModel);
            }
        }
        catch (SQLException ex)
        {
            logger.error("Error occurred during retrieveAllByEventId(eventId["+eventId+"]) ", ex);
            throw ex;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return otherWeightsAndMeasureList;
    }

   /**
    * Retrieves a list of all OtherWeightsAndMeasureModels for the given Shipment.
    *
    * @param shipmentId The Shipment ID for which otherweightsandmeasures should be retrieved
    *
    * @return List of otherWeightsAndMeasureModel elements
    */
    public List retrieveAllByShipmentId(long shipmentId) 
        throws SQLException
    {
        List otherWeightsAndMeasureList = new ArrayList();
        Connection connection = null;
        PreparedStatement pStmt = null;
        OtherWeightsAndMeasureModel otherWeightsAndMeasureModel = null;
        ResultSet rs = null;
        try
        {
            StringBuffer otherWeightsAndMeasureQuery = new StringBuffer("SELECT OTHERWEIGHTSANDMEASURESID,DOMAINOBJECTID,EVENTID");
            otherWeightsAndMeasureQuery.append(",INVOICELINEITEMID,MEASUREVALUETYPECODE,MEASUREVALUE,MEASUREVALUEQUALIFIER,MEASUREVALUEUOM,DOMAINOBJECTCODE");
            otherWeightsAndMeasureQuery.append(",CREATEUSERID,CREATETIMESTAMP,LASTUPDATEUSERID,LASTUPDATETIMESTAMP,DOMAINNAME, SHIPMENTID FROM OTHERWEIGHTSANDMEASURES WHERE SHIPMENTID = ?");
            logger.debug("retrieveAllByShipmentId(shipmentId["+shipmentId+"]) begin.\n [DQL] "+otherWeightsAndMeasureQuery.toString());
            connection = getConnection();
            pStmt = connection.prepareStatement(otherWeightsAndMeasureQuery.toString());
            pStmt.setLong(1, shipmentId);
            rs = pStmt.executeQuery();
            while (rs.next())
            {
                long otherWeightsAndMeasureId = rs.getLong(1);
                long domainObjectId = rs.getLong(2);
                long eventId = rs.getLong(3);
                long invoiceLineItemId = rs.getLong(4);
                String measureTypeCode = rs.getString(5);
                double measureValue = rs.getDouble(6);
                String measureQualifer = rs.getString(7);
                String unitOfMeasure = rs.getString(8);
                String domainObjectType = rs.getString(9);
                String createUserId = rs.getString(10);
                Timestamp createTimestamp = rs.getTimestamp(11);
                String lastUpdateUserId = rs.getString(12);
                Timestamp lastUpdateTimestamp = rs.getTimestamp(13);
                String domainName = rs.getString(14);
                otherWeightsAndMeasureModel = new OtherWeightsAndMeasureModel(otherWeightsAndMeasureId, domainObjectId, eventId, invoiceLineItemId, measureTypeCode, measureValue, measureQualifer, unitOfMeasure, domainObjectType, createUserId, createTimestamp, lastUpdateUserId, lastUpdateTimestamp, domainName);
                otherWeightsAndMeasureModel.setShipmentId(shipmentId);
                otherWeightsAndMeasureList.add(otherWeightsAndMeasureModel);
            }
        }
        catch (SQLException ex)
        {
            logger.error("Error occurred during retrieveAllByShipmentId(shipmentId["+shipmentId+"])", ex);
            throw ex;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return otherWeightsAndMeasureList;
    }

    public void deleteAllByShipmentId(long shipmentId) 
        throws SQLException
    {
        String otherWeightsAndMeasureDeleteDML = "DELETE OTHERWEIGHTSANDMEASURES WHERE SHIPMENTID = ?";
        HashMap<Integer, Object> paramMap = new HashMap<Integer, Object>();
        paramMap.put(1, shipmentId);
        
        executeUpdate(otherWeightsAndMeasureDeleteDML,paramMap);
    }
    
    public void deleteAllByInvoiceId(long invoiceId) 
        throws SQLException
    {
        logger.info("deleteAllByInvoiceId(): begin");
        String otherWeightsAndMeasureDeleteDML = "DELETE OTHERWEIGHTSANDMEASURES WHERE INVOICEID = ?";
        HashMap<Integer, Object> paramMap = new HashMap<Integer, Object>();
        paramMap.put(1, invoiceId);
        
        executeUpdate(otherWeightsAndMeasureDeleteDML,paramMap);
    }
    
    /**
     * Retrieves a list of all OtherWeightsAndMeasureModels for the given Invoice.
     *
     * @param invoiceId The Invoice ID for which otherweightsandmeasures should be retrieved
     *
     * @return List of otherWeightsAndMeasureModel elements
     */
    public List retrieveAllByInvoiceId(long invoiceId) 
        throws SQLException
    {
        List otherWeightsAndMeasureList = new ArrayList();
        Connection connection = null;
        PreparedStatement pStmt = null;
        OtherWeightsAndMeasureModel otherWeightsAndMeasureModel = null;
        ResultSet rs = null;
        try
        {
            StringBuffer otherWeightsAndMeasureQuery = new StringBuffer("SELECT OTHERWEIGHTSANDMEASURESID,DOMAINOBJECTID,EVENTID");
            otherWeightsAndMeasureQuery.append(",INVOICELINEITEMID,MEASUREVALUETYPECODE,MEASUREVALUE,MEASUREVALUEQUALIFIER,MEASUREVALUEUOM,DOMAINOBJECTCODE");
            otherWeightsAndMeasureQuery.append(",CREATEUSERID,CREATETIMESTAMP,LASTUPDATEUSERID,LASTUPDATETIMESTAMP,DOMAINNAME FROM OTHERWEIGHTSANDMEASURES WHERE INVOICEID = ?");
            logger.debug("retrieveAllByInvoiceId(invoiceId["+invoiceId+"]) begin. \n[DQL]: " + otherWeightsAndMeasureQuery.toString());
            connection = getConnection();
            pStmt = connection.prepareStatement(otherWeightsAndMeasureQuery.toString());
            pStmt.setLong(1, invoiceId);
            rs = pStmt.executeQuery();
            while (rs.next())
            {
                long otherWeightsAndMeasureId = rs.getLong(1);
                long domainObjectId = rs.getLong(2);
                long invoiceLineItemId = rs.getLong(4);
                String measureTypeCode = rs.getString(5);
                double measureValue = rs.getDouble(6);
                String measureQualifer = rs.getString(7);
                String unitOfMeasure = rs.getString(8);
                String domainObjectType = rs.getString(9);
                String createUserId = rs.getString(10);
                Timestamp createTimestamp = rs.getTimestamp(11);
                String lastUpdateUserId = rs.getString(12);
                Timestamp lastUpdateTimestamp = rs.getTimestamp(13);
                String domainName = rs.getString(14);
                otherWeightsAndMeasureModel = new OtherWeightsAndMeasureModel(otherWeightsAndMeasureId, domainObjectId, 0, invoiceLineItemId, measureTypeCode, measureValue, measureQualifer, unitOfMeasure, domainObjectType, createUserId, createTimestamp, lastUpdateUserId, lastUpdateTimestamp, domainName);
                otherWeightsAndMeasureModel.setInvoiceId(invoiceId);
                otherWeightsAndMeasureList.add(otherWeightsAndMeasureModel);
            }
        }
        catch (SQLException ex)
        {
            logger.error("Error occurred during retrieveAllByInvoiceId(invoiceId["+invoiceId+"])", ex);
            throw ex;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return otherWeightsAndMeasureList;
    }

    public void deleteAllByInvoiceDetailId(long invoiceDetailId) throws SQLException
    {
        String otherWeightsAndMeasureDeleteDML = "DELETE OTHERWEIGHTSANDMEASURES WHERE INVOICEDETAILID = ?";
        HashMap<Integer, Object> paramMap = new HashMap<Integer, Object>();
        paramMap.put(1, invoiceDetailId);
        
        executeUpdate(otherWeightsAndMeasureDeleteDML,paramMap);
    }
    
    /**
     * Retrieves a list of all OtherWeightsAndMeasureModels for the given Invoice.
     *
     * @param invoiceId The Invoice ID for which otherweightsandmeasures should be retrieved
     *
     * @return List of otherWeightsAndMeasureModel elements
     */
    public List retrieveAllByInvoiceDetailId(long invoiceDetailId) throws SQLException
    {
        List otherWeightsAndMeasureList = new ArrayList();
        Connection connection = null;
        PreparedStatement pStmt = null;
        OtherWeightsAndMeasureModel otherWeightsAndMeasureModel = null;
        ResultSet rs = null;
        try
        {
            StringBuffer otherWeightsAndMeasureQuery = new StringBuffer("SELECT OTHERWEIGHTSANDMEASURESID,DOMAINOBJECTID,EVENTID");
            otherWeightsAndMeasureQuery.append(",INVOICELINEITEMID,MEASUREVALUETYPECODE,MEASUREVALUE,MEASUREVALUEQUALIFIER,MEASUREVALUEUOM,DOMAINOBJECTCODE");
            otherWeightsAndMeasureQuery.append(",CREATEUSERID,CREATETIMESTAMP,LASTUPDATEUSERID,LASTUPDATETIMESTAMP,DOMAINNAME FROM OTHERWEIGHTSANDMEASURES WHERE INVOICEDETAILID = ?");
            logger.debug ("retrieveAllByInvoiceDetailId(invoiceDetailId[" + invoiceDetailId + "]) begin. \n [DQL] " 
                    + otherWeightsAndMeasureQuery.toString());
            connection = getConnection();
            pStmt = connection.prepareStatement(otherWeightsAndMeasureQuery.toString());
            pStmt.setLong(1, invoiceDetailId);
            rs = pStmt.executeQuery();
            while (rs.next())
            {
                long otherWeightsAndMeasureId = rs.getLong(1);
                long domainObjectId = rs.getLong(2);
                long invoiceLineItemId = rs.getLong(4);
                String measureTypeCode = rs.getString(5);
                double measureValue = rs.getDouble(6);
                String measureQualifer = rs.getString(7);
                String unitOfMeasure = rs.getString(8);
                String domainObjectType = rs.getString(9);
                String createUserId = rs.getString(10);
                Timestamp createTimestamp = rs.getTimestamp(11);
                String lastUpdateUserId = rs.getString(12);
                Timestamp lastUpdateTimestamp = rs.getTimestamp(13);
                String domainName = rs.getString(14);
                otherWeightsAndMeasureModel = new OtherWeightsAndMeasureModel(otherWeightsAndMeasureId, domainObjectId, 0, invoiceLineItemId, measureTypeCode, measureValue, measureQualifer, unitOfMeasure, domainObjectType, createUserId, createTimestamp, lastUpdateUserId, lastUpdateTimestamp, domainName);
                otherWeightsAndMeasureModel.setInvoiceDetailId(invoiceDetailId);
                otherWeightsAndMeasureList.add(otherWeightsAndMeasureModel);
            }
        }
        catch (SQLException ex)
        {
            logger.error("Error occurred during retrieveAllByInvoiceDetailId(invoiceDetailId[" + invoiceDetailId + "]) ", ex);
            throw ex;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return otherWeightsAndMeasureList;
    }
}

