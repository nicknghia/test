/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/dao/InspectionOrCheckDAO.java,v 1.3.4.2 2010/08/22 23:08:30 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: InspectionOrCheckDAO.java,v $
 *  Revision 1.3.4.2  2010/08/22 23:08:30  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.3.4.1  2010/03/15 14:45:10  mechevarria
 *  fix jdbc methods to use bind vars
 *
 *  Revision 1.3  2006/04/21 12:51:49  uvasundhara
 *  Statement is replaced by PreparedStatement
 *
 *  Revision 1.2  2006/03/28 21:22:58  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.1  2005/08/20 12:30:16  pjain
 *  centralized DAO package
 *
 *  Revision 1.3  2005/06/14 11:57:19  ranand
 *  delete method calls to Base DAO delete method
 *
 *  Revision 1.2  2004/11/10 10:25:30  biju
 *  method name changes + removal of NamingException
 *
 *  Revision 1.1  2004/09/15 13:12:45  ranand
 *  2.6 Baseline
 *
 * 
 */


package com.freightdesk.fdfolio.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Types;
import java.util.ArrayList;
import java.util.List;

import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdfolio.event.model.InspectionOrCheckModel;

public class InspectionOrCheckDAO extends BaseDao
{
   
    public void create(InspectionOrCheckModel inspectionOrCheckModel) throws SQLException
    {
        String insQuery = "INSERT INTO INSPECTIONORCHECK(INSPECTIONORCHECKID, EVENTID, INSPECTIONORCHECKTYPECODE, INSPECTIONORCHECKDATE, INSPECTIONORCHECKVALUE, INSPECTIONORCHECKSTATUS, INSPECTIONORCHECKQUALIFIER, INSPECTIONREMARKS, STATUS, CREATEUSERID, CREATETIMESTAMP, LASTUPDATEUSERID, LASTUPDATETIMESTAMP, DOMAINNAME) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";
        PreparedStatement pStmt = null;
        Connection connection = null;
        try
        {
            logger.info("create() begins. Sql " + insQuery);
            connection = getConnection();
            pStmt = connection.prepareStatement(insQuery);
            
            if(inspectionOrCheckModel.getInspectionorCheckId() == 0)
                inspectionOrCheckModel.setInspectionorCheckId(getNextID("INSPECTIONORCHECKID"));
            
            pStmt.setLong(1, inspectionOrCheckModel.getInspectionorCheckId());
            
            if(inspectionOrCheckModel.getEventId() != 0)
                pStmt.setLong(2, inspectionOrCheckModel.getEventId());
            else
                pStmt.setNull(2, Types.NUMERIC);
    
            pStmt.setString(3, inspectionOrCheckModel.getInspectionorCheckTypeCode());
            pStmt.setTimestamp(4, inspectionOrCheckModel.getInspectionorCheckDate());
            pStmt.setString(5, inspectionOrCheckModel.getInspectionorCheckValue());
            pStmt.setString(6, inspectionOrCheckModel.getInspectionorCheckStatus());
            pStmt.setString(7, inspectionOrCheckModel.getInspectionorCheckQualifier());
            pStmt.setString(8, inspectionOrCheckModel.getInspectionreMarks());
            pStmt.setString(9, inspectionOrCheckModel.getStatus());
            pStmt.setString(10, inspectionOrCheckModel.getCreateUserId());
            pStmt.setTimestamp(11, inspectionOrCheckModel.getCreateTimestamp());
            pStmt.setString(12, inspectionOrCheckModel.getLastUpdateUserId());
            pStmt.setTimestamp(13, inspectionOrCheckModel.getLastUpdateTimestamp());
            pStmt.setString(14, inspectionOrCheckModel.getDomainName());
            pStmt.executeUpdate();
            logger.info("Create() finished.");
        }
        catch (SQLException sqEx)
        {
            logger.error("Exception occured in create(InspectionOrCheckModel) ", sqEx);
            throw sqEx;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }

    public void delete(long inspectionorCheckId) throws SQLException
    {
        String delQuery = "DELETE FROM INSPECTIONORCHECK WHERE INSPECTIONORCHECKID = ?";
        deleteRecord (delQuery,inspectionorCheckId);
    }

    public void update(InspectionOrCheckModel inspectionOrCheckModel) 
        throws SQLException
    {
        String query = "UPDATE INSPECTIONORCHECK SET  INSPECTIONORCHECKTYPECODE = ? , INSPECTIONORCHECKDATE = ? , INSPECTIONORCHECKVALUE = ? , INSPECTIONORCHECKSTATUS = ? , ";
        query = query + " INSPECTIONORCHECKQUALIFIER = ?, INSPECTIONREMARKS = ?,CREATEUSERID = ?, CREATETIMESTAMP = ?, ";
        query = query + " LASTUPDATEUSERID = ?, LASTUPDATETIMESTAMP = ? , DOMAINNAME = ? WHERE INSPECTIONORCHECKID = ?";
        PreparedStatement pStmt = null;
        Connection connection = null;
        try
        {
            logger.info("update()  begins. Sql " + query);
            connection = getConnection();
            pStmt = connection.prepareStatement(query);
            pStmt.setString(1, inspectionOrCheckModel.getInspectionorCheckTypeCode());
            pStmt.setTimestamp(2, inspectionOrCheckModel.getInspectionorCheckDate());
            pStmt.setString(3, inspectionOrCheckModel.getInspectionorCheckValue());
            pStmt.setString(4, inspectionOrCheckModel.getInspectionorCheckStatus());
            pStmt.setString(5, inspectionOrCheckModel.getInspectionorCheckQualifier());
            pStmt.setString(6, inspectionOrCheckModel.getInspectionreMarks());
            pStmt.setString(7, inspectionOrCheckModel.getCreateUserId());
            pStmt.setTimestamp(8, inspectionOrCheckModel.getCreateTimestamp());
            pStmt.setString(9, inspectionOrCheckModel.getLastUpdateUserId());
            pStmt.setTimestamp(10, inspectionOrCheckModel.getLastUpdateTimestamp());
            pStmt.setString(11, inspectionOrCheckModel.getDomainName());
            pStmt.setLong(12, inspectionOrCheckModel.getInspectionorCheckId());
            pStmt.executeUpdate();
            logger.info("update() finished.");
        }
        catch (SQLException e)
        {
            logger.error("Exception occured in update() ", e);
            throw e;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }

    public InspectionOrCheckModel retrieve(long inspectionorCheckId) 
        throws SQLException
    {
        InspectionOrCheckModel inspectionOrCheckModel = null;
        String query = "SELECT INSPECTIONORCHECKID, INSPECTIONORCHECKTYPECODE, INSPECTIONORCHECKDATE, INSPECTIONORCHECKVALUE, INSPECTIONORCHECKSTATUS, INSPECTIONORCHECKQUALIFIER, INSPECTIONREMARKS, CREATEUSERID, CREATETIMESTAMP, LASTUPDATEUSERID, LASTUPDATETIMESTAMP, DOMAINNAME  FROM INSPECTIONORCHECK WHERE INSPECTIONORCHECKID=?";
		PreparedStatement pStmt = null;
        Connection connection = null;
        ResultSet rs = null;
        try
        {
            logger.info("retrieve (" + inspectionorCheckId + "): begin");
            logger.debug ("DQL: " + query);
            connection = getConnection();
			pStmt = connection.prepareStatement(query);
			pStmt.setLong(1,inspectionorCheckId);
		    rs = pStmt.executeQuery();
            if (rs.next())
            {
                inspectionOrCheckModel = new InspectionOrCheckModel();
                inspectionOrCheckModel.setInspectionorCheckId(rs.getLong(1));
                inspectionOrCheckModel.setInspectionorCheckTypeCode(rs.getString(2));
                inspectionOrCheckModel.setInspectionorCheckDate(rs.getTimestamp(3));
                inspectionOrCheckModel.setInspectionorCheckValue(rs.getString(4));
                inspectionOrCheckModel.setInspectionorCheckStatus(rs.getString(5));
                inspectionOrCheckModel.setInspectionorCheckQualifier(rs.getString(6));
                inspectionOrCheckModel.setInspectionreMarks(rs.getString(7));
                inspectionOrCheckModel.setCreateUserId(rs.getString(8));
                inspectionOrCheckModel.setCreateTimestamp(rs.getTimestamp(9));
                inspectionOrCheckModel.setLastUpdateUserId(rs.getString(10));
                inspectionOrCheckModel.setLastUpdateTimestamp(rs.getTimestamp(11));
                inspectionOrCheckModel.setDomainName(rs.getString(12));
            }
            logger.info("retrieve()  finished.");
        }
        catch (SQLException sqEx)
        {
            logger.error("Exception occured in retrieve(inspectionorCheckId) ", sqEx);
            throw sqEx;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return inspectionOrCheckModel;
    }

    public List retrieveByEventId (long eventId) 
        throws SQLException
    {
        List inspectionOrCheckModelList  = new ArrayList();
        String query = "SELECT INSPECTIONORCHECKID, INSPECTIONORCHECKTYPECODE, INSPECTIONORCHECKDATE, INSPECTIONORCHECKVALUE, INSPECTIONORCHECKSTATUS, INSPECTIONORCHECKQUALIFIER, INSPECTIONREMARKS, CREATEUSERID, CREATETIMESTAMP, LASTUPDATEUSERID, LASTUPDATETIMESTAMP, DOMAINNAME  FROM INSPECTIONORCHECK WHERE EVENTID=?";
		PreparedStatement pStmt = null;
       // Statement stmt = null;
        Connection connection = null;
        ResultSet rs = null;
        try
        {
            logger.info ("retrieveByEventId (" + eventId + "): begin");
            logger.debug ("DQL: " + query);
            connection = getConnection();
			pStmt = connection.prepareStatement(query);
			pStmt.setLong(1,eventId);
            rs = pStmt.executeQuery();
            while (rs.next())
            {
                InspectionOrCheckModel inspectionOrCheckModel = new InspectionOrCheckModel();
                inspectionOrCheckModel.setInspectionorCheckId(rs.getLong(1));
                inspectionOrCheckModel.setInspectionorCheckTypeCode(rs.getString(2));
                inspectionOrCheckModel.setInspectionorCheckDate(rs.getTimestamp(3));
                inspectionOrCheckModel.setInspectionorCheckValue(rs.getString(4));
                inspectionOrCheckModel.setInspectionorCheckStatus(rs.getString(5));
                inspectionOrCheckModel.setInspectionorCheckQualifier(rs.getString(6));
                inspectionOrCheckModel.setInspectionreMarks(rs.getString(7));
                inspectionOrCheckModel.setCreateUserId(rs.getString(8));
                inspectionOrCheckModel.setCreateTimestamp(rs.getTimestamp(9));
                inspectionOrCheckModel.setLastUpdateUserId(rs.getString(10));
                inspectionOrCheckModel.setLastUpdateTimestamp(rs.getTimestamp(11));
                inspectionOrCheckModel.setDomainName(rs.getString(12));
                inspectionOrCheckModelList.add(inspectionOrCheckModel);
            }
            logger.info ("retrieveByEventId (" + eventId + "): finished, retrieved list size: " + 
                    inspectionOrCheckModelList.size());
        }
        catch (SQLException sqEx)
        {
            logger.error("Exception occured in retrieveByEventId (" + eventId + ")", sqEx);
            throw sqEx;
        }
        finally
        {
            ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        return inspectionOrCheckModelList;
    }
}

