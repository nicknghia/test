/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/util/Document.java,v 1.1.10.1 2010/08/22 23:08:34 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: Document.java,v $
 *  Revision 1.1.10.1  2010/08/22 23:08:34  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdfolio.document.util;



/**
 * EventModel associated with EventDao and ShipmentEventAction.
 * This class is a Value Object to transfer the data from presentation layer
 * to the Database.
 *
 *
 * @author Biju Joseph
 */

public class Document implements java.io.Serializable

{
    private String documentName;
    private String documentDescription;
    private String documentPath;

    public Document() {
    }

    public Document(String documentName,String documentDescription,String documentPath)
    {
		this.documentPath = documentPath;
		this.documentName = documentName;
		this.documentDescription = documentDescription;
    }

	/**
	 * Returns the documentDescription.
	 * @return String
	 */
	public String getDocumentDescription() {
		return documentDescription;
	}

	/**
	 * Returns the documentName.
	 * @return String
	 */
	public String getDocumentName() {
		return documentName;
	}

	/**
	 * Returns the documentPath.
	 * @return String
	 */
	public String getDocumentPath() {
		return documentPath;
	}

	/**
	 * Sets the documentDescription.
	 * @param documentDescription The documentDescription to set
	 */
	public void setDocumentDescription(String documentDescription) {
		this.documentDescription = documentDescription;
	}

	/**
	 * Sets the documentName.
	 * @param documentName The documentName to set
	 */
	public void setDocumentName(String documentName) {
		this.documentName = documentName;
	}

	/**
	 * Sets the documentPath.
	 * @param documentPath The documentPath to set
	 */
	public void setDocumentPath(String documentPath) {
		this.documentPath = documentPath;
	}

}

