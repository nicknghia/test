/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/common/SessionFactoryUtil.java,v 1.1.8.2 2010/08/22 23:08:26 mechevarria Exp $ 
 * 
 *  Modification History:
 *  $Log: SessionFactoryUtil.java,v $
 *  Revision 1.1.8.2  2010/08/22 23:08:26  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.1.8.1  2008/06/03 12:39:05  mechevarria
 *  gov_solutions merge updates
 *
 *  Revision 1.2  2007/04/25 08:42:29  atripathi
 *  moved to hibernate 3
 *
 *  Revision 1.1  2005/09/07 14:03:27  pjain
 *  baseline
 *
 *    
 */
package com.freightdesk.fdfolio.common;

import org.apache.log4j.Logger;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.cfg.Configuration;


/**
 * Utility class which provides Hibernate session.
 * 
 * @author Pankaj Jain
 */
public class SessionFactoryUtil {

    private static Logger logger = Logger.getLogger(SessionFactoryUtil.class); 
    private static Configuration configuration = null;

    private static SessionFactory sessionFactory = null;

    private SessionFactoryUtil(){   
    }

    public static Configuration getConfiguration()
        throws HibernateException
    {
        if (configuration==null)
        {
            configuration = new Configuration().configure("hibernate.cfg.xml");
            logger.debug ("new configuration: " + configuration);
        }

        return configuration;
    }

    public static SessionFactory getSessionFactory()
        throws HibernateException
    {
        if (sessionFactory==null)
        {
            sessionFactory = getConfiguration().buildSessionFactory();
            logger.info ("built sessionFactory: " + sessionFactory);
        }

        return sessionFactory;   
    }

    public static Session getSession()
    {
        //logger.debug ("getSession(): begin");
        try {
            return getSessionFactory().openSession();
        }
        catch (Exception ex) {
            logger.error("Exception in getSession(): ", ex);
            throw new RuntimeException(ex);
        }        
    }

    /** Closes the session.  Does not throw back any exception.
     * Also, does not log them with full stack trace, since session
     * close exceptions do not have any natural implication
     * or follow up. */
    public static void closeSession(Session session)
    {
        try {
            if (session.isOpen())
                session.close();
        } catch (Exception ex) {
            logger.debug ("Exception in closeSession, ignoring " + ex);
        }
    }

}
