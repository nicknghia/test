#!/bin/bash

## Compile and Run the code generator

javac CamirCodeGenerator.java
java -cp . CamirCodeGenerator $*
/cygdrive/c/Program\ Files/DevTools/vim/vim61/gvim.exe $*.java  &
