/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/common/LcpDictionary.java,v 1.3.10.1 2010/08/22 23:08:26 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: LcpDictionary.java,v $
 *  Revision 1.3.10.1  2010/08/22 23:08:26  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 * 
 */


package com.freightdesk.fdfolio.common;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;


/**
 * Encapsulates mapping between the Lcp Application and external application that can be set
 * differently for each deployment
 *
 *
 * Implemented as a singleton, and only allows a visiting
 * BootstrapServlet to initialize it.
 *
 * @author  Sangeeta Taneja
 * @version 1.0
 */
public class LcpDictionary {


    /**
     * The (only) instance of this Singleton
     */
    protected static LcpDictionary _instance;

    /**
     * The interal data structure used to store the properties
     */
    private Properties inner;

       /**
     * Gets the property using the given key
     * @param key The key for the mapping
     * @return The property corresponding to the key
     */
    public static String getProperty (String key) {
        return getInstance().inner.getProperty(key);
    }

    /**
     * Requires a secret to be initialized.
     */
    public synchronized static void load (InputStream inputStream, int secret)
        throws IOException
    {
        if (secret != 187568912) {
            System.err.println ("Where are you coming from?");
            throw new RuntimeException ("Unauthorized access to LcpDictionary.load()");
        }
        getInstance().inner.load(inputStream);
    }

    /**
     * Only constructor is declared private.
     */
    private LcpDictionary() {
        inner = new Properties();
    }

    /**
     * The getInstance() method for this Singleton.
     * Creates an instance if necessary.
     */
    private static LcpDictionary getInstance() {
        if (_instance == null) {
            _instance = new LcpDictionary();
        }
        return _instance;
    }
}
