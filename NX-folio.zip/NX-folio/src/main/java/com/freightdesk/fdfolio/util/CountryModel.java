/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/util/CountryModel.java,v 1.3.4.1 2010/08/22 23:08:34 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: CountryModel.java,v $
 *  Revision 1.3.4.1  2010/08/22 23:08:34  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.3  2006/03/28 21:23:01  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.2  2005/08/01 09:41:08  pjain
 *  refactored UserModel to BaseModel
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdfolio.util;

import java.io.Serializable;
import java.sql.Timestamp;

import com.freightdesk.fdcommons.BaseModel;

// Referenced classes of package com.freightdesk.fdfolio.util:
//            UserModel

public class CountryModel extends BaseModel
    implements Serializable
{

    private String countryCode;
    private String countryName;

    public CountryModel()
    {
    }

	/**
	 * Implements the abstract method defined by UserModel.
	 * @return primaryKey  the unique id key for this model object.
	 */
	public long getPrimaryKey(){
		throw new RuntimeException("Why do you want the primary key of a CountryModel?");
	}  
	
    public CountryModel(String countryCode, String countryName, String createUserId, Timestamp createTimestamp, String lastUpdateUserId, Timestamp lastUpdateTimestamp, String domainName)
    {
        this.countryCode = countryCode;
        this.countryName = countryName;
        super.createUserId = createUserId;
        super.createTimestamp = createTimestamp;
        super.lastUpdateUserId = lastUpdateUserId;
        super.lastUpdateTimestamp = lastUpdateTimestamp;
        super.domainName = domainName;
    }

    public String getCountryCode()
    {
        if(countryCode == null)
            countryCode = "";
        return countryCode;
    }

    public String getCountryName()
    {
        if(countryName == null)
            countryName = "";
        return countryName;
    }

    public void setCountryCode(String countryCode)
    {
        this.countryCode = countryCode;
    }

    public void setCountryName(String countryName)
    {
        this.countryName = countryName;
    }
}

