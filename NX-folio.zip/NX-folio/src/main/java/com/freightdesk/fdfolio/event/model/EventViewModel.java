/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/event/model/EventViewModel.java,v 1.1.10.1 2010/08/22 23:08:38 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: EventViewModel.java,v $
 *  Revision 1.1.10.1  2010/08/22 23:08:38  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.1  2004/09/15 13:12:45  ranand
 *  2.6 Baseline
 *
 * 
 */


package com.freightdesk.fdfolio.event.model;



import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Struts ActionForm class associated with EventDetail.jsp and ShipmentEventAction.
 * This class is a JavaBean which contains a set of properties related
 * to ShipmentEvent and their corresponding getter and setter methods.
 *
 * @author Rajender Anand
 */

	public class EventViewModel implements Serializable {

	    private String eventId;
	    private String eventTypeText;
	    private String appointmentReason;
	    private Timestamp eventDateTime;
	    private String locationName;
        private String containerIdentifier;
		private String eventDateTimeZone;
		
    	public String getEventId(){
			return eventId;
    	}

    	public void setEventId(String eventId){
				this.eventId = eventId;
    	}


    	public void setEventTypeText(String eventTypeText){
			this.eventTypeText = eventTypeText;
    	}
    	public String getEventTypeText(){
			return eventTypeText;
    	}

    	public String getAppointmentReason(){
			return (appointmentReason==null?"":appointmentReason);
    	}

    	public void setAppointmentReason(String appointmentReason){
			this.appointmentReason = appointmentReason;
    	}

	  	public String getLocationName(){
			return (locationName==null?"":locationName);
    	}

    	public void setLocationName(String locationName){
			this.locationName = locationName;
    	}

		/**
		 * Returns the containerIdentifier.
		 * @return String
		 */
		public String getContainerIdentifier() {
			return containerIdentifier;
		}

		/**
		 * Sets the containerIdentifier.
		 * @param containerIdentifier The containerIdentifier to set
		 */
		public void setContainerIdentifier(String containerIdentifier) {
			this.containerIdentifier = containerIdentifier;
		}

        /**
         * @return eventDateTime
         */
        public Timestamp getEventDateTime()
        {
            return eventDateTime;
        }

        /**
         * @param timestamp EventDateTime
         */
        public void setEventDateTime(Timestamp timestamp)
        {
            eventDateTime = timestamp;
        }

        /**
         * @return
         */
        public String getEventDateTimeZone()
        {
            return eventDateTimeZone;
        }

        /**
         * @param string
         */
        public void setEventDateTimeZone(String string)
        {
            eventDateTimeZone = string;
        }

	}
