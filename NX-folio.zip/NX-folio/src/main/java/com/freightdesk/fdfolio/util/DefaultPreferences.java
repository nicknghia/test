/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/util/DefaultPreferences.java,v 1.1.10.1 2010/08/22 23:08:34 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: DefaultPreferences.java,v $
 *  Revision 1.1.10.1  2010/08/22 23:08:34  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdfolio.util;

import java.util.HashMap;
import java.util.Map;

/**
 * DefaultPreferences contains the default preferences for LCP.
 */
public final class DefaultPreferences
{
    public static final String ALERT_USR_FOR_SHIPMT_CHANGES_GOING_TO_EXT_LINK = 
        "ALERT_USR_FOR_SHIPMT_CHANGES_GOING_TO_EXT_LINK";

    private Map inner;

    private DefaultPreferences() {
        inner = new HashMap();
        inner.put (ALERT_USR_FOR_SHIPMT_CHANGES_GOING_TO_EXT_LINK, new Boolean (true));
    }

    private static DefaultPreferences instance;

    public static DefaultPreferences getInstance()
    {
        if (instance == null)
            instance = new DefaultPreferences();
        return instance;
    }

    public String getProperty (String key)
    {
        return (String) inner.get (key);
    }
}

