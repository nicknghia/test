/**
 * Copyright (c) NTELX
 *  All rights reserved.
 *
 * This software is the confidential and proprietary information of NTELX
 * ("Confidential Information").  You shall not disclose such Confidential Information
 * and shall use it only in accordance with the terms of the license agreement you entered
 * into with NTELX.
 *
 *
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/common/LcpReferenceData.java,v 1.20.2.16 2010/09/23 19:35:23 mechevarria Exp $
 *
 *  Modification History:
 *  $Log: LcpReferenceData.java,v $
 *  Revision 1.20.2.16  2010/09/23 19:35:23  mechevarria
 *  remove ejb layer for instantiating objects.  direct calls to bean class now made
 *
 *  Revision 1.20.2.15  2010/08/22 23:08:26  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.20.2.14  2010/01/28 01:52:39  mechevarria
 *  uom update
 *
 *  Revision 1.20.2.13  2009/09/23 18:02:18  mechevarria
 *  import clean via eclipse
 *
 *  Revision 1.20.2.12  2009/09/22 19:32:42  mechevarria
 *  updated user management
 *
 *  Revision 1.20.2.11  2009/09/02 19:34:48  jhansford
 *  Changes for UAT on 9/3/2009
 *
 *  Revision 1.20.2.10  2009/08/12 18:16:02  jhansford
 *  Added Pull Down to switch domains on edit user page.
 *
 *  Revision 1.20.2.9  2009/03/24 16:40:16  mechevarria
 *  add hour and minute fields
 *
 *  Revision 1.20.2.8  2009/03/16 17:00:00  mechevarria
 *  comment out loading of reference data not currently used in FAS
 *
 *  Revision 1.20.2.7  2009/03/11 13:30:37  jhansford
 *  no message
 *
 *  Revision 1.20.2.6  2009/03/09 14:05:15  jhansford
 *  STD can COC Jsp are added
 *
 *  Revision 1.20.2.5  2009/02/26 20:33:30  jhansford
 *  Cached Carrier ID and Airport Lookups
 *
 *  Revision 1.20.2.4  2009/02/10 17:49:28  mbegley
 *  enhanced Eventhome Query and fixed paging
 *
 *  Revision 1.20.2.3  2009/01/28 20:46:49  mechevarria
 *  updates for air carrier screening reporting.  caching of air carrier and airport lists
 *
 *  Revision 1.20.2.2  2008/12/18 20:29:50  mechevarria
 *  additional updates for the eventhomepage and industry reporting modifications
 *
 *  Revision 1.20.2.1  2008/06/03 12:39:05  mechevarria
 *  gov_solutions merge updates
 *
 *  Revision 1.20.4.2  2008/02/13 21:07:29  fdoughty
 *  Added instanced ItemClassifications to Item page
 *
 *  Revision 1.20.4.1  2008/01/24 18:37:45  fdoughty
 *  Added reference validation for SHIPMENT.OBJECTTYPE
 *
 *  Revision 1.20  2007/01/23 11:24:27  atripathi
 *  method name changed from set1TimeZones to setTimeZones
 *
 *  Revision 1.19  2006/10/30 11:21:51  ranand
 *  removed unused variable
 *
 *  Revision 1.18  2006/10/27 16:54:17  mbegley
 *  added support for conveyance Make reference
 *
 *  Revision 1.17  2006/10/27 13:16:45  mbegley
 *  added getter/setter for conveyanceColorList reference
 *
 *  Revision 1.16  2006/10/11 12:31:38  ranand
 *  removed dependency on SYSTEMNAVIGATIONTYPE
 *
 *  Revision 1.15  2006/10/06 07:04:20  ranand
 *  added new List for ConveyanceReference Type
 *
 *  Revision 1.14  2006/10/03 08:35:11  dbansal
 *  conveyance details
 *
 *  Revision 1.13  2006/04/10 22:43:56  aarora
 *  Removed redundant code
 *
 *  Revision 1.12  2006/03/28 21:23:00  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.11  2005/10/01 15:50:18  amrinder
 *  Moved access control logic to action class
 *
 *  Revision 1.10  2005/09/16 13:29:28  nsehra
 *  changed clearReferenceData , the check will come from permissions and not from navigation type
 *
 *  Revision 1.9  2005/09/01 14:01:37  nsehra
 *  orgRoleList  added
 *
 *  Revision 1.8  2005/04/26 22:46:08  amrinder
 *  Removed defunct comments
 *
 *  Revision 1.7  2005/02/08 19:32:32  amrinder
 *  Now implementing Serializable for J2EE compatibility
 *
 *  Revision 1.6  2005/01/18 22:05:28  amrinder
 *  Minor formatting changes
 *
 *  Revision 1.5  2004/09/21 08:44:31  ranand
 *  package of Manager classes  changed from folioweb to folio
 *
 *  Revision 1.4  2004/09/16 07:25:20  ranand
 *  package name changed from organization to orghierarchy in fdfolio
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 */

package com.freightdesk.fdfolio.common;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;

import org.apache.log4j.Logger;

import com.freightdesk.fdfolio.dao.EventDAO;
import com.freightdesk.fdfolio.orghierarchy.ejb.OrganizationSLSBean;
import com.freightdesk.fdfolio.useraccess.ejb.UserAccessSLSBean;
import com.freightdesk.fdcommons.OptionBean;



/**
 * LcpReferenceData encapsulates the reference data for the LCP application.
 * It holds lists of code-name elements.
 *
 * <P>
 * LcpReferenceData is implemented as a collection of singletons.  For each domain,
 * there is at most one instance of LcpReferenceData.  A map is used internally to hold
 * references to singletons.
 *
 * <P>
 * <B>Usage:</B><BR>
 * This class has no public consructors.
 * To use the LcpReferenceData, obtain an instance using the
 * <code>getInstance (String domainName) </code> method.
 *
 * <P>
 * @see com.freightdesk.fdfolio.item.ejb.ItemSLSBean#fillLcpReferenceData ItemSLSBean.fillLcpReferenceData
 * @see com.freightdesk.fdfolio.order.ejb.OrderSLSBean#fillLcpReferenceData OrderSLSBean.fillLcpReferenceData
 * @see com.freightdesk.fdfolio.settlement.ejb.SettlementSLSBean#fillLcpReferenceData SettlementSLSBean.fillLcpReferenceData
 * @see com.freightdesk.fdfolio.shipment.ejb.ShipmentSLSBean#fillLcpReferenceData ShipmentSLSBean.fillLcpReferenceData
 * @see com.freightdesk.fdfolio.tariff.ejb.TariffSLSBean#fillLcpReferenceData TariffSLSBean.fillLcpReferenceData
 *
 * @author Amrinder Arora
 */
public class LcpReferenceData
    implements Serializable
{
    // just an object to synchronize on
    private static Object lock = new Object();

    // the map of the instances of this singleton
    // instances of LcpReferenceData for each domain
    private static Map _instances = new HashMap();

    /** A logger */
    public static transient Logger logger = Logger.getLogger("com.freightdesk.common.LcpReferenceData");

    // domain Name that this intance of LcpReferenceData is for
    private String domainName;

    /**
     * The following data is independent of domain
     */
    /** A list of time zones */
    private static List timeZones;
    /** A list of domain objects */
    private static List domainObjectsList = new ArrayList();
    /** A map of domain objects */
    private static Map domainObjectsMap = new HashMap();

    /**
     * The following data is specific for each domain.
     */
    /** A list of transport mode (code and name pairs) */
    private List transportModesList = new ArrayList();
    /** A list of shipping terms (code and name pairs) */
    private List shippingTermsList = new ArrayList();
    private List shipmentReferenceTypesList = new ArrayList();
    private List shipmentStatusList = new ArrayList();
    private List currencySymbolsList = new ArrayList();
    private List involvedPartyTypesList = new ArrayList();
    private List involvedPartyReferenceTypesList = new ArrayList();
    private List shipmentChargeTypesList = new ArrayList();
    private List shipmentInstructionTypesList = new ArrayList();
    private List EDI_ISO_equipmentTypesList = new ArrayList();
    private List equipmentStatusesList = new ArrayList();
    private List stopFunctionsList = new ArrayList();
    private List eventsList = new ArrayList();
    private List appointmentReasonsList = new ArrayList();
    private List packageTypesList = new ArrayList();
    private List marksNumbersTypesList = new ArrayList();
    private List countryCodesList = new ArrayList();
    private List packageReferenceTypesList = new ArrayList();
    private List methodOfPaymentCodesList = new ArrayList();
    private List freightPaymentTypeCodesList = new ArrayList();
    private List vesselRoleCodesList = new ArrayList();
    private List incoTermTypeCodesList = new ArrayList();
    private List bolStatusTypeCodesList = new ArrayList();
    private List serviceLevelCodesList = new ArrayList();
    private List serviceTypeCodesList = new ArrayList();
    private List inBondTypeCodesList = new ArrayList();
    private List weightUOMsList = new ArrayList();
    private List volumeUOMsList = new ArrayList();
    private List lengthUOMsList = new ArrayList();
    private List UOMsList = new ArrayList();


    private List organizationReferenceTypeCodesList = new ArrayList(); // organization reference codes
    private List orghierarchyTypeCodesList = new ArrayList();//organization codes
    private List orgRoleCodesList = new ArrayList();//org codes
    private List sellPackList = new ArrayList();
    private List sellPackCurrencyCodeList = new ArrayList();
    private List itemClassificationList = new ArrayList();
    private List itemItlClassificationList = new ArrayList();
    private List itemHazmatList = new ArrayList();
    private List itemCommodityClassTypeList = new ArrayList();
    private List commodityClass = new ArrayList();
    private List commodityClassIDNameList = new ArrayList();

    private List orderTypeCodes = new ArrayList();
    private List orderStatusTypeCodes = new ArrayList();
    private List transactionStatusTypeCodes = new ArrayList();
    private List eventCategoryCodes = new ArrayList();
    private List eventTypeCodes = new ArrayList();
	private List eventReferenceTypeCodes = new ArrayList();
    private List containerTypeList = new ArrayList();
    private List accessorialTypesList = new ArrayList();
    private List rateCostTypesList = new ArrayList();
    private List containerTypeGroupList = new ArrayList();
    private List commodityClassGroupList = new ArrayList();
    private List accessorialTypeList     = new ArrayList();
    private List accessorialCostTypeList     = new ArrayList();
    private List accessorialEffectRangeTypeList     = new ArrayList();
    private List determinantList                    = new ArrayList();

    private List paymentTermsTypeCodeList = new ArrayList();
    private List inspectionOrCheckTypeCodeList = new ArrayList();
    // Codes for Invoice
    private List invoiceStatusCodeList = new ArrayList();
    private List dateTimeStampReferenceTypeCodeList = new ArrayList();
    private List otherMeasureTypesList = new ArrayList();
    private List securityDeviceValueTypeCodeList = new ArrayList();

    // Codes for Conveyance
    private List categoryList = new ArrayList();
    private List conveyanceColorList = new ArrayList();
    private Map categoryToTypeListMap = new HashMap();
    private List conveyanceMakeList = new ArrayList();

    private List invoiceChargeTypeCodeList = new ArrayList();
    // End of codes for Invoice
    // map representation of codes
    private Map accessorialTypeMap = new HashMap();
    private Map rateCostTypeMap = new HashMap();

    private Map transportModesMap = new HashMap();
    private Map shippingTermsMap = new HashMap();
    private Map shipmentReferenceTypesMap = new HashMap();
    private Map shipmentStatusMap = new HashMap();
    private Map currencySymbolsMap = new HashMap();
    private Map involvedPartyTypesMap = new HashMap();
    private Map involvedPartyReferenceTypesMap = new HashMap();
    private Map shipmentChargeTypesMap = new HashMap();
    private Map shipmentInstructionTypesMap = new HashMap();
    private Map EDI_ISO_equipmentTypesMap = new HashMap();
    private Map equipmentStatusesMap = new HashMap();
    private Map stopFunctionsMap = new HashMap();
    private Map eventsMap = new HashMap();
    private Map eventCategoryTypesMap = new HashMap();
    private Map appointmentReasonsMap = new HashMap();
    private Map packageTypesMap = new HashMap();
    private Map marksNumbersTypesMap = new HashMap();
    private Map countryCodesMap = new HashMap();
    private Map packageReferenceTypesMap = new HashMap();
    private Map methodOfPaymentCodesMap = new HashMap();
    private Map freightPaymentTypeCodesMap = new HashMap();
    private Map vesselRoleCodesMap = new HashMap();
    private Map serviceLevelCodesMap = new HashMap();

    private Map organizationReferenceTypeCodesMap = new HashMap(); // orgreference codes
    private Map orghierarchyTypeCodesMap = new HashMap(); //orghierarchy type codes
	private Map orgRoleCodesMap = new HashMap(); //orghierarchy type codes
    private Map sellPackMap = new HashMap();
    private Map itemClassificationMap = new HashMap();
    private Map itemItlClassificationMap = new HashMap();
    private Map itemHazmatMap = new HashMap();
    private Map itemCommodityClassTypeMap = new HashMap();
    private Map itemCommodityClassMap     = new HashMap();
    private Map commodityClassMap = new HashMap();
    private Map commodityClassIDNameMap = new HashMap();
    private Map itemClassIDNameMap = new HashMap();
    private Map commodityClassCodeIDMap = new HashMap();
    private Map UOMsMap = new HashMap();

    private Map orderTypeCodesMap = new HashMap();
    private Map orderStatusTypeCodesMap = new HashMap();
    private Map transactionStatusTypeCodesMap = new HashMap();
    private Map eventCategoryCodesMap = new HashMap();
    private Map eventReferenceTypeCodesMap = new HashMap();
    private Map containerTypeMap = new HashMap();
    private Map serviceTypeCodesMap = new HashMap();
    private Map inBondTypeCodesMap = new HashMap();
    private Map paymentTermsTypeCodeMap = new HashMap();
    private Map inspectionOrCheckTypeCodeMap = new HashMap();

    // Codes for Invoice
    private Map invoiceStatusCodeMap = new HashMap();
    private Map dateTimeStampReferenceTypeCodeMap = new HashMap();
    private Map otherMeasureTypesMap = new HashMap();
    // End of codes for Invoice

    private Map incoTermTypeCodesMap = new HashMap();
    // Code for SecurityDevice
    private Map securityDeviceTypeMap = new HashMap();
    private Map securityDeviceValueTypeMap = new HashMap();
    private Map securityDeviceValueTypeCodeMap = new HashMap();

    private Map invoiceChargeTypeCodeMap = new HashMap();

    private List conveyanceReferenceTypeList= new ArrayList();

	private List objectTypesList = new ArrayList();

	private Map objectTypesMap = new HashMap();
	
	// FAS specific addition for Carrier Reporting
	private List reportingTypeCodeList = new ArrayList();
	private Map reportingTypeCodesMap = new HashMap();
	
	private List<OptionBean> securityDeviceTypeList         = new ArrayList(); 
	private List<OptionBean> chainOfCustodyTypeCodeList     = new ArrayList();
	private List<OptionBean> packagingTypeCodeList          = new ArrayList();
	private List<OptionBean> commodityTypeCodeList          = new ArrayList();
	private List<OptionBean> alarmTypeCodeList              = new ArrayList();
	private List<OptionBean> methodOfResolutionTypeCodeList = new ArrayList();
	private List<OptionBean> extPackageTypeList             = new ArrayList();
	private List<OptionBean> fillerTypeList                 = new ArrayList();


	private List<String> hourList = new ArrayList<String>();
	private List<String> minuteList = new ArrayList<String>();
	


	/** Initializes the list of domain objects. */
    protected void initDomainObjectsList()
    {
        domainObjectsList.add (new OptionBean ("Shipment", "SHIP"));
        domainObjectsList.add (new OptionBean ("Shipment Leg", "LEG"));
        domainObjectsList.add (new OptionBean ("Package", "PCKGE"));
        domainObjectsList.add (new OptionBean ("Equipment", "EQPMT"));
        domainObjectsList.add (new OptionBean ("Organization", "ORGNZ"));
        domainObjectsList.add (new OptionBean ("Document", "DOC"));
        domainObjectsList.add (new OptionBean ("Document Submission", "DOCSB"));
        domainObjectsList.add (new OptionBean ("Order", "ORDER"));
    }

    /**
     * Retrieves the list of time zone option beans.
     *
     * Since the timeZones is a static attribute, we need to obtain it only once.
     * i.e., this code runs only when the <b>first</b> instance is created.
     * The reason this code is not declared as a static block is that
     * JNDI names cannot be looked up that soon (The resourcees may not have been
     * bound at class load time).
     */
    protected void initTimeZones()
    {
        try {
            Context initialContext = new InitialContext();
            UserAccessSLSBean userAccesssSLS = new UserAccessSLSBean();
            timeZones = userAccesssSLS.getTimeZoneOBs();
        }
        catch (Exception t) {
            logger.error("Exception in getting time zones", t);
            throw new RuntimeException("getting time zones did not complete successfully");
        }
    }

    /**
     * Creates an instance of LcpReferenceData for a particular domain name.
     * This constructor is declared private, and it is only called from
     * the getInstance() method.  It retrieves the data from the DB.
     */
    private LcpReferenceData(String domainName)
    {
        this.domainName = domainName;

        // The LcpReferenceData constructor takes a *long* time, we must log it
        logger.info("A new instance of LcpReferenceData being created for: " + this.domainName);

        try {
            Context initialContext = new InitialContext();
            
            // Gets the time zones if they have not been looked up yet.
            if (timeZones == null)
                initTimeZones();
            
            try {
                
                OrganizationSLSBean organizationSLS = new OrganizationSLSBean();
                organizationSLS.fillLcpReferenceData(this, domainName);
                securityDeviceTypeList         = organizationSLS.getPublicSecurityDeviceModels();
                chainOfCustodyTypeCodeList     = organizationSLS.getChainOfCustodyTypeCodes();
                packagingTypeCodeList          = organizationSLS.getPackageTypeCodeList(); 
                commodityTypeCodeList          = organizationSLS.getCommodityCodeList();
                alarmTypeCodeList              = organizationSLS.getAlarmTypeCodeList(); 
                methodOfResolutionTypeCodeList = organizationSLS.getMethodOfResolutionTypeCodeList();
                extPackageTypeList             = organizationSLS.getExtPackagingCodeList();
                fillerTypeList                 = organizationSLS.getFillerCodeList();
                logger.debug("organizationSLS.fillLcpReferenceData() finished.");
            }
            catch (Exception t) {
                logger.error("Exception in getOrganizationReferenceTypeCodesList", t);
                throw new RuntimeException("LcpReferenceData(): Organization " + "organization reference type codes list did not complete successfully");
            }
            
           try {
        	   // load event type and category codes
        	   EventDAO eventDAO = new EventDAO();
        	   eventDAO.fillLcpReferenceData(this, domainName);
        	   
               logger.debug("eventSLS.fillLcpReferenceData() finished.");
           }
           catch (Exception t) {
               logger.error("Exception in loaded Event type reference data", t);
               throw new RuntimeException(t);
           }
           // create the hour and minute list for web pulldowns
           hourList = createNumberList(0,23);
           minuteList = createNumberList(0,59);
        }
        catch (NamingException ne) {
            logger.error("NamingException in LcpReferenceData()", ne);
            throw new RuntimeException("NamingException in LcpReferenceData()");
        }

        logger.info("Finished creating LcpReferenceData instance for: " + domainName);
    }
    
    

    public List<String> getHourList() {
		return hourList;
	}

	public void setHourList(List<String> hourList) {
		this.hourList = hourList;
	}

	public List<String> getMinuteList() {
		return minuteList;
	}

	public void setMinuteList(List<String> minuteList) {
		this.minuteList = minuteList;
	}

	/**
     * A backdoor to reload data.
     */
    public static void clearReferenceData (int secret)
    {
        logger.info ("clearReferenceData (): begin");
        
        
        if (7834797 == secret)
            _instances.clear();
        else throw new RuntimeException ("PUTZ!! Your phone number not good enough to reload reference data.");
    }

    /**
     * Clears all retrieved reference data.
     * This ensures that next time an instance is requested, it will
     * be refreshed from the DB.
     */
    public static void clearReferenceData ()
    {
        logger.info ("clearReferenceData (): begin");
        
    }

    /**
     * Clears all retrieved reference data.
     * This ensures that next time an instance is requested, it will
     * be refreshed from the DB.
     */
    public static void clearReferenceData (String domainName)
    {
        logger.info ("clearReferenceData (" + domainName + "): begin");
        if ((domainName == null) || (domainName.length() == 0))
            throw new IllegalArgumentException ("Trying to reload data for 'null' domain.");

        // Only a domain administrator can reload the refernce data for that domain
        logger.debug("clearReferenceData(): Removing ref data for " + domainName);
        _instances.remove(domainName);
    }

    /**
     * Gets the instance for this domainName.
     * The first time this method is called for that domain,
     * it creates an instance, and puts it in the internal map.
     * Next time, it returns the already created instance for that domain.
     *
     * <P><B>What can happen if no synchronization is used?</B><BR>
     * A section of this method is declared synchronized for an important reason.
     * When the server starts up, it may have many requests simultaneously, and many of these
     * requests may try to "get" an instance of reference data of a domain.
     * Since no prior instance of reference data will be available, each request
     * will spawn off a request to the constructor.  The last constructor that finishes
     * will then store the reference data object in the instances Map.  After that though,
     * the situation will be stabalized, and only the cached reference data object
     * will be returned.  It is justified to declare a section of this method sychronized,
     * since the only case in which that section takes long to return is when it calls the
     * constructor, and that is precisely when sychronization is required.
     *
     * <P>The entire method could be declared synchronized too, but that would
     * put performance penalty on the frequent usage of getInstance().  After the
     * first time call for a particular domain, all future calls will return the cached
     * copy, so there is no reason to synchronize on that.
     *
     * <P>A better scheme would be if synchronization was performed on object
     * locks that created on a per-domain basis.  In essence, the current method
     * will not even allow two constructors to run for separate domains, while
     * we only need to stop two constructors to run for same domain.
     */
    public static LcpReferenceData getInstance(String domainName)
    {
        logger.debug ("LcpReferenceData.getInstance: " + domainName);
        LcpReferenceData lrd = (LcpReferenceData) (_instances.get(domainName));
        if (lrd != null)
            return lrd;
        // synchronizing on the lock.  There is nothing magical about lock,
        // just need some object to synchronize on, and lock is a static attribute
        // and hence available in this method.
        synchronized (lock) {
            logger.debug ("In the synchronized block");
            // previous call to get was outside of synchronized block, must call it again
            lrd = (LcpReferenceData) (_instances.get(domainName));
            if (lrd == null) {
                logger.debug ("Creating new instance of LcpReferenceData for " + domainName);
                lrd = new LcpReferenceData(domainName);
                _instances.put(domainName, lrd);
            }
            logger.debug ("leaving the synchronized block");
        }
        return lrd;
    }

    public Map getIncoTermTypeCodesMap()
    {
        return incoTermTypeCodesMap;
    }
    public void setIncoTermTypeCodesMap(Map incoTermTypeCodesMap)
    {
        this.incoTermTypeCodesMap = incoTermTypeCodesMap;
    }
    public Map getPaymentTermsTypeCodeMap()
    {
        return paymentTermsTypeCodeMap;
    }
    public void setPaymentTermsTypeCodeMap(Map paymentTermsTypeCodeMap)
    {
        this.paymentTermsTypeCodeMap = paymentTermsTypeCodeMap;
    }
    public List getPaymentTermsTypeCodeList()
    {
        return paymentTermsTypeCodeList;
    }
    public void setPaymentTermsTypeCodeList(List paymentTermsTypeCodeList)
    {
        this.paymentTermsTypeCodeList = paymentTermsTypeCodeList;
    }

    //Getter and setter methods for Invoice
    public Map getInvoiceStatusCodeMap()
    {
        return invoiceStatusCodeMap;
    }
    public void setInvoiceStatusCodeMap(Map invoiceStatusCodeMap)
    {
        this.invoiceStatusCodeMap = invoiceStatusCodeMap;
    }
    public List getInvoiceStatusCodeList()
    {
        return invoiceStatusCodeList;
    }
    public void setInvoiceStatusCodeList(List invoiceStatusCodeList)
    {
        this.invoiceStatusCodeList = invoiceStatusCodeList;
    }

        public Map getDateTimeStampReferenceTypeCodeMap()
    {
        return dateTimeStampReferenceTypeCodeMap;
    }
    public void setDateTimeStampReferenceTypeCodeMap(Map dateTimeStampReferenceTypeCodeMap)
    {
        this.dateTimeStampReferenceTypeCodeMap = dateTimeStampReferenceTypeCodeMap;
    }
    public List getDateTimeStampReferenceTypeCodeList()
    {
        return dateTimeStampReferenceTypeCodeList;
    }
    public void setDateTimeStampReferenceTypeCodeList(List dateTimeStampReferenceTypeCodeList)
    {
        this.dateTimeStampReferenceTypeCodeList = dateTimeStampReferenceTypeCodeList;
    }
    
    public List getAccessorialTypeList() {
        return accessorialTypeList;
    }

    public List getAccessorialCostTypeList() {
        return accessorialCostTypeList;
    }

    public List getAccessorialEffectRangeTypeList() {
        return accessorialEffectRangeTypeList;
    }

    /** Gets the list of containerTypeGroup */
    public List getContainerTypeGroupList() {
        return containerTypeGroupList;
    }

    public List getCommodityClassGroupList() {
        return this.commodityClassGroupList;
    }


    /** Sets the list of containerTypeGroup*/
    public void setContainerTypeGroupList(List containerTypeGroupList) {
        this.containerTypeGroupList = containerTypeGroupList;
    }

    public void setCommodityClassGroupList(List commodityClassGroupList) {
            this.commodityClassGroupList = commodityClassGroupList;
        }

	public List<OptionBean> getSecurityDeviceTypeList() {
		return securityDeviceTypeList;
	}

	public void setSecurityDeviceTypeList(List<OptionBean> securityDeviceTypeList) {
		this.securityDeviceTypeList = securityDeviceTypeList;
	}

    /** Gets the list of transport modes */
    public List getTransportModesList() {
        return transportModesList;
    }

    /**
     * Sets the list of transport modes.
     * This method is only used in the initialization step.
     *
     * @param newList The new list of transport modes
     */

    public List getShippingTermsList() {
        return shippingTermsList;
    }

    public List getShipmentReferenceTypesList() {
        return shipmentReferenceTypesList;
    }

    public List getShipmentStatusList() {
        return shipmentStatusList;
    }

    public List getCurrencySymbolsList() {
        return currencySymbolsList;
    }

    public List getInvolvedPartyTypesList() {
        return involvedPartyTypesList;
    }

    public List getShipmentChargeTypesList() {
        return shipmentChargeTypesList;
    }

    public List getShipmentInstructionTypesList() {
        return shipmentInstructionTypesList;
    }

    public List getEDI_ISO_equipmentTypesList() {
        return EDI_ISO_equipmentTypesList;
    }

    public List getEquipmentStatusesList() {
        return equipmentStatusesList;
    }

    public List getStopFunctionsList() {
        return stopFunctionsList;
    }

    public List getEventsList() {
        return eventsList;
    }

    public List getAppointmentReasonsList() {
        return appointmentReasonsList;
    }

    public List getPackageTypesList() {
        return packageTypesList;
    }

    public List getMarksNumbersTypesList() {
        return marksNumbersTypesList;
    }

    public List getCountryCodesList() {
        return countryCodesList;
    }

    public List getPackageReferenceTypesList() {
        return packageReferenceTypesList;
    }

    public List getMethodOfPaymentCodesList() {
        return methodOfPaymentCodesList;
    }

    public List getFreightPaymentTypeCodesList() {
        return freightPaymentTypeCodesList;
    }

    public List getSellPackList() {
        return sellPackList;
    }

    public List getSellPackCurrencyCodeList() {
        return sellPackCurrencyCodeList;
    }

    public List getVesselRoleCodesList() {
        return vesselRoleCodesList;
    }

    public List getItemClassificationList() {
        return itemClassificationList;
    }

    public List getItemItlClassificationList() {
        return itemItlClassificationList;
    }

    public List getItemHazmatList() {
        return itemHazmatList;
    }

    public List getItemCommodityClassTypeList() {
        return itemCommodityClassTypeList;
    }

    public List getCommodityClass() {
        return commodityClass;
    }
    public List getCommodityClassIDNameList() {
        return commodityClassIDNameList;
    }

    public List getDeterminantList(){
        return determinantList;
    }
    //getter/setter methods for Map variables
    public Map getTransportModesMap() {
        return transportModesMap;
    }

    public Map getAccessorialTypeMap() {
          return accessorialTypeMap;
      }
    public Map getRateCostTypeMap() {
              return rateCostTypeMap;
          }


    public Map getShippingTermsMap() {
        return shippingTermsMap;
    }
    public void setShippingTermsMap(Map newMap) {
        this.shippingTermsMap = newMap;
    }

    public Map getShipmentReferenceTypesMap() {
        return shipmentReferenceTypesMap;
    }
    public void setShipmentReferenceTypesMap(Map newMap) {
        this.shipmentReferenceTypesMap = newMap;
    }

    public Map getShipmentStatusMap() {
        return shipmentStatusMap;
    }
    public void setShipmentStatusMap(Map newMap) {
        this.shipmentStatusMap = newMap;
    }

    public Map getCurrencySymbolsMap() {
        return currencySymbolsMap;
    }
    public void setCurrencySymbolsMap(Map newMap) {
        this.currencySymbolsMap = newMap;
    }

    public Map getInvolvedPartyTypesMap() {
        return involvedPartyTypesMap;
    }
    public void setInvolvedPartyTypesMap(Map newMap) {
        this.involvedPartyTypesMap = newMap;
    }

    public Map getShipmentChargeTypesMap() {
        return shipmentChargeTypesMap;
    }
    public void setShipmentChargeTypesMap(Map newMap) {
        this.shipmentChargeTypesMap = newMap;
    }

    public Map getShipmentInstructionTypesMap() {
        return shipmentInstructionTypesMap;
    }
    public void setShipmentInstructionTypesMap(Map newMap) {
        this.shipmentInstructionTypesMap = newMap;
    }

    public Map getEDI_ISO_equipmentTypesMap() {
        return EDI_ISO_equipmentTypesMap;
    }
    public void setEDI_ISO_equipmentTypesMap(Map newMap) {
        this.EDI_ISO_equipmentTypesMap = newMap;
    }

    public Map getEquipmentStatusesMap() {
        return equipmentStatusesMap;
    }
    public void setEquipmentStatusesMap(Map newMap) {
        this.equipmentStatusesMap = newMap;
    }

    public Map getStopFunctionsMap() {
        return stopFunctionsMap;
    }
    public void setStopFunctionsMap(Map newMap) {
        this.stopFunctionsMap = newMap;
    }

    public Map getEventsMap() {
        return eventsMap;
    }
    public void setEventsMap(Map newMap) {
        this.eventsMap = newMap;
    }

    public Map getAppointmentReasonsMap() {
        return appointmentReasonsMap;
    }
    public void setAppointmentReasonsMap(Map newMap) {
        this.appointmentReasonsMap = newMap;
    }

    public Map getPackageTypesMap() {
        return packageTypesMap;
    }
    public void setPackageTypesMap(Map newMap) {
        this.packageTypesMap = newMap;
    }

    public Map getMarksNumbersTypesMap() {
        return marksNumbersTypesMap;
    }
    public void setMarksNumbersTypesMap(Map newMap) {
        this.marksNumbersTypesMap = newMap;
    }

    public Map getCountryCodesMap() {
        return countryCodesMap;
    }
    public void setCountryCodesMap(Map newMap) {
        this.countryCodesMap = newMap;
    }

    public Map getPackageReferenceTypesMap() {
        return packageReferenceTypesMap;
    }
    public void setPackageReferenceTypesMap(Map newMap) {
        this.packageReferenceTypesMap = newMap;
    }

    public Map getOrganizationReferenceTypeCodesMap() {
        return organizationReferenceTypeCodesMap;
    }

    public Map getOrghierarchyTypeCodesMap()
    {
        return orghierarchyTypeCodesMap;
    }
    public void setOrganizationReferenceTypeCodesMap(Map newMap) {
        this.organizationReferenceTypeCodesMap = newMap;
    }
    public void setOrghierarchyTypeCodesMap(Map newMap)
    {
        this.orghierarchyTypeCodesMap = newMap;
    }
	public Map getOrgRoleCodesMap()
	{
			return orgRoleCodesMap;
	}
	public void setOrgRoleCodesMap(Map newMap)
	{
		this.orgRoleCodesMap = newMap;
	}
    public Map getMethodOfPaymentCodesMap() {
        return methodOfPaymentCodesMap;
    }
    public void setMethodOfPaymentCodesMap(Map newMap) {
        this.methodOfPaymentCodesMap = newMap;
    }

    public Map getFreightPaymentTypeCodesMap() {
        return freightPaymentTypeCodesMap;
    }
    public void setFreightPaymentTypeCodesMap(Map newMap) {
        this.freightPaymentTypeCodesMap = newMap;
    }

    public Map getSellPackMap() {
        return sellPackMap;
    }
    public void setSellPackMap(Map newMap) {
        this.sellPackMap = newMap;
    }

    public Map getVesselRoleCodesMap() {
        return vesselRoleCodesMap;
    }
    public void setVesselRoleCodesMap(Map newMap) {
        this.vesselRoleCodesMap = newMap;
    }

    public Map getItemClassificationMap() {
        return itemClassificationMap;
    }
    public void setItemClassificationMap(Map newMap) {
        this.itemClassificationMap = newMap;
    }

    public Map getItemItlClassificationMap() {
        return itemItlClassificationMap;
    }
    public void setItemItlClassificationMap(Map newMap) {
        this.itemItlClassificationMap = newMap;
    }

    public Map getItemHazmatMap() {
        return itemHazmatMap;
    }
    public void setItemHazmatMap(Map newMap) {
        this.itemHazmatMap = newMap;
    }

    public Map getContainerTypeMap() {
        return containerTypeMap;
    }
    public void setContainerTypeMap(Map containerTypeMap) {
        this.containerTypeMap = containerTypeMap;
    }

    /**
     * Gets the hazmatTypeName from the hazmatTypeCode.  Returns
     * null if there is no such code in the hazmat map.
     */
    public String getHazmatTypeName(String hazmatTypeCode) {
        return (String) (itemHazmatMap.get(hazmatTypeCode));
    }

    public Map getItemCommodityClassTypeMap() {
        return itemCommodityClassTypeMap;
    }

    public Map getItemCommodityClassMap() {
        return itemCommodityClassMap;
    }

    public void setItemCommodityClassTypeMap(Map newMap) {
        this.itemCommodityClassTypeMap = newMap;
    }

    public void setItemCommodityClassMap(Map newMap) {
        this.itemCommodityClassMap = newMap;
    }

    public Map getCommodityClassMap() {
        return commodityClassMap;
    }
    public void setCommodityClassMap(Map newMap) {
        this.commodityClassMap = newMap;
    }
    public List<OptionBean> getCommodityTypeCodeList() {
		return commodityTypeCodeList;
	}

	public void setCommodityTypeCodeList(List<OptionBean> commodityTypeCodeList) {
		this.commodityTypeCodeList = commodityTypeCodeList;
	}

	public List<OptionBean> getAlarmTypeCodeList() {
		return alarmTypeCodeList;
	}

	public void setAlarmTypeCodeList(List<OptionBean> alarmTypeCodeList) {
		this.alarmTypeCodeList = alarmTypeCodeList;
	}

	public List<OptionBean> getExtPackageTypeList() {
		return extPackageTypeList;
	}
	
	public List<OptionBean> getFillerTypeList() {
		return fillerTypeList;
	}

	public void setFillerTypeList(List<OptionBean> fillerTypeList) {
		this.fillerTypeList = fillerTypeList;
	}

	public void setExtPackageTypeList(List<OptionBean> extPackageTypeList) {
		this.extPackageTypeList = extPackageTypeList;
	}

	public List<OptionBean> getMethodOfResolutionTypeCodeList() {
		return methodOfResolutionTypeCodeList;
	}

	public void setMethodOfResolutionTypeCodeList(
			List<OptionBean> methodOfResolutionTypeCodeList) {
		this.methodOfResolutionTypeCodeList = methodOfResolutionTypeCodeList;
	}

	public Map getOrderTypeCodesMap()
    {
        return orderTypeCodesMap;
    }
    public void setOrderTypeCodesMap(Map newMap)
    {
        this.orderTypeCodesMap = newMap;
    }
    public Map getOrderStatusTypeCodesMap()
    {
        return orderStatusTypeCodesMap;
    }
    public void setOrderStatusTypeCodesMap(Map newMap)
    {
        this.orderStatusTypeCodesMap = newMap;
    }
    public Map getTransactionStatusTypeCodesMap()
    {
        return transactionStatusTypeCodesMap;
    }
    public void setTransactionStatusTypeCodes(Map newMap)
    {
        this.transactionStatusTypeCodesMap = newMap;
    }
    public Map getEventCategoryCodesMap()
    {
        return eventCategoryCodesMap;
    }
    public void setEventCategoryCodesMap(Map newMap)
    {
        this.eventCategoryCodesMap = newMap;
    }
    public Map getEventReferenceTypeCodesMap()
    {
        return eventReferenceTypeCodesMap;
    }
    public void setEventReferenceTypeCodesMap(Map newMap)
    {
        this.eventReferenceTypeCodesMap = newMap;
    }
    public Map getServiceTypeCodesMap()
    {
        return serviceTypeCodesMap;
    }

    public void setServiceTypeCodesMap(Map newMap)
    {
        this.serviceTypeCodesMap = newMap;
    }

    public Map getInBondTypeCodesMap()
    {
        return inBondTypeCodesMap;
    }
    public void setInBondTypeCodesMap(Map newMap)
    {
        this.inBondTypeCodesMap = newMap;
    }
    public Map getCommodityClassIDNameMap()
    {
        return commodityClassIDNameMap;
    }

    public Map getItemClassIDNameMap()
    {
    	return itemClassIDNameMap;
    }
    
    /**
     * Gets the list of time zones.  The list of time zones is static, and therefore
     * independent of the domain.
     */
    public List getTimeZones() {
        return timeZones;
    }

    /**
     * Sets the list of time zones.  The list of time zones is static, and therefore
     * independent of the domain.  This method is only used in the initialization step.
     */
    public void setTimeZones(List newTimeZones) {
        //this.timeZones = newTimeZones; // Should be accessed in static way.
        LcpReferenceData.timeZones = newTimeZones;
    }

    /** Gets the list of organization reference type codes */
    public List<OptionBean> getOrganizationReferenceTypeCodesList() {
        return organizationReferenceTypeCodesList;
    }

    public List getOrghierarchyTypeCodesList()
    {
        return orghierarchyTypeCodesList;
    }

    /** Sets the list of organization reference type codes */
    public void setOrganizationReferenceTypeCodesList(List newList) {
        this.organizationReferenceTypeCodesList = newList;
    }

    public void setOrghierarchyTypeCodesList(List newList)
    {
        this.orghierarchyTypeCodesList = newList;
    }

	public List getOrgRoleCodesList()
	{
		return orgRoleCodesList;
	}
	public void setOrgRoleCodesList(List newList)
	 {
		 this.orgRoleCodesList = newList;
	 }

    /**
     * Gets the list of order type codes
     */
    public List getOrderTypeCodesList() {
        return orderTypeCodes;
    }

    /**
     * Sets the list of order type codes
     */
    public void setOrderTypeCodesList(List newList) {
        this.orderTypeCodes = newList;
    }

    /**
     * Gets the list of order type codes
     */
    public List getOrderStatusTypeCodes() {
        return orderStatusTypeCodes;
    }
    public void setOrderStatusTypeCodes(List newList)
    {
        this.orderStatusTypeCodes = newList;
    }
    public List getTransactionStatusTypeCodes()
    {
        return transactionStatusTypeCodes;
    }
    public void setTransactionStatusTypeCodes(List newList)
    {
        this.transactionStatusTypeCodes = newList;
    }

    public List getEventCategoryCodes()
    {
        return eventCategoryCodes;
    }
    public void setEventCategoryCodes(List newList)
    {
        this.eventCategoryCodes = newList;
    }

    public List getEventReferenceTypeCodes()
    {
        return eventReferenceTypeCodes;
    }

    public void setEventReferenceTypeCodes(List newList)
    {
        this.eventReferenceTypeCodes = newList;
    }
    /**
     * Gets the country code for the given country name.
     *
     * <P>
     * Iterates through countryCodesList and returns the country
     * code for the given country name.  If the given country name
     * is not available in the list, it returns null.
     *
     * @param countryName The country name
     * @return The two letter coutry code for the given country name,
     * or null if no name in the list matched the given country name.
     */
    public String getCountryCode(String countryName) {
        for (int index = 0; index < countryCodesList.size(); index++) {
            OptionBean optionBean = (OptionBean) (countryCodesList.get(index));
            if (optionBean.getLabel().equalsIgnoreCase(countryName)) {
                return optionBean.getValue();
            }
        }
        return null;
    }

    /**
     * Gets the country name for the given country code.
     *
     * <P>
     * Searches the country code in countryCodesMap and returns the country
     * name for the given country code.  If the given country code
     * is not available in the Map, it returns null.
     *
     * @param countryCode The two letter coutry code
     * @return The country name for that country code, null if no country
     * code in the list matches the given country code.
     */
    public String getCountryName(String countryCode) {
        return (String) (countryCodesMap.get(countryCode));
    }


    /**
     * Gets the inco term type codes list
     */
    public List getIncoTermTypeCodesList () {
        return incoTermTypeCodesList;
    }

    /**
     * Gets the BOL (Bill of Lading) status type codes list
     */
    public List getBolStatusTypeCodesList() {
        return bolStatusTypeCodesList;
    }

    /**
     * Gets the list of service types
     */
    public List getServiceTypeCodesList() {
        return serviceTypeCodesList;
    }

    /**
     * Gets the list of service level codes
     */
    public List getServiceLevelCodesList() {
        return serviceLevelCodesList;
    }

    /**
     * Gets the list of service level codes in a map
     */
    public Map getServiceLevelCodesMap() {
        return serviceLevelCodesMap;
    }

    /**
     * Gets the list of in bond type codes
     */
    public List getInbondTypeCodesList() {
        return inBondTypeCodesList;
    }

    /**
     * Gets the list of weight UOM codes
     */
    public List getWeightUOMsList() {
        return weightUOMsList;
    }

    /**
     * Gets the list of volume UOM codes
     */
    public List getVolumeUOMsList() {
        return volumeUOMsList;
    }

    /** Gets the list of length UOM codes */
    public List getLengthUOMsList () {
        return lengthUOMsList;
    }

    /**
     * Gets the list of Container Type
     */
    public List getContainerTypeList() {
        return containerTypeList;
    }

    /**
     * Gets the list of Accessorial Types
     */
    public List getAccessorialTypesList() {
        return this.accessorialTypesList;
    }

    public void setAccessorialTypeList(List accessorialTypesList) {
        this.accessorialTypesList = accessorialTypesList;
    }

    /**
     * Gets the list of Accessorial Types
     */
    public List getRateCostTypesList() {
           return this.rateCostTypesList;
    }

    public void setRateCostTypesList(List rateCostTypesList) {
        this.rateCostTypesList = rateCostTypesList;
    }

    public List<OptionBean> getChainOfCustodyTypeCodes()
    {
    	logger.debug("In Get chain of custody type codes "); 
    	return chainOfCustodyTypeCodeList;
    }

    public List<OptionBean> getPackagingTypeCodeList() {
		return packagingTypeCodeList;
	}

	public void setPackagingTypeCodeList(List<OptionBean> packagingTypeCodeList) {
		this.packagingTypeCodeList = packagingTypeCodeList;
	}

	/**
     * Sets the list of Container Type
     */
    public void setContainerTypeList(List containerTypeList) {
        this.containerTypeList = containerTypeList;
    }

    /**
     * Gets the list of Domain Object option beans
     */
    public List getDomainObjectsList ()
    {
        return domainObjectsList;
    }

    /**
     * Gets the Map of Domain Object option beans
     */
    public Map getDomainObjectsMap ()
    {
        return domainObjectsMap;
    }
    /**
     * Returns the otherMeasureTypesMap.
     * @return Map
     */
    public Map getOtherMeasureTypesMap() {
        return otherMeasureTypesMap;
    }

    /**
     * Sets the otherMeasureTypesMap.
     * @param otherMeasureTypesMap The otherMeasureTypesMap to set
     */
    public void setOtherMeasureTypesMap(Map otherMeasureTypesMap) {
        this.otherMeasureTypesMap = otherMeasureTypesMap;
    }

    /**
     * @return
     */
    public Map getSecurityDeviceTypeMap()
    {
        return securityDeviceTypeMap;
    }

    /**
     * @return
     */
    public Map getSecurityDeviceValueTypeMap()
    {
        return securityDeviceValueTypeMap;
    }
    /**
     * @return
     */
    public Map getSecurityDeviceValueTypeCodeMap()
    {
        return securityDeviceValueTypeCodeMap;
    }

    public List getOtherMeasureTypesList()
    {
        return otherMeasureTypesList;

    }

    /**
     * @return
     */
    public void setSecurityDeviceValueTypeCodeMap(Map securityDeviceValueTypeCodeMap)
    {
        this.securityDeviceValueTypeCodeMap = securityDeviceValueTypeCodeMap;
    }

    /**
     * Sets the otherMeasureTypesList.
     * @param otherMeasureTypesList The otherMeasureTypesList to set
     */
    public void setOtherMeasureTypesList(List otherMeasureTypesList) {
        this.otherMeasureTypesList = otherMeasureTypesList;
    }

    /**
     * Returns the uOMsList.
     * @return List
     */
    public List getUOMsList() {
        return UOMsList;
    }

    /**
     * Sets the uOMsList.
     * @param uOMsList The uOMsList to set
     */
    public void setUOMsList(List uOMsList) {
        UOMsList = uOMsList;
    }

    /**
     * Returns the uOMsMap.
     * @return Map
     */
    public Map getUOMsMap() {
        return UOMsMap;
    }

    /**
     * Sets the uOMsMap.
     * @param uOMsMap The uOMsMap to set
     */
    public void setUOMsMap(Map uOMsMap) {
        UOMsMap = uOMsMap;
    }

    /**
     * @return
     */
    public List getInvolvedPartyReferenceTypesList()
    {
        return involvedPartyReferenceTypesList;
    }

    /**
     * @return
     */
    public Map getInvolvedPartyReferenceTypesMap()
    {
        return involvedPartyReferenceTypesMap;
    }

    /**
     * Returns the inspectionOrCheckTypeCodeList.
     * @return List
     */
    public List getInspectionOrCheckTypeCodeList() {
        return inspectionOrCheckTypeCodeList;
    }

    /**
     * Returns the inspectionOrCheckTypeCodeMap.
     * @return Map
     */
    public Map getInspectionOrCheckTypeCodeMap() {
        return inspectionOrCheckTypeCodeMap;
    }

    /**
     * Sets the inspectionOrCheckTypeCodeList.
     * @param inspectionOrCheckTypeCodeList The inspectionOrCheckTypeCodeList to set
     */
    public void setInspectionOrCheckTypeCodeList(List inspectionOrCheckTypeCodeList) {
        this.inspectionOrCheckTypeCodeList = inspectionOrCheckTypeCodeList;
    }

    /**
     * Sets the inspectionOrCheckTypeCodeMap.
     * @param inspectionOrCheckTypeCodeMap The inspectionOrCheckTypeCodeMap to set
     */
    public void setInspectionOrCheckTypeCodeMap(Map inspectionOrCheckTypeCodeMap) {
        this.inspectionOrCheckTypeCodeMap = inspectionOrCheckTypeCodeMap;
    }

    /**
     * @return
     */
    public List getSecurityDeviceValueTypeCodeList() {
        return securityDeviceValueTypeCodeList;
    }

    /**
     * @param list
     */
    public void setSecurityDeviceValueTypeCodeList(List list) {
        securityDeviceValueTypeCodeList = list;
    }


       /**
     * @return
     */
    public List getInvoiceChargeTypeCodeList()
    {
        return invoiceChargeTypeCodeList;
    }

    /**
     * @return
     */
    public Map getInvoiceChargeTypeCodeMap()
    {
        return invoiceChargeTypeCodeMap;
    }

    /**
     * @param invoiceChargeTypeCodeList
     */
    public void setInvoiceChargeTypeCodeList(List invoiceChargeTypeCodeList)
    {
        this.invoiceChargeTypeCodeList = invoiceChargeTypeCodeList;
    }

    /**
     * @param invoiceChargeTypeCodeMap
     */
    public void setInvoiceChargeTypeCodeMap(Map invoiceChargeTypeCodeMap)
    {
        this.invoiceChargeTypeCodeMap = invoiceChargeTypeCodeMap;
    }

    /**
     * @return eventCategoryTypesMap
     */
    public Map getEventCategoryTypesMap() {
        return eventCategoryTypesMap;
    }

    public void setEventCategoryTypesMap(Map eventCategoryTypesMap) {
        this.eventCategoryTypesMap = eventCategoryTypesMap;
    }

    /**
     * @return commodityClassCodeIDMap
     */
    public Map getCommodityClassCodeIDMap() {
        return commodityClassCodeIDMap;
    }

    /**
     * @param commodityClassCodeIDMap
     */
    public void setCommodityClassCodeIDMap(Map commodityClassCodeIDMap) {
        this.commodityClassCodeIDMap = commodityClassCodeIDMap;
    }

    public List getCategoryList()
    {
        return categoryList;
    }

    public Map getCategoryToTypeListMap()
    {
        return categoryToTypeListMap;
    }

    /**
     * @return
     */
    public List getConveyanceReferenceTypeList()
    {
        return conveyanceReferenceTypeList;
    }

    public List getConveyanceColorList() {
        return conveyanceColorList;
    }

    public List getConveyanceMakeList() {
        return conveyanceMakeList;
    }
    /**
     * @param conveyanceReferenceTypeList The conveyanceReferenceTypeList to set.
     */
    public void setConveyanceReferenceTypeList(List conveyanceReferenceTypeList)
    {
        this.conveyanceReferenceTypeList = conveyanceReferenceTypeList;
    }

    public void setConveyanceColorList(List conveyanceColorList) {
        this.conveyanceColorList = conveyanceColorList;
    }

    public void setConveyanceMakeList(List conveyanceMakeList) {
        this.conveyanceMakeList = conveyanceMakeList;
    }

	public List getObjectTypesList() {
		return objectTypesList;
	}

	public Map getObjectTypesMap() {
		return objectTypesMap;
	}

	public List getReportingTypeCodeList() {
		return reportingTypeCodeList;
	}

	public void setReportingTypeCodeList(List reportingTypeCodeList) {
		this.reportingTypeCodeList = reportingTypeCodeList;
	}

	public Map getReportingTypeCodesMap() {
		return reportingTypeCodesMap;
	}

	public void setReportingTypeCodesMap(Map reportingTypeCodeMap) {
		this.reportingTypeCodesMap = reportingTypeCodeMap;
	}
	
    public List getEventTypeCodes() {
		return eventTypeCodes;
	}

	public void setEventTypeCodes(List eventTypeCodes) {
		this.eventTypeCodes = eventTypeCodes;
	}
	
	private List<String> createNumberList(int start, int end) {
		List<String> numberList = new ArrayList<String>();
		
		for(int i=start; i<end+1; i++) {
			if(i < 10) {
				numberList.add("0" + Integer.toString(i));
			} 
			else {
				numberList.add(Integer.toString(i));
			}
		}
		
		return numberList;
	}

}

