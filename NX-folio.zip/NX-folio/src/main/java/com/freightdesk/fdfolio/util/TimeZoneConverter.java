/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/util/TimeZoneConverter.java,v 1.2.4.1 2010/08/22 23:08:34 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: TimeZoneConverter.java,v $
 *  Revision 1.2.4.1  2010/08/22 23:08:34  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.2  2006/06/08 21:20:22  aarora
 *  Removed unused method
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 */


package com.freightdesk.fdfolio.util;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Calendar;
import java.util.GregorianCalendar;
import java.util.TimeZone;

import org.apache.log4j.Logger;

public class TimeZoneConverter implements Serializable
{
    /** A logger */
    public static Logger logger = Logger.getLogger("com.freightdesk.fdfolio.util.TimeZoneConverter");

    public static Timestamp convertToTimeZone(String fromTZone, String toTZone, Timestamp aTime)
    {
        if (fromTZone == null || toTZone == null)
            return aTime;
        else if (fromTZone.equalsIgnoreCase(toTZone))
            return aTime;
        Calendar calTZoneFrom = new GregorianCalendar(TimeZone.getTimeZone(fromTZone));
        Calendar calTZoneTo = new GregorianCalendar(TimeZone.getTimeZone(toTZone));

        logger.debug("Time in Mills, entered by user, in GMT::" + aTime.getTime());
        logger.debug(fromTZone + " Time Zone Offset from GMT::" + calTZoneFrom.get(Calendar.ZONE_OFFSET));

        long convertedTimeInMs = aTime.getTime() - calTZoneFrom.get(Calendar.ZONE_OFFSET);
        logger.debug("converted time in MilliSeconds::" + convertedTimeInMs);
        calTZoneTo.setTimeInMillis(convertedTimeInMs);
        calTZoneTo.set(Calendar.YEAR, calTZoneTo.get(Calendar.YEAR) - 1900);
        Timestamp ts = new Timestamp(convertedTimeInMs);
        //ts.setYear(calTZoneTo.get(Calendar.YEAR)-1900);
        logger.debug("Converted time in GMT::" + ts.toString());

        return ts;
    }
}
