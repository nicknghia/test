/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/useraccess/model/SystemRoleModel.java,v 1.4.2.1 2010/08/22 23:08:31 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: SystemRoleModel.java,v $
 *  Revision 1.4.2.1  2010/08/22 23:08:31  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.4  2006/10/11 12:31:38  ranand
 *  removed dependency on SYSTEMNAVIGATIONTYPE
 *
 *  Revision 1.3  2006/03/28 21:23:07  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.2  2005/08/01 09:41:08  pjain
 *  refactored UserModel to BaseModel
 *
 *  Revision 1.1  2004/09/15 13:07:11  ranand
 *  2.6 Baseline
 *
 * 
 */



package com.freightdesk.fdfolio.useraccess.model;

import java.io.Serializable;
import java.sql.Timestamp;

import com.freightdesk.fdcommons.BaseModel;

public class SystemRoleModel extends BaseModel
    implements Serializable
{

    private String systemRoleCode;
    private String systemRoleName;
    private String systemRoleStatus;

    public SystemRoleModel(String systemRoleCode, String systemRoleName,  String systemRoleStatus, String createUserId, Timestamp createTimestamp, String lastUpdateUserId, 
            Timestamp lastUpdateTimestamp, String domainName)
    {
        this.systemRoleCode = systemRoleCode;
        this.systemRoleName = systemRoleName;
        this.systemRoleStatus = systemRoleStatus;
        super.createUserId = createUserId;
        super.createTimestamp = createTimestamp;
        super.lastUpdateUserId = lastUpdateUserId;
        super.lastUpdateTimestamp = lastUpdateTimestamp;
        super.domainName = domainName;
    }

	/**
	 * Implements the abstract method defined by BaseModel.
	 * @throws RunTimeException because no unique id key for this model object exist.
	 */
	public long getPrimaryKey(){
		throw new RuntimeException("Why do you want the primary key of a SystemRoleModel?");
	}  

    public String getSystemRoleStatus()
    {
        if(systemRoleStatus == null)
            systemRoleStatus = "";
        return systemRoleStatus;
    }


    public String getSystemRoleCode()
    {
        if(systemRoleCode == null)
            systemRoleCode = "";
        return systemRoleCode;
    }

    public String getSystemRoleName()
    {
        if(systemRoleName == null)
            systemRoleName = "";
        return systemRoleName;
    }

    public void setSystemRoleStatus(String systemRoleStatus)
    {
        this.systemRoleStatus = systemRoleStatus;
    }


    public void setSystemRoleCode(String systemRoleCode)
    {
        this.systemRoleCode = systemRoleCode;
    }

    public void setSystemRoleName(String systemRoleName)
    {
        this.systemRoleName = systemRoleName;
    }
}

