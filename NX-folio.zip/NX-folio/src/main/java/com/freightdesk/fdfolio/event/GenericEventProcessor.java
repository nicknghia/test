/** 

 * Copyright (c) NTELX 

 *  All rights reserved. 

 * 

 * This software is the confidential and proprietary information of NTELX 

 * ("Confidential Information").  You shall not disclose such Confidential Information 

 * and shall use it only in accordance with the terms of the license agreement you entered 

 * into with NTELX. 

 * 

 * 

 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/event/GenericEventProcessor.java,v 1.1.8.1 2010/08/22 23:08:38 mechevarria Exp $ 

 * 

 *  Modification History:

 *  $Log: GenericEventProcessor.java,v $
 *  Revision 1.1.8.1  2010/08/22 23:08:38  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.1  2005/08/31 13:10:26  nsehra
 *  first version
 *

 */

package com.freightdesk.fdfolio.event;
import org.apache.log4j.Logger;

import com.freightdesk.fdfolio.event.model.EventModel;
 

/**
 * @author Nitin Sehra
 *
 */

public class GenericEventProcessor
{
	protected Logger logger = Logger.getLogger(getClass());
	
	public void eventCreated (EventModel eventModel)
	{
		logger.debug("eventCreated begin:");
	}
}
