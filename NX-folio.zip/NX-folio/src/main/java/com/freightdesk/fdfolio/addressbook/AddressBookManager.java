/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/addressbook/AddressBookManager.java,v 1.18.2.4 2010/09/23 19:35:26 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: AddressBookManager.java,v $
 *  Revision 1.18.2.4  2010/09/23 19:35:26  mechevarria
 *  remove ejb layer for instantiating objects.  direct calls to bean class now made
 *
 *  Revision 1.18.2.3  2010/09/15 15:18:51  mechevarria
 *  add some extra uppercasing...bleh
 *
 *  Revision 1.18.2.2  2010/08/22 23:08:40  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.18.2.1  2010/02/03 20:31:47  mechevarria
 *  update addresshome load query getorghierarchies to use bind variables
 *
 *  Revision 1.18  2006/10/27 09:39:02  dkumar
 *  added address import/export functinality
 *
 *  Revision 1.17  2006/10/19 12:03:39  dkumar
 *  added code for org child navigation
 *
 *  Revision 1.16  2006/09/26 05:52:18  ranand
 *  removed unused import statements
 *
 *  Revision 1.15  2006/07/27 07:53:28  ranand
 *  removed warning
 *
 *  Revision 1.14  2006/04/05 21:22:01  ranand
 *  TextFilter moved to FDCommons
 *
 *  Revision 1.13  2006/03/28 21:22:59  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.12  2006/02/14 19:04:20  aarora
 *  Minor changes
 *
 *  Revision 1.11  2005/08/30 02:14:37  amrinder
 *  Trying to clean the code for handling links on address tab
 *
 *  Revision 1.10  2005/08/09 21:59:22  amrinder
 *  Some formatting changes
 *
 *  Revision 1.9  2005/08/03 12:06:56  ranand
 *  sorting applied on address home page
 *
 *  Revision 1.8  2005/07/06 04:19:39  nsehra
 *  removed isMyAddressbook bcz orgType is already there to prvide the required funcationality
 *
 *  Revision 1.7  2005/07/02 10:09:44  nsehra
 *  changed for myaddressbook
 *
 *  Revision 1.6  2005/03/15 22:10:14  amrinder
 *  Mostly formatting changes
 *
 *  Revision 1.5  2004/09/15 13:01:57  ranand
 *  2.6 Baseline
 */


package com.freightdesk.fdfolio.addressbook;

import java.util.Collections;
import java.util.List;

import crt.com.freightdesk.fdfolio.addressbook.util.OrgSearchResult;
import com.freightdesk.fdfolio.common.BaseManager;
import crt.com.freightdesk.fdfolio.orghierarchy.OrgComparator;
import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;
import com.freightdesk.fdfolio.search.ejb.SearchBean;
//import com.freightdesk.fdfolioweb.addressbook.form.AddressBookAdvancedSearchForm;
//import com.freightdesk.fdfolioweb.addressbook.form.AddressHomeForm;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.TextFilter;
import com.freightdesk.fdfolioweb.addressbook.action.AddressHomeAction;

/**
 * The business logic facade for the Addressbook Manager.
 * Addressbook Manager is responsible for interacting with the business objects
 * related to all addressbook needs.
 *
 * It is mostly involved in search related functionalities.
 *
 * @author Biju Joseph
 * @author Amrinder Arora
 */
public class AddressBookManager
    extends BaseManager
{
    /** Reference to  */
    


    private long getTotalAddressCount(String query, Credentials credentials) throws Exception
    {
        StringBuffer entireSqlBuffer = new StringBuffer ("SELECT COUNT(*)");
        entireSqlBuffer.append (" FROM ORGHIERARCHY OH ");
        entireSqlBuffer.append (" WHERE OH.DOMAINNAME in ('PUBLIC', '" + credentials.getDomainName() + "')");
        entireSqlBuffer.append (query);
        String sql = entireSqlBuffer.toString();
        logger.info("getTotalAddressCount, query is: " + sql);
        try {
            // Gets the search result from the SearchBean
            SearchBean searcher = new SearchBean();
            long count = searcher.executeQuery_long (sql);
            logger.info("getTotalAddressCount(): returning " + count );
            return count;
        } catch (Exception ex) {
            logger.error ("getAdvancedSearchResults, exception: ", ex);
            throw ex;
        }
    }

    /**
     * Retrieves results based on advanced search criteria having more than one attribute. 
     * 
     * This method generates the SQL query based on enduser's input and gets the results from the
     * SearchBean based on that query.  The search request is given from the Addressbook Advanced Search page. 
     * In this Addressbook advanced search, enduser can give multiple search criterias 
     * to search a specific address. 
     * {@link com.ntelx.nxcommons.TextFilter#getSQLString TextFilter.getSQLString}
     *
     * @param addrbkAdvancedSearchForm      Searches attribute at a given instance.
     * @param credentials                   User information.
     * @param startIndex                    Starting index of ROWNUM.
     * @param endIndex                      Ending Index of ROWNUM.
     * 
     * @return List                         Lists organization details. 
     *
     * @throws java.lang.Exception          If an unexpected exception occurs during SQL generation and SearchBean usage
     */
    public OrgSearchResult getAdvancedSearchResults(String query, Credentials credentials, 
            long startIndex, long endIndex) 
        throws Exception
    {
        try {
            StringBuffer entireSqlBuffer = new StringBuffer ("SELECT * FROM (SELECT OH.ORGID, OH.ORGNAME, OH.COUNTRYCODE, OH.PARENTORGID, OH.ORGHIERARCHYTYPECODE, OH.LASTUPDATETIMESTAMP, OH.CITY, OH.STATEPROVINCE, OH.ADDRESSLINE1, OH.STATEPROVINCECODE, ROWNUM myrow ");
            entireSqlBuffer.append (" FROM ORGHIERARCHY OH ");
            entireSqlBuffer.append (" WHERE OH.DOMAINNAME in ('PUBLIC', '" + credentials.getDomainName() + "')");
            entireSqlBuffer.append (query);
            entireSqlBuffer.append (" ) WHERE myrow between "+startIndex+" AND "+endIndex);
            String sql = entireSqlBuffer.toString();
            logger.info("getAdvancedSearchResults, query is: " + sql);

            // Gets the search result from the SearchBean
            SearchBean searcher = new SearchBean();
            List<OrghierarchyModel> orgList = searcher.getAdvanceOrgSearch(sql, credentials.getDomainName());
            logger.info("getAdvancedSearchResults(): returning " + orgList.size() + " orghierarchies.");
            long count = getTotalAddressCount (query, credentials);
            OrgSearchResult addressSearchResult = new OrgSearchResult(orgList, count);
            return addressSearchResult;
        }
        catch (Exception ex) {
            logger.error ("getAdvancedSearchResults, exception: ", ex);
            throw ex;
        }
    }

    /** Gets the advanced search query from the ActionForm. */
//    public String getAdvanceSearchQuery(AddressBookAdvancedSearchForm addrbkAdvancedSearchForm,
//            Credentials credentials, long startIndex, long endIndex)
//    {
//        String orgCheckBox = addrbkAdvancedSearchForm.getChkOrganization();
//        String contactCheckBox = addrbkAdvancedSearchForm.getChkContact();
//        String addressCheckBox = addrbkAdvancedSearchForm.getChkAddress();
//        /** sqlBuffer holds part of the WHERE clause of the query */
//        StringBuffer sqlBuffer = new StringBuffer();
//        //oragnization/Location info has been selected for search
//        if ((orgCheckBox != null) && (!orgCheckBox.equals("")))
//        {
//            logger.debug ("Appending organization where clause to advanced search query");
//
//            String orgLocName = addrbkAdvancedSearchForm.getTxtOrgLocName();
//            String orgLocNameSelect = addrbkAdvancedSearchForm.getSelectedOrgLocName();
//
//            if (orgLocName != null && !orgLocName.equals("")) {
//                sqlBuffer.append (" AND OH.ORGNAME " + TextFilter.getSQLString (orgLocNameSelect, orgLocName));
//            }
//
//            String SCACCode = addrbkAdvancedSearchForm.getTxtSCACCode();
//            String SCACCodeSelect = addrbkAdvancedSearchForm.getSelectedSCACCode();
//
//            if (SCACCode != null && !SCACCode.equals("")) {
//                sqlBuffer.append (" AND  OH.SCACCODE " + TextFilter.getSQLString (SCACCodeSelect, SCACCode));
//            }
//
//            String EINSNumber = addrbkAdvancedSearchForm.getTxtEINSNumber();
//            String EINSNumberSelect = addrbkAdvancedSearchForm.getSelectedEINSNumber();
//            if (EINSNumber != null && !EINSNumber.equals("")) {
//                sqlBuffer.append (" AND OH.EINNUMBER " + TextFilter.getSQLString (EINSNumberSelect, EINSNumber));
//            }
//
//            String DUNSNumber = addrbkAdvancedSearchForm.getTxtDUNSNumber();
//            String DUNSNumberSelect = addrbkAdvancedSearchForm.getSelectedDUNSNumber();
//            if (DUNSNumber != null && !DUNSNumber.equals("")) {
//                sqlBuffer.append (" AND OH.DUNSNUMBER " + TextFilter.getSQLString (DUNSNumberSelect, DUNSNumber));
//            }
//        }
//
//        // contact info has been selected for search
//        if ((contactCheckBox != null) && (!contactCheckBox.equals("")))
//        {
//            logger.debug ("Appending contact where clause to advanced search query");
//
//            String firstName = addrbkAdvancedSearchForm.getTxtFirstName();
//            String firstNameSelect = addrbkAdvancedSearchForm.getSelectedFirstName();
//            if ((firstName != null) && (!firstName.equals(""))) {
//                sqlBuffer.append (" AND OH.CONTACTFIRSTNAME " + TextFilter.getSQLString (firstNameSelect, firstName));
//            }
//
//            String lastName = addrbkAdvancedSearchForm.getTxtLastName();
//            String lastNameSelect = addrbkAdvancedSearchForm.getSelectedLastName();
//            if (lastName != null && !lastName.equals("")) {
//                sqlBuffer.append (" AND OH.CONTACTLASTNAME " + TextFilter.getSQLString (lastNameSelect, lastName));
//            }
//
//            String title = addrbkAdvancedSearchForm.getTxtTitle();
//            String titleSelect = addrbkAdvancedSearchForm.getSelectedTitle();
//            if (title != null && !title.equals("")) {
//                sqlBuffer.append (" AND OH.CONTACTTITLE " + TextFilter.getSQLString (titleSelect, title));
//            }
//
//            String department = addrbkAdvancedSearchForm.getTxtDepartment();
//            String departmentSelect = addrbkAdvancedSearchForm.getSelectedDepartment();
//            if (department != null && !department.equals("")) {
//                sqlBuffer.append (" AND OH.ORGROLECODE " + TextFilter.getSQLString (departmentSelect, department));
//            }
//        }
//
//        // address info has been selected for search
//        if ((addressCheckBox != null) && (!addressCheckBox.equals("")))
//        {
//            logger.debug ("Appending address where clause to advanced search query");
//
//            String address1 = addrbkAdvancedSearchForm.getTxtAddress1();
//            String address1Select = addrbkAdvancedSearchForm.getSelectedAddress1();
//
//            if ((address1 != null) && (!address1.equals(""))) {
//                sqlBuffer.append (" AND OH.ADDRESSLINE1 " + TextFilter.getSQLString (address1Select, address1));
//            }
//
//            String address2 = addrbkAdvancedSearchForm.getTxtAddress2();
//            String address2Select = addrbkAdvancedSearchForm.getSelectedAddress2();
//
//            if ((address2 != null) && (!address2.equals(""))) {
//                sqlBuffer.append (" AND OH.ADDRESSLINE2 " + TextFilter.getSQLString (address2Select, address2));
//            }
//
//            String city = addrbkAdvancedSearchForm.getTxtCity();
//            String citySelect = addrbkAdvancedSearchForm.getSelectedCity();
//            if (city != null && !city.equals("")) {
//                sqlBuffer.append (" AND OH.CITY " + TextFilter.getSQLString (citySelect, city));
//            }
//
//            String state = addrbkAdvancedSearchForm.getTxtState();
//            String stateSelect = addrbkAdvancedSearchForm.getSelectedState();
//            if (state != null && !state.equals("")) {
//                sqlBuffer.append (" AND  OH.STATEPROVINCE " + TextFilter.getSQLString (stateSelect, state));
//            }
//
//            String stateCode = addrbkAdvancedSearchForm.getTxtStateCode();
//            String stateCodeSelect = addrbkAdvancedSearchForm.getSelectedStateCode();
//            if (stateCode != null && !stateCode.equals("")) {
//                sqlBuffer.append (" AND  OH.STATEPROVINCECODE " + TextFilter.getSQLString (stateCodeSelect, stateCode));
//            }
//
//            String zip = addrbkAdvancedSearchForm.getTxtZip();
//            String zipSelect = addrbkAdvancedSearchForm.getSelectedZip();
//            if (zip != null && !zip.equals("")) {
//                sqlBuffer.append (" AND  OH.ZIPPOSTCODE " + TextFilter.getSQLString (zipSelect, zip));
//            }
//
//            String country = addrbkAdvancedSearchForm.getTxtCountry();
//            String countrySelect = addrbkAdvancedSearchForm.getSelectedCountry();
//            if (country != null && !country.equals("")) {
//                sqlBuffer.append (" AND  OH.COUNTRYCODE " + TextFilter.getSQLString (countrySelect, country));
//            }
//
//            /*
//            String longitude = addrbkAdvancedSearchForm.getTxtLongitude();
//            String longitudeSelect = addrbkAdvancedSearchForm.getSelectedLongitude();
//            String latitude = addrbkAdvancedSearchForm.getTxtLatitude();
//            String latitudeSelect = addrbkAdvancedSearchForm.getSelectedLatitude();
//            */
//        }
//        String sql = sqlBuffer.toString();
//        return sql;
//    }

    /**
     * Retrieves results based on search criteria when the request is from the Address tab. 
     * 
     * This method is used for getting the oraganization list from the SearchBean
     * when the request is from the address tab.  It also shows the organization list when the
     * search criteria is based on organization, location or ccontact. 
     *
     * This method can be called from two sources:
     * <OL>
     * <LI> From a link, such as A, B, and Aa-Ad on the Address Home page.
     * <LI> From the SearchBean string entered on the Address Home page.
     * </OL>
     *
     * @param addrHomeForm            Address attributes at a given instance.
     * @param credentials            User information.
     *
     * @return List                    Lists organization details. 
     *
     * @throws java.lang.Exception    If an unexpected exception occurs during SQL generation and SearchBean usage. 
     */
    public OrgSearchResult getQuickAddressHomeForTab(String search, String selRefType, String refSearchStr, 
            Credentials credentials, String orgType, String orgRole, long startIndex, long endIndex)
        throws Exception
    	{
        logger.info(" getQuickAddressHomeForTab " + " search " + search + " selRefType " + selRefType
            + " refSearchStr " + refSearchStr);
        try  {
            String strSearch = search.toUpperCase();
            String selectedRefType = selRefType.toUpperCase();
            String refSearch = refSearchStr.toUpperCase();
            
            logger.info ("Search Name: " + strSearch + "  Selected reference type: " +selectedRefType+"  Reference search text: "+refSearch);
            
            SearchBean searcher = new SearchBean();
            OrgSearchResult addressSearchResult = searcher.getOrgHierarchies (strSearch, selectedRefType, refSearch, credentials, orgType, orgRole, startIndex, endIndex);
            return addressSearchResult;
        }
        catch (Exception ex)  {
            logger.error ("getQuickAddressHomeForTab, unexpected exception", ex);
            throw ex;
        }
    }

    /**
     * Gets the oraganization list from the SearchBean.
     *
     * This method is used when the hierarchy type is available and requester is oraganization or routing module.  
     *
     * @param addrHomeForm                Address attributes at a given instance.
     * @param credentials                User information.
     * @param parent                    Hierarchy type (ORG or LOC).
     *
     * @return List                        Lists organization details.
     *
     * @throws java.lang.Exception        If an unexpected exception occurs during SQL generation and SearchBean usage.  
     */
    public OrgSearchResult getAddressHome(String search, Credentials credentials, List<String> parent, long startIndex,
            long endIndex) throws Exception
    {
        logger.info ("getAddressHome: started ......");
        try {
            SearchBean searcher = new SearchBean();
            return searcher.getAddressHome(getSearchString(search.toUpperCase()), credentials.getDomainName(),parent, startIndex, endIndex);
        }
        catch(Exception ex)  {
            logger.error ("getAddressHome: Exception is:  ", ex);
            throw ex;
        }
    }

    /**
     * Gets the oraganization list from the SearchBeanof particular orgHierarchyType with given parentorgId.
     *
     */
    public OrgSearchResult getAddressHomeForOrgOrLoc(long parentOrgId, Credentials credentials, String hierarchyTypeCode, long startIndex,
            long endIndex) throws Exception
    {
        logger.info ("getAddressHome: started ......");
        try {
            SearchBean searcher = new SearchBean();
            return searcher.getAddressHomeForOrgOrLoc(parentOrgId,credentials.getDomainName(),hierarchyTypeCode,startIndex,endIndex);
        }
        catch(Exception ex)  {
            logger.error ("getAddressHome: Exception is:  ", ex);
            throw ex;
        }
    }

    /**
     * This method is used for getting the Organization list from the SearchBean 
     *
     * @param addrHomeForm                Address attributes at a given instance.
     * @param credentials                User Information.
     * @param involvedPartyQualifier    Involved Party type code.
     *
     * @return java.util.ArrayList        It returns the list of organization details.
     *
     * @throws java.lang.Exception        If an unexpected exception occurs during SQL generation and SearchBean usage.
     */
    public OrgSearchResult getAddressHomeForLookUp(String search, Credentials credentials,String involvedPartyQualifier, long startIndex, long endIndex)
        throws Exception
    {
        OrgSearchResult addressSearchResult = null;

        logger.info ("getAddressHomeForLookUp: started ........");
        try {
            SearchBean searcher = new SearchBean();
            logger.debug("getAddressHomeForLookUp : searchString :: " + search);
            addressSearchResult = searcher.getAddressHomeForLookUp(search, credentials.getDomainName(),involvedPartyQualifier, startIndex, endIndex);
        }
        catch (Exception ex) {
            logger.error ("getAddressHomeForLookUp: Exception is:  ", ex);
            throw ex;
        }

        return addressSearchResult;
    }
    /**
     * This method is used for getting the Organization list from the SearchBean 
     *
     * @param addrHomeForm                Address attributes at a given instance.
     * @param credentials                User Information.
     * 
     * @return AddressSearchResult        It returns the list of addresses.
     *
     * @throws java.lang.Exception        If an unexpected exception occurs during SQL generation and SearchBean usage.
     */
    public OrgSearchResult getAddressHomeForUserAccess(String search, Credentials credentials, long  startIndex ,
            long endIndex)    throws Exception
    {
        OrgSearchResult addressSearchResult = null;

        logger.info ("getAddressHomeForUserAccess: started ........");
        try {
            SearchBean searcher = new SearchBean();
            logger.debug("getAddressHomeForUserAccess : searchString :: " + search);
            addressSearchResult = searcher.lookupContact(search, credentials.getDomainName(), startIndex, endIndex);
        }
        catch (Exception ex) {
            logger.error ("getAddressHomeForUserAccess: Exception is:  ", ex);
            throw ex;
        }

        return addressSearchResult;
    }
    /**
     * Gets the oraganization list from the SearchBean.
     * 
     * This method is used when the request is from Tariff module.         
     *
     * @param addrHomeForm                Address attributes at a given instance.
     * @param credentials                User Information.
     *
     * @return java.util.ArrayList        It returns the list of organization details.
     *
     * @throws java.lang.Exception        If an unexpected exception occurs during SQL generation and SearchBean usage.  
     */
    public OrgSearchResult getAddressHomeForCarrier(String search, Credentials credentials, long startIndex, long endIndex)
        throws Exception
    {
        logger.info ("getAddressHomeForCarrier: started ");
        try {
            SearchBean searcher = new SearchBean();
            return searcher.getAddressHomeForCarrier(getSearchString(search), credentials.getDomainName(), startIndex, endIndex);
        }
        catch(Exception ex) {
            logger.error ("getAddressHomeForCarrier , Exception is:  ", ex);
            throw ex;
        }
    }

    /**
     * Retrieves the SearchBean string.
     *
     * @param strSearch        Search input.
     *
     * @return String        If the strSearch is null, then it returns a default value, otherwise returns the same searched string.        
     */
    private String getSearchString(String strSearch)
    {
        if (strSearch == null || strSearch.trim().equals("")) {
            strSearch = "A";
        }
        logger.debug ("getSearchString: searchString is " + strSearch);
        return strSearch;
    }

    /**
     * Instantiates the AddressBookManager.
     */
    public AddressBookManager ()
    {
    }

    /**
     * Sorts Orders by a given Column.
     *
     * @param addressList               Contains Address  Models.
     * @param isAscending                True/false.
     * @param fieldAttribute             The attribute of the Address on which the sort is done.
     */
    public void sortByColumn(List<OrghierarchyModel> addressList,String fieldAttribute, boolean isAscending)
    {
        if (fieldAttribute == null || "".equals(fieldAttribute.trim())) {
            fieldAttribute = "orgName";
        }
        Collections.sort(addressList, new OrgComparator(fieldAttribute, isAscending));
    }
}//end of the AddressBookManager
