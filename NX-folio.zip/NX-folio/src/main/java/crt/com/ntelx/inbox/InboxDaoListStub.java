package crt.com.ntelx.inbox;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Random;
import java.util.Set;

import crt.com.freightdesk.fdfolio.dao.HAWBDao;
import crt.com.ntelx.awb.model.HAWB;

public class InboxDaoListStub
{
	//private static String [] identifiers = { "Bobs Burgers", "Coakley" };
	
	public static Map<Long, FaEntry> getRandomInbox()
	{
		Map<Long,FaEntry> faEntryList = new HashMap<Long,FaEntry>();
		
		HAWBDao awbDao = new HAWBDao();
		
		List<HAWB> listAwb = awbDao.retrieveForAWBHome(null, false, 0, null, null, "" );
		
		FaEntry faEntry = null;
		for ( int i = 0; i < listAwb.size(); i++ )
		{
			faEntry = getEntryFromHAWB( listAwb.get( i ) );
			faEntry.setEntryid( new Long( i ) );
			
			faEntry.setFaEntryscores( getFaEntryscoreSet(faEntry) );
			
			faEntryList.put( new Long( i ), faEntry );
		}		
		
		return faEntryList;
	}
	
	private static Set<FaEntryscore> getFaEntryscoreSet( FaEntry faEntry )
	{
		Set<FaEntryscore> entryScoreSet = new HashSet<FaEntryscore>();
				
		Random rand = new Random();		
		int n = rand.nextInt( 5 ) + 1;
		
		FaEntryscore entScore = null;
		for ( int i = 0; i < n; i++ )
		{
			entScore = getRandomEntryScore();
			entScore.setFaEntry( faEntry );
			entryScoreSet.add( entScore );			
		}		
		
		return entryScoreSet;
	}
	
	public static FaEntry getEntryFromHAWB( HAWB awb )
	{
		FaEntry faEntry = new FaEntry();
		Random  rand    = new Random();
		
		faEntry.setIdentifier ( awb.getRefNum() );
		faEntry.setScorevalue ( new BigDecimal( rand.nextInt(7) * 10 ) ); 
		faEntry.setDescription( "Temp Description" );
		faEntry.setReceivedtime( new Date() );
		
		Set<FaEntryreference> refSet = new HashSet<FaEntryreference>();
		FaEntryreference entRef = new FaEntryreference();
		
		entRef.setReferencecode ( "SHIP_NAME"          );
		entRef.setReferencevalue( awb.getShipperName() );
		
		refSet.add( entRef );
		
		entRef = new FaEntryreference();
		
		entRef.setReferencecode ( "COMMODITY"            );
		entRef.setReferencevalue( awb.getCommodityName() );
		
		refSet.add( entRef );
		
		entRef = new FaEntryreference();
		
		entRef.setReferencecode ( "CONSINGEE"            );
		entRef.setReferencevalue( awb.getConsigneeName() );
		
		refSet.add( entRef );
		
		entRef = new FaEntryreference();
		
		entRef.setReferencecode ( "HAWBID"            );
		entRef.setReferencevalue( Long.toString( awb.getHawbID() ) );
		
		refSet.add( entRef );
		
		faEntry.setFaEntryreferences( refSet );
		
		return faEntry;
	}
	
	public static FaEntry getRandomFaEntry()
	{
		FaEntry faEntry = new FaEntry();
		
		//faEntry.setIdentifier( "Identifier" ); 
		//Entry.set
		
		return null;
	}
	
	private static FaEntryscore getRandomEntryScore()
	{
		Random rand = new Random();
		
		BogusCategoryTypeDAO catDao = new BogusCategoryTypeDAO();
		
		FaEntryscore faEntryscore = new FaEntryscore();
		
		int index = rand.nextInt( catDao.catCodes.length ); 
		String category = catDao.catCodes[ index ];
				
		faEntryscore.setScorecategorytypecode( category );
		
		index = rand.nextInt( catDao.typeCodes.length ); 
		String type = catDao.typeCodes[ index ];
		
		faEntryscore.setScoretypecode( type );

		HashSet<FaScoredetails> detailSet = new HashSet<FaScoredetails>();
		
		int sum = 0;
		int thisScore = 0;
		FaScoredetails details = null;
		int numDetails = rand.nextInt(  3 ) + 1;
		for ( int i = 0; i < numDetails; i++ )
		{
			thisScore = rand.nextInt( 15 ) + 1;
			sum += thisScore;
			
			details = new FaScoredetails();
			
			details.setDescription( "Suspicous " + type         );
			details.setRulename   ( category + " Rule"          );
			details.setScorevalue ( new BigDecimal( thisScore ) );
			
			detailSet.add( details );
		}
		
		faEntryscore.setFaScoredetailses( detailSet );
		faEntryscore.setScorevalue( new BigDecimal( sum ) );
		
		return faEntryscore;
	}
}
