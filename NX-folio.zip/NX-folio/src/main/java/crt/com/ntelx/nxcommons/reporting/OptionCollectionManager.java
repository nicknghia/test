package crt.com.ntelx.nxcommons.reporting;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import net.sf.json.JSONArray;

import org.apache.log4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

import com.freightdesk.fdcommons.OptionBean;

public class OptionCollectionManager {
	private static Logger logger = Logger.getLogger("crt.com.ntelx.nxcommons.reporting.OptionCollectionManager");
	private static OptionCollectionManager instance = null;
	private static List<OptionCollection> optionCollectionList = new ArrayList<OptionCollection>();
	
	private static String fileName = "OptionBeans.xml";
	

	private OptionCollectionManager() {
		load();
	}

	public static OptionCollectionManager getInstance() {
		if (instance == null) {
			instance = new OptionCollectionManager();
		}
		return instance;
	}
	
	public void reset() {
		optionCollectionList.clear();
		load();
	}

	public List<OptionCollection> getOptionCollectionList() {
		return optionCollectionList;
	}

	private static void load() {
		try {
			String pathToXml = System.getProperty("RUNTIME_HOME") + File.separator + fileName;
			logger.debug("loading optionCollections from " + pathToXml);
			
			File inputXml = new File(pathToXml);
			
			DocumentBuilderFactory dbf = DocumentBuilderFactory.newInstance();
			DocumentBuilder db = dbf.newDocumentBuilder();
			Document doc = db.parse(inputXml);
			
			read(doc);
			
		} catch (Exception ex) {
			//logger.error("Could not load " + fileName);
			//ex.printStackTrace();
			logger.error("Exception - Could not load: " + ex.getMessage());
		}
	}
	
	public List<OptionBean> getCollection(String collectionName) {
		logger.debug("looking for collection " + collectionName);
		List<OptionBean> collection = new ArrayList<OptionBean>();
		OptionCollection currentCollection = new OptionCollection();
		String currentCollectionName = "";
		
		for(int i=0; i<optionCollectionList.size();i++) {
			currentCollection = optionCollectionList.get(i);
			currentCollectionName = currentCollection.getName();
			
			if(currentCollectionName.equalsIgnoreCase(collectionName)) {
				collection = currentCollection.getOptionBeans();
				i = optionCollectionList.size() + 1;
			}
		}
		
		return collection;
	}
	
	public boolean isValueInCollection(String collectionName, String value) {
		List<OptionBean> optionList = getCollection(collectionName);
		
		for(OptionBean currOption : optionList) {
			if(currOption.getValue().equalsIgnoreCase(value))
				return true;
		}
		
		logger.debug(value + " was not found in collection " + collectionName);
		return false;
		
	}
	
	/*
	 * Get specified collection in JSON format
	 */
	public String getJSON(String collectionName) {
		return getJSON(getCollection(collectionName));
	}
	
	public String getJSON(List<OptionBean> optionList) {
		JSONArray jsonArray = JSONArray.fromObject(optionList);
		return jsonArray.toString();
	}

	public static void read(Document doc) {
		// get all of the optionlist elements
		NodeList optionlists = doc.getElementsByTagName("optionlist");
		
		// go through each optionlist
		for (int i = 0; i < optionlists.getLength(); i++) {
			Node node = optionlists.item(i);
			String listName = node.getAttributes().getNamedItem("name").getNodeValue();
			
			OptionCollection optionListToAdd = new OptionCollection();
			optionListToAdd.setName(listName);

			Element element = (Element) node;
			
			// get the explicit optionbean values from the xml
			NodeList optionBeans = element.getElementsByTagName("optionbean");
			List<OptionBean> optionBeansToAdd = new ArrayList<OptionBean>();
			for (int j = 0; j < optionBeans.getLength(); j++) {

				Element currentBean = (Element) optionBeans.item(j);
				NodeList labelNodes = currentBean.getElementsByTagName("label");
				NodeList valueNodes = currentBean.getElementsByTagName("value");

				Element labelElement = (Element) labelNodes.item(0);
				Element valueElement = (Element) valueNodes.item(0);

				if (labelElement != null && valueElement != null) {

					String label = labelElement.getChildNodes().item(0).getNodeValue();
					String value = valueElement.getChildNodes().item(0).getNodeValue();

					optionBeansToAdd.add(new OptionBean(label, value));
				}
			}

			// get the optionbean values from the db
			NodeList querys = element.getElementsByTagName("query");
			Element queryElement = (Element) querys.item(0);
			if (queryElement != null) {
				String query = queryElement.getChildNodes().item(0).getNodeValue();
				optionListToAdd.setQuery(query);
				optionListToAdd.loadOptionBeansFromDB();
				optionBeansToAdd.addAll(optionListToAdd.getOptionBeans());
			}

			optionListToAdd.setOptionBeans(optionBeansToAdd);
			optionCollectionList.add(optionListToAdd);

		}
		logger.debug("loaded " + optionCollectionList.size() + " optionCollections");
	}

}

