package crt.com.ntelx.query.model;

import org.apache.log4j.Logger;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.List;

import org.apache.commons.beanutils.*;

import crt.com.ntelx.query.model.SearchFilter.Disjunction;
import crt.com.ntelx.query.model.SearchFilter.ValueDataType;

public class QueryModelTransfer{
	
	protected static Logger logger = Logger.getLogger("QueryModelTransfer");
	public static SimpleDateFormat formFormat = new SimpleDateFormat("MM/dd/yyyy");
	public static SimpleDateFormat inputDateFormat = new SimpleDateFormat("yyyy-MM-dd hh:mm:ss");
	public static SimpleDateFormat outputDateFormat = new SimpleDateFormat("MMMMM d, yyyy");

	public enum QueryModelProperties {
	entityType("Entity Type", SearchFilter.ValueDataType.STRING, 50, "ENTTYPE"), 
	carrierType("Carrier Type", SearchFilter.ValueDataType.STRING, 0, "CARTYPE"), 
	domesticCarrier("Domestic Carrier", SearchFilter.ValueDataType.BOOLEAN, 100, ""), 
	foreignCarrier("Foreign Carrier", SearchFilter.ValueDataType.BOOLEAN, 100, ""), 
	reportingStartDate("Reporting Start Date", SearchFilter.ValueDataType.DATE, 140, "RPTSTART"),
	reportingEndDate("Reporting End Date", SearchFilter.ValueDataType.DATE, 140, "RPTEND"),
	createdBy("Created By", SearchFilter.ValueDataType.STRING, 110, "CREATEBY"),
	createdUserID("Created User ID", SearchFilter.ValueDataType.STRING, 100, ""),
	createdDate("Created Date", SearchFilter.ValueDataType.DATE, 110, ""),
	createdStartDate("Created Start Date", SearchFilter.ValueDataType.STRING, 0, "CREATESTRT"),
	createdEndDate("Created End Date", SearchFilter.ValueDataType.STRING, 0, "CREATEEND"),
	updatedBy("Updated By", SearchFilter.ValueDataType.STRING, 110, "UPDATEBY"),
	updatedUserID("Updated User ID", SearchFilter.ValueDataType.STRING, 100, ""),
	updatedDate("Updated Date", SearchFilter.ValueDataType.DATE, 110, ""),
	updatedStartDate("Updated Start Date", SearchFilter.ValueDataType.STRING, 0, "UPDATESTRT"),
	updatedEndDate("Updated End Date", SearchFilter.ValueDataType.STRING, 0, "UPDATEEND"),
	lateFlag("Late Flag", SearchFilter.ValueDataType.BOOLEAN, 70, "LATEFLAG"),
	unlockedFlag("Unlocked Flag", SearchFilter.ValueDataType.BOOLEAN, 70, "UNLOCKFLAG"),
	screenedFlag("Screened Flag", SearchFilter.ValueDataType.BOOLEAN, 70, "SCREENFLAG"),	
	varianceFlagAWB("Variance Flag AWB", SearchFilter.ValueDataType.BOOLEAN, 70, "VARAWBFLAG"),
	varianceFlagWGT("Variance Flag WGT", SearchFilter.ValueDataType.BOOLEAN, 70, "VARWGTFLAG"),
	successfulFlag("Successful Flag", SearchFilter.ValueDataType.BOOLEAN, 70, "SUCCFLAG"),
	companyName("Facility/Carrier Name", SearchFilter.ValueDataType.LIST, 150, ""),
	// companyID not shown
	companyIDs("Company IDs", SearchFilter.ValueDataType.LIST, 0, "COMPANYID"),
	locationType("Location Type", SearchFilter.ValueDataType.LIST, 0, "LOCTYPE"),
	usLocations("US Locations", SearchFilter.ValueDataType.BOOLEAN, 100, ""),
	nonUSLocations("Non-US Locations", SearchFilter.ValueDataType.BOOLEAN, 100, ""),
	airportName("Airport Name", SearchFilter.ValueDataType.LIST, 150, ""),
	//	airportID not shown
	airportIDs("Airport IDs", SearchFilter.ValueDataType.LIST, 0, "AIRPORTID"),	
	entityCity("Entity City", SearchFilter.ValueDataType.STRING, 100, "ENTCITY"),
	entityState("Entity State", SearchFilter.ValueDataType.STRING, 100, "ENTSTATE"),
	// entityStateCode not shown
	entityStateCode("Entity State Code", SearchFilter.ValueDataType.STRING, 0, ""),
	entityZip("Entity Zip", SearchFilter.ValueDataType.STRING, 60, "ENTZIP"),
	entityCountry("Entity Country", SearchFilter.ValueDataType.STRING, 100, "ENTCOUNTRY"),
	// entityCountryCode not shown
	entityCountryCode("Entity Country Code", SearchFilter.ValueDataType.STRING, 0, ""),
	totalAWB("Total AWB", SearchFilter.ValueDataType.STRING, 60, ""),
	totalWGT("Total Weight", SearchFilter.ValueDataType.STRING, 60, ""),
	screenedAWB("Screened AWB", SearchFilter.ValueDataType.STRING, 60, ""),
	screenedWGT("Screened Weight", SearchFilter.ValueDataType.STRING, 60, ""),
	altAWB("Alternate Screening AWB", SearchFilter.ValueDataType.STRING, 100, ""),
	altWGT("Alternate Screening WGT", SearchFilter.ValueDataType.STRING, 100, ""),
	receivedWGT("Received Weight", SearchFilter.ValueDataType.STRING, 60, ""),
	certNum("Certification Number", SearchFilter.ValueDataType.STRING, 130, "CERTNUM"),
	ccsfCompany("Company Name", SearchFilter.ValueDataType.STRING, 150, "CCSFCOMP"),
	sortColumn("Sort Column", SearchFilter.ValueDataType.STRING, 0, "SORTCOL"),
	sortType("Sort Order", SearchFilter.ValueDataType.STRING, 0, "SORTTYPE"),
	fieldsToDisplay("Display Fields", SearchFilter.ValueDataType.STRING,0,"SHOWFIELDS"),
	fieldsNotToDisplay("Hide Fields", SearchFilter.ValueDataType.STRING,0,"HIDEFIELDS");
	
	private Integer fieldWidth;
	private String displayName;
	private SearchFilter.ValueDataType type;
	private String typeCode;
	
	private QueryModelProperties(String displayName, SearchFilter.ValueDataType type, Integer fieldWidth) {
		this.displayName = displayName;
		this.type = type;
		this.fieldWidth = fieldWidth;
	}

	private QueryModelProperties(String displayName, SearchFilter.ValueDataType type, Integer fieldWidth, String typeCode) {
		this.displayName = displayName;
		this.type = type;
		this.fieldWidth = fieldWidth;
		this.typeCode = typeCode;
	}

	public static String getNameFromDisplayName(String displayName)
	{
		String name = "";
		for (QueryModelProperties property : QueryModelProperties.values()) {
			if (property.getDisplayName().equals(displayName.trim()))
			{
				name = property.name();
			}
		}
		return name;
	}
	
	public String getDisplayName() {
		return displayName;
	}
	
	public SearchFilter.ValueDataType getType() {
		return type;
	}
	
	public Integer getFieldWidth() {
		return fieldWidth;
	}	
	
	public String getTypeCode() {
		return typeCode;
	}	
	}    

	private static void makeEntityTypeCriteria(List<SearchFilter> criteria, String value) {
		if (value != null && !value.isEmpty())
		{
			QuerySearchFilter filter;
			String[] ccsfs = {"IAC", "SHIP", "ICSF"};
			String[] cars = {"CAR", "INB"};
			
			if ("CCSF".equals(value))
			{
				filter = new QuerySearchFilter(QueryModelTransfer.QueryModelProperties.entityType.name(), ccsfs, QueryModelTransfer.QueryModelProperties.entityType.getType(), Predicate.IN);
			}
			else if ("CAR".equals(value))
			{
				filter = new QuerySearchFilter(QueryModelTransfer.QueryModelProperties.entityType.name(), cars, QueryModelTransfer.QueryModelProperties.entityType.getType(), Predicate.IN);
			}
			else
			{
				filter = new QuerySearchFilter(QueryModelTransfer.QueryModelProperties.entityType.name(), value, QueryModelTransfer.QueryModelProperties.entityType.getType(), Predicate.EQ);
			}	

			criteria.add(filter);
		}
	}
	
	private static void makeDomesticCarrierCriteria(
			List<SearchFilter> criteria, String entityType, boolean flag) {
		if (flag && ("".equals(entityType) || "CAR".equals(entityType))) 
		{
			QuerySearchFilter filter = new QuerySearchFilter(QueryModelTransfer.QueryModelProperties.domesticCarrier.name(), "Y", QueryModelTransfer.QueryModelProperties.domesticCarrier.getType(), Predicate.EQ);
			criteria.add(filter);
		}
	}

	private static void makeForeignCarrierCriteria(
			List<SearchFilter> criteria, String entityType, boolean flag) {
		if (flag && ("".equals(entityType) || "CAR".equals(entityType))) 
		{
			QuerySearchFilter filter = new QuerySearchFilter(QueryModelTransfer.QueryModelProperties.foreignCarrier.name(), "Y", QueryModelTransfer.QueryModelProperties.foreignCarrier.getType(), Predicate.EQ);
			criteria.add(filter);
		}
	}

	private static void makeStartDateCriteria(List<SearchFilter> criteria, String field,
			String value) {
		if (value != null && !value.isEmpty() && isValidDate(value)) 
		{
			QuerySearchFilter filter = new QuerySearchFilter(field, value, QueryModelProperties.valueOf(field).getType(), Predicate.GTE);
			criteria.add(filter);
		}
	}

	private static void makeEndDateCriteria(
			List<SearchFilter> criteria, String field, String value) {
		if (value != null && !value.isEmpty() && isValidDate(value)) 
		{
			QuerySearchFilter filter = new QuerySearchFilter(field, value, QueryModelTransfer.QueryModelProperties.valueOf(field).getType(), Predicate.LTE);
			criteria.add(filter);
		}
	}
	
	private static void makeGenericCriteria(List<SearchFilter> criteria, String field, String value) {
		if (value != null && !value.isEmpty()) 
		{
			QuerySearchFilter filter = new QuerySearchFilter(field, value, QueryModelTransfer.QueryModelProperties.valueOf(field).getType(), Predicate.LIKE);
			criteria.add(filter);
		}
	}
	
	private static void makeOrCriteria(List<SearchFilter> criteria, String[] fields, String value) {
		if (value != null && !value.isEmpty()) 
		{
			if (fields.length > 0)
			{
				// type is based on the first element
				ValueDataType type = QueryModelProperties.valueOf(fields[0]).getType();
				QuerySearchFilter filter = new QuerySearchFilter(fields, value.toUpperCase(), type, Predicate.LIKE, SearchFilter.Disjunction.OR);
				criteria.add(filter);
			}
		}
	}

	private static void makeFlagCriteria(List<SearchFilter> criteria, String field, boolean flag) {
		if (flag) 
		{
			QuerySearchFilter filter = new QuerySearchFilter(QueryModelTransfer.QueryModelProperties.valueOf(field).name(), "Y", QueryModelTransfer.QueryModelProperties.valueOf(field).getType(), Predicate.EQ);
			criteria.add(filter);
		}
	}
	
	private static void makeInCriteria(List<SearchFilter> criteria,
			String field, String[] strings) {
		if (strings != null && strings.length != 0) 
		{
			QuerySearchFilter filter = new QuerySearchFilter(QueryModelTransfer.QueryModelProperties.valueOf(field).name(), strings, QueryModelTransfer.QueryModelProperties.valueOf(field).getType(), Predicate.IN);
			criteria.add(filter);
		}
	}
		
	private static QuerySort makeSortingCriteria(String sortColumn, String sortType) {
		String propertyName;
		QuerySort filter = new QuerySort();
		if (sortColumn !=null && !sortColumn.isEmpty() && sortType !=null && !sortType.isEmpty())
		{
			propertyName = QueryModelProperties.getNameFromDisplayName(sortColumn);
			if (sortType.equals("asc"))
			{
				filter = new QuerySort(propertyName, Sort.SortDirection.asc);
			}else if (sortType.equals("desc"))
			{
				filter = new QuerySort(propertyName, Sort.SortDirection.desc);
			}
		}
		return filter;
	}
		
	public List<List<String>> setResultsToList(List<QueryModel> modelList, String[] fieldsToDisplay){

		List<List<String>> results = new ArrayList<List<String>>();
		List<String> result = new ArrayList<String>();
		List<String> fieldsArray;
		
		if (fieldsToDisplay != null && fieldsToDisplay.length > 0)
		{
			fieldsArray= Arrays.asList(fieldsToDisplay);
			String mappedResult = "";
						
			// Add rows	per display field
			for (QueryModel item : modelList)
			{
				result = new ArrayList<String>();
				for (String field : fieldsArray)
				{
					if (field != null)
					{
						// use map to get property from model
						mappedResult = getMappedResult(field, item);
						result.add(mappedResult == null ? "" : mappedResult);
					}
				}
				if (!result.isEmpty())
				{
					results.add(result);
				}
			}

			// if the result set is not empty, then add the header at the end.
			// adding the header at the start would possibly create an empty list of lists.
			if (!results.isEmpty())
			{
				result = new ArrayList<String>();
				
				for (String field : fieldsArray)
				{
					result.add(field);
				}
				results.add(0, result);
			}
		}
		
		return results;
	}

	private static String getMappedResult(String field, QueryModel item) {
		String value = "";
		String propertyName = QueryModelProperties.getNameFromDisplayName(field);
				
		// generally very unsafe to call methods like this, but this is only taken from a map that the user never has access to.
		try {
			if ("".equals(propertyName))
				throw new Exception();
			
			value = BeanUtils.getProperty(item, propertyName);

		} 
		catch (Exception e) {
			logger.info("Failed to get: " + field + " with property value of " + propertyName);
			
			logger.error("Exception : " + e.getMessage());
		}
		
		return value;
	}
	
	public static boolean isValidDate(String date)
	{
		SimpleDateFormat inputFormat = new SimpleDateFormat("MM/dd/yyyy");
		boolean valid = false;
		
		try {
			inputFormat.parse(date);
			valid = true;
			} catch (ParseException e) {
			valid = false;
			}
		return valid;
	}
	
}
