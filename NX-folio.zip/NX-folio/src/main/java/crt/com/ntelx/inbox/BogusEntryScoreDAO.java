package crt.com.ntelx.inbox;

import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BogusEntryScoreDAO
{
	private static List<FaEntryscore> entryList = getEntries();
	
	private static List<FaEntryscore> getEntries()
	{
		FasInboxDAO fasDao = new FasInboxDAO();
	
		List<FaEntry> faEntries = fasDao.getEntriesOrderedDate(); 
		
		List<FaEntryscore> scoreEntries = new ArrayList<FaEntryscore>();
		
		FaEntryscore scoreEnt = null; 
		for ( FaEntry faEntry : faEntries )
		{
			scoreEnt = getRandomEntryScore();
			scoreEnt.setFaEntry( faEntry );
			
			//faEntry.setFaEntryscores( )
			
			scoreEntries.add( scoreEnt );
		}
				
		return scoreEntries;
	}
	
	private static FaEntryscore getRandomEntryScore()
	{
		Random rand = new Random();
		
		BogusCategoryTypeDAO catDao = new BogusCategoryTypeDAO();
		
		FaEntryscore faEntryscore = new FaEntryscore();
		
		int index = rand.nextInt( catDao.catCodes.length ); 
		String category = catDao.catCodes[ index ];
				
		faEntryscore.setScorecategorytypecode( category );
		
		index = rand.nextInt( catDao.typeCodes.length ); 
		String type = catDao.typeCodes[ index ];
		
		faEntryscore.setScoretypecode( type );
		
		faEntryscore.setScorevalue( new BigDecimal( rand.nextInt( 50 ) ) );
		
		return faEntryscore;
	}
	
}
