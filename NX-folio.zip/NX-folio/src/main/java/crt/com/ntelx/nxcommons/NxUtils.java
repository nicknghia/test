/** 
 * 
 * Copyright (c) 2000-2002 NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio-utils/FDCommons/src/com/freightdesk/fdcommons/StringUtils.java,v 1.3.4.4 2010/03/01 14:22:05 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: StringUtils.java,v $
 *  Revision 1.3.4.4  2010/03/01 14:22:05  mechevarria
 *  get rid of homerolled escape method
 *
 *  Revision 1.3.4.3  2009/03/20 14:12:17  cdoan
 *  Merged head and GS branch
 *
 *  Revision 1.3.4.2  2008/03/18 13:43:30  mechevarria
 *  added rightpad method for exact fields
 *
 *  Revision 1.3.4.1  2007/12/11 17:28:35  mechevarria
 *  added method for removing dangerous characters
 *
 *  Revision 1.3  2006/04/25 00:06:58  ranand
 *  changed function to ignore case for string replacement
 *
 *  Revision 1.2  2006/04/24 20:33:27  ranand
 *  changed package name
 *
 *  Revision 1.1  2006/04/24 20:29:30  ranand
 *  moved from foilo.util
 *
 *  Revision 1.2  2006/04/07 16:14:46  ranand
 *  removed string conversion to lowercase
 *
 *  Revision 1.1  2004/09/15 13:05:24  ranand
 *  2.6 Baseline
 *
 * 
 */

package crt.com.ntelx.nxcommons;

import com.freightdesk.fdcommons.OptionBean;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;

/**
 * @author Mike Echevarria
 */
public final class NxUtils {
	
	private static Logger logger = Logger.getLogger(NxUtils.class);
	
	public static boolean notEmptyOrBlank(String str) {
		if(str == null || str.trim().isEmpty())
			return false;
		else
			return true;
	}
	
	public static boolean isEmptyOrBlank(String str) {
		if(str == null || str.trim().isEmpty())
			return true;
		else
			return false;
	}

    /**
     * 
     * Finds the given find string in the source and replace it with the
     * replaceString in the source.
     * 
     * @param source
     * @param find
     * @param replaceString
     * @return
     */
    public static String findAndReplace (String source,String find,String replaceString) {
         int i=0,j=0;
         StringBuffer result = new StringBuffer();
         String token = find.toUpperCase();
         if(source.indexOf(token) == -1)
             token = find.toLowerCase();
         while ((i = source.indexOf(token,i)) != -1) {
              result.append(source.substring(j,i));
              result.append(replaceString);
              i += find.length();
              j = i;
              
              token = find.toUpperCase();
              if(source.indexOf(token) == -1)
                  token = find.toLowerCase();
         }
         result.append (source.substring(j,source.length()));
         return result.toString();
	}

    /**
     * convertStringToUniversalForm
     * for adding escape character before ' and "
     * @param inputString
     * @return
     */
    public static String convertStringToUniversalForm(String inputString)
    {
        for(int i=0; i<inputString.length(); i++){
            if(inputString.charAt(i)== '\'' || inputString.charAt(i)=='\"'){
                if(i>0){
                    inputString = inputString.substring(0,i)+"\\"+inputString.substring(i);
                    i++;
                }                                        
                else if(i==0){
                    inputString = "\\"+inputString.substring(i);
                    i++;
                }                                       
            }
        }
        return inputString;
    }
    
    // Right pad a string with spaces to get an exact length
    public static String rightPad(String s, int length) {
    	// check for null
    	if (s == null) {
    		return s;
    	}
    	StringBuffer strBuffer = new StringBuffer(s);
    	int curLen=s.length();
    	
    	while (curLen < length) {
    		strBuffer.append(' ');
    		curLen++;
    	}
    	
    	return strBuffer.toString();
    }
    
    // Since data in database is stored in caps, this helper utility uppercases only the first letter of every word
    public static String upperFirst(String str) {
    	//logger.debug(str);
    	if(isEmptyOrBlank(str)) {
    		logger.debug("input is empty, nothing to do");
    		return str;
    	}
    	
    	String upperFirst = "";
    	
    	// split by each word
    	String[] tokens = str.split(" ");
    	
    	for(String token : tokens) {
    		if(!token.trim().equals(""))
    		  upperFirst +=token.substring(0,1).toUpperCase() + token.substring(1,token.length()).toLowerCase() + " ";
    	}
    	
    	upperFirst.trim();
    	
    	return upperFirst;
    	
    }
    
    public static List<OptionBean> removeOption(List<OptionBean> list, String removeValue) {
    	logger.debug("List size before remove of "+removeValue+" is "+list.size());
    	
    	for (Iterator<OptionBean> iter = list.iterator(); iter.hasNext();) {
    	      OptionBean option = iter.next();
    	      if(option.getValue().equalsIgnoreCase(removeValue))
    	        iter.remove();
    	      
    	}
    	return list;
    }
    
}

