/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 *
 */

package crt.com.ntelx.query.model;

import java.io.Serializable;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

/**
 * QueryModel associated with QueryHomeAction. This class is a
 * Value Object to transfer the data from presentation layer to the Database.
 * 
 * May have to transfer to DTO in the future.
 * 
 * @author Tom Chang
 */

@Entity
@Table(name="V_QUERY")
public class QueryModel implements Serializable {

	private static final long serialVersionUID = 1L;
	
	@Id
	private long eventId;

	@Column(name="ENTITY_TYPE")
	private String entityType;
	
	@Column(name="DOMESTIC_CARRIER")
	private String domesticCarrier;
	
	@Column(name="FOREIGN_CARRIER")
	private String foreignCarrier;
	
	@Column(name = "REPORT_START")
	private String reportingStartDate;
	
	@Column(name = "REPORT_END")
	private String reportingEndDate;

	@Column(name = "CREATED_NAME")
	private String createdBy;
	
	@Column(name = "CREATED_USERID")
	private String createdUserID;

	@Column(name = "CREATE_TIME")
	private String createdDate;
	
	@Column(name = "UPDATED_NAME")
	private String updatedBy;

	@Column(name = "UPDATED_USERID")
	private String updatedUserID;
	
	@Column(name = "UPDATE_TIME")
	private String updatedDate;
	
	@Column(name="FLAG_LATE")
	private String lateFlag;
	
	@Column(name="FLAG_NOT_SCREENED")
	private String screenedFlag;

	@Column(name="FLAG_UNLOCKED")
	private String unlockedFlag;
	
	@Column(name="FLAG_VARIANCE_AWB")
	private String varianceFlagAWB;	

	@Column(name="FLAG_VARIANCE_WGT")
	private String varianceFlagWGT;	

	@Column(name="FLAG_SUCCESS")
	private String successfulFlag;

	@Column(name = "COMPANY_NAME")
	private String companyName;
	
	@Column(name = "COMPANY_ID")
	private String companyIDs;

	@Column(name = "AIRPORT_NAME")
	private String airportName;
	
	@Column(name = "AIRPORT_ID")
	private String airportIDs;

	@Column(name="US_AIRPORT")
	private String usLocations;	

	@Column(name="NON_US_AIRPORT")
	private String nonUSLocations;
	
	@Column(name = "CCSF_CITY")
	private String entityCity;

	@Column(name = "CCSF_STATE_CODE")
	private String entityStateCode;
	
	@Column(name = "CCSF_STATE")
	private String entityState;

	@Column(name = "CCSF_ZIP")
	private String entityZip;

	@Column(name = "CCSF_COUNTRY_CODE")
	private String entityCountryCode;

	@Column(name = "CCSF_COUNTRY")
	private String entityCountry;
	
	@Column(name = "TOTAL_AWB")
	private String totalAWB;

	@Column(name = "TOTAL_WGT")
	private String totalWGT;
	
	@Column(name = "SCREENED_AWB")
	private String screenedAWB;

	@Column(name = "SCREENED_WGT")
	private String screenedWGT;

	@Column(name = "ALT_AWB")
	private String altAWB;

	@Column(name = "ALT_WGT")
	private String altWGT;
	
	@Column(name = "RECEIVED_WGT")
	private String receivedWGT;
	
	@Column(name = "CERT_NUM")
	private String certNum;
	
	@Column(name = "CCSF_COMPANY")
	private String ccsfCompany;

	/**
	 * @return the eventId
	 */
	public long getEventId() {
		return eventId;
	}

	/**
	 * @param eventId the eventId to set
	 */
	public void setEventId(long eventId) {
		this.eventId = eventId;
	}

	/**
	 * @return the entityType
	 */
	public String getEntityType() {
		return entityType;
	}

	/**
	 * @param entityType the entityType to set
	 */
	public void setEntityType(String entityType) {
		this.entityType = entityType;
	}

	/**
	 * @return the domesticCarrier
	 */
	public String getDomesticCarrier() {
		return domesticCarrier;
	}

	/**
	 * @param b the domesticCarrier to set
	 */
	public void setDomesticCarrier(String b) {
		this.domesticCarrier = b;
	}

	/**
	 * @return the foreignCarrier
	 */
	public String getForeignCarrier() {
		return foreignCarrier;
	}

	/**
	 * @param foreignCarrier the foreignCarrier to set
	 */
	public void setForeignCarrier(String foreignCarrier) {
		this.foreignCarrier = foreignCarrier;
	}

	/**
	 * @return the reportingStartDate
	 */
	public String getReportingStartDate() {
		return reportingStartDate;
	}

	/**
	 * @param reportingStartDate the reportingStartDate to set
	 */
	public void setReportingStartDate(String reportingStartDate) {
		this.reportingStartDate = reportingStartDate;
	}

	/**
	 * @return the reportingEndDate
	 */
	public String getReportingEndDate() {
		return reportingEndDate;
	}

	/**
	 * @param reportingEndDate the reportingEndDate to set
	 */
	public void setReportingEndDate(String reportingEndDate) {
		this.reportingEndDate = reportingEndDate;
	}

	/**
	 * @return the createdBy
	 */
	public String getCreatedBy() {
		return createdBy;
	}

	/**
	 * @param createdBy the createdBy to set
	 */
	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	/**
	 * @return the createdUserID
	 */
	public String getCreatedUserID() {
		return createdUserID;
	}

	/**
	 * @param createdUserID the createdUserID to set
	 */
	public void setCreatedUserID(String createdUserID) {
		this.createdUserID = createdUserID;
	}

	/**
	 * @return the createdDate
	 */
	public String getCreatedDate() {
		return createdDate;
	}

	/**
	 * @param createdDate the createdDate to set
	 */
	public void setCreatedDate(String createdDate) {
		this.createdDate = createdDate;
	}

	/**
	 * @return the updatedBy
	 */
	public String getUpdatedBy() {
		return updatedBy;
	}

	/**
	 * @param updatedBy the updatedBy to set
	 */
	public void setUpdatedBy(String updatedBy) {
		this.updatedBy = updatedBy;
	}

	/**
	 * @return the updatedUserID
	 */
	public String getUpdatedUserID() {
		return updatedUserID;
	}

	/**
	 * @param updatedUserID the updatedUserID to set
	 */
	public void setUpdatedUserID(String updatedUserID) {
		this.updatedUserID = updatedUserID;
	}

	/**
	 * @return the updatedDate
	 */
	public String getUpdatedDate() {
		return updatedDate;
	}

	/**
	 * @param updatedDate the updatedDate to set
	 */
	public void setUpdatedDate(String updatedDate) {
		this.updatedDate = updatedDate;
	}

	/**
	 * @return the lateFlag
	 */
	public String getLateFlag() {
		return lateFlag;
	}

	/**
	 * @param lateFlag the lateFlag to set
	 */
	public void setLateFlag(String lateFlag) {
		this.lateFlag = lateFlag;
	}

	/**
	 * @return the screenedFlag
	 */
	public String getScreenedFlag() {
		return screenedFlag;
	}

	/**
	 * @param screenedFlag the screenedFlag to set
	 */
	public void setScreenedFlag(String screenedFlag) {
		this.screenedFlag = screenedFlag;
	}

	/**
	 * @return the unlockedFlag
	 */
	public String getUnlockedFlag() {
		return unlockedFlag;
	}

	/**
	 * @param unlockedFlag the unlockedFlag to set
	 */
	public void setUnlockedFlag(String unlockedFlag) {
		this.unlockedFlag = unlockedFlag;
	}

	/**
	 * @return the varianceFlagAWB
	 */
	public String getVarianceFlagAWB() {
		return varianceFlagAWB;
	}

	/**
	 * @param varianceFlagAWB the varianceFlagAWB to set
	 */
	public void setVarianceFlagAWB(String varianceFlagAWB) {
		this.varianceFlagAWB = varianceFlagAWB;
	}

	/**
	 * @return the varianceFlagWGT
	 */
	public String getVarianceFlagWGT() {
		return varianceFlagWGT;
	}

	/**
	 * @param varianceFlagWGT the varianceFlagWGT to set
	 */
	public void setVarianceFlagWGT(String varianceFlagWGT) {
		this.varianceFlagWGT = varianceFlagWGT;
	}

	/**
	 * @return the successfulFlag
	 */
	public String getSuccessfulFlag() {
		return successfulFlag;
	}

	/**
	 * @param successfulFlag the successfulFlag to set
	 */
	public void setSuccessfulFlag(String successfulFlag) {
		this.successfulFlag = successfulFlag;
	}

	/**
	 * @return the companyName
	 */
	public String getCompanyName() {
		return companyName;
	}

	/**
	 * @param companyName the companyName to set
	 */
	public void setCompanyName(String companyName) {
		this.companyName = companyName;
	}

	/**
	 * @return the companyID
	 */
	public String getCompanyIDs() {
		return companyIDs;
	}

	/**
	 * @param companyID the companyID to set
	 */
	public void setCompanyIDs(String companyIDs) {
		this.companyIDs = companyIDs;
	}

	/**
	 * @return the airportID
	 */
	public String getAirportIDs() {
		return airportIDs;
	}

	/**
	 * @param airportID the airportID to set
	 */
	public void setAirportIDs(String airportIDs) {
		this.airportIDs = airportIDs;
	}

	/**
	 * @return the airportName
	 */
	public String getAirportName() {
		return airportName;
	}

	/**
	 * @param airportName the airportName to set
	 */
	public void setAirportName(String airportName) {
		this.airportName = airportName;
	}

	/**
	 * @return the usLocations
	 */
	public String getUsLocations() {
		return usLocations;
	}

	/**
	 * @param usLocations the usLocations to set
	 */
	public void setUsLocations(String usLocations) {
		this.usLocations = usLocations;
	}

	/**
	 * @return the nonUSLocations
	 */
	public String getNonUSLocations() {
		return nonUSLocations;
	}

	/**
	 * @param nonUSLocations the nonUSLocations to set
	 */
	public void setNonUSLocations(String nonUSLocations) {
		this.nonUSLocations = nonUSLocations;
	}
	
	/**
	 * @return the entityCity
	 */
	public String getEntityCity() {
		return entityCity;
	}

	/**
	 * @param entityCity the entityCity to set
	 */
	public void setEntityCity(String entityCity) {
		this.entityCity = entityCity;
	}

	/**
	 * @return the entityStateCode
	 */
	public String getEntityStateCode() {
		return entityStateCode;
	}

	/**
	 * @param entityStateCode the entityStateCode to set
	 */
	public void setEntityStateCode(String entityStateCode) {
		this.entityStateCode = entityStateCode;
	}

	/**
	 * @return the entityState
	 */
	public String getEntityState() {
		return entityState;
	}

	/**
	 * @param entityState the entityState to set
	 */
	public void setEntityState(String entityState) {
		this.entityState = entityState;
	}

	/**
	 * @return the entityZip
	 */
	public String getEntityZip() {
		return entityZip;
	}

	/**
	 * @param entityZip the entityZip to set
	 */
	public void setEntityZip(String entityZip) {
		this.entityZip = entityZip;
	}

	/**
	 * @return the entityCountryCode
	 */
	public String getEntityCountryCode() {
		return entityCountryCode;
	}

	/**
	 * @param entityCountryCode the entityCountryCode to set
	 */
	public void setEntityCountryCode(String entityCountryCode) {
		this.entityCountryCode = entityCountryCode;
	}

	/**
	 * @return the entityCountry
	 */
	public String getEntityCountry() {
		return entityCountry;
	}

	/**
	 * @param entityCountry the entityCountry to set
	 */
	public void setEntityCountry(String entityCountry) {
		this.entityCountry = entityCountry;
	}

	/**
	 * @return the totalAWB
	 */
	public String getTotalAWB() {
		return totalAWB;
	}

	/**
	 * @param totalAWB the totalAWB to set
	 */
	public void setTotalAWB(String totalAWB) {
		this.totalAWB = totalAWB;
	}

	/**
	 * @return the totalWGT
	 */
	public String getTotalWGT() {
		return totalWGT;
	}

	/**
	 * @param totalWGT the totalWGT to set
	 */
	public void setTotalWGT(String totalWGT) {
		this.totalWGT = totalWGT;
	}

	/**
	 * @return the screenedAWB
	 */
	public String getScreenedAWB() {
		return screenedAWB;
	}

	/**
	 * @param screenedAWB the screenedAWB to set
	 */
	public void setScreenedAWB(String screenedAWB) {
		this.screenedAWB = screenedAWB;
	}

	/**
	 * @return the screenedWGT
	 */
	public String getScreenedWGT() {
		return screenedWGT;
	}

	/**
	 * @param screenedWGT the screenedWGT to set
	 */
	public void setScreenedWGT(String screenedWGT) {
		this.screenedWGT = screenedWGT;
	}

	/**
	 * @return the altAWB
	 */
	public String getAltAWB() {
		return altAWB;
	}

	/**
	 * @param altAWB the altAWB to set
	 */
	public void setAltAWB(String altAWB) {
		this.altAWB = altAWB;
	}

	/**
	 * @return the altWGT
	 */
	public String getAltWGT() {
		return altWGT;
	}

	/**
	 * @param altWGT the altWGT to set
	 */
	public void setAltWGT(String altWGT) {
		this.altWGT = altWGT;
	}

	/**
	 * @return the receivedWGT
	 */
	public String getReceivedWGT() {
		return receivedWGT;
	}

	/**
	 * @param receivedWGT the receivedWGT to set
	 */
	public void setReceivedWGT(String receivedWGT) {
		this.receivedWGT = receivedWGT;
	}

	/**
	 * @return the certNum
	 */
	public String getCertNum() {
		return certNum;
	}

	/**
	 * @param certNum the certNum to set
	 */
	public void setCertNum(String certNum) {
		this.certNum = certNum;
	}

	/**
	 * @return the ccsfComp
	 */
	public String getCcsfCompany() {
		return ccsfCompany;
	}

	/**
	 * @param ccsfComp the ccsfComp to set
	 */
	public void setCcsfCompany(String ccsfCompany) {
		this.ccsfCompany = ccsfCompany;
	}
}
