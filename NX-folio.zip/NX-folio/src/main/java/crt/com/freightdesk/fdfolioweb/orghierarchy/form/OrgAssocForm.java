package crt.com.freightdesk.fdfolioweb.orghierarchy.form;

/*
 * To be used in OrghierarchyForm
 */
public class OrgAssocForm {

    private String orgAssocId;
    private String relationShipType;
    private String srcOrgId;
    private String destOrgId;
    private String destOrgName;
    private String remarks;
    private String beginDate;
    private String endDate;

    public String getDestOrgName() {
        return destOrgName;
    }

    public void setDestOrgName(String destOrgName) {
        this.destOrgName = destOrgName;
    }

    public String getOrgAssocId() {
        return orgAssocId;
    }

    public void setOrgAssocId(String orgAssocId) {
        this.orgAssocId = orgAssocId;
    }

    public String getRelationShipType() {
        if (relationShipType == null) {
            return "";
        } else {
            return relationShipType;
        }
    }

    public void setRelationShipType(String relationShipType) {
        this.relationShipType = relationShipType;
    }

    public String getSrcOrgId() {
        return srcOrgId;
    }

    public void setSrcOrgId(String srcOrgId) {
        this.srcOrgId = srcOrgId;
    }

    public String getDestOrgId() {
        return destOrgId;
    }

    public void setDestOrgId(String destOrgId) {
        this.destOrgId = destOrgId;
    }

    public String getBeginDate() {
        return beginDate;
    }

    public void setBeginDate(String beginDate) {
        this.beginDate = beginDate;
    }

    public String getEndDate() {
        return endDate;
    }

    public void setEndDate(String endDate) {
        this.endDate = endDate;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    @Override
    public int hashCode() {
        int hash = 5;
        hash = 59 * hash + (this.relationShipType != null ? this.relationShipType.hashCode() : 0);
        hash = 59 * hash + (this.srcOrgId != null ? this.srcOrgId.hashCode() : 0);
        hash = 59 * hash + (this.destOrgId != null ? this.destOrgId.hashCode() : 0);
        hash = 59 * hash + (this.remarks != null ? this.remarks.hashCode() : 0);
        hash = 59 * hash + (this.beginDate != null ? this.beginDate.hashCode() : 0);
        hash = 59 * hash + (this.endDate != null ? this.endDate.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object obj) {
        if (obj == null) {
            return false;
        }
        if (getClass() != obj.getClass()) {
            return false;
        }
        final OrgAssocForm other = (OrgAssocForm) obj;
        if ((this.relationShipType == null) ? (other.relationShipType != null) : !this.relationShipType.equals(other.relationShipType)) {
            return false;
        }
        if ((this.srcOrgId == null) ? (other.srcOrgId != null) : !this.srcOrgId.equals(other.srcOrgId)) {
            return false;
        }
        if ((this.destOrgId == null) ? (other.destOrgId != null) : !this.destOrgId.equals(other.destOrgId)) {
            return false;
        }
        if ((this.remarks == null) ? (other.remarks != null) : !this.remarks.equals(other.remarks)) {
            return false;
        }
        if ((this.beginDate == null) ? (other.beginDate != null) : !this.beginDate.equals(other.beginDate)) {
            return false;
        }
        if ((this.endDate == null) ? (other.endDate != null) : !this.endDate.equals(other.endDate)) {
            return false;
        }
        return true;
    }
    
    
}
