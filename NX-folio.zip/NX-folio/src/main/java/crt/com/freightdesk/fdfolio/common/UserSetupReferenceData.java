/** 
 * 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/common/Attic/UserSetupReferenceData.java,v 1.5.4.6 2010/09/23 19:35:23 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: UserSetupReferenceData.java,v $
 *  Revision 1.5.4.6  2010/09/23 19:35:23  mechevarria
 *  remove ejb layer for instantiating objects.  direct calls to bean class now made
 *
 *  Revision 1.5.4.5  2010/08/22 23:08:26  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.5.4.4  2010/04/23 18:47:40  mechevarria
 *  add ability to reload
 *
 *  Revision 1.5.4.3  2010/02/03 20:33:14  mechevarria
 *  parameterize list
 *
 *  Revision 1.5.4.2  2009/05/11 14:22:35  mechevarria
 *  changed status to yes no
 *
 *  Revision 1.5.4.1  2009/05/08 20:31:33  mechevarria
 *  added list for status
 *
 *  Revision 1.5  2006/04/12 04:59:33  aarora
 *  Removed redundant code
 *
 *  Revision 1.4  2005/09/13 13:16:50  nsehra
 *  method added for getting all the systemfuntion , role to permission mapping
 *
 *  Revision 1.3  2004/09/15 13:03:45  ranand
 *  2.6 Baseline
 *
 * 
 */


package crt.com.freightdesk.fdfolio.common;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.ejb.EJBException;
import javax.naming.InitialContext;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.OptionBean;
import com.freightdesk.fdfolio.useraccess.ejb.UserAccessSLSBean;



/**
 * A collection of singletons.  For each domain, there will be at most one
 * instance of DocumentManagerReferenceData.
 *
 * The private variable _instances holds references to singletons.
 */
public class UserSetupReferenceData
{
    // the map of the instances of this singleton
    // instances of DocumentManagerReferenceData for each domain
    private static Map _instances = new HashMap();

    // a logger
    private static Logger logger =
        Logger.getLogger("com.freightdesk.common.UserSetupReferenceData");

    /**
     * The following data is independent of domain
     */
   private List roleList;
   private List currencyList;
   private List<OptionBean> uomList; 
   private List timeZoneList;
   private List systemFunctionList;
   private List<OptionBean> statusList;

    /**
     * Creates an instance of SetupReferenceData for a particular domain name.
     * This constructor is declared private, and it is only called from
     * the getInstance() method.  
     */
    private UserSetupReferenceData(String domainName)
    {
        load(domainName);
    }

    /**
     * Gets the instance for this domainName.
     * The first time this method is called for that domain,
     * it creates an instance, and puts it in the _instances map.
     * Next time, it returns the already created instance for that domain.
     */
    public static UserSetupReferenceData getInstance(String domainName)
    {
        UserSetupReferenceData userSetupReferenceData =
            (UserSetupReferenceData) (_instances.get(domainName));
        if (userSetupReferenceData == null)
            {
            userSetupReferenceData = new UserSetupReferenceData(domainName);
            _instances.put(domainName, userSetupReferenceData);
        }
        return userSetupReferenceData;
    }
    
    public void load(String domainName) {
    	try
        {
			InitialContext ic = new InitialContext();
             UserAccessSLSBean userAccessSLS = new UserAccessSLSBean();
			 roleList = userAccessSLS.getAllSystemRoles(domainName);
             logger.debug("roleList: "+roleList.size());
             currencyList = userAccessSLS.getAllCurrencyCodes(domainName);
             logger.debug("CurrencyList: "+currencyList.size());
			 uomList = userAccessSLS.getAllUnitSystem(domainName);
             logger.debug("uomList: "+uomList.size());
 			 timeZoneList = userAccessSLS.getTimeZoneOBs();
             logger.debug("timeZoneList: "+timeZoneList.size());
			 systemFunctionList = userAccessSLS.getAllSystemFunction();
			 // User access is either active or not, no need for DB call for something so simple
			 initStatusList();
        }
        catch (Exception e)
        {
            logger.error ("Exception in instantiating UserSetupReferenceData for domain " + domainName, e);
            throw new EJBException(e);
        }
    }

  
    
    public List getRoleList()
    {
    	return roleList;
    }
    
    public List getCurrencyList()
    {
    	return currencyList;
    }

    public List<OptionBean> getUomList()
    {
    	return uomList;
    }
    public List getTimeZoneList()
    {
    	return timeZoneList;
    }
    
	
	public List getSystemFunctionList()
	{
	    return systemFunctionList;
	}
	
	public List<OptionBean> getStatusList() {
		return statusList;
	}
	
	private void initStatusList() {
		statusList = new ArrayList<OptionBean>();
		// label, code
		statusList.add(new OptionBean("YES","Y"));
		statusList.add(new OptionBean("NO","N"));
	}

}
