/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package crt.com.freightdesk.fdfolioweb.orghierarchy.action;

import com.freightdesk.fdfolio.dao.OrghierarchyDAO;
import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;
import com.freightdesk.fdfolioweb.orghierarchy.action.OrghierarchyAction;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;
import crt.com.ntelx.nxcommons.model.OrgAssocModel;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import org.apache.commons.lang.time.FastDateFormat;

/**
 *
 * @author mbegley
 */
public class OrgOrgAssocAuditor {

    private OrgOrgAssocAuditor() {
    }
    protected static org.apache.log4j.Logger logger = org.apache.log4j.Logger.getLogger("OrgOrgAssocAuditor");

    public static void auditOrgAssoc(Long orgId, OrghierarchyModel mutatedOrgModel, Credentials credentials) {
        if (orgId != null && orgId != 0) {
            OrghierarchyDAO orgDAO = new OrghierarchyDAO();
            OrghierarchyModel originalModel = orgDAO.retrieve(orgId, null);
            Set<OrgAssocModel> orginal = originalModel.getOrgAssocList();
            Set<OrgAssocModel> mutated = mutatedOrgModel.getOrgAssocList();

            for (OrgAssocModel addedModel : getAddedModels(orginal, mutated)) {
                logAction(credentials, "ORGORGASSOC ADDED TO ORGID:" + orgId, getAuditString(addedModel, "ADDED"));
            }
            for (OrgAssocModel addedModel : getDeletedModels(orginal, mutated)) {
                logAction(credentials, "ORGORGASSOC DELETED TO ORGID:" + orgId, getAuditString(addedModel, "DELETED"));
            }
        } else {
            // THERE is no Original List for a newly added OrgHierarchy, do we audit?
            // Created New OrghierarchyModel.. this is a new SAVE ... audit accordingly.
            //logAction(credentials, "NEW ORGORG ASSOC", "new org org assoc");
        }
    }

    /**
     * return OrgAssocModels that have been added to the Original List
     *
     * @param orginal
     * @param mutated
     * @return
     */
    private static Collection<OrgAssocModel> getAddedModels(Set<OrgAssocModel> orginal, Set<OrgAssocModel> mutated) {
        Collection newItemsList = new ArrayList(mutated);
        newItemsList.removeAll(orginal);
        return newItemsList;

    }

    /**
     * returns OrgAssocModles that have been removed from original List
     *
     * @param orginal
     * @param mutated
     * @return
     */
    private static Collection<OrgAssocModel> getDeletedModels(Set<OrgAssocModel> orginal, Set<OrgAssocModel> mutated) {
        Collection deletedItemsList = new ArrayList(orginal);
        deletedItemsList.removeAll(mutated);
        return deletedItemsList;

    }

    private static String getAuditString(OrgAssocModel assocModel, String action) {
        String result = "%s %s between %s and %s from %s to %s.  Remarks: %s";
        
		FastDateFormat fdf = FastDateFormat.getInstance("MM-dd-yyyy");
        
        return String.format(result,
                action,
                assocModel.getRelationshipTypeCode(),
                assocModel.getDestOrgId(),
                assocModel.getDestOrgId(),
                (assocModel.getBeginDate() != null ? fdf.format(assocModel.getBeginDate()) : ""),
                (assocModel.getEndDate() != null ? fdf.format(assocModel.getEndDate()) : ""),
                assocModel.getComments());
    }

    private static void logAction(Credentials credentials, String change, String changeDesc) {
        try {
            AsyncProcessingLogModel asyncLogModel = new AsyncProcessingLogModel();
            AsyncProcessManager asyncManager = new AsyncProcessManager();
            asyncLogModel.init(credentials.getUserId(), credentials.getDomainName(), change, "ORGAUDIT", changeDesc, credentials.getIpAddress());
			asyncLogModel = asyncManager.createAsyncProcessLog(asyncLogModel);            
            asyncLogModel.setStatus("COMPLETED");
			asyncManager.logResult(asyncLogModel, true, changeDesc, "logAction");
            
        } catch (Exception ex) {
            Logger.getLogger(OrghierarchyAction.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
}
