package crt.com.freightdesk.fdfolio.dao;

import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Date;
import java.util.Iterator;
import java.util.List;

import org.apache.log4j.Logger;
import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.Transaction;

import com.freightdesk.fdfolio.common.SessionFactoryUtil;
import crt.com.freightdesk.fdfolio.dao.FasAppPropertiesDAO;
import crt.com.freightdesk.fdfolio.setup.model.FasAppProperties;

public class FasAppPropertiesDAO
{
	private static Logger logger = Logger.getLogger( FasAppPropertiesDAO.class );
	
	@SuppressWarnings("unchecked")
	public List<FasAppProperties> readAll() throws SQLException 
	{
		Session session = null;
		List<FasAppProperties> props = null;
		
		try 
		{
			session = SessionFactoryUtil.getSession();
			Transaction transaction = session.beginTransaction();
						
            Query query = session.createQuery("from " + FasAppProperties.class.getName() );
            props = query.list();

			transaction.commit();
		} 
		catch (Exception e) 
		{
			logger.error("Exception in create" + e);
			throw (SQLException) new SQLException().initCause(e);
		} 
		finally 
		{
			SessionFactoryUtil.closeSession(session);
		}
		
		return props;
	}
	
	public List<FasAppProperties> setProperty( String key, String value, String userID, String domainname ) throws SQLException 
	{
		Session session = null;
		List<FasAppProperties> props = null;
		
		FasAppProperties fasProps = new FasAppProperties();
		fasProps.setKey  ( key   );
		fasProps.setValue( value );	
		fasProps.setLastUpdateUserId( userID     );
		fasProps.setDomainName      ( domainname );		
		fasProps.setLastUpdateTimestamp( new Timestamp(  new Date().getTime() ) );
		
		try 
		{
			session = SessionFactoryUtil.getSession();
			Transaction transaction = session.beginTransaction();
					
			session.saveOrUpdate( fasProps );			            
            
			transaction.commit();
		} 
		catch (Exception e) 
		{
			logger.error("Exception in create" + e);
			throw (SQLException) new SQLException().initCause(e);
		} 
		finally 
		{
			SessionFactoryUtil.closeSession(session);
		}
		
		return props;
	}
	
	public FasAppProperties getLastUpdateInfo() throws SQLException
	{
		Session session = null;		
		FasAppProperties thisProp = null;
		
		try 
		{
			session = SessionFactoryUtil.getSession();
			Transaction transaction = session.beginTransaction();
						
            Query query = session.createQuery( "from " + FasAppProperties.class.getName() );
            
            	//"SELET CREATEUSERID, CREATETIMESTAMP, DOMAINNAME, LASTUPDATEUSERID, LASTUPDATETIMESTAMP FROM " + FasAppProperties.class.getName() + " GROUP BY CREATEUSERID, CREATETIMESTAMP, DOMAINNAME, LASTUPDATEUSERID, LASTUPDATETIMESTAMP HAVING LASTUPDATETIMESTAMP = MAX( LASTUPDATETIMESTAMP )" );
            
            Iterator<FasAppProperties> iter = query.iterate();
            
            if ( iter.hasNext() )
            {
            	thisProp = iter.next();
            	thisProp.getDomainName();
            }
            
			transaction.commit();
		} 
		catch (Exception e) 
		{
			logger.error("Exception in create" + e);
			throw (SQLException) new SQLException().initCause(e);
		} 
		finally 
		{
			SessionFactoryUtil.closeSession(session);
		}

		return thisProp;
	}

}
