package crt.com.freightdesk.fdfolio.jobs;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

import javax.sql.DataSource;

import org.apache.log4j.Logger;
import org.quartz.Job;
import org.quartz.JobExecutionContext;
import org.quartz.JobExecutionException;

import crt.com.freightdesk.fdfolio.dao.QuartzDao;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdcommons.FDSuiteProperties;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessManager;
import com.freightdesk.fdcommons.asyncprocess.AsyncProcessingLogModel;
import crt.com.ntelx.nxcommons.email.EmailUtil;
import com.freightdesk.fdfolio.useraccess.model.SystemUserModel;

public class ReceiptJob implements Job
{
	protected QuartzDao quartzDao = null; 
    protected Logger logger = Logger.getLogger ( getClass() );
	
	public void execute( JobExecutionContext exeContext ) throws JobExecutionException
	{
		Connection connection = null;
		
		logger.debug( "IN Receipt Execute" );
		
		try
		{
			DataSource dataSource = (DataSource) exeContext.getMergedJobDataMap().get( "dataSource" );			
			String     sendEmails = FDSuiteProperties.getProperty( "ENABLE_SENDMAIL" );	
			
			connection = dataSource.getConnection();
		
			quartzDao = new QuartzDao();			
			quartzDao.setConnection( connection );
							
			List<SystemUserModel> userList = quartzDao.retrieveReceiptUserIds();
			
			List<String> certs = null;
			for ( SystemUserModel user : userList )
			{
				 certs = quartzDao.retrieveRecentCertsByUserID( user.getUserId() );
				 
				 processUser( sendEmails, user, certs );
			}				
	
			
			/*
			List<SystemUserModel> userList = quartzDao.noSubmissionsICSF();
			processList(sendEmails, userList);
						
			logger.debug( "Not Submitting IACS...." );
			userList = quartzDao.noSubmissionsIAC();
			processList(sendEmails, userList);
			*/	

		}
		catch ( SQLException sqlEx )
		{
			throw new JobExecutionException( "Had Problem with connection: " + sqlEx.getMessage() );
		}
		finally 
		{
			ConnectionUtil.closeResources(connection, null, null );			
		}
		
	}
	
	
	private void processUser(String sendEmails, SystemUserModel userModel, List<String> certList )
	{
		logger.debug( "Would be sending to: " + userModel.getUserId() );
		
		for ( String cert : certList )
		{
			logger.debug( "----- Cert: " + cert );
		}
		
		// objects for logging in database
		//
		AsyncProcessingLogModel asyncLogModel   = new AsyncProcessingLogModel();
		AsyncProcessManager asyncRequestManager = new AsyncProcessManager();
		
		logger.info( "Sending Receipt to Email: " + userModel.getEmail()  );
		
		if ( sendEmails.equalsIgnoreCase( "true") )
		{
			try
			{
				// log sent emails
				//
				asyncLogModel.init( "QUARTZ", "PUBLIC", "EMAIL", "ADMIN", 
									"Attempting to send email to " + userModel.getEmail(), "0.0.0.0" );
				
				asyncLogModel = asyncRequestManager.createAsyncProcessLog(asyncLogModel);								
								
				EmailUtil.sendReceiptCCSFEmail( userModel.getContactFirstName(), userModel.getContactLastName(),						  
						  certList,
						  // SysDate is in dateFormat, due date is in lastUpdateUserid
						   "CRT Submissions Receipt", userModel.getEmail() );					
				
				// log success
				asyncRequestManager.logResult(asyncLogModel, true, "Email: " + userModel.getEmail() + " receipt for submissions " + userModel.getOrgName(), 
						                      "doPasswordReset");
			}				
			catch ( Exception e )
			{
				logger.error( "Error With asyncLog Model: " + e );
			}
					                   
		}	
		

		
	}
}
