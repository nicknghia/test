/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolio/addressbook/util/AddressSearchResult.java,v 1.6.6.1 2010/08/22 23:08:33 mechevarria Exp $
 * 
 *  Modification History:
 *  $Log: AddressSearchResult.java,v $
 *  Revision 1.6.6.1  2010/08/22 23:08:33  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.6  2005/08/30 02:16:17  amrinder
 *  Minor Javadoc changes - Javadoc still needs work
 *
 *  Revision 1.5  2004/09/15 13:01:57  ranand
 *  2.6 Baseline
 */

package crt.com.freightdesk.fdfolio.addressbook.util;

import java.util.ArrayList;
import java.util.List;

import com.freightdesk.fdfolio.orghierarchy.model.OrghierarchyModel;

/**
 * Encapsulates result of a search.
 * orgList holds the list of addresses found
 *
 * @author Rajender Anand
 */
public class OrgSearchResult
{
    private List<OrghierarchyModel> orgList;
    private long count;
    
    /** Creates an instance of orgList. */
    public OrgSearchResult()
    {
        orgList = new ArrayList<OrghierarchyModel>();
    }

    /** 
     * Creates an instance of orgList.
     * @param orgList List of organizations
     * @param count 
     */
    public OrgSearchResult(List<OrghierarchyModel> orgList, long count) {
        this.orgList = orgList;
        this.count = count;
    }

    public void setOrgList(List<OrghierarchyModel> orgList){
        this.orgList = orgList;
    
    }
    public void setCount(long count){
        this.count = count;
    
    }

    public List<OrghierarchyModel> getOrgList(){
        return orgList;
    }

    public long getCount(){
        return count;
    }
}
