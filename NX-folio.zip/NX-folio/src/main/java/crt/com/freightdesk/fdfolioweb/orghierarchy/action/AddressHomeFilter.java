package crt.com.freightdesk.fdfolioweb.orghierarchy.action;

public class AddressHomeFilter {
	
	private String search;
	private String reftype;
	private String refvalue;
	private String type;
	
	public AddressHomeFilter() {
		
	}
	
	public String getSearch() {
		return search;
	}
	public void setSearch(String search) {
		this.search = search;
	}
	public String getReftype() {
		return reftype;
	}
	public void setReftype(String reftype) {
		this.reftype = reftype;
	}
	public String getRefvalue() {
		return refvalue;
	}
	public void setRefvalue(String refvalue) {
		this.refvalue = refvalue;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	
	public String toString() {
		return "AddressHomeFilter [search=" + search + ", reftype=" + reftype + ", refvalue=" + refvalue + ", type=" + type + "]";
	}

}
