package crt.com.freightdesk.fdfolioweb.setup.form;

import org.apache.commons.lang.StringEscapeUtils;

import com.freightdesk.fdfolio.common.BasicButtonsForm;

public class SystemMessageForm extends BasicButtonsForm {
	
	private String messageText;
	private String faqTxt;
	private String lastUpdateUserId;
	private String lastUpdateTimestamp;
	
	public String getFaqTxt() {
		if (faqTxt == null)
		{
			this.faqTxt = "";
		}
		
		return faqTxt;
	}
	public void setFaqTxt(String faqTxt) {
		this.faqTxt = faqTxt;
	}
	public String getMessageText() {
		return messageText;
	}
	public void setMessageText(String messageText) {
		this.messageText = messageText; 
	}
	public String getLastUpdateUserId() {
		return lastUpdateUserId;
	}
	public void setLastUpdateUserId(String lastUpdateUserId) {
		this.lastUpdateUserId = lastUpdateUserId;
	}
	public String getLastUpdateTimestamp() {
		if (lastUpdateTimestamp == null)
		{
			this.lastUpdateTimestamp = "";
		}
		else
		{
			this.lastUpdateTimestamp = StringEscapeUtils.escapeHtml(lastUpdateTimestamp);
		}
		
		return lastUpdateTimestamp;
	}
	public void setLastUpdateTimestamp(String lastUpdateTimestamp) {
		this.lastUpdateTimestamp = lastUpdateTimestamp;
	}
}
