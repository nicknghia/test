package crt.com.freightdesk.fdfolio.dao;


import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.BaseDao;
import com.freightdesk.fdcommons.ConnectionUtil;
import crt.com.freightdesk.fdfolio.errorcatalog.model.ErrorCatalogDetailsModel;




public class ErrorCatalogDetailsDAO extends BaseDao
{
	protected final Logger logger = Logger.getLogger(getClass());




	public void create(ErrorCatalogDetailsModel ecdm) throws SQLException
	{
		Connection connection = null;
		PreparedStatement preparedStatement = null;

		try
    	{
    		connection = getConnection();

    		String query = "INSERT INTO ERRORCATALOGDETAIL (errorCatalogDetailId, errorCatalogId, errorCode, referenceIdentifier, referenceCode, referenceValue, errorStatus, errorMessage, createUserId, createTimestamp, domainName) VALUES(ERRORCATALOGDETAILID.NEXTVAL,?,?,?,?,?,?,?,?,sysdate,?)";
    		preparedStatement = connection.prepareStatement(query);

    		//preparedStatement.setInt(1, ecdm.getErrorCatalogDetailsId());
    		preparedStatement.setInt(1, ecdm.getErrorCatalogId());
    		preparedStatement.setString(2, "" + ecdm.getErrorCode());
    		preparedStatement.setString(3, ecdm.getReferenceIdentifier());
    		preparedStatement.setString(4, ecdm.getReferenceCode());
    		preparedStatement.setString(5, ecdm.getReferenceValue());
    		preparedStatement.setString(6, ecdm.getErrorStatus());
    		preparedStatement.setString(7, ecdm.getErrorMessage());
    		preparedStatement.setString(8, ecdm.getCreateUserId());
    		preparedStatement.setString(9, ecdm.getDomainName());

    		preparedStatement.executeUpdate();
    	}
    	catch (SQLException e)
    	{
    		logger.error(e.getMessage());
    		throw e;
    	}
    	finally
    	{
    		ConnectionUtil.closeResources(connection, null, null);
    	}
	}

}