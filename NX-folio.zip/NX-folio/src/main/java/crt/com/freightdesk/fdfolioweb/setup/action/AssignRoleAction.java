/** 
 * Copyright (c) NTELX 
 *  All rights reserved. 
 * 
 * This software is the confidential and proprietary information of NTELX 
 * ("Confidential Information").  You shall not disclose such Confidential Information 
 * and shall use it only in accordance with the terms of the license agreement you entered 
 * into with NTELX. 
 * 
 * 
 *  $Header: /usr2/cvs/fdt/core/src/FDfolio/src/com/freightdesk/fdfolioweb/setup/action/AssignRoleAction.java,v 1.7.2.1 2010/08/22 23:08:38 mechevarria Exp $ 
 * 
 *  Modification History:
 *  $Log: AssignRoleAction.java,v $
 *  Revision 1.7.2.1  2010/08/22 23:08:38  mechevarria
 *  update with company name in copyright
 *
 *  Revision 1.7  2007/01/12 11:53:49  atripathi
 *  user feedback messages added
 *
 *  Revision 1.6  2006/04/25 13:45:24  nsehra
 *  check added for null
 *
 *  Revision 1.5  2006/04/12 23:32:08  aarora
 *  Organized imports
 *
 *  Revision 1.4  2006/03/28 21:22:59  aarora
 *  Repackaging of fdcommons
 *
 *  Revision 1.3  2006/03/28 13:27:34  uvasundhara
 *  setActionMethod is called
 *
 *  Revision 1.2  2005/09/14 00:49:28  amrinder
 *  Enhanced to give feedback to user
 *  Improved some styling and HTML
 *
 *  Revision 1.1  2005/09/13 13:21:41  nsehra
 *  first version
 */
package crt.com.freightdesk.fdfolioweb.setup.action;

import javax.servlet.http.HttpServletRequest;
import crt.com.freightdesk.fdfolio.common.UserSetupReferenceData;
import crt.com.freightdesk.fdfolio.setup.UserSetupManager;
import javax.servlet.http.HttpSession;
import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.log4j.Logger;
import com.opensymphony.xwork2.ActionSupport;
import org.apache.struts2.ServletActionContext;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionKey;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.OptionBean;
import org.apache.commons.lang.StringEscapeUtils;
import com.freightdesk.fdcommons.LcpConstants;
import java.io.Serializable;
import java.util.Hashtable;
import java.util.Iterator;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Struts action to handle requests to and from AssignRole JSP.
 *
 * @author Nitin Sehra
 */
public class AssignRoleAction extends ActionSupport implements ServletRequestAware {
    private String loginTimeRoleMsg;
	private String basicBtnClicked;
	protected Logger logger = Logger.getLogger(getClass());
	private String process;
	private String lastUpdateUserId;
	private String lastUpdateTimestamp;
        
	private List roleList;
    private List<String> roleStrList;
	private String systemRoleCode;
	private List systemFunctionList;
    private List<FuncBean> pmCheckboxList;
	private String hdnProcess;
	private String roleName;
	private Hashtable systemFunctionByRole;
    private boolean unchkall;
    private boolean chkall;	
	private static Map<String, String> systemRoleLinkedMap = new LinkedHashMap<String, String>();
    String[] chk;
	
	HttpServletRequest request = ServletActionContext.getRequest();
	
	/** An instance of UserSetupManager */
	protected UserSetupManager userSetupManager = new UserSetupManager();
	
        HttpSession session = request.getSession();
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
      	  
	
    public String respondBtnSave() throws Exception {
        return null;
    }
    
    public String respondBtnSaveAndNew() throws Exception {	
        return null;
    }
    
    public String respondBtnSaveAndReturn() throws Exception {
        String[] systemRoleFunctions = request.getParameterValues("chk");
        String roleCode = getRoleName();      
               
        
        systemRoleFunctions = getChk();
        
        userSetupManager.deleteSystemRoleFunction(roleCode);
        if(systemRoleFunctions != null && systemRoleFunctions.length >= 1)
            userSetupManager.createSystemRoleFunction(systemRoleFunctions, roleCode, credentials.getUserId());
        
        String[] messageKeyObject=new String[5];
        String messageKey="assignrole.success";
        messageKeyObject[0]=getText("assignrole.success");
        messageKeyObject[1]=roleCode;
        
        messageKeyObject[0] = messageKeyObject[0].replace("{0}", messageKeyObject[1]);
        addActionMessage(messageKeyObject[0]);
        
        return displayPage();
    }

    public String respondBtnCancel() throws Exception {
    	logger.debug("canceling");
        
	addActionMessage(getText("setup.operation.cancel"));
        return displayPage();
    }
	
    public String execute() throws Exception {
        request = ServletActionContext.getRequest();
        session = request.getSession();
        store = SessionStore.getInstance(session);
        credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
                
	logger.debug("entering assignRole action.");
        
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);			           
        
        if ("CANCEL".equalsIgnoreCase(basicBtnClicked)) {           
            return respondBtnCancel();
        }  else if ("SAVE_RETURN".equalsIgnoreCase(basicBtnClicked)) {          
            return respondBtnSaveAndReturn();
        }
        
        return displayPage();
    }

    public String displayPage() throws Exception {
        logger.info("displayPage(): begin");
		
        UserSetupReferenceData userSetupReferenceData = UserSetupReferenceData.getInstance(credentials.getDomainName());
        if ("assignRole".equalsIgnoreCase(getHdnProcess())) {
            logger.debug("displayPage RoleName: "+ getRoleName());
            
            setSystemFunctionList(userSetupReferenceData.getSystemFunctionList());
            List aList = new ArrayList();
            aList.add(getRoleName());
            setSystemFunctionByRole(userSetupManager.getFDRolePermissionList(aList, credentials.getDomainName()));
            setPmCheckboxList(convertToPmCheckboxList(systemFunctionList));
            
            return "assignRole";
        } else {	
            setRoleList(userSetupReferenceData.getRoleList());
            setRoleStrList (convertRoleListToStringList (roleList));
            
            return "displayRole";
        }
    }
	
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }
	
	public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
	
	public String getBasicBtnClicked() {
        return basicBtnClicked;
    }

    public void setBasicBtnClicked(String basicBtnClicked) {
        this.basicBtnClicked = basicBtnClicked;
    }
	
	public String getProcess() {
        return process;
    }

    public void setProcess(String process) {
        this.process = process;
    }
    
    public List getRoleList() {
        return roleList;
    }
	
    public List<FuncBean> getPmCheckboxList() {
        return pmCheckboxList;
    }
    
    public void setRoleStrList(List<String> list) {
        roleStrList = list;
    }
	
    public List<String> getRoleStrList() {
        return roleStrList;
    }

    public List getSystemFunctionList() {
        return systemFunctionList;
    }

    public void setRoleList(List list) {
        roleList = list;
    }
    
    public void setPmCheckboxList(List<FuncBean> list) {
        pmCheckboxList = list;
    }

    public void setSystemFunctionList(List list) {
        systemFunctionList = list;
    }

    public String getSystemRoleCode() {
        return systemRoleCode;
    }

    public void setSystemRoleCode(String string) {
        systemRoleCode = string;
    }

    public String getHdnProcess() {
        return hdnProcess;
    }

    public void setHdnProcess(String string) {
        hdnProcess = string;
    }

    public String getRoleName() {
        return roleName;
    }

    public void setRoleName(String string) {
        roleName = string;
    }

    public Hashtable getSystemFunctionByRole() {
        return systemFunctionByRole;
    }

    public void setSystemFunctionByRole(Hashtable hashtable) {
        systemFunctionByRole = hashtable;
    }
    
    public String[] getChk() {
        return chk;
    }

    public void setChk(String[] string) {
        chk = string;
    }
    
    public boolean getChkall() {
        return chkall;
    }

    public void setChkall(boolean val) {
        chkall = val;
    }
    
    public boolean getUnchkall() {
        return unchkall;
    }

    public void setUnchkall(boolean val) {
        unchkall = val;
    }
        
	private List<String> convertRoleListToStringList(List<OptionBean> roleListOptBean) {
    	
		List<String> theRoleStrList = new ArrayList<String>();
        Iterator<OptionBean> itrRole = roleListOptBean.iterator();
        OptionBean optBean = new OptionBean();		
			
        while (itrRole.hasNext()) {
            optBean = itrRole.next();
            optBean.setLabel(optBean.getLabel().toUpperCase());
            optBean.setValue(optBean.getValue().toUpperCase());
            
			if (optBean.getValue().equalsIgnoreCase("RDONL")) {
				   theRoleStrList.add("READ ONLY (RDONL)");
				   systemRoleLinkedMap.put("READ ONLY (RDONL)", optBean.getValue()); 
		    }
			else if (optBean.getValue().equalsIgnoreCase("TAR")) {
				   theRoleStrList.add("TARGETER (TAR)");
				   systemRoleLinkedMap.put("TARGETER (TAR)", optBean.getValue());
			}
			else if (optBean.getValue().equalsIgnoreCase("APAD")) {
				   theRoleStrList.add("APPLICATION ADMINISTRATOR (APAD)");
				   systemRoleLinkedMap.put("APPLICATION ADMINISTRATOR (APAD)", optBean.getValue());
			}
        }
        
        return theRoleStrList;
    }
    
    private List<FuncBean> convertToPmCheckboxList(List systemFunctionList){
        List aList = getSystemFunctionList();
        List<FuncBean> permCheckboxList = new ArrayList<FuncBean>();
        
        if (aList != null){
            Iterator iterator = aList.iterator();
            while (iterator.hasNext()){
                FuncBean newPmFuncBean = new FuncBean();
                OptionBean optBean = (OptionBean) iterator.next();
                newPmFuncBean.setLabel(optBean.getLabel());
                newPmFuncBean.setValue(optBean.getValue());
                
                if (systemFunctionByRole.containsValue(optBean.getValue())){
                    newPmFuncBean.setCheckboxValue("TRUE");
                } else {
                    newPmFuncBean.setCheckboxValue("FALSE");
                }
                permCheckboxList.add(newPmFuncBean);               
            }
        }
        
        return permCheckboxList;
    }
    
    private void dumpSystemFunctionByRole(Hashtable sysFunctionByRole){       
        return;
    }
    
    public class FuncBean implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 7394391621934562455L;
	private String label;
	private String value;
        private String checkboxValue;

	// constructors
	public FuncBean() {
	}

	/**
	 * label is what is displayed to the user value is what the property is set
	 * to
	 */
	public FuncBean(String label, String value, String checkboxValue) {
		this.label = label;
		this.value = value;
                this.value = checkboxValue;
	}

	// since collection will most likely be shown in web page, escape html and trim white space
	public String getLabel() {
		if (label == null)
			return "";
		else
			return StringEscapeUtils.escapeHtml(label.trim());
	}

	public void setLabel(String newLabel) {
		label = newLabel;
	}

	public String getValue() {
		if (value == null)
			return "";
		else
			return StringEscapeUtils.escapeHtml(value.trim());
	}

	public void setValue(String newValue) {
		value = newValue;
	}
        
        public String getCheckboxValue() {
		if (checkboxValue == null)
			return "";
		else
			return StringEscapeUtils.escapeHtml(checkboxValue.trim());
	}

	public void setCheckboxValue(String newCheckboxValue) {
		checkboxValue = newCheckboxValue;
	}
}

            
}
