package crt.com.freightdesk.fdfolioweb.dashboard.action;


import com.freightdesk.fdcommons.ApplicationTabs;
import com.freightdesk.fdcommons.Credentials;
import com.freightdesk.fdcommons.SessionStore;
import com.freightdesk.fdcommons.SessionKey;
import com.opensymphony.xwork2.ActionSupport;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;
import org.apache.struts2.interceptor.ServletRequestAware;
import org.apache.struts2.ServletActionContext;
import crt.com.freightdesk.fdfolio.common.IncludesUtil;
import crt.com.freightdesk.fdfolio.setup.SystemMessageManager;

public class FasHomeAction extends ActionSupport implements ServletRequestAware {
    protected Logger logger = Logger.getLogger(getClass());
    HttpServletRequest request = ServletActionContext.getRequest();
    private String messageText;
    private String faqTxt;
    private String loginTimeRoleMsg;
    

    public String execute() throws Exception {
        logger.debug("Entering FAS home action.");
        request = ServletActionContext.getRequest();
        HttpSession session = request.getSession(false);
        SessionStore store = SessionStore.getInstance(session);
        Credentials credentials = (Credentials) store.get(SessionKey.CREDENTIALS);
        
	// set the tabs for the app
        SessionStore sessionStore = SessionStore.getInstance(session);
        sessionStore.put (SessionKey.CURRENT_TAB, ApplicationTabs.USERHOME);
        
        loginTimeRoleMsg = IncludesUtil.getWelcomeMsg(credentials)+ "<br>" + IncludesUtil.getExpireMsg(credentials);
        
        SystemMessageManager messageManager = SystemMessageManager.getInstance();
        messageManager = SystemMessageManager.getInstance();
        messageText = messageManager.getMessageModel().getMessageText();
        faqTxt = messageManager.getMessageModel().getFaqTxt();
        
	return "display";
    }
        
    public void setServletRequest(HttpServletRequest request) {
        this.request = request;
    }

    public HttpServletRequest getServletRequest() {
        return this.request;
    }
    
    public String getFaqTxt() {
        if (faqTxt == null)
	{
            this.faqTxt = "";
	}
		
	return faqTxt;
    }
    
    public void setFaqTxt(String faqTxt) {
	this.faqTxt = faqTxt;
    }
        
    public String getMessageText() {
	return messageText;
    }
        
    public void setMessageText(String messageText) {
	this.messageText = messageText; 
    }
    
    public String getLoginTimeRoleMsg() {
        return loginTimeRoleMsg;
    }

    public void setLoginTimeRoleMsg(String loginTimeRoleMsg) {
        this.loginTimeRoleMsg = loginTimeRoleMsg;
    }

}
