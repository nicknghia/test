
package crt.com.freightdesk.fdfolio.dao;


import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

import org.apache.log4j.Logger;

import com.freightdesk.fdcommons.ApplicationProperties;
import com.freightdesk.fdcommons.ConnectionUtil;
import com.freightdesk.fdcommons.OptionBean;


/** 
 * This Data access object defines methods for performing update and
 * read operations on a table.
 *
 * @author Rajender Anand
 */
public class EditDataDAO 
{
    public static String CREATETIMESTAMP     = "CREATETIMESTAMP";
    public static String LASTUPDATETIMESTAMP = "LASTUPDATETIMESTAMP";  
    public static String CREATEUSERID        = "CREATEUSERID";
    public static String LASTUPDATEUSERID    = "LASTUPDATEUSERID";
    public static String STATUS    = "STATUS";
    public static String ACTIVE    = "ACTIVE";
    
    private static List referenceTableList  = null;
    
    private static Logger logger = Logger.getLogger("com.freightdesk.fdfolioweb.etl.EditDataDAO");
    
    public static List getReferenceTableList()
    {
        if (referenceTableList != null)
            return referenceTableList;
        else
        {
            Connection connection = null;
            PreparedStatement pStmt = null;
            ResultSet rs = null;
            referenceTableList = new ArrayList();
            try
            {
                connection = getConnection();
                pStmt = connection.prepareStatement("SELECT table_name FROM  USER_TABLES WHERE UPPER(table_name) LIKE '%TYPE%' order by table_name");
                rs = pStmt.executeQuery();
                
                while (rs.next())
                {
                    referenceTableList.add(new OptionBean(rs.getString(1),rs.getString(1)));
                }
            }
            catch(SQLException e)
            {
                logger.error("Exception in getReferenceTableList" + e.getMessage());
            }
            finally
            {
                ConnectionUtil.closeResources(connection, pStmt, rs);
            }
            return referenceTableList;
        }
            
    }
    public Map retrieve(String tableName, String primaryKey, String primaryKeyColumnName)
        throws SQLException
    {
        String selectRegion = "SELECT  * FROM "+tableName+" WHERE ";
        
        StringTokenizer columnTokenizer = new StringTokenizer(primaryKeyColumnName, ",");
        StringTokenizer keyTokenizer = new StringTokenizer(primaryKey, ",");
        
        int count = 0;
        while(columnTokenizer.hasMoreTokens())
        {
            selectRegion += " "+columnTokenizer.nextToken()+"= ? AND";
            count++;
        }
        selectRegion = selectRegion.substring(0, selectRegion.length()-3);
        
        
        logger.debug("Query :"+selectRegion);
        Connection connection = null;
        PreparedStatement pStmt = null;
        ResultSet rs = null;
        Map data = new HashMap(); 
        try
        {
            //String PrimaryKeyColumn = getPrimaryKeyColumnName(tableName);
            connection = getConnection();
            pStmt = connection.prepareStatement(selectRegion);
            logger.debug("primaryKey :"+primaryKey);

            int keyCount = 1;
            while(keyTokenizer.hasMoreTokens())
            {
                String keyValue = keyTokenizer.nextToken().trim();
                logger.debug("keyCount:"+keyCount+", keyValue:"+keyValue);
                pStmt.setString(keyCount++, keyValue);
            }
            //setting the empty value if primary key values are less then teh number of parameters required.
            if( (keyCount - 1) < count)
            {
                logger.debug("Parameter set in query is less than required, setting empty value for missing values");
                for(int i = 1; i <= count - keyCount; i++)
                {
                    pStmt.setString(keyCount++, "");
                }
                
            }
            
            rs = pStmt.executeQuery();
            ResultSetMetaData rsmd = rs.getMetaData();
            int columnCount = rsmd.getColumnCount(); 
            if (rs.next())
            {
                logger.debug("columnCount:"+columnCount);
              for(int i = 1; i <= columnCount; i++)
              {
                String columnName = rsmd.getColumnName(i);
                String columnValue = rs.getString(i);
                if (columnName!=null)
                    data.put(columnName, columnValue);
              }
            }
            rs.close();
            pStmt.close();
            connection.close();
        }
        catch(SQLException e)
        {
            logger.error("retrieve : Exception while loading the Region  " + e.getMessage());
            throw e;
        }
        finally
        {            
			ConnectionUtil.closeResources(connection, pStmt, rs);
        }
        logger.debug("data:"+data);
        return data;
    }

    /**
     * 
     * @param tableName
     * @return Map of metadata
     * @throws SQLException
     */ 
    public Map retrieve(String tableName)
        throws SQLException
    {
    String selectRegion = "SELECT  * FROM "+tableName;
    
    Connection connection = null;
    PreparedStatement pStmt = null;
    ResultSet rs = null;
    Map data = new HashMap(); 
    try
    {
        //String PrimaryKeyColumn = getPrimaryKeyColumnName(tableName);
        connection = getConnection();
        pStmt = connection.prepareStatement(selectRegion);
        rs = pStmt.executeQuery();
        ResultSetMetaData rsmd = rs.getMetaData();
        int columnCount = rsmd.getColumnCount(); 
        for(int column = 1; column <= columnCount; column++)
        {
          {
            String columnName = rsmd.getColumnName(column);
            String columnValue = "";
            if (STATUS.equalsIgnoreCase(columnName))
                columnValue=ACTIVE;
            if (columnName!=null)
                data.put(columnName, columnValue);
          }
        }
        rs.close();
        pStmt.close();
        connection.close();
    }
    catch(SQLException e)
    {
        logger.error("retrieve : Exception while loading the Region  " + e.getMessage());
        throw e;
    }
    finally
    {        
		ConnectionUtil.closeResources(connection, pStmt, rs);
    }
    return data;
    }
    
    public void update(String tableName, Map data, String primaryKey, String primaryKeyColumn)
        throws SQLException
    {
        Connection connection = null;
        PreparedStatement pStmt = null;
        String updateQuery = createUpdateQuery(tableName, data, primaryKey, primaryKeyColumn);

        StringTokenizer columnTokenizer = new StringTokenizer(primaryKeyColumn, ",");
        StringTokenizer keyTokenizer = new StringTokenizer(primaryKey, ",");
        
        int count = 0;
        while(columnTokenizer.hasMoreTokens())
        {
            updateQuery += " "+columnTokenizer.nextToken()+"= ? AND";
            count++;
        }
        updateQuery = updateQuery.substring(0, updateQuery.length()-3);
        
        
        logger.debug("updateQuery:"+updateQuery);

        try
        {
            connection = getConnection();
            pStmt = connection.prepareStatement(updateQuery);

            int keyCount = 1;
            while (keyTokenizer.hasMoreTokens()) {
                String keyValue = keyTokenizer.nextToken().trim();
                logger.debug("keyCount:" + keyCount + ", keyValue:" + keyValue);
                pStmt.setString(keyCount++, keyValue);
            }
            // setting the empty value if primary key values are less then teh
            // number of parameters required.
            if ((keyCount - 1) < count) {
                logger
                        .debug("Parameter set in query is less than required, setting empty value for missing values");
                for (int i = 1; i <= count - keyCount; i++) {
                    pStmt.setString(keyCount++, "");
                }

            }
            logger.debug("  updateQuery ::  "+updateQuery);
            pStmt.executeUpdate();
            logger.debug("update: after executing the update ");
        }
        catch(SQLException e)
        {
            logger.error("update: Exception while updating the region  " + e.getMessage());
            throw e;
        }
        finally
        {                     
			ConnectionUtil.closeResources(connection, pStmt, null);
        }
    }

    public void delete(String tableName, String primaryKey, String primaryKeyColumn)
        throws SQLException
    {
    Connection connection = null;
        PreparedStatement pStmt = null;
        String deleteQuery = " delete from " + tableName + "  WHERE ";

        StringTokenizer columnTokenizer = new StringTokenizer(
                primaryKeyColumn, ",");
        StringTokenizer keyTokenizer = new StringTokenizer(primaryKey, ",");

        int count = 0;
        while (columnTokenizer.hasMoreTokens()) {
            deleteQuery += " " + columnTokenizer.nextToken() + "= ? AND";
            count++;
        }
        deleteQuery = deleteQuery.substring(0, deleteQuery.length() - 3);

        logger.debug("deleteQuery:" + deleteQuery);

        try {
            connection = getConnection();
            pStmt = connection.prepareStatement(deleteQuery);

            int keyCount = 1;
            while (keyTokenizer.hasMoreTokens()) {
                String keyValue = keyTokenizer.nextToken().trim();
                logger.debug("keyCount:" + keyCount + ", keyValue:" + keyValue);
                pStmt.setString(keyCount++, keyValue);
            }
            // setting the empty value if primary key values are less then teh
            // number of parameters required.
            if ((keyCount - 1) < count) {
                logger
                        .debug("Parameter set in query is less than required, setting empty value for missing values");
                for (int i = 1; i <= count - keyCount; i++) {
                    pStmt.setString(keyCount++, "");
                }

            }

            pStmt.executeUpdate();
            logger.debug("delete: after executing the delete");
        } catch (SQLException e) {
            logger.error("delete: Exception while deleting " + e.getMessage());
            throw e;
        } finally {

            if (pStmt != null) {
                pStmt.close();
            }
            if (connection != null) {
                connection.close();
            }
        }
    }
    
    /**
     * Inserts data into a table 
     * @param tableName
     * @param data
     * @throws SQLException
     */
    public void insert(String tableName, Map data)
        throws SQLException
    {
    Connection connection = null;
    PreparedStatement pStmt = null;
    String insertQuery = createInsertQuery(tableName, data);
    try
    {
        connection = getConnection();
        pStmt = connection.prepareStatement(insertQuery);
        logger.debug("  insertQuery ::  "+insertQuery);
        pStmt.executeUpdate();
        logger.debug("insert: after executing the insert");
    }
    catch(SQLException e)
    {
        logger.error("insert: Exception while inserting record" + e.getMessage());
        throw e;
    }
    finally
    {
        if(pStmt != null){
            pStmt.close();
        }
        if(connection != null){
            connection.close();
        }
    }
    }
    

    /** 
     * Gets a list of all Primary Keys.
     * 
     * @param  tableName
     */
    public List retrieveAllPrimaryKeys(String tableName) 
        throws SQLException
    {
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        List keys = new ArrayList();

        try 
        {
            String PrimaryKeyColumn = getPrimaryKeyColumnName(tableName);
            logger.debug("PrimaryKeyColumn:"+PrimaryKeyColumn);
            String query = "SELECT "+PrimaryKeyColumn+" FROM "+tableName;
            logger.debug("Query: " + query);
            
            conn = getConnection();
            ps = conn.prepareStatement(query);
            rs = ps.executeQuery();
            ResultSetMetaData resultSetMetaData = rs.getMetaData();
            int columnCount = resultSetMetaData.getColumnCount();
            while (rs.next())
            {
                String primaryKey = "";
                for(int i = 1 ; i <= columnCount; i++)
                {
                    primaryKey += rs.getString(i)+" ,";
                }
                primaryKey = primaryKey.substring(0, primaryKey.length()-1);
                keys.add(primaryKey);
            }
            rs.close();
            ps.close();
            conn.close();
        }
        catch (SQLException sqlEx){
            logger.error("Exception occured in retrieveAllPrimaryKeys "+sqlEx.getMessage());
            throw sqlEx;
        }
        finally 
        {            
			ConnectionUtil.closeResources(conn, ps, rs);
        }
        return keys;
    }
    
    /**  This methods returns the primary key of the table whose name is passed 
     *   as an argument assuming that the table has sequence as primary key.
     *   
     */
    public String getPrimaryKeyColumnName(String tableName) throws SQLException
    {
        logger.info("getPrimaryKeyColumnName(): begin");
        Connection conn = null;
        PreparedStatement ps = null;
        ResultSet rs = null;
        String primaryKeyColumnName = "";

        try {
            conn = getConnection();
            DatabaseMetaData dbmd = conn.getMetaData();
            rs = dbmd.getPrimaryKeys(null, null, tableName);
            List columnNamesList = new ArrayList();
            while(rs.next()){
                String columnName = rs.getString("COLUMN_NAME");
                if(!columnNamesList.contains(columnName))
                {
                    columnNamesList.add(columnName);
                    primaryKeyColumnName += columnName+" , ";
                }
            }
            
        }
        catch (SQLException sqlEx){
            logger.error("Exception occured in getPrimaryKeyColumnName"+sqlEx.getMessage());
            throw sqlEx;
        }
        finally {
            ConnectionUtil.closeResources(conn, ps, rs);
        }
        primaryKeyColumnName = primaryKeyColumnName.trim();
        primaryKeyColumnName = primaryKeyColumnName.substring(0,primaryKeyColumnName.length()-1);
        
        
        return primaryKeyColumnName;
    }
   
    /** Gets a connection to the DB */
    public static Connection getConnection() throws SQLException 
    {
        /*Connection connection = null;

		try	{
            Class.forName("oracle.jdbc.driver.OracleDriver");
            connection = DriverManager.getConnection("jdbc:oracle:thin:@oracleserver:1521:INLCPDEV","fdadmin","FDTadmin");
		}
		catch (Exception ex) {
			throw new SQLException("  Exception in getConnection ");
		}

        return connection;*/
        
        return ConnectionUtil.getConnection();
    }
    
    /**
     * 
     * create an update query for the table.  
     * 
     * @param data  conatins the column name of a table and its value. 
     * @param primaryKey
     * @param primaryKeyColumn
     * @return
     */
    public String createUpdateQuery(String tableName, Map data, String primaryKey, String primaryKeyColumn)
    {
        String query = "UPDATE "+ tableName+" SET ";
        
        Iterator iterator = data.keySet().iterator();
        int count = 0;
        while (iterator.hasNext())
        {
        	String columnName =(String)iterator.next();
            // CREATETIMESTAMP, CREATEUSERID columns need not be updated
            if (!CREATETIMESTAMP.equalsIgnoreCase(columnName) && !CREATEUSERID.equalsIgnoreCase(columnName) )
            {        
                query += columnName+" = ";
                // Override LASTUPDATETIMESTAMP column
                if (LASTUPDATETIMESTAMP.equalsIgnoreCase(columnName))
                    query += " sysdate " ;
                else
                    query += data.get(columnName);
                
                if(data.size()-1 > count)
                	query += " , ";
            }
            
            count++;
        }
        query += "  WHERE ";
        
        return query;
    }
    
    /**
     * Creates an insert query for the table.
     * @param tableName
     * @param data
     * @return
     */
    public String createInsertQuery(String tableName, Map data)
    {
        StringBuffer query = new StringBuffer("insert into "+ tableName+" (");
        
        Iterator iterator = data.keySet().iterator();
        int count = 0;
        StringBuffer values = new StringBuffer(" VALUES (");
        while (iterator.hasNext())
        {
            String columnName =(String)iterator.next();        
            query.append(columnName);
            // Override CREATETIMESTAMP, LASTUPDATETIMESTAMP column
            if (CREATETIMESTAMP.equalsIgnoreCase(columnName) || LASTUPDATETIMESTAMP.equalsIgnoreCase(columnName))
                values.append(" sysdate ");
            else
                values.append(data.get(columnName));
            
            if(data.size()-1 > count)
            {
                query.append(" , ");
                values.append(" , ");
            }
            
            count++;
        }
        
        return query.append(")").append(values.toString()).append(")").toString();
    }
    
}
